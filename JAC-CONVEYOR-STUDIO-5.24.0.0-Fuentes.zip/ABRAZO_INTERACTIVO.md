# Abrazo interactivo y altura de rodillos · v5.8

En Rodillos de retorno, Explorar abrazo y retorno abre una ventana que permanece disponible mientras cambias el diseño. El deslizador y la entrada numérica permiten modificar el abrazo entre 180° y 210°, en pasos de 0.1°. La vista local permite seleccionar Motriz o Conducido y muestra la tangencia entre envolvente de banda y rodillo. Los cambios actualizan el proyecto, el reparto y el visor cuando el diseño resulta válido.

La altura sigue el sprocket elegido en cada extremo y el espesor de la banda. La cota A de la tabla del sprocket mide del eje al plano de apoyo inferior de la banda. Para la envolvente exterior adoptada por el configurador, el radio es R = A + espesor de banda. El eje del sprocket está en Y_eje = Y_apoyo − A. Con beta = abrazo − 180°, distancia d desde la flecha y radio r del rodillo:

Y_rodillo = Y_eje + d·tan(beta) − (R + r)/cos(beta).

La tangente pasa por debajo de la envolvente del sprocket y por arriba del rodillo. La altura cambia al cambiar dientes, ángulo, diámetro de rodillo, espesor de banda o posición del primer rodillo. Cada extremo usa sus propias referencias. Se usan los datos de fabricante disponibles para E925 de 12, 16 y 20 dientes; no se deduce el diámetro primitivo del diámetro exterior del modelo importado.

La referencia inferior fija de 127 mm y la altura manual histórica dejan de gobernar la altura de retorno. Sus campos siguen siendo compatibles con proyectos antiguos, pero el cálculo actual usa la geometría y el abrazo. Esto corrige el error al seleccionar un sprocket de 20 dientes con la referencia histórica de 127 mm.

El panel muestra cantidad total de rodillos/ejes físicos, diámetro de cuerpo, eje y barreno, largo del cuerpo y del eje, rango de pasos normales, longitud resuelta de catenaria entre centros, L y altura bajo nylamid de ambos primeros rodillos. Si los sólidos están desactivados, indica cero rodillos físicos y la cantidad de posiciones de barreno. Los largos se calculan con el ancho de los soportes, separación lateral, saliente del eje y espesor de los perfiles. Si hay distintos largos, se muestra el rango.

Se mantiene la referencia guardada del manual: L ≤1000 mm, catenaria = L + 200 mm, primeros centros dentro de 200–500 mm / 200–300 mm y abrazo 180–210°. Los cambios pueden producir un reparto inviable por aberturas o fijaciones; en tal caso se muestra el error y se bloquea generar. El visor mantiene el último modelo válido con su aviso.

La envolvente es el modelo nominal del configurador. No se calcula deformación de banda, tensión ni flecha real de catenaria; la dimensión indicada es la separación entre centros de los rodillos de esa zona. La generación SolidWorks utiliza los mismos centros calculados. No se ejecutó una generación real de ensamble durante esta validación.

Pruebas: tangencia inversa a 180°, 186°, 195° y 210° para sprockets de 12/16/20 dientes; cambio de altura por sprocket y espesor; independencia de 127 mm; rechazo fuera del manual; dimensiones y cantidades; sincronización de controles; actualización del proyecto desde la ventana y del explorador abierto al cambiar sprocket; regresiones del reparto, conservación de aberturas, opciones anteriores y medición.
