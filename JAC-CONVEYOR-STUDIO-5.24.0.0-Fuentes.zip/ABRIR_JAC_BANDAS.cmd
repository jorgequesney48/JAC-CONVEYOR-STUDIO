@echo off
start "" "%~dp0outputs\PerfilBandas.exe"
