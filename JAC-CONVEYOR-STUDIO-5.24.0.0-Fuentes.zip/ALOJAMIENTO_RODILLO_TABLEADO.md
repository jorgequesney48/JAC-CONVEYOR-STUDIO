﻿# Alojamiento de rodillos con eje tableado — v5.12

Referencia aportada por el usuario: entrada superior R9 mm, asiento inferior R6.35 mm y caras planas a 5 mm del centro (10 mm entre caras). El usuario confirmó que los círculos se dibujaron tangentes exteriormente, por tanto la distancia entre centros es 15.35 mm. El centro inferior es el centro del eje y se usa como referencia de altura y abrazo.

La aplicación usa esta geometría por defecto. Rodillos → Alojamiento de inserción con eje tableado permite cambiar al barreno circular para otras medidas de eje. El nuevo alojamiento requiere eje Ø12.7 mm; conserva las dimensiones nominales exactas de la referencia, sin añadir holgura de mecanizado.

El visor, el croquis de perfil y el corte de SolidWorks comparten el contorno. SolidWorks crea dos arcos circulares y dos segmentos rectos, verificando el volumen retirado mediante el área analítica. El eje físico incluye dos extremos tableados a 10 mm entre caras, mientras que el cuerpo central sigue siendo redondo para el rodillo. La longitud tableada cubre el saliente exterior y el espesor del perfil, con hasta 1 mm hacia el interior según la separación lateral disponible. Se comprueba su volumen analítico.

El reparto automático busca espacio para la abertura completa y conserva ranuras y logo. Usa una cobertura conservadora de los dos círculos y el conector, por lo que puede rechazar posiciones marginales aunque el contorno exacto cupiera. Los modos de interrumpir ranuras y bajar rodillos siguen disponibles. El tipo de alojamiento se guarda en el proyecto.

Verificación: área del contorno, área del eje, radios y envolvente, reparto automático y separación de la abertura completa respecto a ranuras, persistencia y rechazo de diámetro incompatible. La integración COM compila; el corte y las extrusiones deben comprobarse durante una generación real en SolidWorks.
