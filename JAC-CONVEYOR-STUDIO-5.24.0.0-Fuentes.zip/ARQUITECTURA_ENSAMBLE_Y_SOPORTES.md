# Arquitectura del Ensamble del Transportador, Soportes C y Nylamid

Este documento recopila las especificaciones técnicas y estándares de taller acordados para la fase de ensamble automatizado (`.SLDASM`) en SOLIDWORKS.

---

## 1. Regla Maestra de Ancho y Luz entre Perfiles

Para permitir el libre movimiento de la banda modular plástica y alojar las guías de desgaste con contención lateral:

$$\text{Separación Interior entre Almas} = \text{Ancho Nominal de Banda} + 0.75''\ (19.05\text{ mm})$$

### Desglose por lateral:
* **$0.25''$ ($6.35\text{ mm}$)**: Pestaña vertical del Nylamid lateral (ceja del saque).
* **$0.125''$ ($1/8'' = 3.175\text{ mm}$)**: Holgura operativa libre entre la banda y la cara del Nylamid.
* **Total por lateral**: $0.375''$ ($3/8''$).
* **Total ambos lados**: $0.75''$ ($3/4'' = 19.05\text{ mm}$).

---

## 2. Especificación de las Pistas de Nylamid / UHMWPE

| Tipo | Sección Bruta | Modificación / Saque | Sujeción en Peine | Función |
|---|---|---|---|---|
| **Pistas Centrales** | $0.75''\text{ ancho} \times 1.5''\text{ alto}$<br>($19.05 \times 38.1\text{ mm}$) | Sin saque (sección rectangular pura) | El peine abraza **$1.0''$**.<br>Sobresale **$0.5''$**. | Cama de rodadura central para la banda modular. |
| **Pistas Laterales (2)** | $0.75''\text{ ancho} \times 1.5''\text{ alto}$<br>($19.05 \times 38.1\text{ mm}$) | **Rebaje de $0.5''$ de ancho × $0.25''$ de profundidad** en la esquina superior interior. Deja una ceja exterior de $0.25''$. | El peine abraza **$0.75''$** ($19.05\text{ mm}$). | Guía lateral que evita que la banda roce contra el perfil metálico. La derecha se genera en espejo de la izquierda. |

* **Plano de rodadura coplanar**: el corte central de $1.0''$ y el lateral de $0.75''$ mantienen la cara rebajada de la pletina lateral a la misma altura que la cara superior de las pletinas centrales. La ceja exterior sobresale $0.25''$.
* **Distribución transversal**:
  - 2 pistas laterales obligatorias (pegadas a cada perfil).
  - $K$ pistas centrales distribuidas uniformemente a lo largo del ancho nominal. El número es configurable o sugerido automáticamente según el ancho de la banda.

---

## 3. Soportes Transversales en Canal C ("Peines")

* **Material**: Lámina de acero inoxidable **Calibre 12** (espesor nominal $\approx 2.66\text{ mm}$, configurable en el módulo).
* **Forma**: Perfil doblado en canal C paramétrico (`SoporteBandas.cs`):
  - Lomo superior: $50.80\text{ mm}$ ($2.0''$).
  - Pestaña 1 (frontal con ranurado de peine): $38.10\text{ mm}$ ($1.5''$).
  - Pestaña 2 (trasera): $50.80\text{ mm}$ ($2.0''$).
  - Radio interior de doblez: $1.50\text{ mm}$.
  - Longitud total: Calculada automáticamente como $\text{Ancho de Banda} + 20.00\text{ mm}$ según estándar de taller (con opción a ajuste manual).
* **Cantidad**: **6 soportes en total** distribuidos longitudinalmente.
* **Ranurado superior (Peine para Nylamid)**:
  - Ranuras de ancho $0.75''$ ($19.05\text{ mm}$) para alojar las tiras de Nylamid.
  - Ranuras extremas (2) con profundidad de **$0.75''$ ($19.05\text{ mm}$)** para las pletinas laterales con rebaje.
  - Ranuras centrales ($K$) con profundidad de **$1.0''$ ($25.4\text{ mm}$)** para cama de rodadura.
  - Corte siempre pasante de lado a lado (`FeatureCut4` bidireccional) atravesando completamente ambas alas del canal C.
* **Módulo y Ventana Dedicada (`SoporteForm`)**:
  - Ventana interactiva independiente accesible desde la barra superior y desde el panel lateral de la aplicación principal.
  - Vistas previas 2D sincronizadas en tiempo real: sección transversal acotada y vista longitudinal del soporte con ranuras de peine.
  - Conexión y generación directa del `.SLDPRT` en SOLIDWORKS con metadatos personalizados para ensamble.

---

## 4. Banda Modular (Modelo E925)

* **Espesor nominal de banda**: **$12.0\text{ mm}$**.
* **Representación en el ensamble**:
  - Sólido extruido simplificado (cama volumétrica) de ancho nominal y espesor $12\text{ mm}$, ubicado tangencialmente sobre las pistas de Nylamid.

---

## 5. Placas Extremas de Fijación (Plaquitas Soldadas en Ambos Extremos — Fase 2) ✅ COMPLETADO

* **Propósito**: Plaquitas metálicas soldadas en los extremos del soporte C ($Z = 0$ y $Z = L$) para fijar la estructura rígidamente a los perfiles laterales.
* **Geometría y dimensiones**:
  - **Contorno interior ajustado**: Se sitúa en el interior del canal C, despejando la ranura de Nylamid ($Y_{\text{top}} = \text{Flange1} - \text{OuterSlotDepth} = 38.10 - 19.05 = 19.05\text{ mm}$), con chaflán inferior ajustado al fondo de ambas pestañas ($Y=0$ y $Y=-12.7\text{ mm}$).
  - **Barreno de fijación**: Orificio cuadrado de **$11.00 \times 11.00\text{ mm}$** para tornillo de coche (cuello cuadrado) de $3/8''$.
  - **Centro del barreno**: Centrado horizontalmente ($X_c = 25.40\text{ mm}$) y cota vertical configurable $Y_c = 12.00\text{ mm}$ (por defecto).
  - **Espesor**: Lámina inoxidable Calibre 12 ($2.66\text{ mm}$, configurable).
* **Modalidad Multibody y Pieza Individual**:
  1. **Multicuerpo en el Soporte C (`.SLDPRT`)**: Generadas en $Z = 0$ (`Placa_Union_Izq`) y $Z = L$ (`Placa_Union_Der`) con `Merge = false` para reconocimiento como piezas soldadas independientes en lista de corte (*Weldment Cut List*).
  2. **Exportación Individual**: Botón en la interfaz para generar el `.SLDPRT` suelto de la plaquita para corte láser o troquelado.
* **Vistas previas en la UI**:
  - Vista transversal muestra la plaquita en verde con el barreno cuadrado acotado.
  - Vista longitudinal muestra los dos topes de placa en ambos extremos ($Z = 0$ y $Z = L$).

---

## 6. Orificios en el Alma de los Perfiles Laterales para Soportes C ✅ COMPLETADO

Según el macro `ORIFICIOS SOPORTES.swp` grabado por el usuario:
* **Propósito**: Perforaciones en el alma (web) de los perfiles laterales (LH y RH) para atornillar sólidamente los **6 soportes C** distribuidos a lo largo del transportador mediante tornillos de coche de $3/8''$.
* **Forma y tamaño**: Barrenos cuadrados de **$11.00 \times 11.00\text{ mm}$**.
* **Altura vertical**: **$60.00\text{ mm}$** por debajo del borde superior del alma ($Y = -60.00\text{ mm}$).
* **Distribución longitudinal ($X$) para perfil estándar de $2400\text{ mm}$**:
  - **Orificio 1**: A **$50.00\text{ mm}$** del borde inicial ($55.50\text{ mm}$ al centro), ubicado antes de la primera ranura sin interferir con ella.
  - **Orificio 2**: A **$420.00\text{ mm}$** del primero ($X = 475.50\text{ mm}$ al centro), perfectamente centrado en el vano libre entre la **Ranura 1** y la **Ranura 2**.
  - **Orificio 3**: A **$420.00\text{ mm}$** del segundo ($X = 895.50\text{ mm}$ al centro), ubicado en el vano libre entre la **Ranura 2** y el **Logo central**.
  - **Orificios 4, 5 y 6**: Simétricos mediante simetría respecto al plano medio ($X = 1200.00\text{ mm}$), garantizando espacio despejado para el logo en el centro ($609\text{ mm}$ entre los orificios 3 y 4) y coincidencia exacta entre perfiles LH y RH.
* **Operación SOLIDWORKS**:
  - Operación de corte pasante dedicada: `Barrenos_Soportes_C`.
  - Visualización 2D reactiva en `FrontProfilePreview` con marcadores verdes esmeralda en el configurador.

---

## 7. Próximo Paso: Ensamble Maestro Automatizado (`.SLDASM`) — Fase 3

1. Crear el ensamble `.SLDASM` que inserte:
   - Perfil lateral izquierdo (LH).
   - Perfil lateral derecho (RH) enfrentado a la distancia calculada ($\text{Ancho} + 19.05\text{ mm}$).
   - Los **6 soportes C** posicionados y atornillados en sus 6 barrenos correspondientes.
   - Pistas de Nylamid (2 laterales con saque + $K$ centrales).
   - Basa o cama de banda modular E925 simplificada.
2. Relaciones de posición (*mates*) automáticas de coincidencia y distancia entre los barrenos cuadrados del perfil y las plaquitas soldadas del soporte.



