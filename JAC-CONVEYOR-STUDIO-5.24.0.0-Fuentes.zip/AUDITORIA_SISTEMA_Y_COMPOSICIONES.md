# Auditoría del sistema y composiciones por tramo — v4

La aplicación v5 integra el modelo 3D en la pantalla principal y permite editar sus etiquetas. El uso de la interfaz vigente está en [DISENO_INTERACTIVO_3D.md](DISENO_INTERACTIVO_3D.md); esta auditoría conserva los resultados geométricos de las composiciones y la generación CAD.

## Causa del ensamble mostrado

La aplicación abierta era `outputs/PerfilBandas_banda_completa.exe`, compilada el 2 de octubre a las 01:22, anterior al patrón automático de 300 mm. El ejecutable actualizado de la entrega anterior estaba en `outputs/PerfilBandas.exe`. La inspección del ensamble guardado en `piezas_ensamble/BANDA_COMPLETA` confirmó que sus perfiles no contenían `PatronLogoRanuras` ni separación libre registrada. Conservaban las propiedades de la distribución anterior: cuatro ranuras de 300 mm, dos de 122 mm y cuatro de 162 mm según la pieza. Eso explica las combinaciones de la imagen; las comprobaciones del ejecutable nuevo no acreditaban el resultado producido por la ventana anterior.

El archivo principal `PerfilBandas.exe` de la raíz y los accesos `PerfilBandas_banda_completa.exe` y `PerfilBandas_corregido.exe` ahora son iniciadores del único binario vigente, `outputs/PerfilBandas.exe`. `build.ps1` mantiene esos accesos al compilar. Las versiones anteriores se conservaron en `outputs/legacy_entrypoints`. También se puede usar `ABRIR_JAC_BANDAS.cmd`. La ventana vigente y las propiedades del archivo identifican la versión 4.

Una ventana anterior que ya estaba ejecutándose conserva su código en memoria. Guardar su proyecto y cerrarla antes de abrir la versión 4 evita seguir generando con ese código. No se cerró forzosamente ni se descartó su configuración.

## Composición elegida por el usuario

En **05 Marca / ranuras**, el selector **Combinación de este tramo** admite:

- Automático por recorte.
- Sólo logo.
- De una a cuatro ranuras sin logo.
- De una a cuatro ranuras con un logo, en cualquiera de las posiciones de la secuencia.

Se incluyen `Ranura → Ranura → Logo`, `Logo → Ranura → Ranura` y `Ranura → Logo → Ranura`. El orden se lee desde el inicio longitudinal del tramo hacia su final y se mantiene para ambos laterales. En modo elegido, cambiar el largo o el extremo recortado no cambia ese orden ni elimina elementos. Se recalculan los largos de las ranuras; una selección incompatible se conserva y se explica el conflicto, bloqueando la generación.

Se mantiene la altura, separación libre y elevación como los únicos parámetros dimensionales de ranuras. La selección y escala de la marca siguen siendo ajustes de marca. La separación es común a toda la banda y los proyectos versión 4 guardan cada combinación y el estilo de presentación 3D.

## Corrección del último estado automático

Cuando el recorte deja el último estado del patrón con marca, se genera **sólo el logo**, centrado y con su tamaño seleccionado. Se retiró la última ranura de ese estado. Sin marca seleccionada, el último estado sigue siendo una ranura.

Con logo JAC al 170%, separación de 300 mm y altura de ranura de 60 mm:

| Largo | Patrón automático | Largo de cada ranura |
|---|---|---:|
| 2400 mm | Ranura, ranura, logo, ranura, ranura | 165.5 mm |
| 2150 mm | Ranura, logo, ranura, ranura | 237.333333 mm |
| 1700 mm | Ranura, logo, ranura | 281 mm |
| 1200 mm | Ranura, ranura | 300 mm |
| 1100 mm | Ranura, ranura | 250 mm |
| 700 mm | Sólo logo | No aplica |
| 600 mm | Sólo logo | No aplica |

Con ranuras, los márgenes siguen siendo exactamente G/2. **Sólo logo es una excepción necesaria a la igualdad exacta:** se mantienen márgenes de al menos G/2 y se muestra el valor real; no se estira el emblema. En un perfil de 600 mm, un logo de 238 mm deja 181 mm a cada extremo. Unido a un perfil con margen de 150 mm, el espacio entre cortes es 331 mm. La separación de 300 mm entre elementos de las composiciones con ranuras sigue siendo exacta.

El modo automático sigue eliminando elementos adicionales si el recorte cae en un margen o puente y conservarlos exigiría acortar varias ranuras por debajo del largo de referencia. La interfaz informa esa eliminación. La referencia automática es 2400 mm; para decidir otra organización se utiliza el selector de composición.

## Errores corregidos y protecciones revisadas

| Punto revisado | Corrección / resultado |
|---|---|
| Ejecutables independientes desactualizados | Inicio centralizado y versión visible; respaldo de ejecutables antiguos |
| Patrón en caché después de editar largo, orden o separación | Firma de entradas; se recalcula antes de reutilizar el resultado y conserva las protecciones de solape |
| Suposición de que siempre existe una primera ranura | Vista, resúmenes y propiedades CAD admiten cero ranuras |
| Logo en un extremo elegido manualmente | Comprobación de solapes y soportes para su posición efectiva |
| Combinación demasiado densa | Rechazo antes de CAD, sin sustituir la decisión del usuario |
| NaN, infinito y medidas negativas | Validación antes de construir perfiles, soportes y pletinas; placas y rodillos conservan sus controles |
| Ángulos degenerados, pestañas menores que espesor y factor K inválido | Rechazo antes de generar |
| Proyectos corruptos o combinaciones desconocidas | Rechazo antes de reemplazar el proyecto abierto |
| Migración de versiones 1/2/3 | Conversión al modo automático; barrenos cerrados; conservación de la geometría de placa según versión |
| Inserción de componente equivocado | Se comprueba que el documento abierto corresponde a la ruta solicitada |
| Documentos de igual nombre en carpetas distintas | Se bloquea la regeneración antes de cerrar documentos o mezclar referencias |
| Modelos CAD con cambios sin guardar | Se bloquea la regeneración de esos modelos |
| Guardado de plaquita independiente | Se comprueba el código de guardado y existencia del archivo |
| Ensamble que no quedaba activo al finalizar | Activación explícita antes de aplicar y guardar su presentación |
| Mensajes de rodillos que aún mencionaban ventanas/asientos | Texto actualizado para barrenos circulares |

Se revisaron distribución, perfiles, soportes, pletinas, placas, rodillos, edición por tramos, persistencia e inserción/guardado CAD. Las comprobaciones son geométricas y de funcionamiento del programa; no incluyen resistencia de lámina, cargas, tensiones de banda ni simulación física de montaje. Una auditoría y sus pruebas no garantizan ausencia de cualquier fallo externo de SOLIDWORKS o de cualquier combinación futura.

## Vista 3D dentro del configurador

El botón **Vista 3D** de la cabecera abre una ventana interactiva sin generar archivos ni conectar con SOLIDWORKS. También está disponible en **12 Generación**.

- Girar la rueda hacia adelante o atrás amplía y reduce. Mantener la rueda presionada (botón central) y arrastrar gira la banda alrededor de un punto fijo, sin zoom ni reencuadre automático. **Ctrl + rueda presionada + arrastrar** desplaza la vista en el plano de la pantalla, conservando ángulos y ampliación. Presionar y soltar sin mover no cambia la vista. También se puede girar arrastrando con el botón izquierdo. Arrastrar con el derecho desplaza la vista; los botones **+** y **−** permiten ampliar y reducir.
- Clic sobre una pieza o tarjeta selecciona su tramo en el editor. **Ver tramo** lo encuadra; **Banda completa** recupera todos los tramos.
- **Isométrica**, **Lateral**, **Superior** y **Ajustar** permiten revisar la configuración. Doble clic o tecla Inicio restablecen la isométrica; Escape recupera la banda completa.
- **Editar composición** lleva al selector del tramo. La ventana 3D se actualiza al editar parámetros o abrir otro proyecto.
- Las tarjetas muestran orden automático/manual y longitud. El panel inferior muestra largo de ranura, radio, separación y márgenes reales.

La geometría utiliza `BeltLinePlan`, `ProfileSlotLayout`, `SlideRailGeometry`, `PlateContour` y `ReturnRollerLayout`, compartidos con el generador. Muestra perfiles con logo/ranuras pasantes, orificios cuadrados, soportes C, pletinas y placas activadas. Los rodillos siguen representados por sus barrenos circulares. La proyección conserva proporciones y un búfer de profundidad resuelve las piezas que se ocultan entre sí. El renderizado se suaviza y funciona sin bibliotecas gráficas adicionales.

Es una vista de configuración calculada: no importa la teselación de un archivo SLDASM. Los radios de doblez, detalles de soldadura y pequeñas compensaciones medidas durante la generación se confirman en el CAD; no se incorporan motor, chumaceras ni sprockets como piezas comerciales. Una configuración inválida retira la geometría anterior y explica el conflicto para evitar mostrar un modelo desactualizado.

Capturas comprobadas: `scratch/vista-3d-configurador.png`, `scratch/vista-3d-tramo-logo.png` y `scratch/vista-3d-placas-rodillos.png`.

## Presentación adicional en SOLIDWORKS

En **12 Generación**, elegir **Sombreado con aristas** o **Vista técnica sin sombreado**. La aplicación ajusta la isométrica al modelo, quita perspectiva y desactiva sombras/reflejos de piso en la escena del documento. El botón **Ver ensamble en SOLIDWORKS** abre el archivo de la carpeta de salida y aplica la presentación seleccionada. La escena y vista se guardan con el ensamble generado. No se modifican las preferencias globales de otras piezas.

La escena se administra mediante la [API oficial ISwScene](https://help.solidworks.com/2023/english/api/sldworksapi/SolidWorks.Interop.sldworks~SolidWorks.Interop.sldworks.ISwScene.html).

## Comprobaciones

`scratch/build_system_audit.ps1` compila las pruebas vigentes de `scratch/SystemAuditSmoke.cs`.

- 10 802 patrones automáticos: longitudes de 600 a 6000 mm, en ambos sentidos de recorte.
- Límites del recorte probados antes, exactamente y después de las posiciones de referencia.
- 4123 configuraciones elegidas: 3515 válidas y 608 rechazadas; se comprueban separación entre bordes, márgenes y conservación del orden.
- Invalidez de caché, sólo logo, colisiones, números no finitos, migración 1/2/3 y persistencia 4.
- Vista 3D: apertura desde el configurador, selección por clic sincronizada con el editor, cambios de composición, rechazo de geometría inválida, encuadres lateral/superior, zoom y modelo máximo de 24 tramos. Se inspeccionaron capturas completas y del tramo de sólo logo, además de placas y barrenos de retorno. En esta máquina el render de 4 tramos tomó aproximadamente 65 ms y el de 24 tramos 94 ms; son medidas de prueba, no garantías de rendimiento.
- Regresión de rodillos: siete barrenos cerrados, reparto uniforme y catenaria motriz de 1200 mm, con dimensiones sintéticas de chumacera y profundidad manual de prueba de 180 mm.
- Regresión de placas: tabla A/B, asientos y separación de 50.8 mm frente al perfil mediante `scratch/PlateRegressionV4.exe --clearance`.
- Modo `--cad`: ocho perfiles LH/RH, midiendo el logo solo y las tres combinaciones con dos ranuras; después genera un ensamble automático de cuatro tramos de 2400/600/2400/1100 mm.
- Modo `--verify RUTA`: inspección de los cortes en coordenadas del ensamble, márgenes de juntas, persistencia de la escena y protecciones de documentos abiertos.

El CAD auditado quedó en `scratch/audit-composiciones-cad-20261002-235615`. Los ocho perfiles de prueba y el ensamble `EJEMPLO_4_TRAMOS/BANDA_COMPLETA.SLDASM` pasaron. La medición de las uniones LH/RH dio 331 / 331 / 300 mm, coherente con el tramo de sólo logo y los otros márgenes. Se comprobó que documentos sin guardar y nombres coincidentes en otra carpeta bloquean la regeneración.

Las pruebas `Pattern300Smoke` documentan la versión 3 anterior y su último estado de una ranura. Para la versión vigente se utiliza `SystemAuditSmoke`.

La generación puede dejar piezas parciales si SOLIDWORKS falla a mitad de una operación; no se presenta ese resultado como un ensamble terminado. Generar en otra carpeta permite conservar un conjunto anterior. No se regenera automáticamente el ensamble del usuario al abrir un proyecto.
