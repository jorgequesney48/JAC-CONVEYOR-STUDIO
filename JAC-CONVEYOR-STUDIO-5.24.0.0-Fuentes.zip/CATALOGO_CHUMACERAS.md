﻿# Catálogo de chumaceras

El botón **Chumacera ▾** aparece en Principal y en Detalles > 10 Placas / ejes, para el extremo conducido y el motriz. Su desplegable muestra las últimas seis utilizadas, Buscar en catálogo y Agregar nueva desde modelo 3D.

## Registrar una chumacera

1. Pulsa Chumacera > Agregar nueva desde modelo 3D.
2. Carga SLDPRT, SLDASM, STEP/STP, Parasolid X_T/X_B o IGES/IGS. Se requiere SOLIDWORKS y su plantilla de pieza predeterminada. El modelo debe contener sólidos; STL, OBJ y dibujos 2D no se admiten.
3. El sistema crea una copia de todos los sólidos visibles, incluyendo los componentes resueltos de un ensamble, sin referencias externas al archivo original. La copia se abre en SOLIDWORKS.
4. La detección busca cuatro barrenos interiores iguales en un patrón cuadrado. Si encuentra varios patrones o no puede identificarlo, selecciona con Ctrl, en orden: cara plana que apoya en la placa, cara cilíndrica del eje y cara interior de un barreno de fijación. Regresa al registro y pulsa Leer las tres caras seleccionadas.
5. Revisa el modelo y la cara de apoyo en SOLIDWORKS. Completa marca, referencia y diámetro de asiento. El paso medido se conserva; puedes aumentar la holgura de los barrenos. La abertura central es una propuesta que debes verificar según el cuerpo que atraviesa la placa; no equivale al diámetro de la flecha. La envolvente se mide desde el eje y también contempla piezas salientes.
6. Confirma las medidas y la cara de apoyo. Pulsa Guardar en catálogo y seleccionar.

El modelo se guarda como una pieza sólida SLDPRT independiente, aunque provenga de un ensamble. No se conservan relaciones de posición o edición del ensamble original. Las medidas internas y la orientación usan metros; los campos del registro muestran milímetros.

## Reutilizar y generar

Seleccionar una chumacera activa automáticamente las dos placas de ese extremo y la inserción de sus dos modelos 3D al generar. Aplica su referencia, asiento, abertura, paso, barrenos y envolvente a la placa del extremo seleccionado. El otro extremo conserva su propia elección. El proyecto versión 6 guarda una copia de las medidas y la orientación seleccionadas.

Al generar la banda en SOLIDWORKS, se copia el modelo registrado a la subcarpeta CHUMACERAS del ensamble. Se colocan dos chumaceras por extremo con placas activas, alineadas con la flecha, sus barrenos y la cara exterior de las placas. REFERENCIAS_FLECHAS.json registra el modelo y el identificador del catálogo. Los componentes se colocan y fijan, siguiendo el sistema actual de ensamble; no se crean mates paramétricos nuevos. El visor propio de banda muestra la geometría real de la chumacera sobre las placas, usando la misma orientación y posición del ensamble CAD. Se guarda una malla gráfica en vista3d.bin junto al modelo; la primera selección prepara esta vista con SOLIDWORKS y las siguientes reutilizan la copia, sin abrir CAD. Los modelos ya registrados se actualizan al seleccionarlos o al abrir un proyecto que los utilice. La malla es únicamente gráfica; la generación del ensamble utiliza el sólido SLDPRT.

Si cambias las medidas de una placa después de seleccionar una chumacera, la generación avisa de la diferencia. Vuelve a seleccionarla o pulsa Chumacera > Usar medidas manuales. En modo manual se conservan los campos, pero no se inserta un modelo de chumacera.

## Almacenamiento y límites

El catálogo está en CATALOGO_CHUMACERAS dentro de la carpeta de piezas del programa, junto con catalogo.json y una subcarpeta por modelo. Las importaciones temporales se eliminan al cerrar el registro. Para trasladar el programa y reutilizar los modelos, conserva también esta carpeta. Los proyectos antiguos siguen siendo compatibles; programas antiguos no abren la nueva versión de proyecto.

Esta versión reconoce montaje de cuatro barrenos en patrón cuadrado, con asientos de 1 1/8, 1 1/4 y 1 1/2 pulgadas, que corresponden al generador existente. Un montaje de dos barrenos, ranuras oblongas o patrón rectangular necesita ampliar la geometría de placas antes de registrarse. La detección no interpreta roscas ni el diámetro nominal de tornillos.

## Verificación

scratch/BearingCatalogSmoke.cs verifica persistencia del catálogo, independencia del original, orden de recientes, selección por extremo, proyectos, copias profundas, detección de patrones y ambigüedad, correspondencia de centros y orientación LH/RH, y rechazo de medidas incompatibles.

scratch/BearingCadSmoke.cs crea una pieza de ensayo con cuatro barrenos y una abertura central, importa SLDPRT y STEP, compara las medidas leídas y verifica las referencias seleccionadas. También genera una banda completa con cuatro chumaceras, comprueba su altura y la copia del modelo en el ensamble. Estas pruebas pasaron en SOLIDWORKS; Parasolid, IGES y ensambles de proveedor se admiten por el importador, pero no se verificaron con modelos reales de esos formatos. Los modelos reales deben revisarse al registrarlos.

Verificación del visor: scratch/BearingPreviewSmoke.cs leyó la chumacera SKF ya registrada (7128 triángulos), comprobó sus cuatro posiciones contra la transformación CAD y generó scratch/bearing-preview-real-model.png.
