# Catálogo de sprockets

En Parámetros del tramo motriz o conducido, usar **Sprockets ▾** para seleccionar recientes, buscar por marca/referencia o agregar un modelo. La cantidad es independiente por extremo, editable entre 1 y 50 y distribuida uniformemente sobre el cuadrado de la flecha. No se agregan sprockets a tramos intermedios.

Formatos sólidos: SLDPRT, SLDASM, STEP/STP, Parasolid X_T/X_B e IGES. SOLIDWORKS debe estar instalado para la importación inicial. El catálogo guarda una copia sólida independiente y una malla para la vista 3D en `outputs/piezas_ensamble/CATALOGO_SPROCKETS`.

Para registrar: importar, seleccionar con Ctrl las cuatro caras planas interiores del alojamiento cuadrado en la copia abierta en SOLIDWORKS y pulsar **Leer caras y medidas**. Se calcula el centro, orientación, lado del cuadrado, ancho axial y envolvente exterior. Introducir marca y referencia y guardar. No se detectan automáticamente dientes o datos del fabricante: los parámetros E925 de placas/ejes siguen siendo los configurados en ese apartado.

Primero seleccionar una chumacera o verificar las medidas de montaje del extremo. Al elegir un sprocket se activan las placas y la flecha. El cuadrado debe coincidir con el lado de la flecha (tolerancia de lectura 0.05 mm y holgura nominal máxima 0.5 mm más 0.05 mm de margen de lectura, límite total 0.55 mm); no se deforma el sólido importado. Se rechazan cantidades que provoquen superposición axial. Los centros se sitúan a (i + 0.5) * largoCuadrado / cantidad desde el inicio del cuadrado; el ancho del modelo debe caber en cada intervalo.

La vista se actualiza al cambiar el ancho de banda o la cantidad. El ensamble SOLIDWORKS copia el modelo a su carpeta SPROCKETS e inserta una instancia por posición, alineando el cuadrado con la flecha. Los proyectos versión 8 guardan la elección, medidas, orientación y cantidad. Proyectos anteriores abren sin sprockets.

Verificación: `scratch/SprocketSmoke.cs` prueba reparto, actualización por ancho, rechazo de superposición, copia independiente, catálogo, recientes y guardado de proyecto. Con `--cad` crea una rueda sólida de prueba con alojamiento cuadrado, importa y mide sus caras y verifica las posiciones de tres componentes en un ensamble de SOLIDWORKS.

## Asociación con la banda

Cada registro conserva `BeltModelName`. Al importar se elige el modelo compatible; los recientes y la búsqueda muestran solamente sprockets asociados a la banda del tramo. La opción **Asociar modelo existente a [banda]** permite clasificar registros anteriores o corregir una asociación. Los registros anteriores cuya referencia coincide exactamente con el nombre de banda (ignorando espacios y signos) se asocian al modelo reconocido; otros quedan sin asignación explícita.

La vista y el ensamble rechazan un sprocket de otra banda. Los mensajes muestran el modelo de banda de cada pieza, los lados del alojamiento y la flecha o la longitud requerida y disponible. Estas comprobaciones cubren asociación, orientación registrada, ajuste del cuadrado y distribución axial; no verifican automáticamente el perfil del diente contra la correa ni todas las colisiones del ensamble.

