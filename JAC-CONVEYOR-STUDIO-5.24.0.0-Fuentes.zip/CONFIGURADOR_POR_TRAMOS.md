# Configurador por tramos

## Uso

Abre `outputs/PerfilBandas.exe`. La pantalla inicial es **Banda completa**.

1. Selecciona un tramo en el esquema superior o en su tarjeta izquierda. El esquema también admite las flechas del teclado.
2. Configura el espesor de banda en **01 Dimensiones**; **03 Orificios C** permite nivelar los soportes automáticamente para que la banda quede al ras del perfil. El botón **Usar esta banda en todos los tramos** aplica modelo, ancho y espesor. Edita sus categorías: dimensiones, perfiles, orificios C, uniones/patas, marca/ranuras, soportes C, ranuras guía, pletinas y plaquitas.
3. Consulta a la derecha la referencia de las cotas y el resultado calculado. Las vistas son esquemáticas; no sustituyen una revisión del CAD.
4. Agrega un intermedio o duplica los ajustes del seleccionado como un nuevo intermedio. El primer tramo siempre es conducido y el último motriz.
5. Guarda el proyecto como `.jacband` para conservar todos los ajustes y modos automáticos. La app pregunta por cambios pendientes al abrir otro proyecto o cerrar.
6. Elige una carpeta en **Generación** y genera la estructura en SOLIDWORKS. Reutilizar una carpeta actualiza los archivos del mismo nombre.

Los controles de **Piezas individuales** quedan disponibles en el menú superior para trabajos aislados. Cambiarlos no altera los tramos ya creados.

## Configuraciones independientes y compatibilidad

Cada tramo guarda copias propias de `ProfileSettings` y `SoporteSettings`. Cambiar el largo, perforaciones, ranuras, guías o plaquitas de uno no cambia los demás. Duplicar también realiza copias independientes.

- Largo admitido: 600–6000 mm por tramo. Máximo: 24 tramos.
- Soportes: Auto, 2, 4 o 6. Auto usa 2 por debajo de 1000 mm, 4 por debajo de 2000 mm y 6 desde 2000 mm.
- **Adaptar paso** limita el paso solicitado al espacio disponible. Desactivarlo conserva el paso exacto y bloquea generación si no cabe.
- **Adaptar ranuras** puede reducir cantidad, largo y radio según el espacio del logo. Desactivarlo conserva las medidas solicitadas y valida su ajuste.
- Los soportes se colocan usando los mismos centros de orificio que los perfiles. La altura de la plaquita se compensa individualmente para cada tramo.
- Los dobleces de los laterales siguen orientados hacia afuera.
- El patrón inferior es siempre 2/1 en el conducido, 1/1 en los intermedios y 1/2 en el motriz. El patrón superior se puede activar por tramo.
- Modelo y ancho de correa deben coincidir entre tramos. La altura y doblez inferior deben permitir continuidad en las juntas. El ancho de colocación de los laterales también se comprueba.
- Las cotas de los orificios de las patas se editan por tramo. La separación real de una pareja en una junta equivale a la suma de las dos cotas extremo–centro vecinas; deberá corresponder al soporte de pata que se diseñe después.
- El generador actual crea conjuntamente marca y ranuras laterales: al seleccionar **Sin marca ni ranuras**, ambas se omiten.

## Generación y comprobaciones realizadas

El apartado **10 Placas / ejes** configura por extremo las placas de 3/16 in, tabla E925, diámetro de asiento y montaje de chumacera. **12 Generación** elige la carpeta de salida. Detalles en [PLACAS_FLECHAS_E925.md](PLACAS_FLECHAS_E925.md).

Las tiras de nylamid se prolongan hacia las flechas en extremos con placas activadas, conservando B y dejando 50.8 mm entre el borde de los barrenos de chumacera y el perfil. En los demás tramos mantienen el largo del perfil. Las plaquitas C conservan su contorno, bajan al nivel inferior del nylamid y se alargan ambos dobleces del canal para alojarlas; la nivelación automática coloca la rodadura bajo el doblez superior según el espesor de banda (12 mm para E925). Los tres cuadrados se centran en la mitad del solape real y su distribución vertical evita el paso de cabeza. Un paso de Ø31.75 mm en la placa de chumacera despeja la cabeza del tornillo del soporte exterior. Las ranuras laterales respetan el solape efectivo y reservan 10 mm junto a los barrenos de soportes.

Cada tramo genera perfiles laterales LH/RH, un soporte C y, si se activa la opción, pletinas de deslizamiento LH/RH y centrales. Todas tienen nombre propio. Su largo incluye la prolongación calculada cuando hay placas de flecha activadas. Se reutiliza la pieza central para las distintas ranuras centrales del mismo tramo.

El croquis aportado fija la sección lateral en $19.05 \times 38.1$ mm, con rebaje superior interior de $12.7 \times 6.35$ mm. Los laterales izquierdo y derecho son imágenes espejo. La sección central es rectangular de $19.05 \times 38.1$ mm. Para que la cara rebajada lateral coincida con la cara superior central, el corte lateral estándar cambió a $19.05$ mm y el central permanece en $25.4$ mm. El configurador valida una diferencia de $6.35$ mm entre sus profundidades.

Prueba de pletinas: piezas LH, central y RH de $19.05 \times 38.1 \times 600$ mm comprobadas mediante los cuerpos de SOLIDWORKS. En un ensamble conducido de 600 mm y motriz de 900 mm se verificaron **14 componentes**, incluidas seis pletinas, sus posiciones transversales y la coincidencia de las caras de rodadura. Captura en `scratch/slide_rail_assembly/PLETINAS_EN_BANDA.png`.

Al abrir proyectos `.jacband` de la versión anterior, la app activa las pletinas y adapta la profundidad lateral para conservar la nivelación con las ranuras centrales; marca el proyecto como modificado para que se guarde la actualización.

Prueba CAD: conducido de 800 mm, intermedio de 1500 mm y motriz de 900 mm, con alturas de orificio de 60/65/70 mm, lomo de soporte de 50.8/54.8/58.8 mm y cotas de plaquita de 12/13/14 mm. Resultado: **14 componentes** (6 laterales y 8 soportes), tres piezas de soporte distintas y comprobaciones de posición del generador aprobadas. Artefactos: `scratch/complete_cad_independent/`.

Pruebas de interfaz y datos en `scratch/SectionWorkspaceSmoke.cs`: independencia, edición desde campos, navegación, duplicado, guardado/reapertura, patrones de extremos, rechazo de paso manual incompatible, selección gráfica/teclado y apertura inicial. Capturas revisadas a 1440×900 y 1120×720.

La estructura generada aún no incluye patas, rodillos, flechas, sprockets, chumaceras ni motor. Los nombres conducido/motriz determinan por ahora su posición y patrón de perforación.

## Interfaz web dentro del ejecutable: siguiente etapa posible

Esta entrega sigue siendo WinForms. Se ha separado el estado por tramo de los controles y se guarda en JSON versionado dentro de `.jacband`; el modelo y las reglas pueden reutilizarse al sustituir la interfaz.

Propuesta: una interfaz HTML/CSS/JavaScript, por ejemplo el frontend diseñado en Lovable, integrada mediante **WebView2** dentro del ejecutable. El host C# conservaría la validación, los archivos y la conexión COM con SOLIDWORKS en Windows. Una edición en navegador podría compartir el frontend y la configuración, pero la generación CAD necesitaría ese host local o un servicio Windows definido expresamente.

Microsoft documenta la integración de [WebView2 en WinForms](https://learn.microsoft.com/en-us/microsoft-edge/webview2/get-started/winforms) y la [comunicación entre contenido web y host nativo](https://learn.microsoft.com/en-us/microsoft-edge/webview2/how-to/communicate-btwn-web-native). Para esa etapa todavía hay que empaquetar el frontend, incorporar el SDK/runtime, definir mensajes permitidos y probar la distribución. No se añadió un navegador externo ni un servidor en esta entrega.

## Rodillos de retorno

En **11 Rodillos**, activar los barrenos para ejes de media pulgada. El reparto es global, mantiene intervalos normales iguales entre tramos y reserva 1200 mm entre los dos rodillos cercanos al motriz. La altura usa el abrazo de 186° y la envolvente inferior de banda del croquis (127 mm desde el nylamid), con medidas editables. Tabla, vista y referencias en [RODILLOS_RETORNO.md](RODILLOS_RETORNO.md). La generación ahora se encuentra en **12 Generación**.

## Cantidad común de tiras y montaje pendiente de chumacera (octubre 2026)

En Detalles > 07 Ranuras guía, cambiar «Cantidad de pistas centrales» aplica la misma cantidad a todos los tramos por defecto. El total de tiras es esta cantidad más dos laterales. Los tramos nuevos heredan la cantidad común.

Activa «Permitir cantidades distintas por tramo» para editar cantidades independientes. Al desactivarla, todos los tramos adoptan la cantidad del tramo seleccionado. El modo se guarda en los proyectos versión 5. Al abrir proyectos anteriores se unifican las cantidades usando el primer tramo.

Las placas requieren referencia completa, abertura central, paso de tornillos, diámetro de barrenos, envolvente exterior y confirmación de las medidas de la chumacera. Al activarlas con datos pendientes, el editor abre el apartado de montaje y ofrece «Completar montaje de chumacera». El mensaje enumera los campos pendientes. La vista 3D admite el montaje incompleto y omite barrenos sin dimensiones; la generación CAD sigue validando todos los datos y la geometría.

Verificación: scratch/RailCountSmoke.cs comprueba edición desde el control, propagación, tramos nuevos, modo independiente, guardado/reapertura, vista 3D con montaje incompleto, rechazo CAD y aceptación geométrica de un montaje de prueba completo. No sustituye la comprobación de las dimensiones de la pieza real ni una generación en SOLIDWORKS.
