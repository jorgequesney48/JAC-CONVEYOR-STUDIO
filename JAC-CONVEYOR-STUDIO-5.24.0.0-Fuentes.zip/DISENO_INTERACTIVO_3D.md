# Diseño interactivo de bandas — aplicación v5.3

La banda se edita desde una pantalla clara y minimalista inspirada en los menús de iOS: tarjetas redondeadas, controles agrupados, acentos azules y navegación segmentada. Los tramos están a la izquierda y el modelo ocupa el espacio central. El panel de parámetros permanece cerrado al iniciar y al seleccionar un tramo; al abrirlo aparece a la derecha. El modelo funciona sin iniciar SOLIDWORKS.

## Seleccionar y editar

1. Selecciona un tramo en el menú izquierdo o haz clic en una pieza del modelo. Se resalta su geometría, sin abrir ningún menú de parámetros. Pulsa **Parámetros** cuando quieras editarlo: aparecen el panel y las etiquetas editables del modelo. **Ocultar ajustes**, **×** o Escape cierran el panel y devuelven el espacio al modelo; cambiar de tramo también lo cierra.
2. **Ver tramo** encuadra únicamente el seleccionado. **Ver banda** recupera la banda completa. Isométrica, lateral, superior y ajustar cambian el encuadre.
3. Pulsa una etiqueta del modelo: **Largo**, **Altura de ranura**, **Separación** u **Orden**. Introduce el valor o elige la composición y pulsa **Aplicar**, o Enter. **Cancelar** y Escape cierran ese editor sin modificar el proyecto.
4. El inspector ofrece largo, composición, altura/separación/elevación de ranuras, número de soportes, pletinas, espesor de perfil, ancho de banda y escala del logo. Los valores comunes están marcados como **todos**: ancho de banda y separación. Los demás controles rápidos afectan al tramo seleccionado.
5. **Detalles** contiene las doce categorías completas. **Referencia** conserva los esquemas de perfiles, orificios, soportes, placas y rodillos de la categoría elegida.
6. **Ampliar 3D** abre una ventana mayor con selección; su botón **Medidas** muestra u oculta las etiquetas editables. **Más ajustes** abre los detalles en la pantalla principal. Cambiar una medida en la ventana ampliada también actualiza la pantalla principal.

El resumen muestra modelo y ancho de banda, cantidad de soportes, altura/espesor del perfil, orden de los cortes, largo de cada ranura, radio, separación y márgenes reales.

## Nitidez y acabados del visor

En reposo, el visor mantiene como mínimo la resolución de su área real y utiliza sobremuestreo para suavizar los bordes. Durante zoom, giro y desplazamiento utiliza una imagen intermedia con resolución adaptativa, priorizando la respuesta del mouse. Tras 180 ms sin movimiento recupera el acabado completo. Los extremos curvos de las ranuras tienen más segmentos.

El zoom y el desplazamiento muestran de inmediato la imagen anterior transformada. Los nuevos cálculos se ejecutan en segundo plano, con una sola tarea por visor y agrupación de las peticiones pendientes. El giro publica imágenes intermedias sin bloquear los controles. Si se reanuda un movimiento, se cancela el cálculo de alta calidad anterior. Las copias de imagen se recortan al área que ocupa el modelo y sólo se dibuja la región visible; las imágenes para movimiento utilizan composición rápida. Los controles y las etiquetas conservan su resolución habitual.

La cámara mantiene las medidas, el punto de giro y el desplazamiento en coordenadas de pantalla al cambiar de calidad. La selección se comprueba con la cámara actual; el acabado inoxidable y los colores del Nylamid se conservan al finalizar el movimiento. La misma implementación sirve al visor integrado y la ventana ampliada.

Las líneas se comprueban contra la cara visible en la misma posición subpíxel, con una tolerancia de 0.02 mm. Se conserva la profundidad real del borde, incluida la de caras muy inclinadas. La tolerancia anterior aumentaba al alejarse y dejaba ver contornos de plaquitas a través del perfil. Los materiales del visor son opacos.

Perfiles, soportes y placas tienen acabado visual de acero inoxidable, con iluminación y reflejos suaves. Las tiras de Nylamid utilizan un acabado mate independiente: **blanco** inicialmente. En **Parámetros → Principal → Color Nylamid (todos)** puedes elegir blanco, negro, azul, verde, amarillo, rojo o natural. Se guarda con el proyecto y se sincroniza en el visor integrado y la ventana ampliada; no cambia las medidas ni las composiciones. Estos acabados corresponden al visor de la app; el generador CAD conserva sus materiales actuales.

**Eliminar tramo** lleva fondo rojo y texto blanco al estar disponible; en los extremos, donde no se permite eliminar, se muestra rojo tenue. **Abrir** es azul, **Guardar** verde y **Ampliar 3D / Duplicar** violeta. La cabecera reserva altura suficiente para que los botones no se recorten.

## Controles del mouse

- Rueda adelante/atrás: zoom.
- Rueda presionada y arrastrar: giro alrededor de un punto fijo.
- Ctrl + rueda presionada y arrastrar: desplazamiento en el plano de la pantalla.
- Botón derecho y arrastrar: desplazamiento alternativo.
- Clic izquierdo: seleccionar una pieza o editar una etiqueta.

Girar y desplazar conservan la ampliación. Los botones +/− también permiten zoom.

## Validación de cambios

Las ediciones rápidas se comprueban sobre una copia del proyecto antes de aplicarse: distribución, separación, soportes, solapes de placas y barrenos de rodillos. Si un cambio no cabe, el modelo conserva su geometría válida. Un valor inválido del inspector se marca en rojo y se indica como **pendiente, sin aplicar**; la generación queda bloqueada hasta corregirlo. Cambiar de tramo o cerrar el panel descarta las propuestas pendientes sin modificar los valores aplicados. Los cambios válidos ya aplicados se conservan. El editor sobre el modelo mantiene el valor propuesto y el motivo del rechazo para que se pueda corregir o cancelar.

Cambiar de tramo también cierra cualquier editor flotante sin aplicarlo, evitando modificar otra pieza por accidente. Los ajustes completos de **Detalles** conservan su funcionamiento previo y sus validaciones; al realizar una edición allí se dejan de utilizar las propuestas pendientes del inspector rápido.

Se mantienen las composiciones automáticas y elegidas, el último recorte con sólo logo y los barrenos circulares de rodillos. El modelo representa la configuración paramétrica; radios de doblez, soldaduras y compensaciones de fabricación siguen confirmándose en el CAD.

## Guardado y compatibilidad

La versión de la aplicación es **5.3.0**. El formato de proyecto sigue siendo `.jacband`, versión de esquema 4: conserva las mismas piezas y parámetros y abre proyectos de las versiones 1 a 4. Los archivos que no incluyen `NylamidColor` comienzan en blanco. No se reemplaza un archivo CAD al abrir un proyecto. Los nuevos tramos heredan las medidas comunes del proyecto actual, incluido el ancho y separación importados o editados.

Inicia con `PerfilBandas.exe` de la raíz. Si la app anterior está abierta, guarda su proyecto, ciérrala y abre la nueva versión; la actualización no descarta ni cierra esa ventana automáticamente.

## Comprobaciones

La suite `scratch/SystemAuditSmoke.cs` comprueba selección desde menú/modelo, edición por tramo, modificaciones comunes, etiquetas editables, rechazo sin sustituir la geometría válida, bloqueo de generación con propuestas pendientes, edición en la vista ampliada, persistencia, herencia de medidas al agregar tramos, inicio real de `MainForm` y distribución a 1120 × 720. Conserva las regresiones de mouse y las pruebas de 10 802 distribuciones automáticas y 4123 composiciones elegidas.

La selección no abre el panel en las pruebas de menú ni de clic 3D. También se verifica la recuperación del espacio al cerrarlo, la reapertura con los valores aplicados y la ampliación del lienzo a más de 800 px en la ventana mínima con el panel oculto.

Las pruebas de calidad comparan imágenes completas con y sin una placa a 0.6 mm detrás de una lámina: los píxeles son idénticos en vista lateral e isométrica. Se comprueba que el visor de 3400 × 1000 produce un raster de 6800 × 2000, que los botones caben al 100 % y al 150 %, y que el color del Nylamid persiste y sólo altera las tiras. Capturas nuevas: `scratch/app-inoxidable-ultrapanoramica.png`, `scratch/app-nylamid-azul.png` y `scratch/app-botones-escala150.png`.

La prueba de navegación usa seis tramos y una ventana con un visor de 3384 × 1111. Comprueba ráfagas de 24 entradas sin recalcular en el controlador del mouse, publicación de imágenes durante el giro, recuperación de la calidad al detener rueda o giro, selección posterior y cierre con trabajo pendiente. Las mediciones locales se guardan en `scratch/FLUIDEZ_3D.txt`; son tiempos de dibujo, no una garantía de FPS para cualquier equipo.

Capturas: `scratch/app-principal-v5.png`, `scratch/app-minimalista-modelo.png`, `scratch/app-minimalista-parametros.png`, `scratch/app-editor-sobre-modelo.png` y `scratch/app-interactiva-1120.png`.

## Giro alrededor de la zona visible

Al comenzar a girar con la rueda presionada, el visor elige una superficie cercana al centro de la ventana y la mantiene fija en pantalla. Después de desplazar o ampliar hacia una chumacera, el siguiente giro usa esa zona como centro, en lugar del centro de la banda completa. La elección respeta los orificios y el tramo visible cuando se usa Ver tramo. Si no hay superficies visibles, utiliza el plano de la cámara.

Ajustar, Ver banda y Ver tramo restablecen el centro de la vista correspondiente. El cálculo se comparte con el renderizado en segundo plano para conservar la posición al cambiar el centro de giro.

Verificación: scratch/OrbitSmoke.cs comprobó desplazamiento a ambos extremos, giro con zoom, conservación de la posición al cambiar el centro, punto de giro fijo, vista por tramo, orificios y restablecimiento con Ajustar.
