# Distribución automática de logo y ranuras

**Actualización v4:** se añadió un selector de composiciones por tramo y el último estado automático con marca ahora usa sólo logo. Las cifras y pruebas del último estado de una ranura de esta versión 3 son históricas. Consulta [la auditoría y comportamiento vigente](AUDITORIA_SISTEMA_Y_COMPOSICIONES.md).

Implementación del criterio solicitado, con referencia de 2400 mm. Sustituye las ranuras manuales y el sistema de ventanas con guías antigiro. El contorno elaborado de las placas de flecha se conserva.

## Uso

En **05 Marca / ranuras**, seleccionar la marca y su escala, y ajustar solamente estos parámetros de ranuras:

| Parámetro | Valor inicial | Referencia |
|---|---:|---|
| Altura de ranura | 60 mm | Abertura de arriba abajo; radio = altura / 2 |
| Separación libre | 300 mm | Entre bordes de ranuras o de ranura y logo; común a toda la banda |
| Borde inferior sobre doblez | 80 mm | Distancia vertical desde la tangencia del doblez inferior al borde inferior de la abertura |

En **01 Dimensiones**, el selector **Extremo recortado** permite invertir el patrón longitudinal. Los laterales LH y RH reciben las mismas posiciones longitudinales. Cantidad, largo, radio y posiciones son resultados automáticos; la vista informa los elementos efectivamente generados.

El margen en cada extremo es siempre la mitad de la separación libre: 150 mm para el criterio de 300 mm. Una unión sin separación física conserva 150 + 150 = 300 mm libres. Si existe una junta física de ancho J, la separación entre aberturas aumenta a 300 + J.

## Cálculo y recorte

El patrón completo es `R1 — R2 — LOGO — R3 — R4`. Se compara el recorte con las posiciones de las aberturas en la referencia de 2400 mm y se selecciona el estado:

| Abertura alcanzada por el recorte | Resultado |
|---|---|
| Ninguna | Cuatro ranuras y logo entre las dos centrales |
| Primera ranura | Tres ranuras y logo después de la primera |
| Segunda ranura | Dos ranuras y logo entre ambas |
| Logo | Dos ranuras sin logo |
| Tercera ranura o posteriores | Una ranura sin logo |

Se redistribuyen los elementos completos, sin dejar medias aberturas junto al corte. Al volver a alargar el perfil se recuperan los elementos que correspondan; ocultar el logo por recorte no cambia la selección de marca guardada.

Con L = largo final, G = separación libre, N = cantidad de ranuras, K = presencia de logo (0 o 1) y W = ancho exterior real de la marca:

`largo de cada ranura = (L − (N + K) × G − K × W) / N`

Todas las ranuras de un mismo patrón tienen el mismo largo. Cuando el corte cae en un puente o margen y el estado inicial exigiría acortar varias ranuras por debajo de su largo de referencia, se elimina un elemento adicional hasta encontrar un patrón válido. La vista muestra esa eliminación adicional. La última ranura sí puede acortarse; necesita al menos la altura de abertura más 2 mm de tramo recto. Si tampoco cabe, se bloquea la generación y se explica el motivo.

Ejemplos con logo JAC al 170%, ancho real de 238 mm, altura de abertura de 60 mm y separación de 300 mm:

| Largo del perfil | Ranuras | Logo | Largo de cada ranura |
|---|---:|---|---:|
| 2400 mm | 4 | Sí | 165.5 mm |
| 2150 mm | 3 | Sí | 237.333333 mm |
| 1700 mm | 2 | Sí | 281 mm |
| 1200 mm | 2 | No | 300 mm |
| 700 mm | 1 | No | 400 mm |

La posición vertical del centro es `tangencia inferior + elevación + altura / 2`. El logo se alinea con ese centro. Se comprueba su altura completa y su ancho real, sin deformarlo. Los perfiles mayores de 2400 mm conservan cuatro ranuras ampliadas si cumplen las comprobaciones.

## Protecciones y rodillos

Se reservan 10 mm respecto a los dobleces, soportes y solapes de placas. Un conflicto se informa en la interfaz antes de generar; no se altera silenciosamente la geometría mecánica.

Los rodillos usan exclusivamente barrenos circulares cerrados, de diámetro `diámetro de eje + holgura diametral`. Se conserva el cálculo de posiciones globales, altura y catenaria. No se asigna una ventana a cada rodillo ni se exige que una ranura quede encima. Si un barreno invade el patrón calculado, el reparto intenta otra cantidad de intervalos uniformes; los primeros rodillos y la catenaria conservan sus referencias. Si no existe una solución, se informa del conflicto.

## Proyectos y resultados

Los proyectos `.jacband` se guardan como versión 3. Las versiones 1 y 2 se convierten al abrir: separación de 300 mm, altura derivada del radio antiguo y elevación que conserva el centro vertical anterior. Se desactivan los asientos abiertos; se mantiene la geometría de placas que tenía el proyecto. La conversión queda pendiente de guardar y no regenera ni sobrescribe piezas CAD por sí sola. La separación global guardada también se aplica a los nuevos tramos.

Cada ensamble exporta `DISTRIBUCION_LOGO_RANURAS.json` con el patrón efectivo de cada tramo. `REFERENCIAS_RODILLOS.json` registra la configuración y los barrenos circulares. Las piezas incluyen la propiedad `PatronLogoRanuras` y la operación `Logo_Ranuras_Patron300`.

## Comprobación reproducible

Compilar la aplicación con `build.ps1`. Compilar las pruebas con `scratch/build_pattern300.ps1` y ejecutar `scratch/Pattern300Smoke.exe`:

- Sin argumentos: resultados numéricos independientes para los cinco casos, 5401 largos de 600 a 6000 mm, espejo, recuperación al alargar, distintas separaciones, marca hexagonal, conflictos y barrenos cerrados.
- `--preview`: persistencia versión 3, migración de versiones 1/2, herencia del criterio global en nuevos tramos, visualización de errores y capturas de interfaz y patrones.
- `--cad`: cinco longitudes en LH/RH; mide superficies reales, posiciones y ancho de logo, extremos de ranuras, altura, corte pasante, barrenos circulares y un único sólido por perfil.
- `--assembly`: genera una banda de dos tramos, con soportes, pletinas y placas, y mide el espacio libre entre aberturas en las uniones LH/RH.

Los diez perfiles CAD pasaron en `scratch/patron300-cad-20261002-223717`. El proyecto de ejemplo es `scratch/patron300-ejemplo.jacband`; las capturas están en `scratch/patron300-ui.png` y `scratch/patron300-casos.png`.

El ensamble de dos tramos quedó en `scratch/patron300-ensamble-20261002-225554/BANDA_COMPLETA.SLDASM`. La inspección de superficies transformadas a coordenadas del ensamble confirmó **300.000 mm libres en las uniones LH/RH** y barrenos circulares en ambos laterales. La captura es `BANDA_COMPLETA_ISOMETRICA.png` y las medidas resumidas están en `RESULTADO.txt`. Para repetir sólo la inspección sin regenerar piezas, usar `--verify` seguido de la ruta al ensamble.

Las dimensiones de chumacera usadas por las pruebas son sintéticas. El ejemplo usa una profundidad manual del centro de rodillos de 180 mm para comprobar los barrenos con este patrón; no modifica la configuración de altura de proyectos del usuario ni acredita un abrazo determinado.
