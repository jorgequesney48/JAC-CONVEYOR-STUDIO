# Dobleces de perfiles · v5.23

Los perfiles rectos del visor 3D tienen dobleces curvos con radio interior R y radio exterior R + espesor. El alma y las pestañas terminan en las tangencias, sin superposición de esquinas rectas. Las curvas del transportador conservan sus cejas independientes soldadas.

En **Perfiles laterales** se puede ajustar el radio interior y el factor K del perfil. K inicia en 0.45, se guarda en el proyecto y se transmite a la operación de chapa de SolidWorks. También se aplica al copiar los ajustes a todos los tramos.

El radio de la fibra neutra es R + K × espesor. K cambia el desarrollo de la lámina; el radio y el espesor determinan la curvatura de la pieza doblada. El resultado del tramo muestra los radios y el ancho desarrollado. La vista de sección dibuja la fibra neutra en naranja a su posición proporcional.

Las dimensiones de las pestañas mantienen la referencia a la intersección virtual de las caras exteriores usada por el croquis de SolidWorks. Los barrenos inferiores conservan su distancia al extremo libre y las placas de pata mantienen su contorno y posición.

Validación: comparación de centros y radios contra caras cilíndricas de perfiles LH/RH generados en SolidWorks; factores K 0.30 y 0.60; comprobación del ancho desarrollado contra la pieza desplegada. Pruebas de selección de caras y alineación de placas de pata.

Prueba reproducible: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scratch\RunProfileBendRegression.ps1 -Cad`.
