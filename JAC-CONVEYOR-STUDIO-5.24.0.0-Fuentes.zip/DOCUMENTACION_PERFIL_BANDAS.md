# Perfil lateral para bandas transportadoras

## Objetivo

Aplicación de Windows en C# / .NET que diseña y genera en SOLIDWORKS un perfil lateral de lámina inoxidable para bandas transportadoras. La pieza se genera automáticamente como una operación de **Brida base/Pestaña** de chapa metálica a partir de un croquis abierto, con dos dobleces longitudinales hacia afuera, distribución automática de logo y ranuras según el largo, y perforaciones estándar en los extremos para soportes PTR y aditamentos superiores.

Este módulo evoluciona hacia la generación del **Ensamble Automatizado (`.SLDASM`)**, incorporando perfiles enfrentados (LH y RH), soportes transversales en canal C (calibre 12), pistas longitudinales de Nylamid/UHMWPE y la cama de deslizamiento de la banda modular.

---

## Estructura del proyecto

```text
PERFILES/
├── src/
│   └── PerfilBandas.cs              # Código fuente C# WinForms y API de SOLIDWORKS
├── assets/
│   └── LogoA_vectorizado.dxf        # Geometría DXF oficial del Logo A (140 mm base)
├── macros/
│   ├── CORTE DE RANURAS.swp         # Macro de referencia para operaciones de corte
│   ├── Macro1.swp                   # Macro grabada del perfil base original
│   ├── PERFORACIONES SOPORTES.swp   # Macro con las cotas estándar de barrenos
│   └── (macro soporte C en proceso) # Macro para canal C grabado por usuario
├── lib/
│   ├── SolidWorks.Interop.sldworks.dll
│   └── SolidWorks.Interop.swconst.dll
├── outputs/
│   ├── PerfilBandas.exe             # Ejecutable activo vigente
│   ├── band_catalog.json            # Catálogo de modelos de banda (E925, etc.)
│   └── historial/                   # Versiones previas
├── build.ps1                        # Script automatizado de compilación csc
├── README.md                        # Guía rápida de uso
├── DOCUMENTACION_PERFIL_BANDAS.md   # Documentación técnica del perfil
└── ARQUITECTURA_ENSAMBLE_Y_SOPORTES.md # Especificación del ensamble, soportes y Nylamid
```

---

## Alcance actual del configurador (Vigente)

- **Catálogo dinámico de bandas (`band_catalog.json`)**:
  - Modelo inicial: **E925**, anchos configurables de 100 a 1320 mm en múltiplos de 25 mm.
  - Selección de modelo y ancho desde la interfaz gráfica.
  - Generación de metadatos en propiedades personalizadas de la pieza (`ModeloBanda`, `AnchoBanda_mm`).
- **Control de Lado (LH, RH, Par)**:
  - Selector `Izquierdo (LH)`, `Derecho (RH)` y `Par (Izquierdo + Derecho)`.
  - Inversión automática de la dirección de pestañas para perfil derecho.
  - Espejado del croquis del Logo A en perfiles RH para que se mantenga legible hacia el exterior.
  - Nomenclatura automática de archivo: `PerfilLateral_LH_...` y `PerfilLateral_RH_...`.
- **Perfil lateral paramétrico de chapa metálica**: Longitud, altura del alma y calibres inoxidables (10, 12, 14, 16 y 18).
- **Pestañas superior e inferior configurables**: Longitud de pestaña y ángulo independientes.
- **Corte central vectorizado**: Logo A corporativo vectorizado (ancho base 140 mm) con escala porcentual, o Marca B (hexágono Ø 70 mm).
- **Ranuras horizontales automáticas**: de una a cuatro ranuras con distribución por recorte, separación libre inicial de 300 mm y márgenes de 150 mm. El logo se redistribuye u omite según el largo. Controles de altura, separación y elevación; detalles en [DISTRIBUCION_LOGO_RANURAS_300.md](DISTRIBUCION_LOGO_RANURAS_300.md).
- **Patrón estándar de orificios en extremos (Soportes PTR y Aditamentos)**:
  - Selector independiente para **Extremo Izquierdo** y **Extremo Derecho** (`Ninguno`, `Empalme (1 orificio)`, `Final de banda (2 orificios)`).
  - Toggles para activar/desactivar independientemente:
    - ☑ `Perforaciones inferiores (soporte a 45°)`
    - ☑ `Perforaciones superiores (aditamentos)`
  - Cotas estándar de fabricación: cuadrados exactos de **11.00 × 11.00 mm** (para tornillo de cuello cuadrado de 3/8"), a **31.75 mm (1¼")** del borde y **63.5 mm (2½")** entre orificios.
  - **Centrado robusto mediante `GetBox()` e interpolación de ejes**: Los orificios se ubican con precisión en el centroide de la cara de la pestaña sin desfasarse por radios de doblez ni espesores de lámina.
  - **Corte ciego acotado al espesor (`swEndCondBlind`)**: El corte se limita a $2\times$ el calibre de la lámina, asegurando que perfore limpiamente la pestaña sin penetrar la cavidad interior ni dañar el alma inclinada de 5°.
- **Vistas previas 2D sincronizadas en tiempo real**:
  - Sección transversal con indicación de dobleces hacia afuera.
  - Vista frontal completa con alma, ranuras, logo y los orificios superiores e inferiores marcados en rojo en sus pestañas correspondientes.
- **Trazabilidad y propiedades personalizadas**: Registro de metadatos en la pieza `.SLDPRT` (`Largo_mm`, `Alma_mm`, `Calibre`, `Lado`, `ModeloBanda`, `AnchoBanda_mm`, `OrificioExtIzq`, etc.).

---

## Estándares de fabricación consolidados

| Parámetro | Valor estándar | Notas |
|---|---:|---|
| Longitud total | 2,400 mm | Rango configurable: 100 a 12,000 mm |
| Altura del cuerpo vertical (alma) | 225.50 mm | Cara principal del perfil |
| Calibre inicial | 14 | Inoxidable estándar (1.90 mm) |
| Radio interior de doblez | 1.50 mm | Dobleces normalizados |
| Pestaña superior | 31.75 mm | 1¼ pulgada (doblez 90°) |
| Pestaña inferior | 31.75 mm | 1¼ pulgada (doblez 45°) |
| Factor K | 0.45 | Factor de desarrollo de chapa |
| Escala de Logo A | 170% | 238 mm de ancho resultante |
| Ranuras horizontales | 4 | Longitud 300 mm, radio 30 mm |
| Tamaño de orificios de extremos | 11.00 × 11.00 mm | Cuadrado para tornillo 3/8" |
| Distancia orificio al borde | 31.75 mm | 1¼ pulgada del extremo |
| Paso entre orificios | 63.50 mm | 2½ pulgadas entre centros |
| Profundidad de corte en pestaña | $2\times$ espesor | Evita perforar el alma de 5° |

---

## Soluciones técnicas implementadas

### 1. Solución al corte "Por todo" que perforaba el alma de 5°
* **Problema:** En la llamada a `FeatureCut4`, la condición final `swEndConditions_e.swEndCondThroughAll` provocaba que la extrusión continuara indefinidamente en la dirección normal a la pestaña, atravesando el interior del perfil e impactando contra el alma inclinada de 5°.
* **Solución:** Se configuró como corte ciego `swEndConditions_e.swEndCondBlind` con profundidad igual a `cutDepth = (s.ThicknessMm / 1000.0) * 2.0`. Esto garantiza corte limpio a través del calibre sin tocar ninguna otra pared.

### 2. Centrado transversal exacto de orificios (`GetBox` + `ModelToSketchTransform`)
* **Problema:** Las fórmulas analíticas basadas en trigonometría no tomaban en cuenta el radio de doblez ni el desplazamiento del plano neutro de chapa, resultando en orificios descentrados en pestañas inclinadas.
* **Solución:** Se extrae la caja delimitadora 3D de la cara seleccionada (`face.GetBox()`), se calcula el centroide real de la cara en el modelo y se proyecta al sistema de coordenadas local del croquis interpolando entre $Z_\text{mín}$ y $Z_\text{máx}$.

### 3. Solución al estiramiento por *Snapping* en el croquis
* **Problema:** `CreateCenterRectangle` enganchaba sus vértices a las aristas del sólido, deformando los cuadrados a 24.95 mm.
* **Solución:** Se dibujan los 4 lados con llamadas directas a `CreateLine` con `AddToDB = true`.

### 4. Alineación en altura de barrenos para soportes C en perfiles y ensamblaje
* **Diagnóstico del problema:** Al ensamblar `SOPORTE_C` contra `PERFIL_LATERAL_LH` y `PERFIL_LATERAL_RH`, los orificios cuadrados de 11×11 mm no coincidían en altura. En el macro manual del usuario, la restricción coincidente de la pestaña superior del soporte con la pestaña del perfil dejaba el barreno del soporte en $Y = -26.10\text{ mm}$, mientras que los barrenos del perfil lateral estaban calibrados a $Y = -60.00\text{ mm}$ del borde superior (diferencia de $33.90\text{ mm}$).
* **Solución matemática e implementación:**
  - Los 6 orificios en ambos perfiles laterales (`PERFIL_LATERAL_LH` y `PERFIL_LATERAL_RH`) están estandarizados a $Y = -60.00\text{ mm}$ desde el borde superior del alma, con paso longitudinal idéntico: $Z = [55.50, 475.50, 895.50, 1504.50, 1924.50, 2344.50]\text{ mm}$.
  - En `SOPORTE_C`, las plaquitas soldadas en extremos tienen el barreno centrado en $X = 25.40\text{ mm}$ y $Y = 12.00\text{ mm}$.
  - El motor de ensamblaje automatizado (`SolidWorksEnsambleGenerator` en `src/EnsambleBandas.cs`) orienta transversalmente cada soporte C con la matriz ortogonal rígida:
    $$\begin{pmatrix} X_\text{assy} \\ Y_\text{assy} \\ Z_\text{assy} \end{pmatrix} = \begin{pmatrix} 0 & 0 & 1 \\ 0 & 1 & 0 \\ -1 & 0 & 0 \end{pmatrix} \begin{pmatrix} X_\text{part} \\ Y_\text{part} \\ Z_\text{part} \end{pmatrix} + \begin{pmatrix} 0 \\ -0.072 \\ Z_i + 0.0254 \end{pmatrix}$$
  - Esto coloca el centro de los barrenos de la plaquita izquierda y derecha exactamente en $Y = -60.00\text{ mm}$ y $Z = Z_i$, logrando una concentricidad de $0.000\text{ mm}$ en los 6 pares de orificios de ambos laterales.
  - Además, deja el lomo del soporte C en $Y = -31.24\text{ mm}$, profundidad ideal para que las pistas de Nylamid ($19.05\text{ mm}$) y la banda modular ($12.0\text{ mm}$) corran a ras del borde superior del transportador.

---

## Módulo de Ensamblaje Automatizado (`src/EnsambleBandas.cs`)
* Genera el archivo `piezas_ensamble\ENSAMBLE_BANDA.SLDASM`.
* Inserta y fija `PERFIL_LATERAL_LH` en el origen.
* Inserta y ubica `PERFIL_LATERAL_RH` paralelo a la distancia exacta de la luz del transportador.
* Inserta los 6 soportes C (`SOPORTE_C-1` a `SOPORTE_C-6`) montados exactamente en cada uno de los 6 orificios.
* Dispone del botón interactivo tanto en el configurador de perfiles como en el diseñador de soportes:
  `🚀 ARMAR ENSAMBLE COMPLETO EN SOLIDWORKS (2 LATERALES + 6 SOPORTES C ALINEADOS)`.
