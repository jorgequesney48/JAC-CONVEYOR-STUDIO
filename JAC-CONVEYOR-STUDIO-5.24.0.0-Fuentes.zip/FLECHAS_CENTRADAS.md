# Flechas centradas en la banda

Las flechas se muestran en el visor 3D y se generan como piezas SLDPRT dentro del ensamble de SOLIDWORKS cuando están activadas las placas del extremo y Generar y colocar flecha.

## Centrado y separación

La sección cuadrada queda centrada transversalmente a la banda. Desde la cara interior de cada placa hasta el hombro donde comienza el cuadrado quedan exactamente **10 mm**. Si las caras interiores están en X izquierda y X derecha:

- Inicio del cuadrado = X izquierda + 10 mm.
- Fin del cuadrado = X derecha − 10 mm.
- Largo cuadrado = distancia interior entre placas − 20 mm.
- Centro cuadrado = punto medio de las dos placas.

El visor utiliza la geometría nominal de perfiles y soportes. Al generar en SOLIDWORKS se recalcula con las caras medidas de las placas/perfiles. El eje queda a la misma altura y posición longitudinal de los barrenos de las chumaceras. El ancho de banda modifica el espacio entre placas y el largo cuadrado en tiempo real; el lado cuadrado y los largos cilíndricos conservan sus valores editables.

## Ajustes

En Detalles > 10 Placas / ejes > Apartado > Flecha 3D:

- Generar y colocar flecha.
- Lado del motor / cuñero: RH o LH (RH inicial).
- Lado cuadrado: 38.1 mm / 1.5 pulgadas inicialmente.
- Longitud cilíndrica del lado motor y del lado libre: 101.6 mm / 4 pulgadas inicialmente.
- Cuñero activo en la flecha motriz; la conducida usa extremos sin cuñero inicialmente.
- Ancho de cuñero 7.9375 mm, profundidad 3.97002 mm y longitud 50.8 mm inicialmente; son editables.

Los valores iniciales corresponden a los campos del GeneradorFlechaSolidWorks_v13. El diámetro cilíndrico se obtiene del asiento seleccionado para la chumacera (1 1/8, 1 1/4 o 1 1/2 pulgadas). El cuñero se abre hasta la punta del lado motor; el extremo opuesto conserva un cilindro liso. El sistema permite cambiar el lado del motor por cada extremo.

El largo cuadrado calculado aparece en el propio apartado Flecha 3D. Las medidas y el lado del motor se conservan en proyectos versión 7. Al abrir versiones anteriores se habilitan las flechas en los extremos con placas activas; el cuñero queda activo sólo en el motriz.

## Generación y límites

Cada extremo genera TRAMO_XX_TIPO_FLECHA.SLDPRT como un sólido paramétrico con centro cuadrado, extremo liso, asiento cilíndrico del motor y sección final con cuñero. La flecha se coloca y fija en el ensamble, con la sección cuadrada centrada y el lado motor elegido. REFERENCIAS_FLECHAS.json incluye archivo, posición del cuadrado, largo y configuración.

El ejecutable independiente GeneradorFlechaSolidWorks_v13.exe se conserva; el configurador de bandas genera la flecha con su propia integración CAD, sin controlar las ventanas del otro programa. Esta función coloca la flecha: todavía no añade modelos de sprockets, motor, cuñas ni tornillos. Los largos de los extremos y el cuñero deben corresponder al conjunto de chumacera y motor usado; son editables y no se obtienen del catálogo del motor.

## Verificación

scratch/ConveyorShaftSmoke.cs verifica ancho entre 100 y 1320 mm, centrado, separación de 10 mm, lados motor RH/LH, perfil de cuñero, copia y guardado de configuración, cambio de ancho interactivo y presencia en el visor. Su modo --cad comprueba una flecha real en SOLIDWORKS, incluyendo volumen y un único sólido, y genera una banda con dos flechas. El generador comprueba el centro colocado contra el eje y las caras medidas.
