# Visor GPU — versión 5.19

El visor utiliza automáticamente OpenGL de la tarjeta que Windows asigna a la aplicación. La tarjeta activa aparece en la vista 3D y en el diagnóstico de rendimiento. En equipos con dos adaptadores se puede asignar la GPU de alto rendimiento desde Configuración de Windows > Pantalla > Gráficos, seleccionando el ejecutable instalado.

La geometría se conserva en la GPU mientras se gira, desplaza o amplía el modelo. Superficies, contornos y texto se presentan juntos mediante un único intercambio de buffers. Los contornos mantienen el mismo detalle durante el movimiento y al detenerse; la navegación ya no requiere leer la imagen de la GPU para reconstruirlos. Los agujeros conservan su geometría real. Las curvas usan segmentos de un grado y el suavizado automático intenta MSAA 4×, después 2× y finalmente el formato normal si el controlador no lo admite.

Si el controlador no ofrece las funciones necesarias, el visor vuelve al renderizador CPU y muestra el motivo. También se puede cambiar de modo desde el menú Vista. Un proyecto guardado con preferencia CPU conserva esa elección. La sincronización vertical se solicita cuando el controlador ofrece la extensión correspondiente; sus ajustes pueden prevalecer.

## Instalación

El ZIP en `release` incluye ejecutable, dependencias, recursos y catálogos iniciales. Extraerlo completo y ejecutar `INSTALAR.cmd`. Se instala por usuario, sin administrador, y crea accesos directos. También se puede ejecutar directamente desde la carpeta extraída. Para actualizar, cerrar primero la aplicación y repetir la instalación; se preservan los catálogos existentes y los proyectos.

Destinado a Windows 10/11, con .NET Framework 4.8 recomendado y controlador gráfico del fabricante. No instala controladores ni garantiza aceleración en todos los equipos. El configurador funciona sin iniciar SolidWorks; generar CAD requiere una instalación compatible de SolidWorks.

Para crear otro paquete después de compilar: `powershell -ExecutionPolicy Bypass -File tools\Package-JAC.ps1`.

## Verificación local

Probado con NVIDIA GeForce RTX 4080 Laptop GPU: MSAA 4×, modelo de 16 798 caras y 40 posiciones consecutivas de giro sin cuadros vacíos ni reconstrucción de geometría. Mediana de la llamada de dibujo/presentación: 4,61 ms; percentil 95: 5,67 ms. Es una medición local con ventana de prueba, no una garantía de FPS ni de rendimiento en otros equipos.

Pasaron pruebas de profundidad en placas inclinadas, agujeros, selección, igualdad de detalle entre movimiento y reposo, cambio GPU/CPU en vista principal y ampliada, arrastre, y recuperación tras pérdida simulada del contexto. Se verificó instalación y actualización en una carpeta aislada, preservando proyecto y catálogo. No se probó en otra computadora ni se regeneraron piezas de SolidWorks para este cambio del visor.

Pruebas: `scratch/GpuStableSmoke.cs`, `GpuDepthStableSmoke.cs`, `GpuHolesSmoke.cs`, `RendererSwitchSmoke.cs` y `RendererDragSmoke.cs`. La prueba de arrastre solicita explícitamente el cuadro GPU porque su ventana está fuera de pantalla y Windows puede omitir WM_PAINT.

Referencias técnicas: [doble buffer de OpenGL en Windows](https://learn.microsoft.com/en-us/windows/win32/opengl/drawing-with-double-buffers) y [creación de contextos WGL](https://wikis.khronos.org/opengl/Creating_an_OpenGL_Context).
