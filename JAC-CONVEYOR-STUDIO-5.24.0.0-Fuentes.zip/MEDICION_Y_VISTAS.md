# Medición y vistas acotadas · JAC Bandas v5.5

## Medir en el visor

1. Pulsa **Medir caras** debajo del visor principal o ampliado.
2. Haz clic en la primera superficie (naranja) y en la segunda (azul).
3. Lee la **distancia mínima en mm**, sus componentes X/Y/Z y el ángulo entre las caras. La línea une los puntos de menor separación; no necesariamente los puntos donde hiciste clic.
4. Puedes girar con la rueda presionada y usar el zoom entre selecciones. Un arrastre izquierdo también gira; un clic selecciona la cara.
5. **Limpiar** inicia otra medición. **Salir de medir** o Escape vuelve al modo normal.

X es transversal a la banda, Y es altura y Z es longitudinal. Los valores ΔX/ΔY/ΔZ son magnitudes positivas. Dos caras en contacto dan distancia cero. Los barrenos y huecos no se consideran superficie sólida. Al reconstruir la geometría se limpia la medición anterior; cambiar CPU/GPU conserva la selección.

Se mide la geometría nominal del configurador. Las caras de piezas importadas corresponden a sus triángulos de visualización; las superficies curvas y radios esquemáticos no equivalen a una medición del CAD definitivo.

## Vistas acotadas

Selecciona el tramo y pulsa **Vistas acotadas**. También está en el menú **Vista**.

La lámina incluye:

- Frontal del tramo seleccionado, con el paso de banda ampliado: separación interior de perfiles, paso entre labios de guías y altura del perfil.
- Lateral de la banda completa y su largo total.
- Superior de la banda completa, ancho interior, largo del tramo seleccionado y largo total.
- Ancho y espesor de correa, espesor de perfil y holgura total respecto a las guías. La holgura por lado supone una correa centrada.

El paso libre se obtiene entre las caras interiores de los labios de las guías laterales: largo resuelto del soporte menos 12.7 mm y menos la holgura aprobada de las ranuras. Si las guías están desactivadas no se presenta esa cota.

Usa **100%** y las barras de desplazamiento para revisar detalles, **Ajustar** para ver la hoja completa y **Guardar lámina PNG** para exportar 2400 × 1800 píxeles. La lámina es una instantánea de la configuración al abrirla; vuelve a abrirla después de cambiar parámetros.

No se necesita abrir ni generar en SolidWorks para medir o obtener estas vistas.