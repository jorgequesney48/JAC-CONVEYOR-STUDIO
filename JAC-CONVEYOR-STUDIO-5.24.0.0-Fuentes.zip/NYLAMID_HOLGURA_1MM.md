# Ranuras de nylamid con 1 mm de holgura

Las tiras mantienen su ancho de 0.75 pulgadas (19.05 mm). El ancho predeterminado de las ranuras del soporte C es 20.05 mm: 1 mm adicional total.

Las dos tiras laterales permanecen pegadas a las caras interiores de los perfiles: la izquierda comienza en X=0 y la derecha termina en X=largo del soporte. La holgura lateral de 1 mm queda hacia el interior de la banda. Las tiras centrales se centran en las ranuras y dejan 0.5 mm libres a cada lado. Se conservan las profundidades y la nivelación vertical.

La misma distribución se usa en el visor, las cotas, el ensamble de SolidWorks y las guías superiores/inferiores de curvas. El editor mantiene sincronizados ancho de ranura y holgura total.

Los proyectos `.jacband` pasan a versión 16. Al abrir proyectos anteriores, las ranuras estándar de 19.05 mm se actualizan a 20.05 mm. Los anchos personalizados se conservan; el proyecto actualizado queda pendiente de guardar.

Validación: `scratch/RunNylamidSlotToleranceRegression.ps1 -Cad` pasa 249 comprobaciones de contacto lateral, holgura central, cotas, malla, migración y editor. La generación nativa de un soporte C confirma aristas de ranura de 20.05 mm en SolidWorks.
