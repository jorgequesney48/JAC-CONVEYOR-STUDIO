# Unión transversal de patas — v5.17

Cada estación de patas lleva por defecto un PTR que une las caras interiores del par, formando una H. Se orienta transversalmente, perpendicular a los perfiles longitudinales. Su eje queda a 10 pulgadas (254 mm) del piso de la base niveladora. La altura es al centro del PTR, no a su borde inferior.

En Patas se puede desactivar «Unir cada par de patas en H» y ajustar «Altura del eje del travesaño desde la base · in». La sección sigue el PTR vertical seleccionado: 1½ o 2 pulgadas, con pared de 3 mm como la representación de las patas. El largo se calcula entre caras interiores, sin penetrar en las patas. La unión se representa a tope; no se añaden cordones de soldadura.

Se incluye una unión por estación existente, tanto extremos como juntas y estaciones centrales, respetando el reparto actual de patas. Cambiar ancho de banda, sección del PTR o altura actualiza el visor. Se comprueba que la sección completa del travesaño quede por encima de la tapa inferior y por debajo del montaje superior.

La pieza editable `TRAMO_…_PTR_UNION_H.SLDPRT` se genera y se coloca en el ensamble de SolidWorks. Se reutiliza por estación de un mismo tramo. La lista de piezas y REFERENCIAS_PATAS.json incorporan cantidades, largos y altura del eje. La configuración se guarda dentro de VerticalSupports del proyecto.

Pruebas: LegCrossbarSmoke verifica predeterminados, ambas secciones, alturas de banda de 900 y 1300 mm, contacto entre caras interiores, orientación, desactivación, rechazo de alturas que invaden tapas o salen del PTR, serialización y lista de piezas. LegCrossbarCadSmoke crea y abre las piezas reales de 1½ y 2 pulgadas en SolidWorks, verifica dimensiones y transformación transversal y restaura el documento que estaba activo. No se regeneró un ensamble completo del usuario durante esta entrega. Captura de prueba: auditoria/2026-10-05/interfaz/patas-h.png.
