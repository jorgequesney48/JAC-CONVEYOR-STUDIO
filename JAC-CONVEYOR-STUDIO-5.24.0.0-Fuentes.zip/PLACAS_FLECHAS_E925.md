# Placas de flecha E925 — uso e implementación

Actualización: los proyectos nuevos pueden usar un contorno con alivio inferior cóncavo y radios configurables. Consulta [Rediseño de placas y accesos](REDISENO_PLACAS_Y_ACCESOS.md). Las referencias de montaje de este documento se conservan; la descripción rectangular corresponde al modo anterior.

## Separación de chumacera y prolongación de nylamid

La solicitud posterior exige **50.8 mm libres desde el borde del barreno más cercano hasta el extremo del perfil**. Los barrenos de chumacera y la abertura central ya no se trasladan al perfil; éste sólo recibe los tres cuadrados de solape. Se verifica la separación antes de generar y también en los generadores de piezas.

El usuario autorizó prolongar sólo el nylamid para conservar B. Con paso 102 mm y diámetro 16 mm de la prueba, el eje queda a `50.8 + 102/2 + 16/2 = 109.8 mm` del perfil. Con B de 45 mm, las tiras se prolongan `109.8 - 45 = 64.8 mm` hacia la flecha. La abertura central también se considera: se utiliza el mayor alcance entre su radio y medio paso más el radio de barreno.

Los perfiles conservan su longitud. Las tres pistas se prolongan únicamente en el extremo exterior del conducido o motriz con placas activadas; los extremos de empalme y los intermedios siguen al ras. Las plaquitas del soporte quedan al nivel inferior del nylamid lateral; se elimina el alojamiento local inferior usado por la versión anterior.

## En la aplicación

Seleccionar el tramo conducido o motriz y abrir **10 Placas / ejes**. Activar «Generar dos placas para esta flecha». La configuración se guarda por tramo en el proyecto `.jacband`. Al duplicar un extremo como intermedio, las placas se desactivan en la copia.

Tres grupos mantienen separados los ajustes:

1. **Banda y flecha:** 12, 16 o 20 dientes, asiento de 1 1/8, 1 1/4 o 1 1/2 pulgadas y B elegida.
2. **Dimensiones de placa:** longitud automática o manual, cobertura, solape, barrenos de unión y descripción de fijación.
3. **Montaje de chumacera:** referencia completa, abertura central, paso de cuatro barrenos, diámetro de perforación y envolvente de la chumacera.

La vista se puede cambiar entre lateral y transversal. Los errores de configuración impiden generar y aparecen tanto en el apartado como en el estado de la banda.

## Referencias confirmadas

| Dientes | Ø primitivo mm | A mm | B máxima mm |
|---|---:|---:|---:|
| 12 | 96.59 | 42 | 47 |
| 16 | 128.15 | 58 | 54 |
| 20 | 159.81 | 73 | 59 |

Tabla aportada por el usuario, interpretada en mm. `Y_eje = Y_rodadura - A`. El plano de rodadura corresponde a las tiras centrales y al escalón interior de las laterales; la ceja exterior no se usa como referencia. El diámetro del asiento no altera A.

Espesor de placa: **3/16 in = 4.7625 mm**.

## Espesor y nivel de banda

En **01 Dimensiones**, configurar **Espesor de la banda · mm** (E925: 12 mm). En **03 Orificios C**, activar **Nivelar según espesor de banda**. La altura del nylamid, los barrenos de soportes y el eje de flecha se actualizan para que la cara superior de la banda quede al ras del doblez superior de 90°. La medida A del fabricante sigue bajando desde el plano de rodadura. Con 16 dientes y banda de 12 mm, el eje queda a 70 mm bajo el perfil. Cada tramo guarda su ajuste; una banda completa requiere el mismo modelo, ancho y espesor en todos sus tramos. El botón **Usar esta banda en todos los tramos** aplica las tres medidas.

La altura manual sigue disponible al desactivar la nivelación. Los proyectos anteriores adoptan 12 mm y nivelación automática y quedan marcados para guardar la actualización.

## Solape y cobertura

La placa apoya con su **cara interior sobre la cara exterior del perfil**. El solape mínimo de **50.8 mm (2 in)** es editable. Sus tres cuadrados bajan **25.4 mm** respecto al reparto vertical anterior, tanto en placa como en perfil. La placa incorpora un paso circular de **Ø31.75 mm (1.25 in)** centrado en el tornillo del soporte exterior cuando su cabeza intersecta el solape; el perfil conserva el barreno cuadrado original del soporte. Los cuatro barrenos propios de la chumacera conservan su forma circular.

Los tres cuadrados quedan exactamente a la mitad del solape real. El solape se amplía cuando hace falta para alojar el paso circular completo y dejar 4 mm de material al borde interior. La distribución vertical de los cuadrados se ajusta para conservar 4 mm debajo del paso circular, sin mover su columna longitudinal. Con el centro del soporte a 55.5 mm del extremo, el solape real es 75.375 mm y la columna queda a 37.6875 mm del extremo. Las ranuras laterales reservan este solape efectivo.

Se conservó también una alternativa de prolongación al ras; ésta no genera una unión soldada ni orejas.

El contorno es rectangular con dos esquinas R20 en el extremo libre (radio reducido para tamaños pequeños). En la zona solapada se practican alivios respecto a las tangencias de los dobleces, con separación geométrica de 0.25 mm. La extensión mantiene el borde superior al nivel del doblez superior de su perfil.

La distancia del extremo exterior al eje toma el mayor entre el radio primitivo más el margen de cobertura y la mitad de la envolvente de la chumacera más 20 mm. La longitud automática suma esa distancia, **la distancia eje–perfil necesaria para los 50.8 mm libres y el solape**. El margen solicitado inicial de **10 mm** se limita automáticamente al espacio disponible entre el círculo primitivo y los bordes de placa, manteniendo el borde superior al nivel del perfil; la interfaz muestra el margen real (5.925 mm en la prueba de 16 dientes y banda de 12 mm). Es una propuesta de diseño editable, no un diámetro exterior ni un espesor de banda publicados por el fabricante. Debe contrastarse con el conjunto real. Los cuadrados de solape de **11 × 11 mm** también son una propuesta editable; el módulo no dimensiona la resistencia de la unión.

El CAD mide ambas caras de perfil, sus tangencias y la cara superior. Se invierte el sentido del espesor en RH para que LH/RH sean espejos, tengan la cara interior local X=0 y compartan el nivel superior Y=0. El ensamble coloca RH a la longitud del soporte y ambos ejes quedan coaxiales.

B coloca el eje respecto al extremo del nylamid, según el esquema del fabricante. El nylamid se prolonga automáticamente al separar la flecha del perfil. Una longitud manual de placa que deje los barrenos a menos de 50.8 mm del perfil se rechaza; si cumple, la prolongación conserva B.

Las plaquitas del soporte conservan su contorno original y barreno: su borde superior local está a `Flange1HeightMm - 12.7 mm` (25.4 mm con la pestaña de referencia de 38.1). Ambos dobleces del canal se alargan `max(0, profundidad lateral - 12.7)` mm: 6.35 mm con ranura lateral de 19.05. Las alturas reales son 44.45 y 57.15 mm con las referencias de 38.1/50.8. Con nivelación automática, el centro del soporte se calcula a partir del espesor de banda y la altura real de sus dobleces. Para E925 de 12 mm, el barreno queda a 57.15 mm bajo el borde superior y la rodadura a Y=-12 mm. La plaquita sigue coincidiendo con la cara inferior del nylamid lateral. No se recorta el contorno de la plaquita ni se hace un alojamiento inferior en la tira.

Las ranuras del perfil se resuelven en espacios disponibles fuera del solape de la placa, reservando 10 mm alrededor de los barrenos de soportes y 20 mm junto al logo. El ajuste automático puede cambiar posición, longitud, radio y cantidad efectiva. En modo manual, una intersección se rechaza. CAD y vista previa usan la misma lista de ranuras resueltas.

## Chumacera: datos necesarios

F208 identifica el alojamiento indicado por el usuario, pero no determina la abertura de placa del montaje. Los campos de la abertura, patrón y envolvente comienzan pendientes, para introducir las medidas del conjunto real y el inserto utilizado con cada asiento.

Referencia informativa: [JTEKT UCF208](https://koyo.jtekt.co.jp/en/products/detail/print.php?pno=UCF208) publica un cuerpo de 130 mm, paso cuadrado de 102 mm, barrenos del alojamiento de 16 mm y asiento métrico de 40 mm. Esta referencia no selecciona un inserto para los tres diámetros en pulgadas ni define automáticamente la perforación de la placa.

## Archivos generados

- Dos `TRAMO_nn_TIPO_PLACA_FLECHA_LH/RH.SLDPRT` por extremo activado.
- Tres cuadrados coincidentes en cada perfil y placa. Los cuatro barrenos circulares de chumacera y la abertura central se realizan únicamente en las placas.
- Pletinas prolongadas hacia las flechas donde se activan las placas, sin alojamiento inferior para la plaquita nivelada.
- `BANDA_COMPLETA.SLDASM` con las placas insertadas y fijas.
- `REFERENCIAS_FLECHAS.json`: ejes en coordenadas globales, rodadura, A/B, dientes, asiento, dimensiones de placas, extremos y prolongación de nylamid y separación barreno–perfil. Es un archivo de intercambio documentado; el ejecutable anterior no lo importa automáticamente.

## Ejecutable de flechas existente

Se inspeccionó `GeneradorFlechaSolidWorks_v13.exe` sin modificarlo ni ejecutar su lógica. Es un paquete .NET con `GeneradorFlechaSolidWorks.dll`. Su `Main` no recibe argumentos y no se encontraron referencias a lectura de argumentos. Contiene un formulario, un generador de flechas/sprockets y otro de placas. Sus campos iniciales de placa incluyen patrón 95 × 75 mm, abertura 40 mm y barrenos 14 mm; no se trasladaron como medidas confirmadas de la F208.

La integración automática de flechas requiere adaptar ese código a un contrato de entrada o disponer de su fuente. Este módulo genera las placas y las referencias; aún no inserta flechas, sprockets, chumaceras, tornillos ni motor como sólidos.

## Comprobaciones

`scratch/ShaftPlateSmoke.cs` comprueba tabla, diámetros, B fuera de rango, copia independiente, persistencia y vistas. El modo `--cad` genera un ensamble de prueba con parámetros de chumacera explícitamente sintéticos, sin sustituir la ficha del usuario. El generador verifica el volumen de las placas, el volumen retirado al perforar perfiles y la posición de los ejes.

La revisión del ensamble guardado en `scratch/shaft-plates-cad-20261002-003017` pasó con dos tramos de 600 y 900 mm, 18 componentes y cuatro placas. Se midieron los tres cuadrados de 11 × 11 mm en cada placa: su columna coincide con la mitad exacta del solape de 75.375 mm. Cada paso circular mide Ø31.75 mm y está centrado en el tornillo del soporte exterior. Las seis pistas tienen su plano de rodadura a 12 mm bajo el doblez superior; ambos perfiles tienen la cara superior Y=0. El eje de 16 dientes queda a Y=-70 mm, manteniendo A=58. Las plaquitas conservan su volumen y coinciden con la cara inferior del nylamid; no comparten volumen con las tiras. Las seis tiras se prolongan 64.8 mm sólo en los extremos exteriores. B se conserva en 45 mm, el eje queda a 109.8 mm del perfil y el barreno de chumacera más cercano conserva 50.8 mm libres. Las ranuras respetan el solape y los barrenos C. También se probaron espesores configurables de 12, 18 y 20 mm, la separación entre cuadrados y paso circular, el rechazo de espesores incompatibles entre tramos y la persistencia del espesor y modo de nivelación en proyectos.

La verificación geométrica no incluye cálculo de cargas, tensiones de tornillos, flexión de placa o dimensionamiento de la flecha. Tampoco confirma interferencias con piezas comerciales que todavía no se han suministrado como CAD.

## Integración de flechas centradas

El configurador ahora genera y coloca flechas paramétricas en su propio ensamble y visor 3D. La sección cuadrada sigue el ancho de banda y queda 10 mm dentro de cada cara interior de placa. El motor y cuñero pueden orientarse a RH o LH. Detalles y medidas iniciales en [FLECHAS_CENTRADAS.md](FLECHAS_CENTRADAS.md).
