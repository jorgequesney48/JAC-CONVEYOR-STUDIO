# Plan de modificación: distribución automática de logo y ranuras

Estado: implementado en el programa. Uso, criterios finales y comprobaciones en [DISTRIBUCION_LOGO_RANURAS_300.md](DISTRIBUCION_LOGO_RANURAS_300.md). El contenido siguiente conserva el plan previo como referencia de diseño.

## 1. Objetivo y alcance

Reemplazar la distribución actual por un patrón automático que conserve material libre de 300 mm entre elementos consecutivos —ranura/ranura o ranura/logo— y 150 mm entre la abertura extrema y cada extremo físico del perfil. Al unir dos perfiles sin separación, sus márgenes sumarán 300 mm.

El largo y cantidad de ranuras, sus posiciones, sus radios y la posición/presencia efectiva del logo serán resultados del cálculo. El usuario editará solamente tres parámetros relacionados con las ranuras: altura de abertura, separación libre y elevación respecto al doblez inferior.

Los rodillos volverán a barrenos circulares cerrados. Se retirará la obligación de que una ranura cubra cada rodillo, así como las guías abiertas de 9 mm y sus asientos. Se conservarán el reparto mecánico de rodillos, sus alturas, diámetros y catenaria. Se conservará el rediseño exterior de las placas de flecha: esta petición cambia la distribución de cortes del perfil y el alojamiento de los rodillos.

## 2. Convenciones que utilizará el diseño

### 2.1 Distancias horizontales

- **G:** separación libre entre bordes exteriores de dos elementos consecutivos. Valor inicial: 300 mm. No es paso entre centros.
- **E:** margen libre desde el extremo físico del perfil hasta el borde de la primera o última abertura. Se calcula como `E = G / 2`; inicialmente 150 mm.
- **W:** ancho horizontal exterior real del logo, incluyendo todas sus islas y trazos. No se medirá entre centros de letras ni respecto al origen de su croquis.
- **L:** longitud final del perfil, incluyendo los márgenes de ambos extremos.
- **S:** longitud total de cada ranura, incluidos sus extremos redondeados.

G será común a la banda completa. Permitir valores distintos por tramo rompería el criterio de las uniones: 150 mm más 200 mm, por ejemplo, ya no son 300 mm. Los extremos terminales conservarán también E mientras se utilice esta regla.

Si el montaje incorpora una separación física J entre perfiles, el espacio entre aberturas será `E izquierdo + J + E derecho`. La garantía de 300 mm corresponde a una unión sin separación. Las placas de unión y solapes son obstáculos adicionales, no nuevos orígenes para medir E.

### 2.2 Distancias verticales

- **H:** altura de la abertura de arriba abajo; no es el espesor de lámina.
- **D:** distancia vertical desde la tangencia del doblez inferior con el alma recta hasta el borde inferior de la ranura.
- **Yt:** coordenada de dicha tangencia. El borde inferior estará en `Yt + D` y el centro en `Yt + D + H/2`.
- Los extremos de la ranura serán semicirculares, con radio derivado `R = H/2`.

Esta referencia evita medir desde una arista exterior que cambia con calibre y radio de doblez. En CAD se utilizará la tangencia medida; la vista previa utilizará el mismo criterio geométrico. La interfaz mostrará explícitamente una flecha de cota desde la tangencia. El código llama 135° al ángulo interior correspondiente al doblez inferior de 45°; se verificará esa equivalencia al medirlo.

El centro vertical del logo se alineará inicialmente con el centro de las ranuras para formar una misma franja visual. Su altura completa deberá caber en el alma. Si no cabe, se informará el conflicto; no se deformará ni encogerá silenciosamente.

### 2.3 Sentido de recorte

Para explicar y probar los casos se parte de un patrón de referencia de 2400 mm y se recorta desde la izquierda, conservando el extremo derecho. Los casos inversos serán su espejo. La longitud de referencia no se confundirá con la longitud final ni se sustituirá por ésta después de cada edición.

Propuesta inicial: registrar el sentido de recorte como dato del configurador de tramos, no como otro parámetro de ranura. Hasta que el configurador especifique otro criterio, utilizar un sentido canónico reproducible; no deducirlo de si se genera LH o RH. Ambos laterales deben recibir la misma distribución longitudinal.

Los 2400 mm se consideran referencia del ejemplo, no un límite universal de fabricación. Para perfiles mayores, el cálculo podrá conservar el patrón de cuatro ranuras y ampliar sus longitudes si pasa las comprobaciones; cualquier límite de abertura larga deberá ser explícito. No dividir automáticamente un perfil de más de 2400 mm en módulos sin que lo determine el configurador de banda.

## 3. Patrón de referencia y estados de reducción

Patrón completo, de izquierda a derecha:

`extremo — E — R1 — G — R2 — G — LOGO — G — R3 — G — R4 — E — extremo`

Las etiquetas R1–R4 identifican ranuras del patrón de referencia, no posiciones que deban conservarse después de redistribuir.

| Situación del recorte de referencia | Elementos eliminados | Distribución final a calcular |
|---|---|---|
| Perfil completo | Ninguno | R1, R2, logo, R3, R4 |
| El corte alcanza R1 | R1 | R2, logo, R3, R4 |
| El corte alcanza R2 | R1 y R2 | R3, logo, R4 |
| El corte alcanza el logo | R1, R2 y logo | R3, R4 |
| El corte alcanza R3 | R1, R2, logo y R3 | R4 |
| El corte alcanza R4 o queda una longitud extrema | Patrón agotado | Aplicar comprobación explícita de longitud mínima; no emitir una abertura degenerada |

En el caso de dos ranuras con logo, éste se colocará **entre las dos**, centrado en el conjunto. En el caso de tres ranuras, se conservará una antes del logo y dos después, invirtiéndose en el recorte opuesto. El logo no se forzará al centro del perfil cuando ese patrón es asimétrico.

Todas las posiciones se recalcularán después de seleccionar el estado. No se cortará un patrón viejo y se dejarán medias ranuras abiertas al extremo.

## 4. Cálculo exacto de longitudes

Si quedan N ranuras y K logos, donde K vale 0 o 1, hay `N + K - 1` separaciones interiores. La longitud disponible para ranuras será:

`T = L - 2E - (N + K - 1)G - K·W`

Con `2E = G`:

`T = L - (N + K)G - K·W`

Propuesta visual inicial: todas las ranuras de un mismo estado tendrán igual longitud, `S = T/N`. Así se evita un conjunto de longitudes arbitrarias y el cálculo resulta comprobable. La regla permite que crezcan al eliminar elementos. Si una longitud común no satisface los obstáculos, no se cambiará G ni E a escondidas.

| Patrón | Longitud de cada ranura |
|---|---|
| 4 ranuras y logo | `(L - 5G - W) / 4` |
| 3 ranuras y logo | `(L - 4G - W) / 3` |
| 2 ranuras y logo | `(L - 3G - W) / 2` |
| 2 ranuras sin logo | `(L - 2G) / 2` |
| 1 ranura sin logo | `L - G` |

### Ejemplo numérico verificable

Con G=300 mm y un logo de W=238 mm —140 mm a escala 170 %, según los parámetros actuales; confirmar también su caja geométrica real—:

| L final | Estado usado como ejemplo | S resultante | Márgenes |
|---:|---|---:|---:|
| 2400 mm | 4 ranuras + logo | 165.5 mm | 150 mm por extremo |
| 2150 mm | 3 ranuras + logo | 237.333… mm | 150 mm por extremo |
| 1700 mm | 2 ranuras + logo | 281 mm | 150 mm por extremo |
| 1200 mm | 2 ranuras sin logo | 300 mm | 150 mm por extremo |
| 700 mm | 1 ranura sin logo | 400 mm | 150 mm por extremo |

Estos largos se eligieron para representar los estados del recorte; no son umbrales universales. Los umbrales se obtendrán del patrón de referencia real y del tamaño de logo utilizado.

Una sola ranura en un perfil de 600 mm mediría 300 mm con este criterio. Por tanto, que quede una sola no significa necesariamente que deba ser más corta que las originales. Se reducirá cuando L lo requiera, sin perder sus márgenes.

Los cálculos conservarán precisión completa. Las cotas mostradas podrán redondearse, pero no se construirá CAD acumulando dimensiones redondeadas.

## 5. Casos no definidos directamente por los ejemplos del usuario

### 5.1 Corte en un puente o en el margen inicial

Se deben tratar expresamente, porque no todo corte cae dentro de una ranura o del logo.

Propuesta:

1. Determinar qué elementos quedan afectados por el plano de corte del patrón de referencia.
2. Elegir inicialmente el estado correspondiente a los elementos supervivientes.
3. Recalcular sus longitudes con G y E exactos.
4. Para los estados de varias ranuras, dar preferencia a conservar o ampliar el largo de referencia, coherente con la petición de alargar las restantes.
5. Si esto no cabe, avanzar al siguiente estado de reducción antes de disminuir las separaciones o generar una ranura inviable.
6. Mostrar la razón del cambio: por ejemplo, «Se elimina una ranura adicional para conservar 300 mm interiores y 150 mm en los extremos».

Esto puede adelantar una eliminación antes de que el plano de corte alcance literalmente la siguiente ranura. Es una propuesta para resolver los cortes en puentes y márgenes; no estaba especificada expresamente en los ejemplos. Si se prefiere conservar más ranuras acortándolas también en estos estados, cambia esta prioridad, pero no las ecuaciones ni la arquitectura.

### 5.2 Perfil demasiado corto

La condición geométrica mínima de una cápsula es `S > H`: debe quedar un tramo recto entre sus extremos. Se definirá además un tramo recto mínimo interno de fabricación, documentado y no editable como largo de ranura.

Para una sola ranura: `L >= G + Smin`. Si no se cumple, bloquear el patrón y explicar la longitud mínima necesaria. No convertirla en un círculo ni reducir G automáticamente. El configurador actual admite tramos desde 600 mm; no se ampliará ese rango como efecto secundario.

### 5.3 Logo desactivado o que no cabe

La ausencia de logo no desactivará las ranuras. Para «Sin marca», se resolverá una familia sin logo con los mismos márgenes y separaciones. Si el usuario sí eligió logo, se omitirá sólo por el estado de reducción previsto, no porque el código encuentre un hueco incómodo. Distinguir configuración del logo y presencia efectiva en el tramo permitirá restaurarlo automáticamente al volver a alargarlo.

### 5.4 Obstáculos del montaje

El patrón se comprobará contra cuadrados de soportes, solapes y fijaciones, dobleces, cortes de unión y barrenos de rodillos. Las distancias se verificarán en el plano del alma, considerando ambas coordenadas, para no prohibir una ranura sólo porque coincide longitudinalmente con un agujero situado a otra altura.

No se aumentará el margen extremo a costa del criterio de 150 mm sin informar. Si una placa invade el espacio exigido, o un soporte coincide con un corte y no hay solución permitida, declarar incompatibilidad y señalar las cotas involucradas. La modificación del reparto de soportes no forma parte de este cambio.

## 6. Pasos de implementación

### Paso 1 — Fijar especificación y ejemplos de referencia

1. Crear los cinco esquemas de distribución con cotas G, E, H, D y W.
2. Calcular los intervalos reales de R1, R2, logo, R3 y R4 en el perfil de referencia.
3. Documentar el sentido de corte, la medición entre bordes y la referencia vertical.
4. Incluir cortes dentro de cada abertura y dentro de cada puente.
5. Registrar la prioridad propuesta para los casos de puentes/márgenes del apartado 5.1 como decisión visible del diseño.

Entrega: tabla de referencia y ejemplos numéricos que luego se usarán como pruebas independientes.

### Paso 2 — Retirar el acoplamiento con rodillos

1. Cambiar el comportamiento activo a barrenos circulares cerrados.
2. Retirar de la interfaz el modo de asientos abiertos, las ventanas por rodillo, el tableado y la profundidad de guía.
3. Conservar diámetro de eje, holgura del barreno, diámetro de rodillo, alturas, distancias a flechas y catenaria.
4. Eliminar de la ruta de generación los cortes de guía y asientos abiertos, y la exigencia de cobertura por ventana.
5. Conservar la posibilidad de probar otro reparto mecánico válido de rodillos si un barreno choca con una ranura; nunca modificar el nuevo patrón de ranuras para garantizarle acceso.
6. Si un rodillo de referencia fija choca y no puede moverse dentro de los criterios existentes, bloquear e identificar el conflicto.

Archivos: `ReturnRollerLayout.cs`, `ReturnRollerGenerator.cs`, `ReturnRollerEditor.cs`, `ProfileSlotLayout.cs`, `CompleteBeltGenerator.cs` y vistas.

Entrega: modo de rodillos nuevamente circular y sin dependencia funcional de las ranuras.

### Paso 3 — Crear los datos del nuevo patrón

Entradas propuestas:

- Separación libre G, común a la banda.
- Altura de abertura H.
- Distancia inferior D a la tangencia del doblez.
- Referencia de longitud y sentido de recorte, gestionados por el configurador.
- Tipo y escala elegidos de logo, conservados como configuración de marca.

Resultado calculado único:

- Estado seleccionado y motivo.
- Lista de ranuras con extremos, centro, altura, radio y longitud efectiva.
- Logo visible/omitido, posición X/Y y caja exterior real.
- Márgenes y separaciones resultantes.
- Diagnósticos y cualquier incompatibilidad.

La posición vertical ya no debe depender del indicador `Functional`, que hoy representa los accesos de rodillos. Todas las ranuras nuevas tendrán coordenadas explícitas. `SlotCount`, `SlotOverallLengthMm`, `SlotSpacingMm` y `SlotEndRadiusMm` dejarán de ser fuentes de decisión editables; quedarán únicamente como datos antiguos si hacen falta para migrar.

Entrega: modelo de datos desacoplado, compartido por cálculo, vista y CAD.

### Paso 4 — Implementar un resolvedor determinista

1. Validar que L, G, H, D y dimensiones de marca sean finitas y físicamente utilizables.
2. Construir el patrón de referencia y clasificar el recorte.
3. Seleccionar el primer estado permitido y calcular S.
4. Aplicar el criterio de longitud mínima y las prioridades del apartado 5.
5. Construir posiciones acumulando desde E: elemento, G, elemento, etc.
6. Comprobar que el último borde termine exactamente en `L - E`, dentro de la tolerancia numérica.
7. Calcular el centro del logo a partir de su lugar en la secuencia; no usar `L/2` de forma universal.
8. Aplicar H y D a las coordenadas verticales.
9. Comprobar colisiones y material remanente.
10. Devolver el resultado completo o un error explicativo. Nunca devolver una lista incompleta ocultando una ranura fallida.

Archivos: reestructurar `ProfileSlotLayout.cs`; sustituir `FitSlotsAndMark` y las reglas de sólo 2/4/6 ranuras de `BeltLinePlan.cs`. Puede añadirse una clase específica de patrón para que la lógica no quede repartida entre controles.

Entrega: función geométrica sin llamadas a SolidWorks ni dependencias de interfaz, fácil de comprobar.

### Paso 5 — Integrar banda completa y resolver conflictos

Orden único de cálculo:

`tramos y referencias → soportes/placas → patrón de ranuras y logo → barrenos de rodillos → validación final → CAD`

1. Resolver cada tramo con sus referencias reales.
2. Verificar los márgenes de ambos lados de cada unión.
3. Distribuir los rodillos contra el patrón ya resuelto.
4. Sustituir la comprobación actual del logo centrado por su caja y posición efectivas.
5. Evitar que `ReturnRollerLayout.Apply` vuelva a redistribuir las ranuras después de calcular los rodillos.
6. Usar el mismo resultado en el configurador y en la generación; no recalcular con reglas diferentes al pulsar Generar.

Entrega: coincidencia entre la validación de banda y las piezas producidas.

### Paso 6 — Simplificar la interfaz

En «Marca / ranuras», dejar estos controles de ranura:

| Control | Comportamiento |
|---|---|
| Altura de ranura · mm | H; determina también su radio |
| Separación libre · mm | G, inicialmente 300; aplica a toda la banda |
| Borde inferior de ranura sobre doblez · mm | D, desde la tangencia del doblez inferior |

Retirar cantidad manual, largo manual, paso entre centros, radio independiente y alternancia manual/automático de ranuras. Actualizar también la pantalla antigua de generación individual, no sólo el configurador por tramos.

Mostrar como resultados no editables:

- Cantidad final de ranuras y longitud calculada.
- «Logo incluido» u «Omitido por longitud del tramo».
- Margen de extremo `G/2`.
- Patrón utilizado y explicación de una eliminación.

La selección/escala del logo seguirá perteneciendo a Marca, no a los tres parámetros de ranura. Cualquier cambio de tamaño recalculará el patrón; no modificará G silenciosamente.

Entrega: controles coherentes en ambas pantallas y estado del botón Generar ligado a la validación real.

### Paso 7 — Actualizar las vistas

1. Dibujar el logo en su centro calculado y omitirlo cuando corresponda al estado.
2. Dibujar las ranuras con H y D reales, sin centrar siempre la franja en el alma.
3. Mostrar cotas de 150/300 mm o los valores derivados de G.
4. Añadir una vista de dos perfiles unidos para comprobar la suma de márgenes.
5. Volver a dibujar los barrenos circulares de rodillos.
6. Señalar obstáculos y conflictos sin presentar como válido un patrón incompleto.

Archivos: `PerfilBandas.cs`, `CompleteBeltView.cs`, `ReturnRollerEditor.cs` y vistas que consuman el perfil.

Entrega: las mismas posiciones que se exportarán a SolidWorks, con lectura clara de las separaciones.

### Paso 8 — Actualizar CAD y referencias exportadas

1. Usar centros de logo y ranuras calculados, transformados al croquis desde coordenadas del modelo.
2. Mantener líneas/arcos explícitos para evitar que las relaciones automáticas desplacen las ranuras.
3. Admitir 1, 2, 3 y 4 ranuras, con o sin logo según el estado.
4. Calcular el número de segmentos esperado a partir de los contornos efectivos, no de supuestos de 2/4/6 ranuras y logo siempre presente.
5. Generar sólo barrenos circulares en el módulo de rodillos.
6. Exportar estado, G, E, H, D, posiciones reales, anchos y presencia del logo.
7. Registrar por separado parámetros solicitados y valores derivados para poder auditar una pieza.

Entrega: piezas LH/RH con cortes pasantes coincidentes y datos suficientes para comprobar las cotas.

### Paso 9 — Migrar proyectos guardados

1. Incrementar el formato de proyecto a versión 3 y aceptar lectura de versiones 1 y 2.
2. Conservar dimensiones de perfiles, soportes, placas, referencias mecánicas y configuración de rodillos.
3. Convertir el modo abierto de versión 2 a barrenos cerrados conforme a esta petición; informar del cambio en el resumen del proyecto.
4. Inicializar G en 300 mm. Convertir la altura antigua como `H = 2·radio anterior` cuando corresponda.
5. Obtener D de la posición anterior de la ranura y la tangencia inferior. Si resulta inválido, solicitar corregir la cota mostrando el rango admisible; no aceptar una intersección con el doblez.
6. Descartar resultados calculados de versiones anteriores y resolver nuevamente el patrón.
7. Marcar el proyecto como modificado para que se guarde la actualización. No sobrescribir automáticamente archivos de usuario ni regenerar CAD existente al abrirlos.
8. No aplicar otra vez las migraciones antiguas que pudieran resetear el estilo de placa o referencias ya configuradas.

Entrega: lectura reproducible de proyectos anteriores sin reactivar las guías de rodillos.

### Paso 10 — Pruebas geométricas

Comprobar, como mínimo:

- Perfil de 2400 mm: cuatro ranuras, logo, cuatro espacios de 300 mm y márgenes de 150 mm.
- Corte dentro de R1, R2, logo, R3 y R4; cortes exactamente sobre sus límites.
- Corte en cada puente y en el margen inicial.
- Recorte desde el lado contrario: distribución en espejo, no cambio de logo legible.
- Cambiar el orden de edición de largos debe producir el mismo resultado final.
- Acortar y volver a alargar debe restaurar elementos eliminados, incluido el logo.
- Dos ranuras con logo: marca entre ambas y separaciones iguales.
- Dos ranuras sin logo: puente central de 300 mm, no un hueco extra reservado para la marca ausente.
- Una sola ranura: `S = L - G`, con validación de largo mínimo.
- Ausencia voluntaria de logo sin desaparición de ranuras.
- G distinto de 300 mm: recalcular E=G/2 en toda la banda y validar cada unión.
- Diferentes alturas H y cotas D; interferencia superior/inferior, variación de calibre y radio de doblez.
- Colisión con soportes, solapes o barrenos; rechazo o nuevo reparto de rodillos dentro de sus reglas permitidas.
- Proyectos v1/v2 convertidos a v3; guardar, cerrar y reabrir conserva el mismo patrón.

Además, un barrido de longitudes dentro del rango admitido comprobará invariantes: ningún corte fuera del perfil, separación interior constante, márgenes correctos, logo único como máximo y ausencia de contornos degenerados. Los valores esperados de los ejemplos se calcularán independientemente del resolvedor.

### Paso 11 — Pruebas CAD y entrega

1. Generar en carpeta nueva un par LH/RH por cada estado representativo.
2. Medir en las superficies reales los bordes, longitudes, alturas, radios y coordenadas de logo.
3. Comprobar separaciones de 300 mm y márgenes de 150 mm con tolerancia de medición definida, inicialmente 0.02 mm; el cálculo interno deberá ser más preciso.
4. Generar dos tramos unidos y medir los 300 mm entre aberturas a ambos lados de la junta.
5. Confirmar barrenos cerrados de rodillos, cortes pasantes, reconstrucción sin errores y un solo sólido por perfil.
6. Revisar visualmente los cinco estados, en lateral e isométrica, incluyendo perfiles cortos.
7. Compilar el ejecutable, actualizar documentación y entregar proyecto de ejemplo, CAD, capturas y tabla de cotas verificadas.

## 7. Criterios de aceptación

1. El usuario no necesita introducir cantidad, largo ni radio de ranuras.
2. Todas las separaciones entre elementos consecutivos son G; ambos márgenes extremos son G/2.
3. Los casos de eliminación y desplazamiento del logo siguen el estado de recorte y se explican en la interfaz.
4. El logo deja de depender de un centro fijo y puede desaparecer/restaurarse según el largo.
5. La altura de ranura se referencia de forma inequívoca al doblez inferior.
6. Vista previa, configuración guardada, datos exportados y CAD coinciden.
7. Los rodillos sólo reciben orificios circulares cerrados y ya no obligan a crear una ranura encima.
8. No se ocultan incompatibilidades reduciendo distancias, omitiendo cortes o alterando referencias mecánicas.

## 8. Orden de trabajo recomendado

Primero cerrar los ejemplos y las reglas de los cortes en puentes; después desarrollar el resolvedor y probar sus ecuaciones. A continuación retirar el acoplamiento con rodillos, integrar el patrón y simplificar las pantallas. Finalmente actualizar CAD/persistencia y ejecutar las pruebas de unión y medición. La propuesta termina en la entrega de un ejecutable y un conjunto CAD verificado; este documento por sí solo no aplica cambios al sistema.
