# Plan: placas de flecha y chumaceras para E925

Actualizado: 2026-10-01. Este documento conserva el plan inicial. Su implementación y las decisiones posteriores de solape exterior y cobertura se describen en [PLACAS_FLECHAS_E925.md](PLACAS_FLECHAS_E925.md), que prevalece sobre las propuestas iniciales siguientes.

## Datos aportados por el usuario

- Dos placas rectangulares por flecha, paralelas a los perfiles laterales.
- Caras interiores al ras de las caras interiores de los perfiles.
- Borde superior al nivel del doblez superior de 90 grados.
- Dimensión vertical ajustada al claro recto entre dobleces: interpretación pendiente de comprobar en sección, incluyendo tangencias y radios.
- Espesor: 3/16 in = 4.7625 mm.
- Chumacera indicada: F208. Pendientes marca y designación completa/inserto compatible con cada diámetro de asiento.
- Diámetros habituales de la parte cilíndrica de la flecha que entra en la chumacera: 1.125 in (28.575 mm), 1.25 in (31.75 mm) y 1.5 in (38.10 mm). Serán opciones de selección por flecha; no se establece todavía una opción predeterminada.
- Referencia A: superficie de apoyo de la banda sobre las tiras de nylamid azules del esquema proporcionado.

Tabla transcrita de la imagen del usuario para E925. Se interpreta en mm; la captura no muestra el encabezado de unidades.

| Dientes Z | Diámetro primitivo | A | B máxima |
|---|---:|---:|---:|
| 12 | 96.59 | 42 | 47 |
| 16 | 128.15 | 58 | 54 |
| 20 | 159.81 | 73 | 59 |

No interpolar otras cantidades de dientes ni aplicar estos datos a otros modelos de banda.

## Referencias geométricas

En el ensamble actual X es transversal, Y crece hacia arriba y Z sigue el largo de la banda.

La referencia de rodadura es la cara superior de las tiras centrales y el escalón interior de las laterales, que deben ser coplanares. La ceja exterior lateral sobresale 6.35 mm de ese plano y no es el origen de A.

    Y_eje = Y_rodadura - A

La posición del eje se recalculará a partir de la posición real de las tiras cuando cambien soporte, ranuras o sprocket. No derivar A del radio primitivo, radio exterior ni de un espesor nominal de banda.

En el código actual el nivel se obtiene de la transformación del soporte, su altura superior medida y la profundidad de las ranuras. Conviene extraer esa referencia de CompleteBeltGenerator a una función compartida para generación y vista previa, conservando la medición CAD como verificación final.

Según el esquema, B es la distancia longitudinal entre el eje y el extremo de la tira más cercano a ese eje. Debe ser positiva en el sentido mostrado y no superar el máximo tabulado. El máximo no define por sí solo la posición longitudinal del eje ni una holgura mínima frente al sprocket real.

Actualmente las tiras se extruyen al largo íntegro de cada tramo. La implementación deberá separar largo del tramo, posición del eje y recorte de tiras de los extremos conducido y motriz. Conservar la continuidad de apoyo en las uniones intermedias y comprobar interferencias con la geometría real de sprockets.

## Chumacera y placa

F208 no basta para fijar el diámetro de flecha o el orificio de paso de la placa. Registrar por separado alojamiento, inserto, diámetro de flecha, abertura de placa y patrón de fijación.

El selector «Diámetro de asiento en chumacera» ofrecerá 1 1/8, 1 1/4 y 1 1/2 pulgadas. Esta cota corresponde únicamente a la zona cilíndrica de apoyo de la flecha; no define la sección donde se montan los sprockets. Cada flecha conservará su elección y ambos apoyos usarán el mismo diámetro en esta primera versión.

Seleccionar un diámetro no modificará A ni el nivel del eje para un mismo sprocket y plano de rodadura. Tampoco asignará ese diámetro directamente a la abertura central de la placa: dicha abertura se resolverá con el montaje real de la chumacera. Verificar cada combinación de alojamiento/inserto/diámetro antes de habilitarla; no asumir que las tres medidas están disponibles para cualquier F208.

Referencia de catálogo, NO selección confirmada del usuario: JTEKT UCF208 publica d=40 mm, L=130 mm, J=102 mm, N=16 mm y tornillo M14. N corresponde al barreno del alojamiento; no asignarlo automáticamente como diámetro de perforación de la placa. La abertura central debe contemplar la envolvente real del inserto y la holgura de montaje.

Fuentes consultadas:
- https://koyo.jtekt.co.jp/en/products/detail/print.php?pno=UCF208
- https://cdn.skfmediahub.skf.com/api/public/0901d19680bd1e86/pdf_preview_medium/0901d19680bd1e86_pdf_preview_medium.pdf

Pendientes antes de cerrar piezas para fabricación:
- Marca o plano de la chumacera completa y referencia del inserto utilizado para cada uno de los tres diámetros de asiento indicados.
- Longitud de la placa, posición del eje respecto al extremo del perfil y fijación de la placa al bastidor.
- Confirmación del contorno de placa respecto a los dos dobleces; validar el espacio para cuerpo, barrenos y tornillos manteniendo A.
- Confirmación de unidades de la tabla si el documento completo indica algo distinto de mm.

## Implementación propuesta

1. Incorporar catálogo E925 y configuración de placas por tramo en BeltSectionSpec, con copia independiente y persistencia en proyectos. Proyectos anteriores conservarán su comportamiento hasta activar el módulo.
2. Crear cálculo compartido de rodadura, eje, placas, patrón de fijación y extremos de tiras; distinguir datos confirmados de dimensiones pendientes.
3. Añadir categoría «Placas y chumaceras» en CompleteBeltView: dientes, A y B máxima de solo lectura, B elegida, espesor, chumacera, diámetro de asiento (1 1/8, 1 1/4 o 1 1/2 in), dimensiones de placa y posición longitudinal. Disponible inicialmente para conducido y motriz.
4. Dibujar vista lateral y sección transversal acotadas dentro del ejecutable, mostrando rodadura, eje, A, B, dobleces y envolvente de la chumacera.
5. Generar las dos placas con un eje transversal común e insertarlas en CompleteBeltGenerator; adaptar las tiras de los extremos al recorte calculado.
6. Inspeccionar entradas/salidas de GeneradorFlechaSolidWorks_v13.exe antes de definir su integración. Compartir dientes y eje con ese generador para evitar parámetros duplicados.

## Verificación prevista

- Reproducir A=42/58/73 y B máxima=47/54/59 para Z=12/16/20.
- Comprobar Y_rodadura - Y_eje = A y coaxialidad de las dos placas.
- Comprobar espesor 4.7625 mm, alineación de caras y referencia superior.
- Comprobar conversión y persistencia de los tres diámetros de asiento; cambiar el diámetro manteniendo sprocket y rodadura no debe cambiar A ni Y_eje. Rechazar combinaciones de chumacera/inserto sin compatibilidad confirmada.
- Rechazar combinaciones de banda/dientes sin datos y B fuera de rango.
- Cambiar altura de soporte, profundidad de ranuras, ancho y largo de tramo y verificar actualización consistente de vista previa y CAD.
- Validar borde libre de barrenos, tornillos, abertura central y ausencia de interferencias con dobleces, soportes y sprockets.
- Verificar guardado/carga y conservar el comportamiento de proyectos previos.
