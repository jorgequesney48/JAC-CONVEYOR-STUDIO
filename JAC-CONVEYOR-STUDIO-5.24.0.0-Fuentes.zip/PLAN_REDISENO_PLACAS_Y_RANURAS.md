# Plan de rediseño: placas y ranuras de montaje de rodillos

Estado: implementación realizada, compilada y verificada en CAD con 14 asientos alineados en una banda de tres tramos. Véase `REDISENO_PLACAS_Y_ACCESOS.md` para el funcionamiento actual. La aclaración posterior del usuario sobre puntas tableadas de 9 mm por 10 mm sustituye el semicírculo simple por una guía antigiro con fondo curvo. Esta versión asigna una ventana por rodillo; no agrupa varios ejes en una sola ventana. El recorrido axial completo de montaje requiere las dimensiones restantes del eje real.

## 1. Intención e interpretación geométrica

Tomar la imagen aportada como referencia estética para las placas de flecha: zona de unión de altura completa, extremo compacto alrededor de la chumacera, esquinas redondeadas y transición inferior cóncava amplia y tangente. La imagen no permite deducir cotas ni radios exactos.

En el perfil lateral, sustituir el barreno cerrado de cada eje de rodillo por un asiento semicircular abierto hacia una ranura longitudinal. Se interpreta que el borde inferior recto de la ranura pasa por el centro geométrico del asiento; el semicírculo se recorta por debajo de ese borde. El extremo del eje entra por la ventana y baja hasta apoyarse en el asiento. La ventana permanece dentro del alma: no se propone abrirla hasta el borde superior del perfil.

La cobertura longitudinal requerida corresponde al eje y su holgura de montaje. El cuerpo del rodillo queda entre perfiles; si debe pasar por la ventana, su diámetro y el recorrido de montaje exigirán una abertura mayor. Se resolverá esta comprobación en el primer croquis de montaje.

## 2. Situación actual comprobada en el código

- `ProfileSlotLayout.Resolve` excluye 10 mm alrededor de los barrenos de rodillo; actualmente impide la unión buscada entre ranura y asiento.
- Las ranuras dependen de `MarkA`/`MarkB`, y no se generan sin logo.
- `ProfileSlotSpec` sólo almacena centro longitudinal, longitud y radio; falta altura propia y asociación con los ejes.
- `ReturnRollerLayout.Build` reparte los rodillos globalmente, conserva referencias de flechas y catenaria, e intenta distintos números de intervalos ante conflictos.
- Las alturas de los rodillos pueden variar entre extremos; una ventana horizontal común no siempre puede servir a varios rodillos.
- La placa actual tiene un contorno esencialmente rectangular con dos esquinas redondeadas; sus comprobaciones de contorno y volumen deben actualizarse junto con su forma.

## 3. Reglas obligatorias del sistema

1. **Cobertura completa:** todo rodillo debe tener un asiento y una ventana de acceso correspondiente en ambos laterales. No se permite generar una banda con un rodillo sin acceso.
2. **Cobertura útil, sin centrado obligatorio:** el intervalo longitudinal del eje, ampliado por la holgura de entrada, debe quedar dentro del tramo recto útil de la ranura. No basta con que el centro caiga entre los extremos exteriores redondeados.
3. **Asiento conectado:** la ventana y el semicírculo forman una abertura continua; no deben quedar membranas, líneas duplicadas ni pequeños residuos de material.
4. **Altura de trabajo:** conservar la posición funcional de los rodillos, el recorrido de retorno y las referencias de abrazo. Ajustar las ventanas a los rodillos, no moverlos sólo para mejorar la apariencia.
5. **Holgura y apoyo:** distinguir centro geométrico del asiento y centro real del eje apoyado. Con holgura radial, no coinciden exactamente. Incorporar esa compensación al cálculo de altura, en vez de asumir que un asiento sobredimensionado mantiene el centro del eje.
6. **Material protegido:** respetar dobleces, extremos, empalmes, solapes, fijaciones, soportes C y material remanente debajo del asiento. Las separaciones mínimas serán parámetros explícitos y validados. Los valores actuales son un punto de partida geométrico, no una comprobación de resistencia del nuevo diseño.
7. **Ranuras compartidas:** una ventana podrá servir a varios rodillos sólo si todos los asientos caben, hay separación suficiente entre ellos y sus alturas son compatibles. Si no, crear ventanas independientes.
8. **Prioridades:** montaje y referencias mecánicas; material y zonas protegidas; acceso de todos los rodillos; logo; simetría y uniformidad visual. Reubicar o reducir el logo sólo con una opción explícita; de otro modo, informar el conflicto.
9. **Incompatibilidad visible:** si no existe solución, bloquear la generación e identificar tramo, rodillo, zona conflictiva y ajuste posible. Nunca omitir silenciosamente un asiento.
10. **Montaje real:** verificar la trayectoria de entrada de ambos extremos del eje, su longitud y salientes, espacio entre perfiles, interferencias con banda y soportes, y necesidad de retención ante levantamiento. Un semicírculo abierto apoya el eje, pero por sí solo no lo retiene hacia arriba.

Condición longitudinal para un asiento asociado a una ventana:

`inicioRectoUtil + radioPaso <= posicionEje <= finRectoUtil - radioPaso`

`radioPaso` incluye el radio del eje y la holgura de entrada. Además se verificará el área libre real durante el recorrido de inserción; esta desigualdad por sí sola no demuestra que el montaje sea posible.

## 4. Secuencia de implementación

### Fase 1 — Croquis paramétrico y montaje

- Dibujar la nueva placa sobre las referencias existentes de eje, chumacera y fijaciones.
- Dibujar una ventana con su asiento, un caso con eje descentrado y un caso con dos rodillos en una ventana.
- Mostrar borde inferior, centro del asiento, centro del eje apoyado, radio y holguras.
- Comprobar el recorrido de inserción de un rodillo completo; documentar si requiere desplazamiento axial, eje retráctil u otro recurso de montaje.
- Definir radios de placa, ancho de material alrededor de fijaciones, altura de ventana, longitud máxima sin puente y separación mínima entre asientos. Las dimensiones pendientes se definirán con el croquis acotado y los componentes reales, no midiendo píxeles de la referencia.

Entrega: croquis acotado y configuración inicial reproducible antes de modificar los cortes CAD.

### Fase 2 — Geometría común

- Extender el modelo de ranura con altura, tramo recto útil e identificadores de asientos asociados.
- Representar cada asiento con radio, centro, posición funcional del eje y ventana de acceso.
- Añadir un contorno paramétrico de placa con segmentos y arcos tangentes, compartido por previsualización, validación y CAD.
- Separar activación de ventanas funcionales y activación del logo.
- Versionar la configuración y conservar lectura de proyectos anteriores con barrenos cerrados; ofrecer conversión explícita al nuevo montaje.

Archivos principales: `ProfileSlotLayout.cs`, `ReturnRollerLayout.cs`, `ShaftPlateGeometry.cs`, `PerfilBandas.cs` y persistencia del proyecto.

### Fase 3 — Resolver rodillos y ventanas conjuntamente

1. Calcular referencias de flechas y candidatos de rodillos con las restricciones mecánicas existentes.
2. Construir obstáculos reales en el plano del alma, considerando su altura y extensión longitudinal.
3. Reservar una abertura viable para cada eje antes de repartir ranuras adicionales.
4. Agrupar asientos compatibles y ajustar largo/posición de sus ventanas sin exigir centrado.
5. Aplicar longitudes máximas, puentes mínimos, radios y separación de obstáculos.
6. Si falla una distribución, intentar otra dentro de los límites actuales de paso y catenaria; validar también sus ventanas antes de aceptarla.
7. Emitir un único resultado con rodillos, ventanas, asientos, asociaciones y diagnóstico.

Evitar la dependencia circular actual: el perfil inicial no debe resolver ranuras definitivas antes de conocer los rodillos. En modo manual, las dimensiones elegidas se validan y se informa cualquier incompatibilidad sin reajustes ocultos.

Archivos principales: `BeltLinePlan.cs`, `ReturnRollerLayout.cs`, `ProfileSlotLayout.cs`.

### Fase 4 — Placas con el aspecto de la referencia

- Crear el recorte inferior cóncavo y sus transiciones tangentes; mantener una familia pequeña y coherente de radios.
- Conservar la zona completa necesaria para el solape y los tres cuadrados de fijación.
- Mantener eje, patrón de chumacera, abertura central y acceso a la cabeza del soporte.
- Conservar las referencias A/B y la separación configurada respecto al perfil; comprobarlas contra el nuevo contorno.
- Validar distancias al borde curvo real, cobertura requerida y sección remanente en la transición. Si no cabe el recorte, reducirlo o declarar la combinación incompatible.
- Recalcular área/volumen esperado a partir del nuevo contorno, eliminando la fórmula exclusiva de la placa rectangular.

Archivos principales: `ShaftPlateGeometry.cs`, `ShaftPlateGenerator.cs`, `ShaftPlatePreview.cs`.

### Fase 5 — CAD, interfaz y exportación

- Generar la unión geométrica de ventana y asientos como corte pasante continuo en LH/RH; eliminar el barreno cerrado en el nuevo modo.
- Actualizar los supuestos de cantidad de segmentos y volumen de los cortes existentes.
- Usar el mismo resultado geométrico en vista previa, generación y ensamble.
- Mostrar rodillos numerados y sus ventanas; informar cobertura completa o el conflicto concreto.
- Exponer modo de montaje, holguras, altura/largo de ventanas, puentes mínimos y estilo de placa con sus radios.
- Exportar centros funcionales, centros de asientos, radios, ventanas y asociaciones en las referencias JSON.

Archivos principales: `PerfilBandas.cs`, `ReturnRollerGenerator.cs`, `CompleteBeltGenerator.cs`, `CompleteBeltView.cs`, `ReturnRollerEditor.cs`, `ShaftPlateEditor.cs` y vistas afectadas.

### Fase 6 — Verificación y entrega

- Casos geométricos: eje descentrado, cerca del extremo redondeado, dos ejes por ventana, diferentes alturas, sin logo, obstáculos, juntas, solapes y tramo sin espacio suficiente.
- Conservar referencias de extremos, paso máximo y catenaria en bandas de varios tramos.
- Verificar holgura cero y positiva: el eje apoyado debe quedar a la altura funcional calculada.
- Comprobar correspondencia de LH/RH, cortes pasantes, continuidad de aberturas, reconstrucción sin errores y un solo sólido por pieza.
- Probar guardar/reabrir tanto proyectos antiguos como nuevos.
- Generar un conjunto de ejemplo en carpeta independiente y revisar vistas lateral, isométrica y detalle del asiento, además del recorrido de montaje.
- Actualizar documentación y entregar las cotas pendientes de comprobación de fabricación/carga. La validación geométrica no sustituye el dimensionamiento mecánico del material remanente ni de la retención.

## 5. Criterios de aceptación

- El 100 % de los rodillos tiene un acceso útil y asiento coincidente en ambos perfiles.
- Los ejes pueden quedar descentrados respecto a sus ranuras sin perder acceso.
- Ninguna ventana funcional depende de que exista logo.
- No se modifican las referencias mecánicas para forzar la estética.
- Placa, vistas y CAD comparten el mismo contorno con transiciones tangentes.
- Los conflictos bloquean la generación y explican cómo corregirlos.
- La prueba de montaje confirma que el rodillo completo puede introducirse y asentarse con los componentes previstos.
