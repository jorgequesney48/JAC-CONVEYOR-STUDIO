# Suite de Automatización de Bandas Transportadoras — Módulo Perfiles y Ensamble

Módulo generador paramétrico en C# WinForms y API de SOLIDWORKS 2026, diseñado para la creación de perfiles laterales inoxidables de chapa metálica y la generación automatizada de ensambles (`.SLDASM`) para transportadores de banda modular.

## Estado Actual del Módulo

- **v5.18 · Tramos curvos E925**: configuración de giro/radio, perfiles con cejas soldadas a 90°, soportes de ambos niveles y retorno de dos pletinas laterales y una central. Los soportes inferiores conservan el sentido de los superiores. Barrenos de patas en rectos junto a curvas, centro de curva y uniones curva–curva. Los rectos conservan sus rodillos, con un centro a 150 mm antes de cada curva y catenaria dentro de los rectos del motriz. Patas curvas pendientes. Uso, criterios y límites: [TRAMOS_CURVOS.md](TRAMOS_CURVOS.md).

- **Versión 5.3, interfaz minimalista y diseño 3D**: tarjetas claras redondeadas, botones con colores por función y **Eliminar tramo** en rojo. Navegación 3D con zoom inmediato, renderizado en segundo plano y calidad adaptativa al mover el modelo. Visor nítido en pantallas anchas, líneas ocultas corregidas y acabado visual inoxidable; Nylamid blanco con siete colores disponibles, guardados con el proyecto. Seleccionar un tramo sólo resalta el modelo; **Parámetros** abre el panel y las medidas editables cuando se necesitan. **Principal / Detalles / Referencia** conservan los ajustes rápidos y completos. Uso en [DISENO_INTERACTIVO_3D.md](DISENO_INTERACTIVO_3D.md). Inicia con `PerfilBandas.exe` de la raíz o `ABRIR_JAC_BANDAS.cmd`.
- **Composiciones por tramo**: selector de orden de ranuras/logo junto al modo automático y sólo logo para el último recorte. Se mantienen las validaciones de geometría y la presentación del ensamble CAD. Resultados y límites en [AUDITORIA_SISTEMA_Y_COMPOSICIONES.md](AUDITORIA_SISTEMA_Y_COMPOSICIONES.md).

- **Rodillos de retorno**: apartado «11 Rodillos», barrenos Ø0.50 in con holgura editable, reparto uniforme entre tramos, altura calculada para abrazo de 186° y catenaria motriz de 1200 mm. Referencias del croquis editables. Uso en [RODILLOS_RETORNO.md](RODILLOS_RETORNO.md).
- **Placas de flecha por tramo**: apartado «Placas / ejes», tabla E925, asientos de 1 1/8, 1 1/4 y 1 1/2 in, espesor 3/16 in y solape exterior con tres cuadrados para tornillos coche centrados en la mitad del solape real. Paso Ø31.75 mm para la cabeza del soporte exterior. Las ranuras respetan placas y soportes. Las pletinas se prolongan hacia las flechas para conservar B y separar los barrenos del perfil 2 pulgadas. Las plaquitas C conservan su contorno y quedan debajo del nylamid mediante alargamiento de ambos dobleces. Espesor de banda configurable (12 mm para E925); soportes y flecha se nivelan automáticamente para que la banda quede al ras del perfil. Los perfiles LH/RH comparten el nivel superior. Uso y límites en [PLACAS_FLECHAS_E925.md](PLACAS_FLECHAS_E925.md).

- **Chapa metálica paramétrica**: Longitud, altura de alma, calibres inoxidables (10 al 18), radios y ángulos configurables.
- **Catálogo de bandas modular**: Lectura dinámica de `band_catalog.json` (Modelo E925 con anchos de 100 a 1320 mm en saltos de 25 mm).
- **Manejo de lados (LH / RH / Par)**:
  - Generación de perfil izquierdo (LH) y derecho (RH) con orientación correcta de pestañas y logo.
  - Modo Par para generar ambos archivos listos para ensamble.
- **Logo y ranuras automáticas**: separación libre de 300 mm y márgenes de 150 mm; recorte con eliminación y redistribución de elementos. Sólo se ajustan altura, separación y elevación de ranura. El logo puede moverse u omitirse según el largo. Uso y pruebas en [DISTRIBUCION_LOGO_RANURAS_300.md](DISTRIBUCION_LOGO_RANURAS_300.md).
- **Orificios de extremos con centrado real y corte ciego**:
  - Cuadrados exactos de 11.00 × 11.00 mm (para tornillo de cuello cuadrado de 3/8").
  - Ubicación en pestaña inferior a 45° y pestaña superior a 90°.
  - Centrado insensible a espesor y radios mediante interpolación con `GetBox()`.
  - Profundidad de corte acotada al calibre (`swEndCondBlind`) para no perforar el alma inclinada de 5°.
- **Ensamble Automatizado (`.SLDASM`) — En desarrollo**:
  - Distancia entre perfiles gobernada por `AnchoBanda + 0.75"` (Nylamid lateral + holguras).
  - 6 soportes en canal C (calibre 12) posicionados en los espacios intermedios entre ranuras y logo.
  - Pletinas de deslizamiento longitudinales: laterales en espejo con rebaje superior de $0.5'' \times 0.25''$, centrales rectangulares y cortes de soporte nivelados.

## Compilación

Para compilar el ejecutable desde la terminal:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

El binario actualizado se genera automáticamente en `outputs\PerfilBandas.exe`.

## Documentación Detallada

- [DOCUMENTACION_PERFIL_BANDAS.md](DOCUMENTACION_PERFIL_BANDAS.md): Manual técnico del perfil lateral y operaciones de chapa metálica.
- [ARQUITECTURA_ENSAMBLE_Y_SOPORTES.md](ARQUITECTURA_ENSAMBLE_Y_SOPORTES.md): Especificaciones técnicas del ensamble, soportes C, Nylamid y holguras.
- [band_catalog.json](outputs/band_catalog.json): Catálogo configurable de modelos y anchos de banda.

## Configurador por tramos

La pantalla inicial permite seleccionar tramos desde tarjetas o un esquema, editar sus configuraciones independientes y guardar proyectos. Consulta [CONFIGURADOR_POR_TRAMOS.md](CONFIGURADOR_POR_TRAMOS.md) para uso, comprobaciones y propuesta de interfaz web integrada.


- **Catálogo de chumaceras**: botón Chumacera con seis recientes, búsqueda, registro desde modelo sólido 3D y selección independiente por extremo. Las medidas se aplican a la placa y el modelo se coloca en el ensamble CAD. Uso, formatos y límites en [CATALOGO_CHUMACERAS.md](CATALOGO_CHUMACERAS.md).

### Navegación del configurador de banda
La barra superior organiza Dimensiones, Perfiles, Travesaños, Nylamid, Patas, Transmisión y Rodillos. Más ajustes y Todos los parámetros dan acceso a las doce categorías. Archivo reúne abrir/guardar; Vista reúne orientaciones, encuadre y visor ampliado. El panel derecho permanece abierto y conserva su categoría al cambiar de tramo. La paleta usa turquesa, grafito y grises claros; la acción Generar en SOLIDWORKS permanece visible abajo a la derecha. Verificación visual y de navegación: scratch/StudioUiSmoke.cs (1440 y 1100 píxeles de ancho).
