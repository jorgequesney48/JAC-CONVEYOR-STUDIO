# Placas y accesos antigiro para rodillos

**Documento histórico:** el sistema de accesos antigiro descrito aquí fue sustituido por barrenos circulares y una distribución independiente de logo/ranuras. El contorno elaborado de placas se conserva. Consulta [la implementación vigente](DISTRIBUCION_LOGO_RANURAS_300.md); los controles y pruebas de asientos abiertos de este documento ya no corresponden a la aplicación actual.

## Geometría solicitada

La aclaración del usuario sustituye el asiento semicircular simple del plan inicial: los ejes son varillas fijas de Ø12.7 mm, con dos caras paralelas separadas 9 mm y tableado de 10 mm en cada punta. La nueva abertura consta de una ventana longitudinal, una guía vertical con ancho igual al tableado más la holgura de ajuste, y un fondo que conserva el arco inferior de la varilla. El círculo completo ya no se perfora en el modo abierto.

El ancho inicial es 9 mm sin holgura. El radio inicial del fondo es 6.35 mm. La altura inicial de ventana es 40 mm, su largo máximo 300 mm y la distancia vertical desde el borde inferior de la ventana al centro del asiento es 12.7 mm. Estas tres últimas medidas son parámetros propuestos y editables. El usuario puede aplicar holgura al ancho y al diámetro; la altura del centro del asiento compensa la holgura radial para mantener el centro funcional del eje una vez apoyado.

La guía debe tener una profundidad mínima igual al radio del asiento. Se impide una holgura que haga el ancho de guía igual o mayor al diámetro de la varilla, porque se perdería el bloqueo geométrico del giro. El tableado debe cubrir al menos el espesor del perfil. No se dimensiona aquí la resistencia del contacto.

## Uso

En **11 Rodillos**, activar los alojamientos y **Asientos abiertos hacia ranuras**. La vista inicial muestra los accesos del tramo; el selector **Vista** permite volver a la distribución y catenaria global. Los parámetros de ventana y tableado son comunes a la banda. La tabla identifica la ranura asignada a cada eje dentro de su tramo.

En **10 Placas / ejes**, activar **Contorno elaborado con alivio inferior**. Las esquinas redondeadas y el recorte cóncavo inferior emplean un contorno común para CAD y vista previa. El alivio solicitado se limita según la envolvente de chumacera, perforaciones y cobertura del sprocket. Si no hay espacio para alivio, su radio efectivo es cero; no se fuerza un recorte sobre la envolvente protegida. Se conservan los barrenos, el solape y las referencias A/B.

Los proyectos nuevos usan ambos modos nuevos. Los archivos versión 1 conservan sus barrenos cerrados y placa anterior al abrirse; cada opción permite convertirlos expresamente. El guardado usa versión 2 y conserva los nuevos parámetros.

## Reglas del reparto

- Se calcula primero la distribución global de rodillos con las referencias y catenaria existentes.
- Cada eje obtiene una ventana propia. No se exige centrado: su sección completa y holgura de entrada deben quedar dentro del tramo recto útil.
- El modo automático puede desplazar y acortar la ventana. El modo manual conserva el largo indicado y bloquea una combinación incompatible.
- Se reservan los accesos de los ejes siguientes antes de asignar el largo a una ventana, evitando que la primera ocupe todo el espacio.
- Las ventanas respetan material junto a cortes y dobleces, solapes, fijaciones de soportes, logo y puente mínimo entre accesos.
- La protección de soportes y logo considera su altura, además de su longitud.
- Las ventanas funcionales se generan también sin logo. Sus dimensiones son independientes de las ranuras decorativas.
- Una distribución sólo se acepta cuando todos sus accesos son válidos. Si falla, se intenta otro número de intervalos uniformes; si ninguno cabe, se informa el conflicto y no se genera.
- Esta versión utiliza una ventana por rodillo; la unión de varios asientos en una sola ventana queda fuera de esta implementación.

## CAD y comprobación

Las ventanas se dibujan mediante líneas y arcos explícitos transformados desde las coordenadas reales del perfil. Se evita `CreateSketchSlot` en las ventanas funcionales porque durante la prueba la solución de ese croquis desplazaba las aberturas respecto a los asientos.

La guía y el arco inferior se cortan después de la ventana, con un solape interno de 0.1 mm dentro del vacío existente. El volumen retirado debe coincidir con la sección de guía situada debajo de la ventana y su fondo circular, multiplicada por el espesor. Así se detectan ventanas desplazadas o interferencias inesperadas. La placa usa el área analítica de su contorno de líneas y arcos para comprobar el volumen final.

`REFERENCIAS_RODILLOS.json` versión 2 contiene las ventanas de cada tramo, posiciones globales/locales, centros funcionales, centros de asiento, ancho tableado, radio, profundidad de guía e índice de ventana.

Pruebas reproducibles: `scratch/build_redesign.ps1` compila `scratch/RedesignSmoke.cs`. Sin argumentos comprueba reparto, cobertura descentrada, independencia del logo, holguras, modo manual, rechazos geométricos y contorno. `--preview` verifica persistencia nueva/antigua y genera capturas. `--cad` genera un ensamble de tres tramos en una carpeta nueva; `--verify` inspecciona los asientos reales de ambos laterales en ese ensamble activo.

## Montaje pendiente de cotejar con el rodillo real

El sistema comprueba la abertura transversal y la longitud mínima de tableado respecto al espesor. Aún falta el largo total del eje, distancia entre hombros del tableado y posición axial final para verificar el recorrido completo de inserción de las dos puntas fijas. No se insertan sólidos de rodillos ni de ejes, ni se garantiza ese recorrido mediante una simulación de montaje. El alojamiento abierto tampoco incluye un cierre que retenga levantamiento.

Las medidas de chumacera del ejemplo de prueba son sintéticas; deben sustituirse por las del montaje real antes de fabricar.

## Resultado verificado

- Compilación de `outputs/PerfilBandas.exe` correcta.
- Pruebas geométricas, modo manual, rechazo de holgura que pierde antigiro, modo anterior y persistencia de versiones 1/2 correctos.
- Ensamble de tres tramos, siete rodillos previstos y cuatro placas generado en `scratch/redesign-cad-20261002-204332/BANDA_COMPLETA.SLDASM`.
- Inspección independiente de superficies: 14 fondos cilíndricos con abertura de 9 mm, radio de 6.35 mm y corte pasante de 1.9 mm, ubicados en las coordenadas globales y alturas calculadas; cada perfil conserva un solo sólido.
- Las comprobaciones de volumen de los seis perfiles y las cuatro placas pasaron durante la generación.
- Proyecto de ejemplo: `scratch/redesign-example.jacband`. Capturas: `scratch/redesign-access.png`, `scratch/redesign-plate.png` y `scratch/redesign-cad-20261002-204332/REDISENO.png`.
