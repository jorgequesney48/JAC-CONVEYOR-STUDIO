﻿Actualización v5.8: consulta [Abrazo interactivo y altura por sprocket](ABRAZO_INTERACTIVO.md). La referencia inferior fija de 127 mm ya no gobierna el retorno; la altura se calcula con el sprocket, el espesor de banda y el ángulo de abrazo.

# Reparto automático de rodillos · v5.7

Referencia permanente: imagen aportada por el usuario el 2026-10-05, TRANSPORTADOR SUPERIOR A 2 METROS. Se conserva en assets/manual/rodillos_transportador_mayor_2m.png y dentro del ejecutable. En Rodillos de retorno, Ver imagen del manual guardada abre la referencia sin conexión ni archivos temporales. build.ps1 incorpora la imagen como recurso en futuras compilaciones.

Criterios transcritos de la imagen:

- Aplicación: transportadores superiores a 2000 mm.
- Flecha conducida a primer rodillo: 200–500 mm.
- Flecha motriz a primer rodillo: 200–300 mm.
- Paso normal de referencia L: máximo 1000 mm.
- Primera catenaria, entre primer y segundo rodillo del motriz: L + 200 mm.
- Abrazo del sprocket motriz: 180–210°.

Interpretación para evitar aberturas con pasos variables: se guarda L = longitud resuelta de catenaria − 200 mm. Todos los intervalos normales deben ser ≤L, ≤1000 mm y ≤el máximo normal introducido. Por ello la catenaria no supera 1200 mm. La imagen no prescribe diámetro de rodillo, tensión, flecha real o distancia mínima de material; esas medidas siguen siendo parámetros del diseño. A y B son referencias del esquema, pero no aparecen valores numéricos en esta imagen.

Uso: Rodillos de retorno > Cruces con ranuras > Automático · conservar aberturas. Activa Calcular longitud de catenaria (predeterminado en configuraciones nuevas) para resolver también esa separación. Si lo desactivas, la longitud introducida debe cumplirse exactamente. Las distancias a primeros rodillos son preferencias; el sistema puede reubicarlos dentro de los rangos del manual, recalculando su altura por tangencia para mantener el abrazo. El reparto automático exige el modo Abrazo y recorrido de banda.

Se conservan las ranuras y el logo del patrón ya resuelto para el perfil. No se recortan ni se omite el logo para acomodar rodillos. Se comprueban barrenos contra juntas, dobleces, fijaciones, solapes, ranuras y envolvente del logo. La tabla muestra todos los centros, pasos anteriores, L y catenaria resuelta. El visor y SolidWorks reciben las mismas coordenadas y aberturas. REFERENCIAS_RODILLOS.json guarda la identidad de la referencia, L y catenaria final.

Búsqueda: intervalos libres continuos para centros intermedios, con propagación de intervalos alcanzables y reconstrucción del reparto. Primeros centros: preferencia exacta y alternativas en incrementos de 1 mm. Catenaria automática: límites de zonas libres y puntos libres próximos a la preferencia. Si no encuentra reparto, bloquea la generación y conserva las aberturas. No garantiza encontrar todos los posibles extremos submilimétricos o todos los recorridos de catenaria variable.

Pruebas: relación L + 200 y límite L ≤1000; conservación exacta de ranuras y logo; catenaria fija incompatible rechazada; catenaria automática compatible; reubicación de primeros centros con abrazo comprobado por cálculo inverso; intervalos libres muy estrechos y casos que requieren retroceso; persistencia; controles del inspector; referencia gráfica incrustada; regresiones de opciones anteriores y medición. No se generó un ensamble en SolidWorks durante esta validación. El cálculo resuelve la distribución geométrica; la curva esquemática no calcula tensión ni flecha real de la banda.
