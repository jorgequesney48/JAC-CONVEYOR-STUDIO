﻿Actualización v5.8: consulta [Abrazo interactivo y altura por sprocket](ABRAZO_INTERACTIVO.md). La referencia inferior fija de 127 mm ya no gobierna el retorno; la altura se calcula con el sprocket, el espesor de banda y el ángulo de abrazo.

Referencia actual v5.7: consulta [Reparto automático y manual guardado](RODILLOS_AUTOMATICOS.md). La imagen aportada por el usuario exige L ≤1000 mm y primera catenaria L + 200 mm. El reparto automático conserva ranuras y logo; la imagen se consulta desde la app.

# Rodillos de retorno

Actualización: los rodillos vuelven a barrenos circulares cerrados. Se retiraron las guías antigiro y la obligación de una ranura encima de cada rodillo. El nuevo patrón independiente se describe en [Distribución de logo y ranuras](DISTRIBUCION_LOGO_RANURAS_300.md).

## Uso

En **11 Rodillos**, activar **Generar barrenos para ejes de rodillos**. Las placas de flecha deben estar activas en ambos extremos para definir la posición real de sus ejes. Los ajustes de rodillos son comunes a toda la banda y se guardan en el proyecto `.jacband`; cada perfil recibe su parte del reparto.

Valores del ejemplo confirmado por el usuario:

| Medida | Valor |
|---|---:|
| Eje del rodillo | Ø12.7 mm / 0.50 in |
| Holgura diametral inicial | 0 mm, editable |
| Rodillo | Ø38.1 mm / 1.50 in |
| Flecha a primer rodillo, ambos extremos | 250 mm |
| Paso normal máximo solicitado | 800 mm |
| Primer a segundo rodillo del motriz | 1200 mm |
| Abrazo del sprocket | 186° |
| Nylamid a punto inferior de la banda sobre el sprocket | 127 mm / 5 in |

El gráfico del fabricante aportado por el usuario indica 200–500 mm al primer rodillo del conducido, 200–300 mm al del motriz, paso normal ≤1000 mm, primera catenaria mayor que las restantes y abrazo 180–210°. Recomienda rodillos Ø50 mm para bandas de paso hasta 30 mm y Ø100 mm para pasos mayores. El ejecutable conserva el Ø38.1 del croquis del usuario y permite cambiarlo. No sustituye estos diámetros por el diámetro del eje.

## Reparto uniforme entre tramos

Se fija el primer rodillo del conducido respecto a su flecha y el primer rodillo motriz respecto a la suya. El segundo rodillo motriz queda exactamente 1200 mm hacia el interior desde el primero. Entre el primero conducido y el segundo motriz se divide la distancia disponible en intervalos iguales que no exceden el paso normal solicitado.

La separación longitudinal no se reinicia en cada tramo. Cada centro global se asigna a un único perfil y se convierte en una coordenada local. Si una junta, un cuadrado de soporte, la placa de flecha o el área del logo coincide con un barreno, se intenta otra cantidad de intervalos, conservando la uniformidad. Los primeros rodillos y el intervalo de catenaria permanecen fijos. Si no cabe el conjunto, se informa del conflicto y se impide generar.

El reparto de rodillos comprueba sus barrenos contra las ranuras y el logo en sus posiciones efectivas. El patrón de ranuras no cambia para acomodar un rodillo; si no existe un reparto uniforme válido, se informa del conflicto. El diámetro del barreno es `diámetro del eje + holgura diametral`.

## Altura y abrazo

La cota de 127 mm se mide desde el plano superior de apoyo del nylamid hasta el punto inferior de la **banda colocada sobre el sprocket**. Corresponde al ejemplo del usuario; debe ajustarse al conjunto real cuando cambia sprocket o banda. No se identifica con el radio primitivo ni se deduce automáticamente de éste.

Con A de la tabla E925, la envolvente de retorno tiene radio `R = profundidad inferior - A`. Para un abrazo `180° + β`, el centro del rodillo queda:

```
Yrodillo = Yeje + distanciaPrimerRodillo × tan(β)
           - (R + radioRodillo) / cos(β)
```

Es la tangente común que sale por debajo de la envolvente del sprocket y llega por arriba del rodillo. Con A=58 mm, profundidad inferior 127 mm, primer centro a 250 mm y rodillo Ø38.1 mm, el centro queda **120.258752 mm debajo del nylamid**. Con banda de 12 mm bajo el doblez superior, su coordenada es **Y=-132.258752 mm**. La comprobación inversa de tangencia da **186°**.

Los extremos se calculan con sus propias referencias de flecha. Si sus alturas difieren, los rodillos normales interpolan la altura entre extremos. El modo **Centro bajo nylamid** permite una cota manual común; no verifica un abrazo determinado.

No se permite una envolvente inferior menor que el radio primitivo del sprocket seleccionado. Cambiar a un sprocket que no cabe en la cota de 127 mm exige introducir la referencia correspondiente. Los barrenos se validan contra el alma recta, dobleces, uniones y otros cortes.

## Resultados

- Barrenos pasantes coincidentes en LH/RH mediante `Barrenos_Ejes_Rodillos_Retorno`.
- Vista del retorno completo con las juntas, rodillos numerados y tramo de catenaria.
- Tabla con tramo, posición Z global, Z local, altura Y y función.
- `REFERENCIAS_RODILLOS.json` con los ajustes y todos los centros generados.

Este apartado genera los orificios. No inserta todavía los rodillos, ejes ni la banda como sólidos. La curva de catenaria de la interfaz es esquemática; no calcula tensiones ni la flecha real de la correa.

## Verificación histórica anterior al patrón de 300 mm

`scratch/ReturnRollerSmoke.cs` comprueba una banda de tres tramos de 600, 2400 y 2100 mm: siete rodillos, paso normal 723.92 mm y último intervalo motriz 1200 mm. Comprueba tangencia por cálculo inverso, asignación a tramos, juntas coincidentes, protección de ranuras, configuraciones incompatibles y persistencia.

El modo `--cad` genera perfiles y ensamble con dimensiones de chumacera explícitamente sintéticas para la prueba; mide cada superficie cilíndrica de los barrenos Ø12.7 mm y su posición global, y verifica su carácter pasante y correspondencia entre ambos laterales.

La prueba CAD en `scratch/rodillos-cad-20261002-011751` confirmó **14 barrenos pasantes Ø12.7 mm**: un par LH/RH para cada uno de los siete centros. Las coordenadas medidas coinciden con el reparto global y la altura Y=-132.258752 mm. El intervalo motriz conserva 1200 mm y los cinco intervalos normales son 723.92 mm. El ensamble generado permanece disponible como `BANDA_COMPLETA.SLDASM` y la captura como `RODILLOS_EN_BANDA.png`.
