# Rodillos y cruces con ranuras · v5.6

En Parámetros > Rodillos de retorno, usa Cruces con ranuras:

- Interrumpir y continuar ranuras: conserva centros y alturas de todos los rodillos. Divide la abertura y deja 20 mm de material desde cada borde del barreno al extremo de los fragmentos. Separación de ranuras permite ajustar este valor entre 10 y 100 mm.
- Bajar rodillos intermedios: conserva los dos rodillos próximos a las flechas en su altura calculada por abrazo. Los demás, incluido el segundo motriz de catenaria, bajan donde sea necesario para dejar la separación configurada entre el cuerpo del rodillo y la parte inferior de ranuras o logo. Los que ya están libres conservan su altura. No se eliminan rodillos ni se cambia el paso longitudinal o la separación de catenaria.

La altura final se muestra en la tabla de posiciones y en el visor 3D. El esquema de retorno indica diferencias de altura, pero su escala vertical y su curva son esquemáticas.

Mantén activado Adaptar recortes a fijaciones y rodillos en Logo y aberturas para poder dividir las ranuras de los extremos o junto a fijaciones. Un fragmento debe tener al menos el diámetro de sus extremos redondeados más 2 mm de tramo recto; sólo se omiten fragmentos que no cumplen esa condición. El patrón inicial centrado se conserva, pero los recortes locales por barrenos no se replican por simetría a lugares sin interferencia.

Los barrenos descendidos siguen comprobándose contra dobleces, uniones, fijaciones y placas de flecha. Si no cabe la distribución, se informa y se bloquea la generación. Se usan las mismas posiciones y fragmentos en el visor y en la generación SolidWorks. La curva esquemática no calcula tensión ni caída real de la banda.

Verificado: separación de 20 mm, conservación de fragmentos asimétricos, omisión de fragmentos cortos, altura de extremos sin cambios, descenso de intermedios, rechazo de altura que invade dobleces, persistencia JSON, reparto longitudinal y herramienta de medición. No se ejecutó una generación de ensamble en SolidWorks en esta validación.
