# Simulación de movimiento · v5.24

Abre el visor ampliado y selecciona **Simulación**, en el apartado derecho junto a **Tramos**. El apartado abre por defecto al ampliar la vista.

- **RPM del eje motriz**: de 0 a 300, con un decimal. El valor puede cambiar durante la marcha. Es la velocidad de la flecha de salida que mueve los sprockets.
- **Iniciar simulación / Pausar simulación**: avanza en tiempo real o conserva la posición alcanzada.
- **Volver al inicio**: pausa y devuelve la marca al origen.
- **Sentido**: carga hacia el motriz o movimiento inverso.
- **Patrón E925 Flush Grid**: representación visual de las aberturas alternadas del manual, sobre carga, curvas, abrazos y retorno. Una franja naranja permite seguir una posición durante la vuelta completa.

El cálculo usa el paso de 25 mm indicado por el manual E925 y los dientes configurados del sprocket motriz:

`velocidad [m/min] = RPM × dientes × 25 / 1000`

Ejemplo: Z16 a 30 RPM equivale a 12 m/min; cada revolución avanza 400 mm. La longitud del circuito se mide sobre el recorrido central, incluyendo los abrazos y las catenarias existentes, y permite calcular el tiempo de una vuelta completa de la banda.

La apariencia toma como referencia la página 2 de `assets/manual/E925_FlushGrid_curvas.pdf`. El documento da el paso y muestra el Flush Grid; no entrega el contorno de fabricación de cada abertura. El patrón del visor es una aproximación visual, y no cambia la geometría de las piezas generadas en CAD. La simulación representa la cinemática sin deslizamiento, no cargas, esfuerzo, potencia ni colisiones.

Si la trayectoria está oculta, iniciar la simulación la muestra automáticamente. Ocultarla, cerrar la ventana o modificar la geometría detiene la animación; los cambios geométricos reinician el recorrido. Las RPM, el sentido y la preferencia de patrón se guardan con el proyecto. Los proyectos anteriores conservan 30 RPM, sentido normal y patrón activado por defecto.

El visor GPU actualiza la fase del patrón conservando sus listas de geometría. La alternativa CPU usa peticiones asíncronas con una copia de la fase y deja completar cada cuadro antes de tomar la posición actual. El avance se mide por tiempo transcurrido, independientemente de los cuadros por segundo.

Validación reproducible: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scratch\RunBeltSimulationRegression.ps1`. Comprueba avance y reversa, 0 RPM, continuidad física del circuito, coordenadas de patrón, CPU/GPU, reutilización de malla, controles, pausa, reinicio, cierre y guardado de opciones.
