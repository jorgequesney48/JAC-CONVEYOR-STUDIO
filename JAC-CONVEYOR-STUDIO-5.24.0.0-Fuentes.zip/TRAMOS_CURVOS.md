﻿# Tramos curvos · JAC Conveyor Studio v5.21.3

## Uso

Pulsa **+ Agregar curva** o **Tramos → Agregar tramo curvo**. Se inserta un tramo intermedio. En **Banda y perfil → Dimensiones**, elige derecha/izquierda, ángulo y radio. El ángulo y el radio sólo modifican la curva seleccionada; el modelo 3D se recalcula al cambiar los parámetros. El resumen muestra sus longitudes, soportes y pletinas. La cámara sigue el centro real del tramo seleccionado.

E925 admite únicamente anchos nominales en múltiplos de 20 mm desde 100 mm (100, 120, 140…). Los anchos de proyectos previos que no cumplan esta regla requieren selección explícita de un ancho válido antes de generar CAD o DXF. El catálogo y el ancho inicial están corregidos a paso 20 mm y 520 mm respectivamente.

El radio automático usa ancho × factor por intervalos de la tabla completa aportada por el usuario (2026-10-06): 100–<200: 1.27; 200–<300: 1.60; 300–<400: 1.68; 400–<500: 1.73; 500–<600: 1.82; 600–<720: 1.84; 720–<800 y 800–<1000: 1.88; desde 1000: 1.92. Ejemplo: 520 mm → 946.4 mm. Los radios impresos se conservan como referencia; el cálculo aplica la fórmula, sin interpolación. La referencia al borde interior se mantiene interpretada del croquis de página 9. El editor permite abrir la tabla completa y el PDF original.

## Geometría de esta fase

- Dos almas curvas, de la misma altura que el tramo recto.
- Cada perfil CAD tiene tres cuerpos: alma, ceja superior y ceja inferior. Las cejas son piezas soldadas a 90°, con contacto en el borde del alma y sin solapamiento de volúmenes; no se generan operaciones de doblez entre ellas.
- Los soportes de los extremos de cada curva se retiran según la esquina interior de su envolvente para dejar una holgura predeterminada de 5 mm con el soporte vecino; ajustable en el editor de curva. En modo automático se redistribuyen manteniendo la cantidad. En manual se conservan los interiores o se indica si no caben. Barrenos del visor, CAD y DXF siguen las mismas estaciones. Ver auditoria/2026-10-06/SEPARACION_SOPORTES_CURVAS.md.
- Soportes C superiores e inferiores, orientados radialmente y en el mismo sentido, con las ranuras hacia arriba. Los inferiores llevan una ranura central.
- Pletinas laterales superiores e inferiores de las curvas con ranura C: 6.35 mm de nylamid arriba de la banda, 6.35 mm de pared al costado del perfil y ranura de espesor de banda + 1.5875 mm. El resto de la altura queda debajo. Las centrales conservan su sección rectangular; el retorno conserva una central. Los alivios de las plaquitas se recortan en CAD.
- Los rectos adyacentes a curvas tienen dos agujeros de pata en ese extremo, como un final; la pata se coloca por completo del lado recto. La ceja inferior de cada curva tiene un par central y un agujero por extremo unido a otra curva para compartir el soporte. En una unión recto–curva, la curva no lleva agujero extremo de pata.
- Los orificios cuadrados de ambos niveles se incluyen en los perfiles CAD y en el visor. El visor aproxima las superficies curvas mediante segmentos; los sectores CAD son arcos circulares.
- Las juntas de las pletinas consideran la separación y la expansión configuradas.
- Dos patas centrales curvas para PTR de 1½ pulgadas y travesaño H opcional. La placa usa la geometría doblada de la referencia: chapa de 2.7 mm, 45°, radio interior 2.7 mm y exterior 5.4 mm. Se conserva la lengua de soldadura y se reconstruye el asiento con borde circular adaptado y esquinas de 7 mm. Los dos cuadrados centrales de 11 mm llevan paso recto de 63.5 mm y una orientación común en CAD, visor y DXF. La placa generada es un sólido con el doblez real, sin operación nativa Desplegar. La unión entre dos curvas tiene un único par de patas compartidas, con una mitad del asiento adaptada a cada radio y un travesaño H opcional. La variante PTR de 2 pulgadas sigue pendiente. Las patas rectas conservan su placa y sus dobleces.

## Reglas y salidas

Entrada y salida rectas ≥ 1.5 × ancho nominal; entre giros opuestos, recto ≥ 2 × ancho. Para giros del mismo sentido no se impone ese mínimo. La longitud total suma el borde exterior de cada curva. El rango de ángulo 1–180° es de esta versión, no un límite publicado por el manual.

Se guardan parámetros de curva con el proyecto. SolidWorks genera las piezas y ensambla los rectos según los marcos del recorrido, incluyendo la orientación de placas, flechas y patas rectas. Cada revisión conserva `TRAZADO_CURVAS.json`, referencias XYZ globales y lista de piezas. Las vistas de rutas curvas muestran planta e isométrica con dimensiones nominales de radio, ángulo, arcos, paso y holgura.

Los rectos conservan rodillos, ejes y alojamientos de retorno al insertar curvas. El reparto se resuelve por grupos de rectos contiguos con la altura, los márgenes y el paso del cálculo recto. El centro del último rodillo queda exactamente a 150 mm antes de cada entrada a curva; al salir de una curva, el siguiente grupo empieza con un rodillo a 150 mm. Las curvas llevan exclusivamente las tres pletinas inferiores de retorno. La catenaria motriz se resuelve dentro del último grupo de rectos: si se exige una longitud que no cabe, la app muestra una incidencia. El esquema de distribución usa la distancia acumulada por el centro del recorrido y no dibuja catenarias atravesando curvas. `REFERENCIAS_RODILLOS.json` incluye centros XYZ y ejes transversales globales para las rutas mixtas.

Cada curva genera seis DXF analíticos 1:1 en CNC_CURVAS: dos almas desarrolladas para rolear y cuatro cejas planas para soldar, con barrenos. El factor de fibra neutra del alma es ajustable (0.5 predeterminado). Los DXF tienen contornos cerrados y arcos exactos; el manifiesto registra espesor, radios, dimensiones y áreas. El CAD conserva cuerpos soldados, sin desplegado nativo. La exportación de otras chapas sigue siendo manual. Ver auditoria/2026-10-06/RADIOS_Y_CNC_CURVAS.md.

## Fuente conservada

`assets/manual/E925_FlushGrid_curvas.pdf`, `E925_curvas_criterios.json` y `RESUMEN_E925_CURVAS.md`. El resumen registra las diferencias entre los perfiles comerciales del catálogo y las pletinas existentes solicitadas por el usuario, así como los datos que el catálogo no especifica.






## Transición de retorno a rectos — versión 5.20.6

Las tres pletinas de retorno se prolongan en línea recta, tangentes al extremo de la curva, hacia los rectos adyacentes. Terminan 10 mm antes de la envolvente longitudinal del rodillo. El centro del rodillo permanece a 150 mm de la unión; por tanto la prolongación mide 150 − diámetro/2 − 10 mm (120,95 mm para Ø38,1). La corona del rodillo queda 10 mm arriba de la superficie que sostiene la banda, no del labio lateral de retención. Se modifica el eje y los alojamientos del rodillo para mantener esa altura.

Entre curvas se conserva la separación térmica, sin prolongación tangente. Sin rodillos o sin pletinas habilitadas no se agrega prolongación. Visor y generación SolidWorks usan el mismo cálculo; TRAZADO_CURVAS.json registra longitudes y alturas de transición. Las pletinas se generan como cuerpos curvos y prolongaciones tangentes dentro de la misma pieza.


## Reutilización de piezas — versión 5.20.7

Cada revisión mantiene un registro de geometrías generadas. Los componentes iguales del ensamble apuntan al mismo archivo, sin reconstruir ni copiar la pieza por tramo. Aplica a soportes C (también entre niveles cuando son idénticos), perfiles terminados, rodillos/ejes, pletinas, placas y flechas, patas completas, PTR, tapas, placas de pata, bases niveladoras y travesaños H.

La comparación incluye los barrenos, ranuras y centros de soporte resueltos, aunque esos campos no se incluyan en la configuración guardada. En los perfiles se ignoran únicamente el número de tramo, la posición global y el nombre de función del rodillo, conservando su posición local y geometría. Radios, alturas de alojamientos, dobleces, espesores y mecanizados distintos producen archivos distintos. La geometría tangente de retorno forma parte de la comparación de pletinas curvas.

Solo se reutilizan resultados guardados correctamente durante la revisión actual. El registro se limpia al terminar o fallar. REUTILIZACION_PIEZAS.json relaciona archivos únicos y llamadas resueltas por reutilización. Los objetos COM temporales se liberan entre tramos y bloques de patas; la inserción aprovecha documentos ya cargados. Las revisiones anteriores se conservan.


## Guías ranuradas y nivel de banda — versión 5.20.8

La ranura se aplica a los dos laterales de las curvas, tanto superiores como de retorno. Se conserva la tira de 19.05 × 38.1 mm: pared lateral de 6.35 mm, material superior de 6.35 mm y altura de ranura igual al espesor configurado de banda más 1.5875 mm de holgura. Con banda de 12 mm, la ranura mide 13.5875 mm y quedan 18.1625 mm de material inferior. La sección se refleja para el lateral opuesto.

La cara superior de la banda de trabajo queda 6.35 mm debajo del borde superior metálico en rectos y curvas. Se ajustan las alturas de los elementos que sostienen la banda y los ejes motriz/conducido. La altura configurada desde el piso hasta la banda se conserva ajustando la longitud de las patas. Las pletinas centrales y los laterales rectos conservan su sección. Los soportes de curva adaptan la profundidad de sus ranuras laterales para alinear los pisos de apoyo; con banda de 12 mm y ranura central de 25.4 mm, la lateral mide 5.4625 mm.

En las prolongaciones laterales de retorno, el techo de la ranura se abre gradualmente hacia el rodillo para acompañar la banda que llega 10 mm más alta. El piso y la pared permanecen continuos. El recorte se mantiene dentro de la tira de 38.1 mm. El centro del rodillo sigue a 150 mm de la unión y la punta conserva 10 mm de separación respecto a su envolvente. Las prolongaciones centrales mantienen su sección rectangular.

Visor y SolidWorks usan los mismos parámetros. Cada lateral ranurado se genera como un sólido; la reutilización por geometría incluye el espesor de banda y los recortes de entrada. Los proyectos existentes se recalculan al abrirse y las revisiones CAD ya generadas se conservan. Ver auditoria/2026-10-06/GUIAS_RANURADAS_5.20.8.md.


## Mayor agarre y cantidad editable — versión 5.20.9

Se sustituye la altura de las tiras laterales ranuradas de las curvas por 50.8 mm (2 pulgadas), en trabajo y retorno. El ancho sigue en 19.05 mm. Las centrales y las guías de rectos conservan su sección. Las dimensiones indicadas para la versión 5.20.8 quedan como historial y son reemplazadas por esta sección.

Con banda de 12 mm quedan 30.8625 mm de material inferior y el asiento lateral en el soporte aumenta de 5.4625 a 18.1625 mm (ranura central de 25.4 mm). Se conservan pared y cubierta de 6.35 mm, ranura de 13.5875 mm y cara superior de banda a 6.35 mm bajo el perfil. Las alturas de montaje y las entradas de retorno se recalculan con la tira de 2 pulgadas.

En Dimensiones de la curva y Orificios para soportes C hay un apartado Cantidad de soportes de este tramo: automático o número editable con flechas de 2 a 32. En curvas la cantidad se aplica a cada nivel. El panel de edición rápida también permite seleccionar estas cantidades. El reparto automático redistribuye los centros; se rechazan cantidades que no caben o causan solapamientos. La selección se guarda en el proyecto y actualiza visor, barrenos CAD y DXF.


## Nylamid al ras del perfil — versión 5.20.10

Se corrige el saliente vertical de 1.5875 mm: la cara superior de la tira lateral ranurada coincide con el borde superior metálico (Y = 0). La nivelación anterior contaba solo la cubierta de 6.35 mm y omitía la holgura de 1.5875 mm sobre la banda. El descenso correcto de la cara de banda es cubierta + holgura = 7.9375 mm. Este valor reemplaza el descenso de 6.35 mm indicado en las versiones anteriores.

Rectos y curvas comparten la nueva cara de banda. Se conservan la tira lateral de 2 pulgadas, ranura espesor de banda + 1/16, material superior y pared de 1/4, agarre en el soporte y cantidad editable. Se ajustan soportes, ejes y longitud de patas manteniendo la altura configurada piso–banda. La transición del retorno conserva rodillo 10 mm arriba y punta 10 mm antes de la envolvente.


## Trayectoria completa de la banda — versión 5.21.0

Se modela la envolvente completa con ancho nominal y espesor configurados: trabajo en rectos y curvas, retorno en curvas, tangentes y abrazos sobre los rodillos de rectos, y envolturas en ambos extremos. Los extremos usan la posición de eje y la envolvente A de sprocket resuelta; los ángulos resultan de las tangencias con los apoyos vecinos. La banda se cierra sin huecos en las uniones entre tramos y extremos.

En Dimensiones está Mostrar trayectoria de la banda completa. La envolvente se muestra en azul y puede ocultarse para revisar estructura y guías; la preferencia se guarda en el proyecto. No modifica perfiles, nylamid ni soportes.

SolidWorks genera un único TRAYECTORIA_BANDA.SLDPRT con varios cuerpos por recorrido y lo inserta como un solo componente en BANDA_COMPLETA.SLDASM. TRAYECTORIA_BANDA.json conserva geometría y límites. No genera cada módulo de banda ni representa dientes. Las curvas en planta son sectores circulares CAD; los abrazos verticales se discretizan a un máximo de 1 grado. El modelo de retorno es una envolvente por tangentes sin flecha de catenaria ni cálculo de tensión: los rodillos por debajo de la tangente común pueden quedar sin contacto. Si no hay rodillos activados, conecta los apoyos extremos y curvas. No permite deducir una longitud de compra de banda con holgura o expansión.

Pruebas de cierre, ancho/espesor, nivel, ocultar/mostrar y generación nativa: auditoria/2026-10-06/TRAYECTORIA_COMPLETA_5.21.0.md.


## Catenaria ajustable — versión 5.21.1

Se añade curvatura de caída entre rodillos mediante catenarias hiperbólicas y se resuelven iterativamente los puntos de tangencia con la envolvente de cada rodillo. Los abrazos conectan la pendiente de entrada y salida sin huecos. La caída se mide en el punto medio del vano, verticalmente respecto a la cuerda entre sus contactos, no desde el eje del rodillo.

El usuario autorizó dejar una aproximación inicial y estimar después con material y temperaturas. Valores iniciales: 10 mm entre rodillos normales y 50 mm entre primer y segundo rodillo del motriz. En Rodillos de retorno pueden modificarse por separado o ponerse a 0 para volver a tangentes. No constituyen una caída aprobada de fabricante. Las curvas continúan apoyadas sobre nylamid y las entradas rectas a curva conservan su transición de 10 mm.

TRAYECTORIA_BANDA.json incluye los vanos curvados, caída configurada y longitud geométrica adicional por vano. No convierte esta suma en longitud de compra ni resuelve tensión, módulos adicionales o dilatación. Los rodillos que quedan debajo de la envolvente compatible pueden no tener contacto. El visor y SolidWorks comparten la curva calculada; CAD aproxima catenarias por segmentos y mantiene un archivo de trayectoria.

Ver auditoria/2026-10-06/CATENARIA_5.21.1.md.


## Ranuras debajo de soportes — versión 5.21.2

Las aberturas alargadas del perfil recto quedan completas debajo de la parte más baja del soporte C superior, con 10 mm de material libre. La referencia considera las pestañas frontal y posterior reales, incluido el descenso de plaquitas. Se limita la elevación solicitada del patrón, manteniendo la altura de ranura. Si no cabe con 10 mm sobre el doblez inferior, se indica un conflicto; no se genera una abertura que sobrepase el soporte. La regla aplica a patrones automáticos y combinaciones manuales, con adaptación de recortes activada o desactivada.

La separación libre predeterminada entre ranuras es 200 mm y los márgenes del patrón siguen su cálculo de mitad de separación. Los valores explícitos guardados en proyectos anteriores se conservan y pueden cambiarse a 200 mm en el editor. La altura resultante se comparte entre visor, CAD y referencias del patrón.


## Margen rodillo–ranura — versión 5.21.3

El margen entre el borde del alojamiento del eje de retorno y la ranura alargada cambia de 50 a 20 mm por instrucción del usuario. Se usa en búsqueda de posiciones, comprobación de interferencias, interrupción/continuación de ranuras y referencias. También se normalizan a 20 mm los proyectos que conservaban el valor anterior. Se mantienen los 100 mm de reserva junto a extremos y la regla de ranuras 10 mm debajo del soporte.

354 comprobaciones incluyendo margen de recorte 20 mm en alojamientos circulares y tableados, normalización del valor anterior y regresiones de recorrido/catenaria: scratch/clearance20_regression.txt. Compilación 5.21.3.0: scratch/build_5.21.3.txt.


### 5.21.4 — Ranuras de las almas curvas

Cada espacio entre soportes tiene dos ventanas rectangulares en el lateral exterior y una en el interior, para giros derechos o izquierdos. La cantidad sigue los soportes resueltos del tramo; no hay aberturas antes del primer soporte ni después del último.

El borde superior queda 1 mm debajo de la parte más baja del soporte superior completo. El inferior queda 1 mm arriba del nylamid lateral de retorno de 2 pulgadas. La altura resulta de esas dos cotas; con alma de 225.5 mm y configuración actual es 6.2 mm. Al aumentar la altura del alma crece la abertura. Si no hay altura o espacio longitudinal suficiente, la validación explica qué dimensión debe corregirse.

Las ventanas respetan el ancho tangencial del soporte más 2 mm por lado. Las dos exteriores conservan un puente de hasta 20 mm ajustado al espacio disponible. Las esquinas son rectas; el desarrollo representa el corte nominal sin compensación CAM. La separación respecto a los rodillos de los tramos rectos sigue siendo 20 mm.

Visor, recortes nativos en SOLIDWORKS y DXF comparten las mismas cotas angulares y alturas. El DXF desarrolla la abertura a radio neutro; CORTE.json distingue barrenos de ranuras. Se mantiene la reutilización de piezas iguales.

Verificación: 310 comprobaciones de ambos giros, 2/4/6 soportes, almas 225.5/300 mm y ángulos 45/90/180 grados, más corte nativo de las almas LH/RH y comprobación de volumen en SOLIDWORKS. Evidencias en auditoria/2026-10-06/ranuras_curvas.


### 5.21.5 — Rodillos debajo de ranuras y retorno de curva ajustable

En Rodillos de retorno hay dos barras: separación alojamiento–ranura y elevación de la corona sobre el retorno de curva. Ambas parten de 10 mm, con recorrido de 0 a 50 mm y pasos de 1 mm. El cambio se aplica al modelo durante el movimiento, con actualizaciones limitadas a intervalos de 100 ms. El proyecto v14 guarda los dos valores y la opción de permitir interrupciones; al abrir proyectos anteriores se inicia este nuevo arreglo a 10/10 mm con las interrupciones desactivadas.

Los rodillos normales y el segundo motriz quedan debajo de la ranura más baja del tramo. La distancia se mide desde su borde inferior hasta el punto más alto del alojamiento completo: 24.35 mm arriba del eje para la entrada R9/R6.35, o medio diámetro de barreno para agujeros circulares. Se añade una tolerancia geométrica de 0.0001 mm para evitar coincidencias numéricas. Se comprueban cuadrados de soportes superiores e inferiores, solapes, dobleces y logo.

Los primeros rodillos junto a ambos sprockets conservan la tangencia calculada a partir de diámetro, espesor de banda, distancia y abrazo. Los rodillos junto a curvas siguen a 150 mm de la unión y conservan la elevación elegida respecto al contacto de las pletinas. Las prolongaciones terminan 10 mm antes del cuerpo del rodillo; este espacio horizontal no se modifica con las barras.

Pletinas, soportes y barrenos inferiores de la curva descienden juntos para aproximar la transición al nivel de los rodillos bajos. El descenso se limita por el componente inferior: tanto soporte como plástico deben quedar por encima del labio inferior; el soporte mantiene 1 mm sobre la cara superior de la ceja. Con el alma predeterminada de 225.5 mm, el descenso máximo actual es 36.6 mm. Cuando se alcanza ese límite se muestra un aviso. Las curvas consecutivas mantienen el mismo nivel de retorno o se rechaza un arreglo incompatible.

La opción Permitir interrumpir ranuras está desactivada por defecto. Se buscan primero posiciones que conserven los contornos; solo al activarla se permite cortar y continuar una ranura necesaria para el abrazo o transición. Si la geometría elegida no permite conservar las ranuras con los rodillos obligatorios, se indica activar la opción o corregir dimensiones. No se altera silenciosamente el margen, el abrazo ni el límite del labio. Los valores predeterminados con el patrón actual de alma 225.5 mm necesitan activar la opción para resolver los rodillos obligatorios; un alma/ranuras con espacio suficiente funciona con la opción desactivada.

El visor, trayectoria completa, colocación y entradas graduales en SOLIDWORKS, caché de piezas y DXF de las almas usan el descenso y la elevación resueltos. CORTE.json registra el descenso. Las alturas superiores de banda y guías permanecen iguales.

Verificación: 3076 comprobaciones de geometría, cierre de trayectoria, ambas barras y eventos de recalculado, guardado/reapertura y migración de proyectos. 48 comprobaciones nativas en SOLIDWORKS: guía inferior descendida, entradas con elevación 0/10/20 mm y almas LH/RH con las ventanas y barrenos inferiores movidos. Evidencias en auditoria/2026-10-06/retorno_ajustable. No se regeneró un ensamble completo en esta verificación.


### 5.21.6 — Interrumpir únicamente la primera ranura

La autorización de interrupción se limita a la primera ranura desde el extremo afectado del tramo recto: inicio para primero conducido/salida de curva; final para primero motriz/antes de curva. Solo se recorta si hace falta. Los rodillos normales y el segundo motriz conservan siempre las ranuras. Una interferencia con otra abertura se rechaza y requiere corregir la geometría.

La opción se llama Interrumpir solo la primera ranura y queda activada por la autorización del usuario. Proyectos anteriores a v15 migran a esta excepción acotada; las barras conservan sus valores cuando proceden de v14. El logo y los márgenes se mantienen. La restricción se aplica en la búsqueda, validación de centros, construcción de fragmentos y adaptación posterior del patrón, compartidas por visor y CAD.

Verificación: 218 comprobaciones específicas de autorización y conservación exacta de otras ranuras en bandas rectas y curvas de ambos giros, anchos 300/520 mm. Además pasan 3076 comprobaciones de retorno, barras, persistencia y trayectoria completa. El caso de ancho 520 mm con rectos de 2400 mm y curva por defecto se resuelve con esta autorización. No se generó un ensamble completo para esta versión.


### 5.21.7 — Tres grupos de altura de rodillos

Los primeros rodillos junto a los ejes de sprockets conservan su tangencia de abrazo. Los rodillos normales, incluido el segundo motriz de catenaria, usan una única cota Y horizontal para todos los tramos rectos de la banda. La cota común se obtiene de la ranura más baja entre todos los rectos y la separación ajustada al alojamiento completo; no se interpola desde los rodillos extremos ni se calcula una altura diferente para cada tramo. Si no hay ranuras, se usa una referencia común de los extremos.

Los rodillos de entrada/salida de curvas conservan su criterio independiente: corona 10 mm sobre el contacto del nylamid de retorno, modificable con la barra de curvas. Esta barra no altera la altura común de los normales. El descenso del retorno conserva el límite estructural del labio inferior. Se mantiene la restricción de interrumpir únicamente la primera ranura desde el extremo autorizado.

Verificación: 3076 comprobaciones de regresión más 78 específicas con ranuras a cotas diferentes, márgenes 5/10/15 mm y elevaciones de curvas 10/20 mm. Visor y generación CAD consumen el mismo plan de posiciones. No se generó un ensamble completo en esta comprobación. El formato de proyecto continúa en v15 porque la nueva altura común es un valor calculado, no un dato que deba guardarse.


### 5.21.8 — Nivel de las curvas compartido por todos los rodillos de retorno

Corrección del criterio anterior: en una banda con curvas, todos los rodillos salvo los primeros junto a ambos ejes de sprockets se colocan al mismo nivel que los de entrada/salida de curvas. La corona queda por defecto 10 mm sobre el contacto del nylamid inferior. La barra Nivel común de rodillos sobre nylamid de curva mueve este nivel común; los rodillos de abrazo conservan su tangencia independiente.

Primero se resuelve una cota común viable del nylamid de todas las curvas, con el descenso permitido por el labio inferior. Después se fija la altura de todos los rodillos de retorno a partir de esa cota y la elevación ajustada. Se buscan posiciones longitudinales libres de ranuras, cuadrados y logo a esa altura, manteniendo el paso máximo. La barra del margen de alojamientos y ranuras sigue controlando la separación durante esa búsqueda; no establece una segunda altura para rodillos normales en bandas con curvas. En bandas totalmente rectas continúa el criterio anterior de altura común debajo de las ranuras.

Solo puede interrumpirse la primera abertura desde un extremo autorizado cuando un rodillo obligatorio lo necesita. Los rodillos ordinarios preservan todas las ranuras y se distribuyen por los espacios libres.

Caso de la captura: ancho 520 mm, rectos de 2400 mm y curva por defecto. Los rodillos normales, segundo motriz y ambas transiciones quedan en Y = -162.6875 mm. Los primeros junto a los sprockets conservan Y = -141.201953 mm. El descenso de curva permanece en 36.6 mm, con 1 mm de material libre sobre el labio. La corona queda a 10 mm sobre el nylamid.

Verificación: 1996 comprobaciones de alturas compartidas, abrazos independientes, ambos giros, curvas consecutivas, trayectoria cerrada, barras y persistencia. Pasan además las 218 comprobaciones de alcance exclusivo a la primera ranura. Evidencias en auditoria/2026-10-06/retorno_nivel_nylamid. Visor y CAD usan las mismas posiciones del plan; no se regeneró un ensamble completo en estas pruebas.


### 5.21.9 — Reparto homogéneo de rodillos

Los grupos rectos comparten una referencia de paso calculada a partir del grupo más restringido. Cada grupo elige el número factible de intervalos con paso medio más cercano a esa referencia. Para ese número, la búsqueda continua minimiza la mayor desviación respecto del paso uniforme; conserva obstáculos, alturas, extremos de curva a 150 mm, abrazo y catenaria. La catenaria mantiene su intervalo especial. No se garantiza paso idéntico cuando las ranuras o extremos obligatorios lo impiden.

Caso de 2400 mm / curva de 90° / 2400 mm, ancho 520 mm: antes los pasos normales variaban entre 424.751 y 756.549 mm; ahora entre 413.837 y 485.049 mm. El primer recto incorpora dos rodillos normales adicionales. Las alturas siguen a 10 mm sobre el nylamid excepto los primeros próximos a los sprockets.

Validación: UniformRollerRegression, 19 comprobaciones (uniformidad exacta sin obstáculos, óptimo con zonas libres disjuntas, caso imposible y ambos giros con anchos 300 y 520); AlignedNylamidReturnRegression, 2068 comprobaciones de geometría, CNC, trayectoria y barras; FirstSlotOnlyRegression, 218 comprobaciones. Compilación completa de la app 5.21.9. No se regeneró un ensamble completo en SolidWorks. El título de ventana toma la versión real del ensamblado.


### Prueba independiente: contorno de 20 mm alrededor de orificios

Se exportó la geometría real del primer recto (2400 mm, alma 225.5 mm, espesor 1.9 mm, ancho de banda 520 mm) desde el plan 5.21.9 y el contorno de asiento tipo chaveta de ReturnRollerSeatGeometry. En outputs/prueba_contorno_rodillos_20mm se incluyen vista comparativa, DXF del alma y dos cupones de 340 x 120 mm. La app y el generador de SolidWorks no se modifican con esta prueba.

La reserva de material se calcula como desplazamiento hacia fuera de todo el contorno del asiento, 20 mm más una tolerancia geométrica de 0.003 mm. Se resta esa reserva de la ranura original. Si queda aislada, se añade un puente de 40 mm de ancho con solape positivo al perfil. Se conserva el contorno original fuera de la reserva; un extremo cambia localmente cuando queda alcanzado por ella. No se añaden chapas ni soldaduras.

Verificación booleana: el alma completa queda como un único polígono conectado, el margen mínimo entre asiento y abertura es 20.001715 mm, todos los cambios quedan dentro de las reservas. Relectura de los tres DXF confirma contornos cerrados y válidos, lámina conectada, unidades mm y formato AC1015. Los DXF del alma omiten dobleces y otros barrenos; son muestras geométricas de la propuesta, sin compensación de herramienta. No se realizó análisis de cargas.
