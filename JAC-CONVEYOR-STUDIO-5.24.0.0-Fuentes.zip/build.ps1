﻿$ErrorActionPreference = 'Stop'

# -----------------------------------------------------------------------
# build.ps1 — Compilador de PerfilBandas (estructura reorganizada)
# Las DLLs se buscan primero en lib\ (local) y luego en la instalacion de SW.
# -----------------------------------------------------------------------

$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$libLocal  = Join-Path $PSScriptRoot 'lib'
$swInstall = 'C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS'

function ResolveLib($fileName) {
    $local = Join-Path $libLocal $fileName
    if (Test-Path $local) { return $local }
    $installed = Join-Path $swInstall $fileName
    if (Test-Path $installed) { return $installed }
    throw "No se encontro $fileName ni en lib\ ni en la instalacion de SOLIDWORKS."
}

$sw      = ResolveLib 'SolidWorks.Interop.sldworks.dll'
$swconst = ResolveLib 'SolidWorks.Interop.swconst.dll'
$srcFiles = Get-ChildItem -Path (Join-Path $PSScriptRoot 'src') -Filter *.cs | ForEach-Object { $_.FullName }
$outDir   = Join-Path $PSScriptRoot 'outputs'
$outExe   = Join-Path $outDir 'PerfilBandas.exe'
$manualResource = '/resource:"' + (Join-Path $PSScriptRoot 'assets\manual\rodillos_transportador_mayor_2m.png') + '",PerfilBandas.ManualRodillos.png'

New-Item -ItemType Directory -Force -Path $outDir | Out-Null
Write-Host "Compilando fuentes en src:" -ForegroundColor Cyan
foreach ($f in $srcFiles) { Write-Host " - $f" -ForegroundColor Gray }

& $compiler /nologo /target:winexe /out:$outExe `
    /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll `
    $manualResource `
    /r:"$sw" /r:"$swconst" $srcFiles

if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
foreach ($dependency in @($sw,$swconst)) {
    $target = Join-Path $outDir (Split-Path $dependency -Leaf)
    if ((Test-Path -LiteralPath $target) -and
        (Get-FileHash -LiteralPath $target).Hash -eq (Get-FileHash -LiteralPath $dependency).Hash) { continue }
    Copy-Item -LiteralPath $dependency -Destination $target -Force
}
Write-Host "Ejecutable generado: $outExe" -ForegroundColor Green

# The root entry point always opens the canonical binary, preventing stale independent builds.
$rootEntry = Join-Path $PSScriptRoot 'PerfilBandas.exe'
$launcherSource = Join-Path $PSScriptRoot 'tools\LaunchJAC.cs'
$entryBackup = Join-Path $outDir 'legacy_entrypoints'
New-Item -ItemType Directory -Force -Path $entryBackup | Out-Null
if ((Test-Path -LiteralPath $rootEntry) -and (Get-Item -LiteralPath $rootEntry).Length -gt 20000) {
    Copy-Item -LiteralPath $rootEntry -Destination (Join-Path $entryBackup ('PerfilBandas_root_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.exe'))
}
& $compiler /nologo /target:winexe /out:$rootEntry /r:System.Windows.Forms.dll $launcherSource
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Inicio principal: $rootEntry" -ForegroundColor Green
foreach ($oldName in @('PerfilBandas_banda_completa.exe','PerfilBandas_corregido.exe')) {
    $oldEntry = Join-Path $outDir $oldName
    try {
        if ((Test-Path -LiteralPath $oldEntry) -and (Get-Item -LiteralPath $oldEntry).Length -gt 20000) {
            Move-Item -LiteralPath $oldEntry -Destination (Join-Path $entryBackup ($oldName.Replace('.exe','_') + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.exe'))
        }
        Copy-Item -LiteralPath $rootEntry -Destination $oldEntry -Force
    } catch { Write-Warning "No se actualizó $oldName. Cierra la versión anterior y compila de nuevo. $($_.Exception.Message)" }
}
