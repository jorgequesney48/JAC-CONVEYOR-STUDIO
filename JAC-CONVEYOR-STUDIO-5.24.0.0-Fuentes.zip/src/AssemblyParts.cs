using System;
using System.Collections.Generic;
using System.Linq;
namespace PerfilBandas {
internal enum AssemblyPartKind { Profile,Support,Rail,CurvePart,ShaftPlate,Shaft,Bearing,Sprocket,LegTube,LegPlate,LegCap,LegBase,Crossbar,ReturnRoller,ReturnAxle,Trajectory,CurveLegPlate }
internal sealed class AssemblyPartItem {
 internal int Section,Side,Quantity;internal AssemblyPartKind Kind;internal string Name,Suffix;
 internal string Key {get{return Section+"/"+Kind+"/"+Side+"/"+Suffix;}}
 internal string SectionText {get{return Section<0?"Banda completa":"Tramo "+(Section+1).ToString("00");}}
}
internal static class AssemblyParts {
 internal static List<AssemblyPartItem> Build(IList<BeltSectionSpec> sections,BeltDesignPlan plan,ReturnRollerSettings rollers,VerticalSupportSettings legs){
  var result=new List<AssemblyPartItem>();
  Action<int,AssemblyPartKind,string,string,int,int> add=(section,kind,name,suffix,qty,side)=>{if(qty>0)result.Add(new AssemblyPartItem{Section=section,Kind=kind,Name=name,Suffix=suffix,Quantity=qty,Side=side});};
  for(int i=0;i<sections.Count;i++){
   var section=sections[i];var p=plan.Profiles[i];var s=plan.Supports[i];if(p==null||s==null)continue;
   if(section.IsCurved){
    add(i,AssemblyPartKind.CurvePart,"Perfil curvo LH","LH",1,0);add(i,AssemblyPartKind.CurvePart,"Perfil curvo RH","RH",1,1);
    add(i,AssemblyPartKind.CurvePart,"Soporte C superior","SOPORTE_SUPERIOR",p.SupportCount,0);add(i,AssemblyPartKind.CurvePart,"Soporte C inferior","SOPORTE_INFERIOR",p.SupportCount,1);
    if(section.IncludeSlideRails)for(int level=0;level<2;level++)foreach(var rail in CurveReturnLayout.Rails(s,p.LengthMm,level==1))add(i,AssemblyPartKind.CurvePart,"Guía curva "+(level==0?"superior ":"inferior ")+rail.Position+" "+rail.Index,"GUIA_"+(level==0?"SUPERIOR_":"INFERIOR_")+rail.Index.ToString("00"),1,level);
   }else{
    add(i,AssemblyPartKind.Profile,"Perfil lateral LH","LH",1,0);add(i,AssemblyPartKind.Profile,"Perfil lateral RH","RH",1,1);add(i,AssemblyPartKind.Support,"Soporte C","SOPORTE_C",p.SupportCount,0);
    if(section.IncludeSlideRails){add(i,AssemblyPartKind.Rail,"Guía nylamid LH","PLETINA_LH",1,0);add(i,AssemblyPartKind.Rail,"Guía nylamid central","PLETINA_CENTRAL",s.CenterSlotCount,1);add(i,AssemblyPartKind.Rail,"Guía nylamid RH","PLETINA_RH",1,2);}
    if(ShaftPlateGeometry.Active(section)){for(int side=0;side<2;side++){add(i,AssemblyPartKind.ShaftPlate,"Placa de flecha "+(side==0?"LH":"RH"),"PLACA_FLECHA_"+(side==0?"LH":"RH"),1,side);}if(section.ShaftPlates.Bearing!=null)add(i,AssemblyPartKind.Bearing,"Chumacera · "+section.ShaftPlates.BearingReference,"CHUMACERA",2,0);}
    if(ConveyorShaftGeometry.Active(section)){add(i,AssemblyPartKind.Shaft,"Flecha","FLECHA",1,0);if(section.ShaftPlates.Shaft.Sprocket!=null){var shaft=ConveyorShaftGeometry.Calculate(section,p,s,ShaftPlateGeometry.Nominal(section,p,s));add(i,AssemblyPartKind.Sprocket,"Sprocket · "+shaft.Settings.Sprocket.Reference,"SPROCKET",SprocketGeometry.Centers(shaft).Length,0);}}
    int returns=rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers?plan.Rollers.Holes.Count(h=>h.SectionIndex==i):0;
    add(i,AssemblyPartKind.ReturnRoller,"Rodillo de retorno","RODILLO_RETORNO",returns,0);add(i,AssemblyPartKind.ReturnAxle,"Eje de retorno","EJE_RETORNO",returns,0);
   }
   int stations=section.IsCurved?CurveLegHoleLayout.LegStations(p,CurveRoute.Frames(sections,plan.Supports[0],plan.Profiles[0])[i]).Length:VerticalSupportLayout.LocalStations(p,i,sections.Count).Length;
   int count=2*stations;
   add(i,AssemblyPartKind.LegTube,"PTR de pata","PATA_PTR",count,0);add(i,AssemblyPartKind.LegCap,"Tapa inferior de PTR","PATA_TAPA",count,0);add(i,AssemblyPartKind.LegBase,"Base niveladora con tornillo y tuercas","PATA_BASE",count,0);
   if(section.IsCurved&&count>0){for(int side=0;side<2;side++){add(i,AssemblyPartKind.CurveLegPlate,"Placa de pata curva "+(side==0?"LH":"RH"),"PLACA_PATA_"+(side==0?"LH":"RH"),1,side);if(p.EndHoleTypeRight=="empalme")add(i,AssemblyPartKind.CurveLegPlate,"Placa de pata compartida "+(side==0?"LH":"RH"),"PLACA_UNION_PATA_"+(side==0?"LH":"RH"),1,side+2);}}
   else add(i,AssemblyPartKind.LegPlate,"Placa superior de pata","PATA_PLACA",count,0);
   if(legs.CrossbarEnabled)add(i,AssemblyPartKind.Crossbar,"Travesaño PTR H","PTR_UNION_H",stations,0);
  }
  add(-1,AssemblyPartKind.Trajectory,"Trayectoria de banda","TRAYECTORIA_BANDA",1,0);return result;
 }
}
}
