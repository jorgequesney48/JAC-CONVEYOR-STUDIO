using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
namespace PerfilBandas {
internal sealed partial class CompleteBeltView {
 internal void ShowAssemblyParts(){
  if(generating)return;
  var plan=BeltDesignPlan.Build(sections,profile,supportTemplate,rollers,verticalSupports);
  if(!plan.Valid){currentPlan=plan;ShowIssues();return;}
  var inventory=AssemblyParts.Build(sections,plan,rollers,verticalSupports);
  using(var dialog=new Form{Name="AssemblyPartsDialog",Text="Piezas del ensamble",Size=new Size(880,610),MinimumSize=new Size(680,420),StartPosition=FormStartPosition.CenterParent,Font=DesignUi.NavigationRegular,BackColor=Color.White}){
   var search=new TextBox{Name="AssemblyPartSearch",Dock=DockStyle.Fill,AccessibleName="Buscar una pieza"};
   var searchBar=new Panel{Dock=DockStyle.Top,Height=40,Padding=new Padding(10,6,10,6)};searchBar.Controls.Add(search);searchBar.Controls.Add(new Label{Text="Buscar:",Dock=DockStyle.Left,Width=70,TextAlign=ContentAlignment.MiddleLeft});
   var hint=new Label{Dock=DockStyle.Top,Height=48,Padding=new Padding(10,6,10,0),Text="Selecciona una pieza para generar su archivo SolidWorks. La cantidad indica cuántas veces aparece en el ensamble."};
   var list=new ListView{Name="AssemblyPartsList",Dock=DockStyle.Fill,View=View.Details,FullRowSelect=true,MultiSelect=false,HideSelection=false};
   list.Columns.Add("Tramo",120);list.Columns.Add("Pieza",470);list.Columns.Add("Cantidad",90);
   list.Resize+=delegate{list.Columns[1].Width=Math.Max(300,list.ClientSize.Width-230);};
   var actions=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=48,Padding=new Padding(8),WrapContents=false};
   var build=new Button{Name="GenerateSelectedPartButton",Text="Generar pieza seleccionada",Width=225,Height=32,Enabled=false};
   var open=new Button{Text="Abrir carpeta",Width=120,Height=32,Enabled=false};
   var message=new Label{Name="IndividualPartStatus",Dock=DockStyle.Bottom,Height=62,Padding=new Padding(10,5,10,5),ForeColor=DesignUi.Muted};
   string output=null;bool busy=false;
   Action reload=()=>{string chosen=list.SelectedItems.Count==0?null:((AssemblyPartItem)list.SelectedItems[0].Tag).Key;list.BeginUpdate();list.Items.Clear();foreach(var part in inventory){if((part.SectionText+" "+part.Name).IndexOf(search.Text,StringComparison.CurrentCultureIgnoreCase)<0)continue;var row=new ListViewItem(new[]{part.SectionText,part.Name,part.Quantity.ToString()}){Tag=part};list.Items.Add(row);if(chosen==part.Key)row.Selected=true;}list.EndUpdate();build.Enabled=list.SelectedItems.Count==1&&!busy;};
   search.TextChanged+=delegate{reload();};
   list.SelectedIndexChanged+=delegate{build.Enabled=list.SelectedItems.Count==1&&!busy;if(list.SelectedItems.Count==1){var part=(AssemblyPartItem)list.SelectedItems[0].Tag;message.Text=part.Name+" · "+part.Quantity+" en el ensamble. Se generará un archivo de esta pieza.";}};
   open.Click+=delegate{if(output!=null)System.Diagnostics.Process.Start("explorer.exe",Path.GetDirectoryName(output));};
   build.Click+=delegate{
    if(busy||list.SelectedItems.Count!=1)return;var selectedPart=(AssemblyPartItem)list.SelectedItems[0].Tag;
    var snapshot=sections.ConvertAll(s=>s.Copy());var p=profile.Copy();var support=supportTemplate.Copy();var r=rollers.Copy();var legs=verticalSupports.Copy();string root=outputFolder;
    busy=generating=true;build.Enabled=false;open.Enabled=false;list.Enabled=search.Enabled=false;generate.Enabled=false;message.Text="Preparando "+selectedPart.Name+"…";
    var worker=new Thread(delegate(){string result=null;Exception failure=null;try{result=SolidWorksEnsambleGenerator.GenerateIndividualPart(snapshot,p,support,r,legs,selectedPart,root,step=>{if(!dialog.IsDisposed)dialog.BeginInvoke((Action)(()=>message.Text=step));},CancellationToken.None);}catch(Exception ex){failure=ex;}
     if(!dialog.IsDisposed)dialog.BeginInvoke((Action)delegate{busy=generating=false;generate.Enabled=true;build.Enabled=true;list.Enabled=search.Enabled=true;message.ForeColor=failure==null?DesignUi.Primary:Color.Firebrick;message.Text=failure==null?"Pieza generada: "+result:failure.Message;if(failure==null){output=result;open.Enabled=true;status.Text="Pieza individual generada · "+selectedPart.Name;} });
    });worker.IsBackground=true;worker.SetApartmentState(ApartmentState.STA);worker.Start();
   };
   dialog.FormClosing+=delegate(object sender,FormClosingEventArgs e){if(busy){e.Cancel=true;message.Text="Espera a que termine la pieza en SolidWorks antes de cerrar.";}};
   actions.Controls.Add(build);actions.Controls.Add(open);dialog.Controls.Add(list);dialog.Controls.Add(searchBar);dialog.Controls.Add(hint);dialog.Controls.Add(message);dialog.Controls.Add(actions);reload();dialog.ShowDialog(this);
  }
 }
}
}
