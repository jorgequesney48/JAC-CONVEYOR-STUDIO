using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal sealed class AssemblyPreview : Control
    {
        public ProfileSettings Settings { get; set; }
        public int HighlightCategory { get; set; }
        public bool Compact { get; set; }

        public AssemblyPreview()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Color.White;
            Font = new Font("Segoe UI", 9f);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Settings == null || Width < 180 || Height < (Compact ? 100 : 180)) return;
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.White);

            RectangleF frame = Compact ? new RectangleF(32, 14, Width - 64, Height - 48) : new RectangleF(48, 42, Width - 96, Height - 112);
            if (frame.Width < 80 || frame.Height < 40) return;
            float railW = Math.Max(6, Math.Min(15, frame.Width * 0.035f));
            float leftX = frame.Left, rightX = frame.Right - railW;
            float beltLeft = leftX + railW + 3, beltRight = rightX - 3;
            using (var belt = new SolidBrush(Color.FromArgb(239, 246, 248)))
            using (var rail = new SolidBrush(Color.FromArgb(42, 83, 111)))
            using (var support = new SolidBrush(Color.FromArgb(155, 185, 201)))
            using (var hole = new SolidBrush(Color.FromArgb(0, 117, 94)))
            using (var outline = new Pen(Color.FromArgb(208, 220, 227), 1f))
            using (var dash = new Pen(Color.FromArgb(166, 191, 205), 1f) { DashStyle = DashStyle.Dash })
            {
                g.FillRectangle(belt, beltLeft, frame.Top, beltRight - beltLeft, frame.Height);
                g.DrawRectangle(outline, beltLeft, frame.Top, beltRight - beltLeft, frame.Height);
                g.FillRectangle(rail, leftX, frame.Top, railW, frame.Height);
                g.FillRectangle(rail, rightX, frame.Top, railW, frame.Height);

                float[] centers = Settings.IncludeSupportHoles ? SupportCenters() : new float[0];
                for (int i = 0; i < centers.Length; i++)
                {
                    float yy = frame.Top + centers[i] * frame.Height;
                    float h = HighlightCategory == 3 ? 9f : 7f;
                    g.FillRectangle(support, beltLeft, yy - h / 2f, beltRight - beltLeft, h);
                    g.FillRectangle(hole, leftX - 2, yy - 4, 8, 8);
                    g.FillRectangle(hole, rightX + railW - 6, yy - 4, 8, 8);
                }

                // Las pestañas quedan fuera del ancho de la banda.
                float flange = Math.Min(18, frame.Width * 0.045f);
                using (var flangePen = new Pen(Color.FromArgb(0, 117, 94), 3f))
                {
                    g.DrawLine(flangePen, leftX, frame.Top + 10, leftX - flange, frame.Top + 10);
                    g.DrawLine(flangePen, rightX + railW, frame.Top + 10,
                        rightX + railW + flange, frame.Top + 10);
                }

                g.DrawLine(dash, beltLeft, frame.Bottom + 13, beltRight, frame.Bottom + 13);
            }

            using (var titleFont = new Font("Segoe UI Semibold", 10f, FontStyle.Bold))
            using (var detailFont = new Font("Segoe UI", 8.5f))
            using (var titleBrush = new SolidBrush(DesignUi.Ink))
            using (var mutedBrush = new SolidBrush(DesignUi.Muted))
            {
                if (!Compact) g.DrawString("ESQUEMA EN PLANTA · NO A ESCALA", titleFont, titleBrush, 24, 14);
                g.DrawString("LH", detailFont, titleBrush, leftX - 2, frame.Bottom + 18);
                g.DrawString("RH", detailFont, titleBrush, rightX - 3, frame.Bottom + 18);
                bool invalidLayout = Settings.IncludeSupportHoles && SupportCenters().Length == 0;
                if (invalidLayout)
                    g.DrawString("La separación no cabe: ajusta largo, borde o paso antes de generar.",
                        detailFont, Brushes.Firebrick, 24, Height - 47);
                string meta = string.Format(CultureInfo.InvariantCulture,
                    "Banda {0} · {1:0} mm   |   Sección {2:0} mm   |   {3}",
                    Settings.BeltModelName, Settings.BandWidthMm, Settings.LengthMm,
                    invalidLayout ? "Distribución inválida" :
                    Settings.IncludeSupportHoles ? Settings.SupportCount + " soportes C" : "Barrenos de soporte desactivados");
                if (!Compact) TextRenderer.DrawText(g, meta, detailFont, new Rectangle(24, Height - 27, Width - 48, 24), DesignUi.Muted, TextFormatFlags.EndEllipsis);
            }
        }

        private float[] SupportCenters()
        {
            double length = Math.Max(1, Settings.LengthMm);
            double[] millimeters;
            try { millimeters = SupportHoleLayout.CentersMm(Settings); }
            catch (InvalidOperationException) { return new float[0]; }
            float[] result = new float[millimeters.Length];
            for (int i = 0; i < result.Length; i++)
                result[i] = (float)Math.Max(0.02, Math.Min(0.98, millimeters[i] / length));
            return result;
        }
    }
}
