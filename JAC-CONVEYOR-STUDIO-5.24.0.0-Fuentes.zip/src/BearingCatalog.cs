﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
namespace PerfilBandas {
    internal sealed class BearingCatalogEntry {
        public string Id, Brand, Reference, ModelFile;
        public double ShaftSeatInches=1.25, OpeningDiameterMm, BoltPitchMm, BoltDiameterMm, EnvelopeMm;
        public double ModelBoltPitchMm, ModelBoltDiameterMm, ModelEnvelopeMm;
        public double[] Origin, U, V, N;
        public bool Verified;
        public DateTime LastUsedUtc, CreatedUtc;
        public string Label {get{return (Brand+" "+Reference).Trim()+" · "+(ShaftSeatInches*25.4).ToString("0.###")+" mm";}}
        public BearingCatalogEntry Copy(){var e=(BearingCatalogEntry)MemberwiseClone();e.Origin=Clone(Origin);e.U=Clone(U);e.V=Clone(V);e.N=Clone(N);return e;}
        static double[] Clone(double[] a){return a==null?null:(double[])a.Clone();}
        public void Validate(){
            if(String.IsNullOrWhiteSpace(Reference)||!Verified)throw new InvalidOperationException("Introduce una referencia y confirma las medidas y la cara de montaje.");
            if(ShaftSeatInches!=1.125 && ShaftSeatInches!=1.25 && ShaftSeatInches!=1.5)throw new InvalidOperationException("Asiento no admitido por el sistema de flechas.");
            foreach(double d in new[]{ModelBoltPitchMm,ModelBoltDiameterMm,ModelEnvelopeMm})if(Double.IsNaN(d)||Double.IsInfinity(d)||d<0||d>1000)throw new InvalidOperationException("Medidas detectadas del modelo no válidas.");
            foreach(double d in new[]{OpeningDiameterMm,BoltPitchMm,BoltDiameterMm,EnvelopeMm})if(Double.IsNaN(d)||Double.IsInfinity(d)||d<=0||d>1000)throw new InvalidOperationException("Las medidas del montaje deben ser positivas y finitas.");
            if(OpeningDiameterMm<=ShaftSeatInches*25.4 || EnvelopeMm<=BoltPitchMm+BoltDiameterMm)throw new InvalidOperationException("Revisa la abertura central y el espacio exterior alrededor de los barrenos.");
            if(ModelBoltPitchMm>0 && Math.Abs(BoltPitchMm-ModelBoltPitchMm)>.001)throw new InvalidOperationException("El paso de la placa debe coincidir con el patrón detectado del modelo.");
            if(ModelBoltDiameterMm>0 && BoltDiameterMm<ModelBoltDiameterMm-.001)throw new InvalidOperationException("El barreno de placa no puede reducir el diámetro detectado.");
            if(ModelEnvelopeMm>0 && EnvelopeMm<ModelEnvelopeMm-.001)throw new InvalidOperationException("La envolvente no puede reducir el tamaño medido del modelo.");
            BearingMath.ValidateFrame(Origin,U,V,N);
        }
        public void Apply(ShaftPlateSettings s){Validate();s.Bearing=Copy();s.BearingReference=(Brand+" "+Reference).Trim();s.ShaftSeatInches=ShaftSeatInches;s.OpeningDiameterMm=OpeningDiameterMm;s.BoltPitchMm=BoltPitchMm;s.BoltDiameterMm=BoltDiameterMm;s.BearingEnvelopeMm=EnvelopeMm;s.BearingDimensionsVerified=true;}
        public bool Matches(ShaftPlateSettings s){return s.BearingDimensionsVerified && Math.Abs(s.ShaftSeatInches-ShaftSeatInches)<1e-6 && Math.Abs(s.OpeningDiameterMm-OpeningDiameterMm)<.001 && Math.Abs(s.BoltPitchMm-BoltPitchMm)<.001 && Math.Abs(s.BoltDiameterMm-BoltDiameterMm)<.001 && Math.Abs(s.BearingEnvelopeMm-EnvelopeMm)<.001;}
    }
    internal sealed class BearingCatalogData {public int Version=1;public List<BearingCatalogEntry> Entries=new List<BearingCatalogEntry>();}
    internal sealed class BearingCatalog {
        public readonly string Root;
        readonly JavaScriptSerializer serializer=new JavaScriptSerializer();
        public BearingCatalog(string root){Root=Path.GetFullPath(root);}
        public static BearingCatalog Default(){return new BearingCatalog(Path.Combine(ProjectPaths.GetDefaultPiecesFolder(),"CATALOGO_CHUMACERAS"));}
        string Index {get{return Path.Combine(Root,"catalogo.json");}}
        public List<BearingCatalogEntry> All(){
            if(!File.Exists(Index))return new List<BearingCatalogEntry>();
            var data=serializer.Deserialize<BearingCatalogData>(File.ReadAllText(Index));
            if(data==null||data.Version!=1||data.Entries==null)throw new InvalidDataException("Catálogo de chumaceras incompatible.");
            foreach(var e in data.Entries){e.Validate();ModelPath(e);}
            return data.Entries.OrderByDescending(e=>e.LastUsedUtc).ThenByDescending(e=>e.CreatedUtc).ToList();
        }
        public string ModelPath(BearingCatalogEntry e){
            Guid id;if(e==null||!Guid.TryParse(e.Id,out id)||e.ModelFile!="modelo.SLDPRT")throw new InvalidDataException("Modelo de catálogo no válido.");
            return Path.Combine(Root,id.ToString("N"),e.ModelFile);
        }
        void Write(List<BearingCatalogEntry> entries){Directory.CreateDirectory(Root);string tmp=Index+".tmp";File.WriteAllText(tmp,serializer.Serialize(new BearingCatalogData{Entries=entries}),System.Text.Encoding.UTF8);if(File.Exists(Index))File.Replace(tmp,Index,null);else File.Move(tmp,Index);}
        public BearingCatalogEntry Add(BearingCatalogEntry entry,string snapshot){
            entry.Validate();if(!File.Exists(snapshot)||!String.Equals(Path.GetExtension(snapshot),".sldprt",StringComparison.OrdinalIgnoreCase))throw new FileNotFoundException("No se encuentra la copia sólida del modelo.",snapshot);
            var all=All();var e=entry.Copy();e.Id=Guid.NewGuid().ToString("N");e.ModelFile="modelo.SLDPRT";e.CreatedUtc=DateTime.UtcNow;e.LastUsedUtc=e.CreatedUtc;
            string path=ModelPath(e);Directory.CreateDirectory(Path.GetDirectoryName(path));File.Copy(snapshot,path,false);all.Add(e);Write(all);return e;
        }
        public void Touch(string id){var all=All();var e=all.FirstOrDefault(x=>x.Id==id);if(e==null)throw new InvalidOperationException("La chumacera ya no está en el catálogo.");e.LastUsedUtc=DateTime.UtcNow;Write(all);}
    }
    internal static class BearingMath {
        internal static double Dot(double[] a,double[] b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
        internal static double[] Sub(double[] a,double[] b){return new[]{a[0]-b[0],a[1]-b[1],a[2]-b[2]};}
        internal static double[] Add(double[] a,double[] b){return new[]{a[0]+b[0],a[1]+b[1],a[2]+b[2]};}
        internal static double[] Scale(double[] a,double d){return new[]{a[0]*d,a[1]*d,a[2]*d};}
        internal static double[] Cross(double[] a,double[] b){return new[]{a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
        internal static double[] Unit(double[] a){double l=Math.Sqrt(Dot(a,a));if(l<1e-10)throw new InvalidOperationException("Referencia geométrica degenerada.");return Scale(a,1/l);}
        internal static double[] Project(double[] point,double[] plane,double[] n){return Sub(point,Scale(n,Dot(Sub(point,plane),n)));}
        internal static void ValidateFrame(double[] o,double[] u,double[] v,double[] n){
            foreach(var a in new[]{o,u,v,n}){if(a==null||a.Length!=3)throw new InvalidOperationException("Falta la orientación del modelo.");foreach(double d in a)if(Double.IsNaN(d)||Double.IsInfinity(d))throw new InvalidOperationException("Orientación no válida.");}
            if(Math.Abs(Dot(u,u)-1)>1e-5||Math.Abs(Dot(v,v)-1)>1e-5||Math.Abs(Dot(n,n)-1)>1e-5||Math.Abs(Dot(u,v))>1e-5||Dot(Cross(u,v),n)<.99999)throw new InvalidOperationException("Las referencias de montaje no forman una orientación ortogonal.");
        }
        // Local model coordinates are metres. Mounting origin maps to the outer plate face.
        internal static double[] Placement(BearingCatalogEntry e,bool right,double x,double y,double z){
            ValidateFrame(e.Origin,e.U,e.V,e.N);double outward=right?1:-1,longitudinal=right?-1:1;
            double[] t=new double[16];for(int j=0;j<3;j++){t[j*3]=outward*e.N[j];t[j*3+1]=e.V[j];t[j*3+2]=longitudinal*e.U[j];}
            t[9]=x-(e.Origin[0]*t[0]+e.Origin[1]*t[3]+e.Origin[2]*t[6]);t[10]=y-(e.Origin[0]*t[1]+e.Origin[1]*t[4]+e.Origin[2]*t[7]);t[11]=z-(e.Origin[0]*t[2]+e.Origin[1]*t[5]+e.Origin[2]*t[8]);t[12]=1;return t;
        }
    }
}
