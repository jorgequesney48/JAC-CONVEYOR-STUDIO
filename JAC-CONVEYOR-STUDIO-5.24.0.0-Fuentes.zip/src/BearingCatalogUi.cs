﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace PerfilBandas {
    internal sealed class BearingMountPreview : Control {
        internal BearingCatalogEntry Entry;
        internal BearingMountPreview(){DoubleBuffered=true;BackColor=Color.White;MinimumSize=new Size(250,250);}
        protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);if(Entry==null){e.Graphics.DrawString("Lee el modelo para ver el montaje.",Font,Brushes.Gray,15,20);return;}var g=e.Graphics;g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;double size=Math.Max(Entry.EnvelopeMm,Entry.BoltPitchMm+Entry.BoltDiameterMm);if(size<=0)return;float scale=(float)(Math.Min(Width-50,Height-110)/size),cx=Width/2f,cy=(Height-40)/2f,r=(float)(Entry.OpeningDiameterMm*scale/2),half=(float)(Entry.EnvelopeMm*scale/2);using(var pen=new Pen(DesignUi.Primary,2)){g.DrawRectangle(pen,cx-half,cy-half,half*2,half*2);if(r>0)g.DrawEllipse(pen,cx-r,cy-r,2*r,2*r);float h=(float)(Entry.BoltPitchMm*scale/2),b=(float)(Entry.BoltDiameterMm*scale/2);foreach(int x in new[]{-1,1})foreach(int y in new[]{-1,1})if(b>0)g.DrawEllipse(pen,cx+x*h-b,cy+y*h-b,2*b,2*b);}g.DrawString("Montaje sobre la placa · mm\nPaso "+Entry.BoltPitchMm.ToString("0.##")+" · barrenos Ø"+Entry.BoltDiameterMm.ToString("0.##")+"\nEnvolvente "+Entry.EnvelopeMm.ToString("0.##")+" · abertura Ø"+Entry.OpeningDiameterMm.ToString("0.##"),Font,Brushes.DimGray,12,Height-76);}
    }
    internal sealed class BearingRegistrationForm : Form {
        readonly BearingImportSession session;readonly BearingCatalog catalog;
        readonly TextBox brand=new TextBox(),reference=new TextBox();readonly ComboBox seat=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};
        readonly NumericUpDown opening=Number(),pitch=Number(),bolt=Number(),envelope=Number();
        readonly CheckBox verified=new CheckBox{Text="Revisé las medidas y la cara de apoyo del modelo",AutoSize=true};
        readonly Label feedback=new Label{AutoSize=true,MaximumSize=new Size(425,0),ForeColor=Color.Firebrick};
        readonly BearingMountPreview preview=new BearingMountPreview{Dock=DockStyle.Fill};
        BearingCatalogEntry detected;internal BearingCatalogEntry Result;
        static NumericUpDown Number(){return new NumericUpDown{Minimum=0,Maximum=1000,DecimalPlaces=3,Width=200};}
        internal BearingRegistrationForm(BearingImportSession import,BearingCatalog store,string source){
            session=import;catalog=store;Text="Registrar chumacera";Size=new Size(960,760);MinimumSize=new Size(880,660);StartPosition=FormStartPosition.CenterParent;Font=DesignUi.NavigationRegular;
            var panel=new Panel{Dock=DockStyle.Left,Width=465,AutoScroll=true,Padding=new Padding(16)};var table=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1};table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.Controls.Add(table);Controls.Add(preview);Controls.Add(panel);
            Action<Control> row=delegate(Control c){c.Margin=new Padding(0,4,0,8);c.Dock=DockStyle.Top;table.Controls.Add(c,0,table.RowCount++);};
            Action<string,Control> field=delegate(string title,Control c){row(new Label{Text=title,AutoSize=true});row(c);};
            row(new Label{Text="Modelo: "+Path.GetFileName(source)+"\nSe guardará una copia sólida independiente del archivo original.",AutoSize=true,MaximumSize=new Size(420,0)});
            var auto=new Button{Text="Detectar montaje automáticamente",Height=32};auto.Click+=delegate{Read(false);};row(auto);
            row(new Label{Text="Si la detección es ambigua, en SOLIDWORKS selecciona con Ctrl, en orden:\n1. Cara plana que apoya en la placa.\n2. Cara cilíndrica del eje.\n3. Cara interior de un barreno de fijación.",AutoSize=true,MaximumSize=new Size(420,0)});
            var selected=new Button{Text="Leer las tres caras seleccionadas",Height=32};selected.Click+=delegate{Read(true);};row(selected);row(feedback);
            field("Marca",brand);reference.Text=Path.GetFileNameWithoutExtension(source);field("Referencia / nombre del modelo",reference);
            seat.Items.AddRange(new[]{"1 1/8 in · 28.575 mm","1 1/4 in · 31.750 mm","1 1/2 in · 38.100 mm"});seat.SelectedIndex=1;field("Asiento de la flecha",seat);
            field("Abertura central de la placa · mm",opening);row(new Label{Text="Revisa el paso del cuerpo y añade la holgura necesaria. No equivale al diámetro del eje.",AutoSize=true,MaximumSize=new Size(420,0)});
            pitch.Enabled=false;field("Paso cuadrado detectado entre centros · mm",pitch);field("Diámetro de barrenos de la placa · mm",bolt);field("Envolvente exterior centrada en el eje · mm",envelope);row(verified);
            var save=new Button{Text="Guardar en catálogo y seleccionar",Height=38,BackColor=DesignUi.Accent,ForeColor=Color.White};save.Click+=delegate{try{var entry=Values();entry.Verified=verified.Checked;Result=catalog.Add(entry,session.SnapshotPath);DialogResult=DialogResult.OK;Close();}catch(Exception ex){feedback.Text=ex.Message;}};row(save);
            foreach(var n in new[]{opening,pitch,bolt,envelope})n.ValueChanged+=delegate{verified.Checked=false;UpdatePreview();};seat.SelectedIndexChanged+=delegate{verified.Checked=false;};brand.TextChanged+=delegate{verified.Checked=false;};reference.TextChanged+=delegate{verified.Checked=false;};
            Shown+=delegate{Read(false);};
        }
        BearingCatalogEntry Values(){if(detected==null)throw new InvalidOperationException("Primero identifica el montaje del modelo.");var e=detected.Copy();e.Brand=brand.Text.Trim();e.Reference=reference.Text.Trim();e.ShaftSeatInches=new[]{1.125,1.25,1.5}[seat.SelectedIndex];e.OpeningDiameterMm=(double)opening.Value;e.BoltPitchMm=(double)pitch.Value;e.BoltDiameterMm=(double)bolt.Value;e.EnvelopeMm=(double)envelope.Value;return e;}
        void UpdatePreview(){if(detected==null)return;preview.Entry=Values();preview.Invalidate();}
        void Read(bool selected){verified.Checked=false;detected=null;preview.Entry=null;preview.Invalidate();try{detected=session.Detect(selected);opening.Value=(decimal)Math.Min(1000,detected.OpeningDiameterMm);pitch.Value=(decimal)Math.Min(1000,detected.BoltPitchMm);bolt.Value=(decimal)Math.Min(1000,detected.BoltDiameterMm);envelope.Value=(decimal)Math.Min(1000,detected.EnvelopeMm);seat.SelectedIndex=Array.IndexOf(new[]{1.125,1.25,1.5},detected.ShaftSeatInches);verified.Checked=false;feedback.ForeColor=DesignUi.Muted;feedback.Text="Patrón cuadrado detectado. Revisa en SOLIDWORKS la cara de apoyo y confirma las medidas. Puedes corregir la holgura de los barrenos y la abertura.";UpdatePreview();}catch(Exception ex){feedback.ForeColor=Color.Firebrick;feedback.Text=ex.Message;}}
    }
    internal sealed class BearingSearchForm : Form {
        internal BearingCatalogEntry Result;readonly ListBox list=new ListBox{Dock=DockStyle.Fill};readonly BearingCatalogEntry[] entries;
        internal BearingSearchForm(BearingCatalog catalog){
            Text="Catálogo de chumaceras";Size=new Size(640,470);StartPosition=FormStartPosition.CenterParent;Font=DesignUi.NavigationRegular;entries=catalog.All().ToArray();
            var search=new TextBox{Dock=DockStyle.Top};var hint=new Label{Text="Buscar por marca, referencia o diámetro de asiento",Dock=DockStyle.Top,Height=28};var select=new Button{Text="Seleccionar",Dock=DockStyle.Bottom,Height=40};
            Controls.Add(list);Controls.Add(select);Controls.Add(search);Controls.Add(hint);list.DisplayMember="Label";
            Action refresh=delegate{list.Items.Clear();foreach(var e in entries)if(e.Label.IndexOf(search.Text,StringComparison.OrdinalIgnoreCase)>=0)list.Items.Add(e);if(list.Items.Count>0)list.SelectedIndex=0;select.Enabled=list.Items.Count>0;};search.TextChanged+=delegate{refresh();};
            Action choose=delegate{if(list.SelectedItem==null)return;Result=(BearingCatalogEntry)list.SelectedItem;DialogResult=DialogResult.OK;Close();};select.Click+=delegate{choose();};list.DoubleClick+=delegate{choose();};refresh();
        }
    }
    internal sealed partial class CompleteBeltView {
        internal void ApplyBearing(BearingCatalogEntry entry,BearingCatalog catalog){
            var section=sections[selected];if(section.Type==BeltSectionType.Intermedio)throw new InvalidOperationException("Selecciona el tramo conducido o motriz.");entry.Validate();string path=catalog.ModelPath(entry);if(!File.Exists(path))throw new FileNotFoundException("Falta el modelo guardado de la chumacera.",path);
            BearingModelMesh.Ensure(catalog,entry);
            catalog.Touch(entry.Id);entry.Apply(section.ShaftPlates);section.ShaftPlates.Enabled=true;Changed();if(category==9)PlateRedraw();
        }
        Button BearingButton(){var button=ViewButton("Chumacera ▾",delegate{},280);button.Name="SelectBearingButton";button.BackColor=DesignUi.Selection;button.ForeColor=DesignUi.Primary;button.AutoEllipsis=true;SetBearingButtonText(button);button.Click+=delegate{ShowBearingMenu(button);};return button;}
        void SetBearingButtonText(Button button){
            var bearing=sections[selected].ShaftPlates.Bearing;
            button.Text=bearing==null?"Chumacera ▾":"Chumacera: "+bearing.Reference+" ▾";
            tips.SetToolTip(button,bearing==null?"Seleccionar una chumacera reciente, buscar o registrar un modelo 3D.":bearing.Label);
        }
        void RefreshBearingButtons(){foreach(var host in new Control[]{quickPanel,fields})foreach(Control c in host.Controls.Find("SelectBearingButton",true)){var button=c as Button;if(button!=null)SetBearingButtonText(button);}}
        ContextMenuStrip bearingMenu;
        void ShowBearingMenu(Button button){
            try{
                var catalog=BearingCatalog.Default();var entries=catalog.All();
                if(bearingMenu==null){
                    bearingMenu=new ContextMenuStrip();
                    Disposed+=delegate{bearingMenu.Dispose();};
                }
                var menu=bearingMenu;
                menu.Close();
                while(menu.Items.Count>0)menu.Items[0].Dispose();
                var header=new ToolStripMenuItem("Últimas utilizadas"){Enabled=false};menu.Items.Add(header);
                foreach(var entry in entries.Take(6)){var e=entry;var item=new ToolStripMenuItem(e.Label);item.Click+=delegate{try{ApplyBearing(e,catalog);}catch(Exception ex){MessageBox.Show(this,ex.Message,"Chumacera");}};menu.Items.Add(item);}
                if(entries.Count==0)menu.Items.Add(new ToolStripMenuItem("Aún no hay chumaceras registradas"){Enabled=false});menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("Buscar en catálogo…",null,delegate{try{using(var search=new BearingSearchForm(catalog))if(search.ShowDialog(this)==DialogResult.OK)ApplyBearing(search.Result,catalog);}catch(Exception ex){MessageBox.Show(this,ex.Message,"Catálogo");}});
                menu.Items.Add("Agregar nueva desde modelo 3D…",null,delegate{RegisterBearing(catalog);});
                if(sections[selected].ShaftPlates.Bearing!=null){menu.Items.Add(new ToolStripSeparator());menu.Items.Add("Usar medidas manuales",null,delegate{sections[selected].ShaftPlates.Bearing=null;Changed();if(category==9)PlateRedraw();});}
                menu.Show(button,new Point(0,button.Height));
            }catch(Exception ex){MessageBox.Show(this,ex.Message,"Catálogo de chumaceras");}
        }
        void RegisterBearing(BearingCatalog catalog){
            using(var file=new OpenFileDialog{Filter=BearingImportSession.Filter,Title="Cargar modelo 3D de chumacera"}){
                if(file.ShowDialog(this)!=DialogResult.OK)return;
                try{UseWaitCursor=true;using(var import=BearingImportSession.Open(file.FileName)){UseWaitCursor=false;using(var registration=new BearingRegistrationForm(import,catalog,file.FileName))if(registration.ShowDialog(this)==DialogResult.OK)ApplyBearing(registration.Result,catalog);}}
                catch(Exception ex){MessageBox.Show(this,ex.Message,"No se pudo registrar la chumacera");}finally{UseWaitCursor=false;}
            }
        }
    }
}
