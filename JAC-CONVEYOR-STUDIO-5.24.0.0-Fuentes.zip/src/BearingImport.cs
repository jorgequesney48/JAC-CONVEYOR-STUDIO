﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
namespace PerfilBandas {
    internal sealed class BearingCylinder {public double[] Point,Axis;public double Radius;public bool Hole;}
    internal sealed class BearingPlane {public double[] Point,Normal;public double Area;}
    internal sealed class BearingPattern {public double[] Center,U,V,N;public double Pitch,Diameter;}
    internal static class BearingDetection {
        internal static List<BearingPattern> Patterns(List<BearingCylinder> cylinders,double[] requiredAxis=null,double[] requiredCenter=null,double[] requiredHole=null,double requiredRadius=0){
            var result=new List<BearingPattern>();
            for(int a=0;a<cylinders.Count;a++)for(int b=a+1;b<cylinders.Count;b++) {
                var first=cylinders[a];var second=cylinders[b];
                if(!first.Hole||!second.Hole||first.Radius<.002||first.Radius>.025||Math.Abs(first.Radius-second.Radius)>.0001||Math.Abs(BearingMath.Dot(first.Axis,second.Axis))<.9999)continue;
                if(requiredRadius>0 && Math.Abs(first.Radius-requiredRadius)>.0001)continue;
                double[] n=BearingMath.Unit(first.Axis);if(requiredAxis!=null&&Math.Abs(BearingMath.Dot(n,requiredAxis))<.9999)continue;
                double[] delta=BearingMath.Sub(second.Point,first.Point);delta=BearingMath.Sub(delta,BearingMath.Scale(n,BearingMath.Dot(delta,n)));
                double pitch=Math.Sqrt(BearingMath.Dot(delta,delta));if(pitch<.02||pitch>.3)continue;
                double[] u=BearingMath.Unit(delta),v=BearingMath.Cross(n,u);
                foreach(int sign in new[]{-1,1}){
                    double[] third=BearingMath.Add(first.Point,BearingMath.Scale(v,sign*pitch)),fourth=BearingMath.Add(second.Point,BearingMath.Scale(v,sign*pitch));
                    Func<double[],BearingCylinder> find=delegate(double[] target){return cylinders.FirstOrDefault(c=>c.Hole && Math.Abs(c.Radius-first.Radius)<.0001 && Math.Abs(BearingMath.Dot(c.Axis,n))>.9999 && Distance(c.Point,target,n)<.00015);};
                    if(find(third)==null||find(fourth)==null)continue;
                    double[] center=BearingMath.Add(BearingMath.Add(first.Point,BearingMath.Scale(u,pitch/2)),BearingMath.Scale(v,sign*pitch/2));
                    if(requiredCenter!=null && Distance(center,requiredCenter,n)>.0002)continue;
                    if(requiredHole!=null && new[]{first.Point,second.Point,third,fourth}.All(q=>Distance(q,requiredHole,n)>.0002))continue;
                    if(result.Any(p=>Math.Abs(p.Pitch-pitch)<.0001&&Math.Abs(p.Diameter-2*first.Radius)<.0001&&Math.Abs(BearingMath.Dot(p.N,n))>.9999&&Distance(p.Center,center,n)<.0002))continue;
                    result.Add(new BearingPattern{Center=center,U=u,V=v,N=n,Pitch=pitch,Diameter=first.Radius*2});
                }
            }
            return result;
        }
        internal static double Distance(double[] a,double[] b,double[] n){var d=BearingMath.Sub(a,b);d=BearingMath.Sub(d,BearingMath.Scale(n,BearingMath.Dot(d,n)));return Math.Sqrt(BearingMath.Dot(d,d));}
    }
    internal sealed class BearingImportSession : IDisposable {
        internal SldWorks Sw;internal ModelDoc2 Model;internal string SnapshotPath;
        internal List<Body2> Bodies=new List<Body2>();
        internal List<BearingCylinder> Cylinders=new List<BearingCylinder>();
        internal List<BearingPlane> Planes=new List<BearingPlane>();
        internal static readonly string Filter="Modelos 3D|*.sldprt;*.sldasm;*.step;*.stp;*.x_t;*.x_b;*.igs;*.iges|Todos los archivos|*.*";
        internal static BearingImportSession Open(string path){
            string ext=Path.GetExtension(path).ToLowerInvariant();if(!new[]{".sldprt",".sldasm",".step",".stp",".x_t",".x_b",".igs",".iges"}.Contains(ext))throw new InvalidOperationException("Carga SLDPRT, SLDASM, STEP, Parasolid o IGES.");
            var session=new BearingImportSession();ModelDoc2 source=null;bool sourceOwned=false;
            try{
                try{session.Sw=(SldWorks)Marshal.GetActiveObject("SldWorks.Application");}catch{Type t=Type.GetTypeFromProgID("SldWorks.Application");if(t==null)throw new InvalidOperationException("Se necesita SOLIDWORKS para importar y medir el modelo.");session.Sw=(SldWorks)Activator.CreateInstance(t);}
                session.Sw.Visible=true;int err=0,warn=0;
                source=(ModelDoc2)session.Sw.GetOpenDocumentByName(Path.GetFullPath(path));sourceOwned=source==null;
                if(source==null){if(ext==".sldprt"||ext==".sldasm")source=session.Sw.OpenDoc6(Path.GetFullPath(path),ext==".sldasm"?2:1,(int)swOpenDocOptions_e.swOpenDocOptions_Silent| (int)swOpenDocOptions_e.swOpenDocOptions_ReadOnly,"",ref err,ref warn);else source=session.Sw.LoadFile4(Path.GetFullPath(path),"r",session.Sw.GetImportFileData(path),ref err);}
                if(source==null)throw new InvalidOperationException("No se pudo importar el modelo (error "+err+").");
                var copies=new List<Body2>();
                if(source.GetType()==(int)swDocumentTypes_e.swDocPART)CopyBodies((PartDoc)source,null,copies);
                else if(source.GetType()==(int)swDocumentTypes_e.swDocASSEMBLY){
                    var assembly=(AssemblyDoc)source;assembly.ResolveAllLightWeightComponents(false);
                    var comps=(object[])assembly.GetComponents(false);if(comps!=null)foreach(Component2 c in comps){if(c.IsSuppressed()||c.IsHidden(false))continue;var doc=(ModelDoc2)c.GetModelDoc2();if(doc==null)throw new InvalidOperationException("El ensamble tiene piezas sin resolver. Abre sus referencias antes de importarlo.");if(doc.GetType()==1)CopyBodies((PartDoc)doc,c.Transform2,copies);}
                }
                if(copies.Count==0)throw new InvalidOperationException("El archivo no contiene sólidos medibles. Carga un modelo sólido, no una malla o un dibujo.");
                string template=session.Sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
                if(!File.Exists(template))throw new InvalidOperationException("Configura la plantilla de pieza predeterminada en SOLIDWORKS.");
                session.Model=(ModelDoc2)session.Sw.NewDocument(template,0,0,0);if(session.Model==null)throw new InvalidOperationException("No se pudo crear la copia del modelo.");
                foreach(var body in copies)if(((PartDoc)session.Model).CreateFeatureFromBody3(body,false,0)==null)throw new InvalidOperationException("No se pudo copiar un sólido de la chumacera.");
                string drafts=Path.Combine(BearingCatalog.Default().Root,"importaciones");Directory.CreateDirectory(drafts);session.SnapshotPath=Path.Combine(drafts,Guid.NewGuid().ToString("N")+".SLDPRT");
                if(!session.Model.SaveAs4(session.SnapshotPath,0,(int)swSaveAsOptions_e.swSaveAsOptions_Silent,ref err,ref warn)||err!=0)throw new InvalidOperationException("No se pudo guardar la copia sólida (error "+err+").");
                session.Model.ShowNamedView2("*Isométrica",(int)swStandardViews_e.swIsometricView);session.Model.ViewZoomtofit2();session.ReadGeometry();return session;
            }catch{session.Dispose();throw;}
            finally{if(sourceOwned&&source!=null)session.Sw.CloseDoc(source.GetTitle());if(session.Model!=null){int error=0;session.Sw.ActivateDoc3(session.Model.GetTitle(),false,0,ref error);}}
        }
        static void CopyBodies(PartDoc part,MathTransform transform,List<Body2> copies){var bodies=(object[])part.GetBodies2((int)swBodyType_e.swSolidBody,true);if(bodies==null)return;foreach(Body2 b in bodies){var copy=(Body2)b.Copy();if(transform!=null&&!copy.ApplyTransform(transform))throw new InvalidOperationException("No se pudo preservar la posición de un componente.");copies.Add(copy);}}
        void ReadGeometry(){
            Bodies=((object[])((PartDoc)Model).GetBodies2((int)swBodyType_e.swSolidBody,true)).Cast<Body2>().ToList();
            foreach(var body in Bodies){var faces=(object[])body.GetFaces();if(faces==null)continue;foreach(Face2 face in faces){var surface=(Surface)face.GetSurface();if(surface.IsCylinder())Cylinders.Add(Cylinder(face));else if(surface.IsPlane()){var p=(double[])surface.PlaneParams;Planes.Add(new BearingPlane{Normal=BearingMath.Scale(BearingMath.Unit(new[]{p[0],p[1],p[2]}),face.FaceInSurfaceSense()?1:-1),Point=new[]{p[3],p[4],p[5]},Area=face.GetArea()});}}}
        }
        static BearingCylinder Cylinder(Face2 face){var surface=(Surface)face.GetSurface();if(!surface.IsCylinder())throw new InvalidOperationException("Selecciona una cara cilíndrica para el eje o barreno.");var p=(double[])surface.CylinderParams;return new BearingCylinder{Point=new[]{p[0],p[1],p[2]},Axis=BearingMath.Unit(new[]{p[3],p[4],p[5]}),Radius=p[6],Hole=face.FaceInSurfaceSense()};}
        internal BearingCatalogEntry Detect(bool selected){
            BearingPlane plane=null;BearingCylinder central=null,hole=null;
            if(selected){
                var active=(ModelDoc2)Sw.ActiveDoc;
                if(active==null || !String.Equals(active.GetPathName(),SnapshotPath,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Selecciona las caras en la copia de la chumacera abierta por este registro.");
                var mgr=(SelectionMgr)Model.SelectionManager;if(mgr.GetSelectedObjectCount2(-1)!=3)throw new InvalidOperationException("Con Ctrl selecciona, en orden: cara plana que apoya en la placa, cara cilíndrica del eje y cara interior de un barreno de fijación.");
                var f=mgr.GetSelectedObject6(1,-1) as Face2;var axis=mgr.GetSelectedObject6(2,-1) as Face2;var bolt=mgr.GetSelectedObject6(3,-1) as Face2;
                if(f==null||axis==null||bolt==null)throw new InvalidOperationException("Selecciona tres caras, no aristas ni componentes.");
                var surface=(Surface)f.GetSurface();if(!surface.IsPlane())throw new InvalidOperationException("La primera cara debe ser plana.");var p=(double[])surface.PlaneParams;plane=new BearingPlane{Normal=BearingMath.Scale(BearingMath.Unit(new[]{p[0],p[1],p[2]}),f.FaceInSurfaceSense()?1:-1),Point=new[]{p[3],p[4],p[5]}};central=Cylinder(axis);hole=Cylinder(bolt);
                if(!hole.Hole||Math.Abs(BearingMath.Dot(central.Axis,plane.Normal))<.9999)throw new InvalidOperationException("El eje debe ser perpendicular a la cara de montaje y el barreno debe ser interior.");
            }
            var patterns=BearingDetection.Patterns(Cylinders,central==null?null:central.Axis,central==null?null:central.Point,hole==null?null:hole.Point,hole==null?0:hole.Radius);
            if(patterns.Count!=1)throw new InvalidOperationException(patterns.Count==0?"No se encontró un patrón de cuatro barrenos cuadrados. Selecciona las tres referencias en SOLIDWORKS y vuelve a leer.":"Hay varios patrones posibles. Selecciona la cara de montaje, el eje y un barreno para identificar el correcto.");
            var pattern=patterns[0];
            if(plane==null){plane=Planes.Where(p=>Math.Abs(BearingMath.Dot(p.Normal,pattern.N))>.9999).OrderByDescending(p=>p.Area).FirstOrDefault();if(plane==null)throw new InvalidOperationException("No se encontró la cara plana de montaje.");}
            double[] n=plane.Normal; // Into the bearing from its mounting face, including bodies protruding through the plate opening.
            var entry=new BearingCatalogEntry{Origin=BearingMath.Project(pattern.Center,plane.Point,n),U=pattern.U,N=n,BoltPitchMm=pattern.Pitch*1000,BoltDiameterMm=pattern.Diameter*1000};entry.V=BearingMath.Cross(n,entry.U);
            entry.EnvelopeMm=2*Math.Max(Math.Max(Math.Abs(Extreme(entry.U,true)-BearingMath.Dot(entry.Origin,entry.U)),Math.Abs(Extreme(entry.U,false)-BearingMath.Dot(entry.Origin,entry.U))),Math.Max(Math.Abs(Extreme(entry.V,true)-BearingMath.Dot(entry.Origin,entry.V)),Math.Abs(Extreme(entry.V,false)-BearingMath.Dot(entry.Origin,entry.V))))*1000;
            var coaxial=Cylinders.Where(c=>Math.Abs(BearingMath.Dot(c.Axis,n))>.9999 && BearingDetection.Distance(c.Point,entry.Origin,n)<.0002).ToList();
            double seat=central!=null?central.Radius*2*1000:coaxial.Where(c=>c.Hole).Select(c=>c.Radius*2*1000).DefaultIfEmpty(0).Min();
            var seats=new[]{1.125,1.25,1.5};double chosen=seats.OrderBy(d=>Math.Abs(d*25.4-seat)).First();if(Math.Abs(chosen*25.4-seat)<.2)entry.ShaftSeatInches=chosen;
            // Propose the largest coaxial clearance within the bolt circle; user verifies actual mounting clearance.
            entry.ModelBoltPitchMm=entry.BoltPitchMm;entry.ModelBoltDiameterMm=entry.BoltDiameterMm;entry.ModelEnvelopeMm=entry.EnvelopeMm;
            entry.OpeningDiameterMm=coaxial.Select(c=>c.Radius*2*1000).Where(d=>d>entry.ShaftSeatInches*25.4 && d<entry.BoltPitchMm-entry.BoltDiameterMm-8).DefaultIfEmpty(0).Max();return entry;
        }
        double Extreme(double[] direction,bool maximum){double extreme=maximum?Double.NegativeInfinity:Double.PositiveInfinity;foreach(var body in Bodies){double x,y,z;var dir=maximum?direction:BearingMath.Scale(direction,-1);if(!body.GetExtremePoint(dir[0],dir[1],dir[2],out x,out y,out z))throw new InvalidOperationException("No se pudo medir la envolvente del sólido.");double v=BearingMath.Dot(new[]{x,y,z},direction);extreme=maximum?Math.Max(extreme,v):Math.Min(extreme,v);}return extreme;}
        public void Dispose(){if(Model!=null&&Sw!=null){try{Sw.CloseDoc(Model.GetTitle());}catch{}Model=null;}if(SnapshotPath!=null&&File.Exists(SnapshotPath))File.Delete(SnapshotPath);}
    }
}
