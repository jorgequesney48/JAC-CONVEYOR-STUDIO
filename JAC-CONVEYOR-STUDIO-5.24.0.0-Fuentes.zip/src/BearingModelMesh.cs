using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
namespace PerfilBandas {
    internal static class BearingModelMesh {
        static readonly Dictionary<string,float[]> cache=new Dictionary<string,float[]>(StringComparer.OrdinalIgnoreCase);
        internal static string PathFor(BearingCatalog catalog,BearingCatalogEntry entry){return Path.Combine(Path.GetDirectoryName(catalog.ModelPath(entry)),"vista3d.bin");}
        internal static void Save(string path,float[] coordinates){
            if(coordinates==null||coordinates.Length==0||coordinates.Length%9!=0)throw new InvalidOperationException("El modelo no devolvió una malla 3D válida.");
            using(var writer=new BinaryWriter(File.Create(path+".tmp"))){writer.Write(1);writer.Write(coordinates.Length);foreach(float v in coordinates){if(Single.IsNaN(v)||Single.IsInfinity(v))throw new InvalidDataException("Coordenada de modelo no válida.");writer.Write(v);}}
            if(File.Exists(path))File.Replace(path+".tmp",path,null);else File.Move(path+".tmp",path);
            lock(cache)cache.Remove(path);
        }
        internal static float[] Read(BearingCatalog catalog,BearingCatalogEntry entry){
            return ReadPath(PathFor(catalog,entry));
        }
        internal static float[] ReadPath(string path){
            lock(cache){float[] data;if(cache.TryGetValue(path,out data))return data;
            if(!File.Exists(path))throw new InvalidOperationException("Falta la vista 3D guardada del componente: "+path);
            using(var reader=new BinaryReader(File.OpenRead(path))){if(reader.ReadInt32()!=1)throw new InvalidDataException("Vista de chumacera incompatible.");int count=reader.ReadInt32();if(count<=0||count%9!=0||count>18000000||reader.BaseStream.Length!=8L+count*4L)throw new InvalidDataException("Malla de chumacera no válida.");data=new float[count];for(int i=0;i<count;i++){data[i]=reader.ReadSingle();if(Single.IsNaN(data[i])||Single.IsInfinity(data[i]))throw new InvalidDataException("Malla de chumacera no válida.");}}
            cache[path]=data;return data;}
        }
        internal static void Ensure(BearingCatalog catalog,BearingCatalogEntry entry){
            string target=PathFor(catalog,entry);if(File.Exists(target)){Read(catalog,entry);return;}
            string path=catalog.ModelPath(entry);if(!File.Exists(path))throw new FileNotFoundException("No se encuentra el modelo 3D guardado de la chumacera.",path);
            SldWorks sw;try{sw=(SldWorks)Marshal.GetActiveObject("SldWorks.Application");}catch{var type=Type.GetTypeFromProgID("SldWorks.Application");if(type==null)throw new InvalidOperationException("Se necesita SOLIDWORKS para preparar la vista 3D por primera vez.");sw=(SldWorks)Activator.CreateInstance(type);}
            var original=(ModelDoc2)sw.ActiveDoc;var doc=(ModelDoc2)sw.GetOpenDocumentByName(path);bool owned=doc==null;int error=0,warning=0;
            try{
                if(doc==null)doc=sw.OpenDoc6(path,1,(int)swOpenDocOptions_e.swOpenDocOptions_Silent| (int)swOpenDocOptions_e.swOpenDocOptions_ReadOnly,"",ref error,ref warning);
                if(doc==null)throw new InvalidOperationException("No se pudo abrir la chumacera para preparar su vista 3D (error "+error+").");
                doc.EditRebuild3();var triangles=((PartDoc)doc).GetTessTriangles(true) as float[];Save(target,triangles);
            }finally{if(owned&&doc!=null)sw.CloseDoc(doc.GetTitle());if(original!=null)sw.ActivateDoc3(original.GetTitle(),false,0,ref error);}
        }
        internal static BeltPoint3D Transform(float[] points,int index,double[] t){double a=points[index],b=points[index+1],c=points[index+2];return new BeltPoint3D(1000*(a*t[0]+b*t[3]+c*t[6]+t[9]),1000*(a*t[1]+b*t[4]+c*t[7]+t[10]),1000*(a*t[2]+b*t[5]+c*t[8]+t[11]));}
    }
}
