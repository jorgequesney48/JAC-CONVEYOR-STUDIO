using System;
using System.Collections.Generic;
using System.Drawing;

namespace PerfilBandas {
    internal struct BeltPoint3D {
        public double X,Y,Z;
        public BeltPoint3D(double x,double y,double z){X=x;Y=y;Z=z;}
        public BeltPoint3D Plus(BeltPoint3D p){return new BeltPoint3D(X+p.X,Y+p.Y,Z+p.Z);}
    }
    internal sealed class BeltFace3D {
        internal string PartKey,FaceKey;
        internal string ParametricFaceKey;internal double FaceParameter;
        internal PointF[] BeltCoordinates;internal double BeltWidthMm;
        public bool IsTransportBelt;
        public BeltPoint3D[] Outer;
        public List<BeltPoint3D[]> Holes=new List<BeltPoint3D[]>();
        public Color Color;
        public BeltSurface3D Surface;
        public int Section;
        public bool DrawEdges=true;
        public bool IsBearing;
        public bool IsShaft;
        public bool IsSprocket;
        public bool IsVerticalSupport;
        public bool IsLegCrossbar;
        public bool IsCurveWeb,IsCurveFlange,IsCurveUpperSupport,IsCurveLowerSupport,IsCurveUpperGuide,IsCurveLowerGuide;
    }
    // Configuration mesh in millimetres, independent of COM and camera projection.
    // Profile bends use concentric inner/outer radii; cuts use the CAD layout calculations.
    internal sealed partial class Belt3DGeometry {
        string facePart;int partFace;
        void BeginPart(string key){facePart=key;partFace=0;}
        public readonly List<BeltFace3D> Faces=new List<BeltFace3D>();
        public readonly List<ProfilePattern> Patterns=new List<ProfilePattern>();
        public readonly List<ProfileSettings> Profiles=new List<ProfileSettings>();
        public readonly List<double> Starts=new List<double>(),Lengths=new List<double>();
        public double Width,Length;
        internal BeltTrajectory Trajectory;
        public List<CurveFrame> RouteFrames;
        internal BeltPoint3D NavigationCenter(int section=-1){if(RouteFrames==null)return new BeltPoint3D(Width/2,-90,section>=0?Starts[section]+Lengths[section]/2:Length/2);if(section>=0)return RouteFrames[section].Point(RouteFrames[section].Width/2,-90,RouteFrames[section].Length/2);double middle=0;foreach(var frame in RouteFrames)middle+=frame.Length/2;foreach(var frame in RouteFrames){if(middle<=frame.Length)return frame.Point(frame.Width/2,-90,middle);middle-=frame.Length;}var last=RouteFrames[RouteFrames.Count-1];return last.Point(last.Width/2,-90,last.Length);}
        static readonly Color Steel=ViewerMaterials.Stainless,Support=ViewerMaterials.Stainless,Plate=ViewerMaterials.Stainless;
        BeltFace3D Face(BeltPoint3D[] points,int section,Color color,BeltSurface3D surface){var f=new BeltFace3D{Outer=points,Section=section,Color=color,Surface=surface,PartKey=facePart,FaceKey=facePart==null?null:facePart+"/"+(partFace++)};Faces.Add(f);return f;}
        void Extrude(BeltPoint3D[] points,BeltPoint3D delta,int section,Color color,List<BeltPoint3D[]> holes,BeltSurface3D surface=BeltSurface3D.StainlessSteel) {
            var a=Face(points,section,color,surface);if(holes!=null)a.Holes.AddRange(holes);
            var other=Array.ConvertAll(points,delegate(BeltPoint3D p){return p.Plus(delta);});
            var b=Face(other,section,color,surface);if(holes!=null)foreach(var hole in holes)b.Holes.Add(Array.ConvertAll(hole,delegate(BeltPoint3D p){return p.Plus(delta);}));
            var loops=new List<BeltPoint3D[]>{points};if(holes!=null)loops.AddRange(holes);
            foreach(var loop in loops)for(int j=0;j<loop.Length;j++){var p=loop[j];var q=loop[(j+1)%loop.Length];Face(new[]{p,q,q.Plus(delta),p.Plus(delta)},section,color,surface);}
        }
        static BeltPoint3D[] Wall(double x,double z,double y,PointF[] contour,bool mirror) {
            return Array.ConvertAll(contour,delegate(PointF p){return new BeltPoint3D(x,y+p.Y,z+(mirror?-p.X:p.X));});
        }
        static PointF[] Rectangle(double left,double bottom,double width,double height){return new[]{new PointF((float)left,(float)bottom),new PointF((float)(left+width),(float)bottom),new PointF((float)(left+width),(float)(bottom+height)),new PointF((float)left,(float)(bottom+height))};}
        static PointF[] Circle(double radius,int n){var r=new PointF[n];for(int i=0;i<n;i++){double a=2*Math.PI*i/n;r[i]=new PointF((float)(radius*Math.Cos(a)),(float)(radius*Math.Sin(a)));}return r;}
        static PointF[] Slot(ProfileSlotSpec s) {
            var result=new List<PointF>();double half=s.LengthMm/2-s.RadiusMm;
            for(int i=0;i<=40;i++){double a=-Math.PI/2+Math.PI*i/40;result.Add(new PointF((float)(half+s.RadiusMm*Math.Cos(a)),(float)(s.RadiusMm*Math.Sin(a))));}
            for(int i=0;i<=40;i++){double a=Math.PI/2+Math.PI*i/40;result.Add(new PointF((float)(-half+s.RadiusMm*Math.Cos(a)),(float)(s.RadiusMm*Math.Sin(a))));}
            return result.ToArray();
        }
        public static Belt3DGeometry Build(IList<BeltSectionSpec> sections,ProfileSettings template,SoporteSettings supportTemplate,ReturnRollerSettings rollers,string nylamidColor="Blanco",BearingCatalog bearings=null,SprocketCatalog sprockets=null,VerticalSupportSettings verticalSupports=null,BeltDesignPlan designPlan=null,bool showTrajectory=true) {
            if(CurveRoute.HasCurves(sections))return BuildCurved(sections,template,supportTemplate,rollers,nylamidColor,bearings,sprockets,verticalSupports,designPlan,showTrajectory);
            Color plastic=ViewerMaterials.Nylamid(nylamidColor);
            var legSettings=verticalSupports??new VerticalSupportSettings();legSettings.Validate();
            var resolved=designPlan??BeltDesignPlan.Build(sections,template,supportTemplate,rollers,legSettings,bearings,sprockets);resolved.RequireValid();
            var rollerPlan=resolved.Rollers;
            var mesh=new Belt3DGeometry();double offset=0;
            for(int i=0;i<sections.Count;i++) {
                var section=sections[i];var p=resolved.Profiles[i].Copy();var s=resolved.Supports[i].Copy();
                if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers)foreach(var h in rollerPlan.Holes)if(h.SectionIndex==i){
                    mesh.BeginPart("s"+i+"/return/"+rollerPlan.Holes.IndexOf(h));
                    Func<PointF,BeltPoint3D> point=q=>new BeltPoint3D(rollers.SideClearanceMm,h.YMm+q.X,offset+h.LocalZMm+q.Y);
                    var bore=Array.ConvertAll(Circle(rollers.ShaftDiameterMm/2,24),q=>point(q));
                    mesh.Extrude(Array.ConvertAll(Circle(rollers.RollerDiameterMm/2,24),q=>point(q)),new BeltPoint3D(s.LengthMm-2*rollers.SideClearanceMm,0,0),i,plastic,new List<BeltPoint3D[]>{bore},BeltSurface3D.Nylamid);
                    double start=-rollers.ShaftProjectionMm-p.ThicknessMm;
                    if(h.Keyhole){double flat=ReturnRollerSeatGeometry.FlatLength(rollers,p),length=s.LengthMm-2*start;var contour=ReturnRollerSeatGeometry.FlatShaft();
                    mesh.Extrude(Array.ConvertAll(contour,q=>new BeltPoint3D(start,h.YMm+q.Y,offset+h.LocalZMm+q.X)),new BeltPoint3D(flat,0,0),i,Steel,null);
                    mesh.Extrude(Array.ConvertAll(Circle(rollers.ShaftDiameterMm/2,48),q=>new BeltPoint3D(start+flat,h.YMm+q.X,offset+h.LocalZMm+q.Y)),new BeltPoint3D(length-2*flat,0,0),i,Steel,null);
                    mesh.Extrude(Array.ConvertAll(contour,q=>new BeltPoint3D(start+length-flat,h.YMm+q.Y,offset+h.LocalZMm+q.X)),new BeltPoint3D(flat,0,0),i,Steel,null);
                    }else mesh.Extrude(Array.ConvertAll(Circle(rollers.ShaftDiameterMm/2,16),q=>new BeltPoint3D(start,h.YMm+q.X,offset+h.LocalZMm+q.Y)),new BeltPoint3D(s.LengthMm-2*start,0,0),i,Steel,null);
                }
                var pattern=ProfileSlotLayout.PatternFor(p);mesh.Patterns.Add(pattern.Copy());mesh.Profiles.Add(p.Copy());mesh.Starts.Add(offset);mesh.Lengths.Add(p.LengthMm);mesh.Width=s.LengthMm;
                ShaftPlateLayout plate=ShaftPlateGeometry.Active(section)?ShaftPlateGeometry.Nominal(section,p,s):null;
                for(int side=0;side<2;side++) {
                    mesh.BeginPart("s"+i+"/profile/"+side);
                    double x=side==0?0:s.LengthMm,sign=side==0?-1:1;
                    var holes=new List<BeltPoint3D[]>();
                    foreach(var slot in pattern.Slots)holes.Add(Wall(x,offset+slot.CenterMm,slot.CenterYMm,Slot(slot),false));
                    if(pattern.LogoVisible) {
                        var contours=p.MarkA?LogoAGeometry.ContoursMm(pattern.LogoWidthMm):new[]{Circle(35*p.MarkScale/100,6)};
                        // The alternative hexagonal mark has a vertex at the top (same orientation as CAD).
                        if(!p.MarkA)for(int j=0;j<6;j++){double a=Math.PI/6+j*Math.PI/3;contours[0][j]=new PointF((float)(35*p.MarkScale/100*Math.Cos(a)),(float)(35*p.MarkScale/100*Math.Sin(a)));}
                        foreach(var contour in contours)holes.Add(Wall(x,offset+pattern.LogoCenterMm,pattern.CenterYMm,contour,side==1));
                    }
                    foreach(double z in SupportHoleLayout.CentersMm(p))holes.Add(Wall(x,offset+z,-p.SupportHoleYMm,Rectangle(-p.SupportHoleSizeMm/2,-p.SupportHoleSizeMm/2,p.SupportHoleSizeMm,p.SupportHoleSizeMm),false));
                    if(p.ResolvedRollerHoles!=null)foreach(var h in p.ResolvedRollerHoles)holes.Add(Wall(x,offset+h.LocalZMm,h.YMm,ReturnRollerSeatGeometry.Contour(h),false));
                    if(plate!=null&&section.ShaftPlates.Mounting==2) {
                        foreach(double y in ShaftPlateGeometry.LapHoleYs(plate))holes.Add(Wall(x,offset+plate.LapHoleZ,y,Rectangle(-plate.LapHoleSizeMm/2,-plate.LapHoleSizeMm/2,plate.LapHoleSizeMm,plate.LapHoleSizeMm),false));
                    }
                    double upper=ProfileBendGeometry.Tangent(p,true),lower=ProfileBendGeometry.Tangent(p,false);
                    mesh.Extrude(Wall(x,offset,0,Rectangle(0,-p.WebHeightMm+lower,p.LengthMm,p.WebHeightMm-upper-lower),false),new BeltPoint3D(sign*p.ThicknessMm,0,0),i,Steel,holes);
                    mesh.BeginPart("s"+i+"/profile/"+side+"/top");mesh.Flange(p,x,sign,offset,true,i);mesh.BeginPart("s"+i+"/profile/"+side+"/bottom");mesh.Flange(p,x,sign,offset,false,i);
                    mesh.BeginPart("s"+i+"/profile/"+side+"/bend/top");mesh.ProfileBend(p,x,sign,offset,true,i);
                    mesh.BeginPart("s"+i+"/profile/"+side+"/bend/bottom");mesh.ProfileBend(p,x,sign,offset,false,i);
                    if(plate!=null){
                        mesh.BeginPart("s"+i+"/shaftplate/"+side);mesh.ShaftPlate(section,p,plate,x,sign,offset,i);
                        var bearing=section.ShaftPlates.Bearing;
                        if(bearing!=null){
                            mesh.BeginPart("s"+i+"/bearing/"+side);var data=BearingModelMesh.Read(bearings ?? BearingCatalog.Default(),bearing);
                            double innerFace=section.ShaftPlates.Mounting==2?x+sign*p.ThicknessMm:x;
                            double bearingX=(innerFace+sign*ShaftPlateLayout.ThicknessMm)/1000;
                            var transform=BearingMath.Placement(bearing,side==1,bearingX,plate.AxisY/1000,(offset+plate.AxisZ)/1000);
                            for(int k=0;k<data.Length;k+=9){var f=mesh.Face(new[]{BearingModelMesh.Transform(data,k,transform),BearingModelMesh.Transform(data,k+3,transform),BearingModelMesh.Transform(data,k+6,transform)},i,Color.FromArgb(90,108,126),BeltSurface3D.Bearing);f.DrawEdges=false;f.IsBearing=true;}
                        }
                    }
                }
                if(ConveyorShaftGeometry.Active(section)){
                    mesh.BeginPart("s"+i+"/shaft");var shaft=ConveyorShaftGeometry.Calculate(section,p,s,plate);mesh.Shaft(shaft,offset,i);
                    if(shaft.Settings.Sprocket!=null){var entry=shaft.Settings.Sprocket;var data=BearingModelMesh.ReadPath((sprockets??SprocketCatalog.Default()).MeshPath(entry));int sprocketIndex=0;foreach(double x in SprocketGeometry.Centers(shaft)){mesh.BeginPart("s"+i+"/sprocket/"+(sprocketIndex++));var t=SprocketGeometry.Placement(entry,x,shaft.AxisY,offset+shaft.AxisZ);for(int k=0;k<data.Length;k+=9){var f=mesh.Face(new[]{BearingModelMesh.Transform(data,k,t),BearingModelMesh.Transform(data,k+3,t),BearingModelMesh.Transform(data,k+6,t)},i,ViewerMaterials.Nylamid(shaft.Settings.SprocketColor??"Amarillo"),BeltSurface3D.Nylamid);f.DrawEdges=false;f.IsSprocket=true;}}}
                }
                double sy=-p.SupportHoleYMm-s.EndPlateHoleYMm;
                var legStations=VerticalSupportLayout.LocalStations(p,i,sections.Count);
                var legMount=VerticalSupportLayout.NominalMountMm(p);
                for(int side=0;side<2;side++)foreach(double station in legStations){
                    double sign=side==0?-1:1;
                    mesh.BeginPart("s"+i+"/leg/"+side+"/"+Array.IndexOf(legStations,station));mesh.VerticalLeg(legSettings,side==1,(side==0?0:s.LengthMm)-sign*legMount[0],legMount[1],offset+station,i);
                }
                if(legSettings.CrossbarEnabled)foreach(double station in legStations){mesh.BeginPart("s"+i+"/crossbar/"+Array.IndexOf(legStations,station));mesh.LegCrossbar(LegCrossbarLayout.Nominal(legSettings,p,s,offset+station),i);}
                int supportIndex=0;foreach(double z in SupportHoleLayout.CentersMm(p)){mesh.BeginPart("s"+i+"/support/"+(supportIndex++));mesh.CrossSupport(s,sy,offset+z,i);}
                if(section.IncludeSlideRails)foreach(var rail in SlideRailGeometry.Placements(s,p.LengthMm)) {
                    mesh.BeginPart("s"+i+"/rail/"+rail.Index);double depth=rail.Position==SlideRailPosition.Center?s.CenterSlotDepthMm:s.OuterSlotDepthMm;
                    double y=sy+s.ActualFlange1HeightMm-depth;
                    var contour=rail.Position==SlideRailPosition.Center?SlideRailGeometry.CenterSectionMm():SlideRailGeometry.SideSectionMm(rail.Position==SlideRailPosition.Right);
                    double start=plate==null?0:plate.RailStartZ,length=plate==null?p.LengthMm:plate.RailLengthMm;
                    var range=SlideRailGeometry.Range(s,i,sections.Count,start,length);start=range[0];length=range[1];
                    mesh.Extrude(Array.ConvertAll(contour,delegate(PointF q){return new BeltPoint3D(rail.FromLeftMm+q.X,y+q.Y,offset+start);}),new BeltPoint3D(0,0,length),i,plastic,null,BeltSurface3D.Nylamid);
                }
                offset+=p.LengthMm;
            }
            mesh.Length=offset;mesh.Trajectory=BeltTrajectory.Build(sections,resolved,supportTemplate,rollers);mesh.BeginPart("trajectory");if(showTrajectory)mesh.AddTrajectory(mesh.Trajectory);return mesh;
        }
        void LegCrossbar(LegCrossbarLayout layout,int section){
            double half=layout.SideMm/2;Converter<PointF,BeltPoint3D> point=p=>new BeltPoint3D(layout.StartX,layout.CenterY+p.X,layout.StationZ+p.Y);int first=Faces.Count;
            var outer=Array.ConvertAll(Rectangle(-half,-half,layout.SideMm,layout.SideMm),point);
            var inner=Array.ConvertAll(Rectangle(-half+LegCrossbarLayout.WallMm,-half+LegCrossbarLayout.WallMm,layout.SideMm-2*LegCrossbarLayout.WallMm,layout.SideMm-2*LegCrossbarLayout.WallMm),point);
            Extrude(outer,new BeltPoint3D(layout.LengthMm,0,0),section,Steel,new List<BeltPoint3D[]>{inner},BeltSurface3D.StainlessSteel);
            for(int i=first;i<Faces.Count;i++){Faces[i].IsVerticalSupport=true;Faces[i].IsLegCrossbar=true;}
        }
        void VerticalLeg(VerticalSupportSettings s,bool right,double mountX,double mountY,double mountZ,int section,float[] curvePlate=null){
            string legKey=facePart;BeginPart(legKey+"/tube");int first=Faces.Count;double sign=right?-1:1,r=Math.Sqrt(.5),bottom=s.TubeBottom(mountY),half=s.TubeSideMm/2,cx=s.EffectiveTubeCenterX;
            Func<double,double,double,BeltPoint3D> point=delegate(double x,double y,double z){return new BeltPoint3D(mountX+sign*x,mountY+y,mountZ+sign*z);};
            var outer=new BeltPoint3D[4];var inner=new BeltPoint3D[4];var outerTop=new BeltPoint3D[4];var innerTop=new BeltPoint3D[4];
            var corners=new[]{new[]{-1.0,-1},new[]{1.0,-1},new[]{1.0,1},new[]{-1.0,1}};
            for(int j=0;j<4;j++){
                double x=cx+corners[j][0]*half,z=corners[j][1]*half,ix=cx+corners[j][0]*(half-3),iz=corners[j][1]*(half-3);
                outer[j]=point(x,bottom,z);inner[j]=point(ix,bottom,iz);outerTop[j]=point(x,x+s.BevelIntercept,z);innerTop[j]=point(ix,ix+s.BevelIntercept,iz);
            }
            var foot=Face(outer,section,Steel,BeltSurface3D.StainlessSteel);foot.Holes.Add(inner);
            var top=Face(outerTop,section,Steel,BeltSurface3D.StainlessSteel);top.Holes.Add(innerTop);
            for(int j=0;j<4;j++){int k=(j+1)%4;Face(new[]{outer[j],outer[k],outerTop[k],outerTop[j]},section,Steel,BeltSurface3D.StainlessSteel);Face(new[]{inner[j],inner[k],innerTop[k],innerTop[j]},section,Steel,BeltSurface3D.StainlessSteel);}
            BeginPart(legKey+"/plate");if(curvePlate!=null){for(int k=0;k<curvePlate.Length;k+=9){var f=Face(new[]{point(curvePlate[k]*1000,curvePlate[k+1]*1000,curvePlate[k+2]*1000),point(curvePlate[k+3]*1000,curvePlate[k+4]*1000,curvePlate[k+5]*1000),point(curvePlate[k+6]*1000,curvePlate[k+7]*1000,curvePlate[k+8]*1000)},section,Steel,BeltSurface3D.StainlessSteel);f.DrawEdges=false;}}else {
            Func<PointF,BeltPoint3D> platePoint=delegate(PointF p){return point(-r*p.Y,-r*p.Y,p.X);};
            var holes=new List<BeltPoint3D[]>();foreach(double u in new[]{-31.75,31.75})holes.Add(Array.ConvertAll(Rectangle(u-5.5,-5.5,11,11),delegate(PointF p){return platePoint(p);}));
            Extrude(Array.ConvertAll(s.PlateContour(),delegate(PointF p){return platePoint(p);}),new BeltPoint3D(sign*r*VerticalSupportSettings.PlateThicknessMm,-r*VerticalSupportSettings.PlateThicknessMm,0),section,Steel,holes);
            }
            BeginPart(legKey+"/cap");var cap=Array.ConvertAll(Rectangle(cx-half,-half,s.TubeSideMm,s.TubeSideMm),delegate(PointF p){return point(p.X,bottom-VerticalSupportSettings.CapThicknessMm,p.Y);});
            var capHole=Array.ConvertAll(Circle((s.ScrewDiameterMm+.762)/2,24),delegate(PointF p){return point(cx+p.X,bottom-VerticalSupportSettings.CapThicknessMm,p.Y);});
            Extrude(cap,new BeltPoint3D(0,VerticalSupportSettings.CapThicknessMm,0),section,Steel,new List<BeltPoint3D[]>{capHole});
            // Lightweight display geometry: omit thread tessellation, as in the generated CAD hardware.
            int hardwareIndex=0;Action<double,int,double,double> hardware=delegate(double radius,int sides,double y,double height){
                BeginPart(legKey+"/hardware/"+(hardwareIndex++));int start=Faces.Count;
                var bores=new List<BeltPoint3D[]>();
                if(sides==6)bores.Add(Array.ConvertAll(Circle(s.CapHoleDiameterMm/2,24),delegate(PointF p){return point(cx+p.X,bottom+y,p.Y);}));
                if(radius==VerticalSupportSettings.FootDiameterMm/2){
                    bores.Add(Array.ConvertAll(Circle(s.FootHoleDiameterMm/2,24),delegate(PointF p){return point(cx+p.X,bottom+y,p.Y);}));
                    bores.Add(Array.ConvertAll(Circle(VerticalSupportSettings.FootAuxHoleDiameterMm/2,16),delegate(PointF p){return point(cx+VerticalSupportSettings.FootAuxHoleXMm+p.X,bottom+y,VerticalSupportSettings.FootAuxHoleZMm+p.Y);}));
                }
                Extrude(Array.ConvertAll(Circle(radius,sides),delegate(PointF p){return point(cx+p.X,bottom+y,p.Y);}),new BeltPoint3D(0,height,0),section,Steel,bores);
                for(int j=start;j<Faces.Count;j++)Faces[j].DrawEdges=false;
            };
            double diameter=s.ScrewDiameterMm;
            hardware(diameter/2,24,-VerticalSupportSettings.FootBelowTubeMm,s.ScrewLengthMm);
            // Retain the floor contact and three locking nuts at their original heights.
            hardware(VerticalSupportSettings.FootDiameterMm/2,48,-VerticalSupportSettings.FootBelowTubeMm,VerticalSupportSettings.FootThicknessMm);
            double nutRadius=s.NutOuterRadius;
            hardware(nutRadius,6,VerticalSupportSettings.LowerNutYMm,s.NutThicknessMm);
            hardware(nutRadius,6,-VerticalSupportSettings.CapThicknessMm-s.NutThicknessMm,s.NutThicknessMm);
            hardware(nutRadius,6,0,s.NutThicknessMm);
            for(int j=first;j<Faces.Count;j++)Faces[j].IsVerticalSupport=true;
        }
        void Shaft(ConveyorShaftLayout l,double offset,int section){
            double d=l.Settings.MotorOnRight?1:-1,origin=l.Settings.MotorOnRight?l.SquareLeftX:l.SquareRightX;int start=Faces.Count;
            Action<PointF[],double,double> segment=delegate(PointF[] shape,double from,double length){var points=Array.ConvertAll(shape,delegate(PointF q){return new BeltPoint3D(origin+d*from,l.AxisY+q.Y,offset+l.AxisZ-d*q.X);});Extrude(points,new BeltPoint3D(d*length,0,0),section,Color.FromArgb(135,146,155),null);};
            double half=l.Settings.SquareSideMm/2;segment(Rectangle(-half,-half,2*half,2*half),0,l.SquareLengthMm);segment(Circle(l.DiameterMm/2,48),-l.Settings.FreeEndLengthMm,l.Settings.FreeEndLengthMm);
            double plain=l.Settings.MotorEndLengthMm-(l.Settings.Keyway?l.Settings.KeyLengthMm:0);segment(Circle(l.DiameterMm/2,48),l.SquareLengthMm,plain);if(l.Settings.Keyway)segment(ConveyorShaftGeometry.KeyedProfile(l),l.SquareLengthMm+plain,l.Settings.KeyLengthMm);
            for(int i=start;i<Faces.Count;i++)Faces[i].IsShaft=true;
        }
        void Flange(ProfileSettings p,double x,double sign,double offset,bool top,int section) {
            double length=top?p.TopFlangeMm:p.BottomFlangeMm,a=(90+(top?p.TopAngleDeg:p.BottomAngleDeg))*Math.PI/180;
            // Left CAD section extends into negative X; mirror it on the right side.
            double dx=-sign*length*Math.Cos(a),dy=length*Math.Sin(a),y=top?0:-p.WebHeightMm;
            double tangent=ProfileBendGeometry.Tangent(p,top);
            var outer=new[]{new BeltPoint3D(x+dx*tangent/length,y+dy*tangent/length,offset),new BeltPoint3D(x+dx,y+dy,offset),new BeltPoint3D(x+dx,y+dy,offset+p.LengthMm),new BeltPoint3D(x+dx*tangent/length,y+dy*tangent/length,offset+p.LengthMm)};
            var holes=new List<BeltPoint3D[]>();bool enabled=top?p.EndHolesTop:p.EndHolesBottom;
            if(enabled)foreach(double z in VerticalSupportLayout.HoleCenters(p,top)) {
                    double half=p.EndHoleSizeMm/2;
                    var loop=new List<BeltPoint3D>();
                    double center=top?(length+tangent)/2:VerticalSupportLayout.BottomHoleFromWebMm(p);
                    foreach(var q in Rectangle(center-half,z-half,p.EndHoleSizeMm,p.EndHoleSizeMm))loop.Add(new BeltPoint3D(x+dx*q.X/length,y+dy*q.X/length,offset+q.Y));
                    holes.Add(loop.ToArray());
            }
            // The upper CAD sketch runs free edge -> web; its material is below
            // the outer datum face. The bottom sketch runs in the opposite direction.
            double materialSide=top?1:-1;
            Extrude(outer,new BeltPoint3D(materialSide*Math.Sin(a)*sign*p.ThicknessMm,materialSide*Math.Cos(a)*p.ThicknessMm,0),section,Steel,holes);
        }
        void ProfileBend(ProfileSettings p,double x,double sign,double offset,bool top,int section) {
            double outerRadius=p.BendRadiusMm+p.ThicknessMm,sweep=ProfileBendGeometry.Sweep(p,top)*(top?1:-1);
            double cx=x+sign*outerRadius,cy=top?-ProfileBendGeometry.Tangent(p,true):-p.WebHeightMm+ProfileBendGeometry.Tangent(p,false);
            int steps=Math.Max(2,(int)Math.Ceiling(Math.Abs(sweep)*180/Math.PI/3));
            Func<double,double,double,BeltPoint3D> point=(radius,angle,z)=>new BeltPoint3D(cx-sign*radius*Math.Cos(angle),cy+radius*Math.Sin(angle),z);
            var cap=new BeltPoint3D[2*(steps+1)];
            for(int j=0;j<=steps;j++) {
                double angle=sweep*j/steps;
                cap[j]=point(outerRadius,angle,offset);
                cap[cap.Length-1-j]=point(p.BendRadiusMm,angle,offset);
            }
            Face(cap,section,Steel,BeltSurface3D.StainlessSteel);
            Face(Array.ConvertAll(cap,q=>q.Plus(new BeltPoint3D(0,0,p.LengthMm))),section,Steel,BeltSurface3D.StainlessSteel);
            // Tangent boundaries are shared with the flat faces. Suppress tessellation
            // edges and retain stable identities when radius/angle changes.
            foreach(bool outside in new[]{true,false})for(int j=0;j<steps;j++) {
                double radius=outside?outerRadius:p.BendRadiusMm,a=sweep*j/steps,b=sweep*(j+1)/steps;
                var face=Face(new[]{point(radius,a,offset),point(radius,b,offset),point(radius,b,offset+p.LengthMm),point(radius,a,offset+p.LengthMm)},section,Steel,BeltSurface3D.StainlessSteel);
                face.DrawEdges=false;face.ParametricFaceKey=facePart+(outside?"/outer":"/inner");face.FaceParameter=(j+.5)/steps;
            }
        }
        void CrossSupport(SoporteSettings s,double sy,double z,int section) {
            double top=sy+s.ActualFlange1HeightMm,backBottom=top-s.ActualFlange2HeightMm,front=z+s.WebWidthMm/2,back=z-s.WebWidthMm/2;
            var cuts=UpperSupportGeometry.Cuts(s);
            foreach(bool rear in new[]{false,true}) {
                var edge=new List<BeltPoint3D>();double zz=rear?back:front,bottom=rear?backBottom:sy;
                edge.Add(new BeltPoint3D(0,bottom,zz));edge.Add(new BeltPoint3D(s.LengthMm,bottom,zz));edge.Add(new BeltPoint3D(s.LengthMm,top,zz));
                for(int j=cuts.Count-1;j>=0;j--){var c=cuts[j];edge.Add(new BeltPoint3D(c[1],top,zz));edge.Add(new BeltPoint3D(c[1],top-c[2],zz));edge.Add(new BeltPoint3D(c[0],top-c[2],zz));edge.Add(new BeltPoint3D(c[0],top,zz));}
                edge.Add(new BeltPoint3D(0,top,zz));Extrude(edge.ToArray(),new BeltPoint3D(0,0,rear?s.ThicknessMm:-s.ThicknessMm),section,Support,null);
            }
            double from=0;foreach(var c in cuts){SupportTop(from,c[0],top,back,front,s.ThicknessMm,section);from=c[1];}SupportTop(from,s.LengthMm,top,back,front,s.ThicknessMm,section);
            if(s.IncludeEndPlates)foreach(double xx in new[]{0.0,s.LengthMm-s.EndPlateThicknessMm}) {
                double yTop=sy+s.Flange1HeightMm-SoporteSettings.EndPlateTopReliefMm;
                var hole=Wall(xx,z,sy+s.EndPlateHoleYMm,Rectangle(-s.EndPlateHoleSizeMm/2,-s.EndPlateHoleSizeMm/2,s.EndPlateHoleSizeMm,s.EndPlateHoleSizeMm),false);
                Extrude(new[]{new BeltPoint3D(xx,sy,front-s.ThicknessMm),new BeltPoint3D(xx,backBottom,back+s.ThicknessMm),new BeltPoint3D(xx,yTop,back+s.ThicknessMm),new BeltPoint3D(xx,yTop,front-s.ThicknessMm)},new BeltPoint3D(s.EndPlateThicknessMm,0,0),section,Support,new List<BeltPoint3D[]>{hole});
            }
        }
        void SupportTop(double from,double to,double y,double back,double front,double thickness,int section) {
            if(to-from<.001)return;Extrude(new[]{new BeltPoint3D(from,y,back),new BeltPoint3D(to,y,back),new BeltPoint3D(to,y,front),new BeltPoint3D(from,y,front)},new BeltPoint3D(0,-thickness,0),section,Support,null);
        }
        void ShaftPlate(BeltSectionSpec section,ProfileSettings p,ShaftPlateLayout l,double x,double sign,double offset,int index) {
            double xx=x+sign*(p.ThicknessMm+.05),direction=section.Type==BeltSectionType.Conducido?1:-1,origin=section.Type==BeltSectionType.Conducido?l.PlateStartZ:l.PlateEndZ;
            var points=new List<BeltPoint3D>();foreach(var e in PlateContour.Build(section.ShaftPlates,l).Edges) {
                int steps=e.Radius==0?1:Math.Max(2,(int)Math.Ceiling(Math.Abs(e.Sweep)/10));
                for(int j=0;j<steps;j++){double a=(e.Start+e.Sweep*j/steps)*Math.PI/180;double z=e.Radius==0?e.X1:e.CX+e.Radius*Math.Cos(a),y=e.Radius==0?e.Y1:e.CY+e.Radius*Math.Sin(a);points.Add(new BeltPoint3D(xx,y,offset+origin+direction*z));}
            }
            var settings=section.ShaftPlates;var holes=new List<BeltPoint3D[]>();
            if(settings.OpeningDiameterMm>0)holes.Add(Wall(xx,offset+l.AxisZ,l.AxisY,Circle(settings.OpeningDiameterMm/2,40),false));
            if(settings.BoltPitchMm>0 && settings.BoltDiameterMm>0)foreach(double dz in new[]{-settings.BoltPitchMm/2,settings.BoltPitchMm/2})foreach(double dy in new[]{-settings.BoltPitchMm/2,settings.BoltPitchMm/2})holes.Add(Wall(xx,offset+l.AxisZ+dz,l.AxisY+dy,Circle(settings.BoltDiameterMm/2,20),false));
            if(settings.Mounting==2)foreach(double y in ShaftPlateGeometry.LapHoleYs(l))holes.Add(Wall(xx,offset+l.LapHoleZ,y,Rectangle(-l.LapHoleSizeMm/2,-l.LapHoleSizeMm/2,l.LapHoleSizeMm,l.LapHoleSizeMm),false));
            if(l.IncludeSupportHeadClearance)holes.Add(Wall(xx,offset+l.SupportHeadZ,l.SupportHeadY,Circle(ShaftPlateGeometry.SupportHeadClearanceDiameterMm/2,24),false));
            Extrude(points.ToArray(),new BeltPoint3D(sign*ShaftPlateLayout.ThicknessMm,0,0),index,Plate,holes);
        }
    }
}


