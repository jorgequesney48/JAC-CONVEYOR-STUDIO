using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace PerfilBandas {
    internal sealed partial class Belt3DPreview : Control {
        internal Belt3DGeometry Mesh {get;private set;}
        internal string Error {get;private set;}
        internal double Yaw=12,Pitch=22,Zoom=1;
        internal int Selected,FocusSection=-1;
        internal event Action<int> SectionSelected;
        internal bool EditableAnnotations;
        internal event Action<string,Rectangle> ParameterEditRequested;
        readonly Dictionary<string,Rectangle> annotationBoxes=new Dictionary<string,Rectangle>();
        internal Rectangle AnnotationBounds(string key){Rectangle r;return annotationBoxes.TryGetValue(key,out r)?r:Rectangle.Empty;}
        Bitmap rendered;
        Belt3DRaster frame;
        readonly Belt3DRaster.Workspace fastBuffers=new Belt3DRaster.Workspace();
        readonly System.Windows.Forms.Timer frameTimer=new System.Windows.Forms.Timer {Interval=16};
        readonly System.Windows.Forms.Timer settleTimer=new System.Windows.Forms.Timer {Interval=180};
        CancellationTokenSource workerCancellation;
        bool workerBusy,workerInteractive,navigation;
        int revision;
        double interactiveBudget=1200000;
        internal int CompletedFrames {get;private set;}
        internal bool NavigationActive {get{return navigation;}}
        internal bool Rendering {get{return workerBusy;}}
        internal bool FrameReady {get{return !pending&&(hardware!=null||frame!=null&&!frame.Interactive);}}
        internal double LastFrameMilliseconds {get;private set;}
        int[] selection;
        int rasterWidth,rasterHeight;
        internal Size RenderSize {get{return new Size(rasterWidth,rasterHeight);}}
        bool pending=true,dragging,needsFit=true;
        Point last,down;
        MouseButtons mouseGesture=MouseButtons.None;
        float panX,panY;
        bool customOrbit,orbitPrepared;
        BeltPoint3D orbitCenter;
        internal BeltPoint3D OrbitCenter {get{PrepareCamera();return new BeltPoint3D(centerX,centerY,centerZ);}}
        internal void BeginOrbit(){
            PrepareCamera();if(Mesh==null || scale<=0)return;
            var point=BeltOrbitPicking.VisibleCenter(Mesh,OrbitCenter,Yaw,Pitch,scale,Width/2d+viewShiftX+panX,Height/2d+viewShiftY+panY,Width,Height,FocusSection);
            var old=Project(point);orbitCenter=point;customOrbit=true;centerX=point.X;centerY=point.Y;centerZ=point.Z;
            panX=(float)(old.X-Width/2d-viewShiftX);panY=(float)(old.Y-Height/2d-viewShiftY);
        }
        double viewShiftX,viewShiftY,fitOffsetX,fitOffsetY;
        double scale,fitScale,centerX,centerY,centerZ;
        int fittedWidth,fittedHeight;
        double cosYaw,sinYaw,cosPitch,sinPitch;
        struct P {public double X,Y,D;public P(double x,double y,double d){X=x;Y=y;D=d;}}
        public Belt3DPreview() {
            SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer,false);
            BackColor=DesignUi.Canvas;Font=new Font("Segoe UI",9);TabStop=true;
            AccessibleName="Vista 3D de la banda: rodar rueda para ampliar; rueda presionada y arrastrar para girar; Control más rueda presionada y arrastrar para desplazar en 2D; clic para seleccionar tramo";
            frameTimer.Tick+=delegate{if(pending&&!workerBusy)QueueFrame();if(!pending&&!workerBusy)frameTimer.Stop();};
            settleTimer.Tick+=delegate{if(Capture&&dragging)return;settleTimer.Stop();navigation=false;Changed();};
        }
        internal void SetModel(Belt3DGeometry mesh,string error,int selected) {
            if(Object.ReferenceEquals(mesh,Mesh)&&selected==Selected&&error==Error)return;
            bool changedSelection=selected!=Selected,hadModel=Mesh!=null;
            if(hadModel)PrepareCamera();
            var previousMesh=Mesh;Mesh=mesh;Error=error;Selected=selected;
            if(!Object.ReferenceEquals(mesh,previousMesh))RestoreMeasurement(previousMesh,mesh);
            CancelWorker();navigation=false;settleTimer.Stop();if(mesh==null)ClearFrame();
            if(!hadModel)needsFit=true;
            if(mesh!=null&&hadModel&&changedSelection)CenterOnSection(selected);
            else if(FocusSection>=0)FocusSection=mesh==null?-1:selected;
            Changed();
        }
        internal void CenterOnSection(int section){
            if(Mesh==null||section<0||section>=Mesh.Starts.Count)return;
            PrepareCamera();
            // Selection changes the target, while retaining orientation and magnification.
            FocusSection=-1;customOrbit=true;orbitPrepared=false;
            orbitCenter=Mesh.NavigationCenter(section);
            centerX=orbitCenter.X;centerY=orbitCenter.Y;centerZ=orbitCenter.Z;
            panX=(float)(fitOffsetX*scale);panY=(float)(fitOffsetY*scale);
        }
        internal void SetView(string view) {
            if(view=="Frontal"){Yaw=90;Pitch=0;}else if(view=="Lateral"){Yaw=0;Pitch=0;}else if(view=="Superior"){Yaw=0;Pitch=90;}else{Yaw=12;Pitch=22;}
            Fit();
        }
        internal void Fit(){customOrbit=false;orbitPrepared=false;Zoom=1;panX=panY=0;needsFit=true;navigation=false;settleTimer.Stop();Changed();}
        internal void ChangeZoom(double factor){ChangeZoomAt(factor,new Point(Width/2,Height/2));}
        internal void ChangeZoomAt(double factor,Point anchor){
            if(Double.IsNaN(factor)||Double.IsInfinity(factor)||factor<=0)return;
            PrepareCamera();double previous=Zoom;
            Zoom=Math.Max(.15,Math.Min(16,Zoom*factor));
            double ratio=Zoom/previous;
            // Scale the complete screen transform around the viewed point, including pan.
            panX=(float)(anchor.X-Width/2d+ratio*(Width/2d+panX-anchor.X));
            panY=(float)(anchor.Y-Height/2d+ratio*(Height/2d+panY-anchor.Y));
            orbitPrepared=false;Navigate();
        }
        internal void FocusOn(int section){
            if(section<0){FocusSection=-1;Fit();return;}
            if(Mesh==null||section>=Mesh.Starts.Count)return;
            // Fit the chosen section once, then retain every section for free navigation.
            FocusSection=section;Fit();PrepareCamera();CenterOnSection(section);Changed();
        }
        void Changed(){revision++;pending=true;if(workerBusy&&!workerInteractive)CancelWorker();if(hardware==null)frameTimer.Start();Invalidate();}
        void Navigate(){navigation=true;settleTimer.Stop();settleTimer.Start();Changed();}
        void CancelWorker(){if(workerCancellation!=null)workerCancellation.Cancel();}
        protected override void OnResize(EventArgs e){base.OnResize(e);if(fitScale<=0||fittedWidth<200||fittedHeight<150||(!customOrbit&&Zoom==1&&panX==0&&panY==0))needsFit=true;Changed();}
        protected override void Dispose(bool disposing){if(disposing){ReleaseHardware();CancelWorker();frameTimer.Dispose();settleTimer.Dispose();ClearFrame();}base.Dispose(disposing);}
        protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);Focus();if(e.Button==MouseButtons.Left&&!Measuring&&Mesh!=null&&EditableAnnotations){foreach(var box in annotationBoxes)if(box.Value.Contains(e.Location)){if(ParameterEditRequested!=null)ParameterEditRequested(box.Key,box.Value);return;}}if(e.Button==MouseButtons.Left||e.Button==MouseButtons.Middle||e.Button==MouseButtons.Right){down=last=e.Location;orbitPrepared=false;mouseGesture=e.Button;dragging=false;Capture=true;Cursor=Cursors.SizeAll;}}
        protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);DragTo(e.Location,ModifierKeys);if(!Capture){bool over=false;if(Mesh!=null&&EditableAnnotations)foreach(var box in annotationBoxes)if(box.Value.Contains(e.Location)){over=true;break;}Cursor=Measuring?Cursors.Cross:over?Cursors.Hand:Cursors.Default;}}
        internal void DragTo(Point location,Keys modifiers){if(!Capture)return;int dx=location.X-last.X,dy=location.Y-last.Y;if(Math.Abs(location.X-down.X)+Math.Abs(location.Y-down.Y)>4)dragging=true;
            if(dragging){if(mouseGesture==MouseButtons.Right||(mouseGesture==MouseButtons.Middle&&(modifiers&Keys.Control)!=0)){panX+=dx;panY+=dy;orbitPrepared=false;}else{if(!orbitPrepared){BeginOrbit();orbitPrepared=true;}Yaw+=dx*.35;Pitch=Math.Max(-89,Math.Min(90,Pitch+dy*.3));}Navigate();}last=location;}
        protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);if(e.Button!=mouseGesture)return;bool wasDragging=dragging;Capture=false;Cursor=Measuring?Cursors.Cross:Cursors.Default;if(e.Button==MouseButtons.Left&&!dragging&&Measuring){MeasureAt(e.Location);}else if(e.Button==MouseButtons.Left&&!dragging){int section=SectionAt(e.Location);if(section>=0&&SectionSelected!=null)SectionSelected(section);}mouseGesture=MouseButtons.None;dragging=false;if(wasDragging)Changed();}
        protected override void OnMouseWheel(MouseEventArgs e){base.OnMouseWheel(e);var handled=e as HandledMouseEventArgs;if(handled!=null)handled.Handled=true;if(Capture&&mouseGesture==MouseButtons.Middle)return;ChangeZoomAt(Math.Pow(1.15,e.Delta/120.0),e.Location);}
        protected override void OnDoubleClick(EventArgs e){base.OnDoubleClick(e);if(mouseGesture!=MouseButtons.Middle)SetView("Isométrica");}
        protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);if(e.KeyCode==Keys.Home){SetView("Isométrica");e.Handled=true;}if(e.KeyCode==Keys.Escape){if(Measuring)SetMeasuring(false);else FocusOn(-1);e.Handled=true;}}
        internal int SectionAt(Point p) {
            if(hardware!=null||pending)Render();if(selection==null||p.X<0||p.Y<0||p.X>=Width||p.Y>=Height)return -1;
            int x=Math.Min(rasterWidth-1,p.X*rasterWidth/Math.Max(1,Width)),y=Math.Min(rasterHeight-1,p.Y*rasterHeight/Math.Max(1,Height));
            return selection[y*rasterWidth+x];
        }
        P Camera(BeltPoint3D p) {
            double longitudinal=p.Z-centerZ,width=p.X-centerX,height=p.Y-centerY;
            double horizontal=cosYaw*longitudinal+sinYaw*width,depth=-sinYaw*longitudinal+cosYaw*width;
            return new P(horizontal,-cosPitch*height+sinPitch*depth,sinPitch*height+cosPitch*depth);
        }
        P Project(BeltPoint3D p){var q=Camera(p);q.X=q.X*scale+Width/2.0+viewShiftX+panX;q.Y=q.Y*scale+Height/2.0+viewShiftY+panY;return q;}
        internal Point ScreenPoint(BeltPoint3D p){PrepareCamera();var q=Project(p);return new Point((int)q.X,(int)q.Y);}
        protected override void OnPaint(PaintEventArgs e) {
            PrepareCamera();if(PaintHardware(e.Graphics))return;
            base.OnPaint(e);PrepareCamera();if(pending){if(IsHandleCreated)QueueFrame();else Render();}
            e.Graphics.Clear(BackColor);
            if(frame!=null&&frame.Display!=null&&Mesh!=null){
                double factor=scale/Math.Max(.000001,frame.fitScale*frame.Zoom);
                var priorOrigin=Project(new BeltPoint3D(frame.PivotX,frame.PivotY,frame.PivotZ));double pivotX=priorOrigin.X,pivotY=priorOrigin.Y;
                double oldX=frame.Width/2.0-frame.fitOffsetX*frame.fitScale*frame.Zoom+frame.panX,oldY=frame.Height/2.0-frame.fitOffsetY*frame.fitScale*frame.Zoom+frame.panY;
                e.Graphics.CompositingQuality=navigation?CompositingQuality.HighSpeed:CompositingQuality.Default;
                e.Graphics.InterpolationMode=navigation?InterpolationMode.NearestNeighbor:InterpolationMode.HighQualityBicubic;
                var image=navigation?frame.Motion:frame.Display;
                var destination=new RectangleF((float)(pivotX-factor*oldX+frame.ContentBounds.X*factor),(float)(pivotY-factor*oldY+frame.ContentBounds.Y*factor),(float)(frame.ContentBounds.Width*factor),(float)(frame.ContentBounds.Height*factor));
                var visible=RectangleF.Intersect(destination,ClientRectangle);
                if(visible.Width>0&&visible.Height>0){var source=new RectangleF((visible.X-destination.X)*image.Width/destination.Width,(visible.Y-destination.Y)*image.Height/destination.Height,visible.Width*image.Width/destination.Width,visible.Height*image.Height/destination.Height);e.Graphics.DrawImage(image,visible,source,GraphicsUnit.Pixel);}
            }
            annotationBoxes.Clear();
            if(!String.IsNullOrEmpty(Error))TextRenderer.DrawText(e.Graphics,"Revisa la configuración\n"+Error,Font,new Rectangle(24,Height/2-60,Math.Max(1,Width-48),140),Color.Firebrick,TextFormatFlags.WordBreak);
            else {
                TextRenderer.DrawText(e.Graphics,"3D  /  "+RendererDescription+"  /  "+(FocusSection<0?"Banda completa":"Tramo "+(FocusSection+1).ToString("00")),Font,new Rectangle(18,16,Math.Max(1,Width-36),44),DesignUi.Ink,TextFormatFlags.WordBreak|TextFormatFlags.EndEllipsis);
                if(Width<620)TextRenderer.DrawText(e.Graphics,"Girar: rueda presionada  ·  Mover: Ctrl + rueda\nZoom: rodar rueda  ·  Seleccionar: clic",Font,new Rectangle(18,Height-45,Width-36,40),DesignUi.Muted,TextFormatFlags.WordBreak);
                else TextRenderer.DrawText(e.Graphics,"Girar: arrastrar con rueda presionada   ·   Mover: Ctrl + rueda presionada   ·   Zoom: rodar rueda",Font,new Rectangle(18,Height-30,Width-36,24),DesignUi.Muted,TextFormatFlags.EndEllipsis);
            }
            DrawMeasurement(e.Graphics);
        }
        void PrepareCamera(){
            cosYaw=Math.Cos(Yaw*Math.PI/180);sinYaw=Math.Sin(Yaw*Math.PI/180);cosPitch=Math.Cos(Pitch*Math.PI/180);sinPitch=Math.Sin(Pitch*Math.PI/180);
            if(Mesh==null)return;if(customOrbit){centerX=orbitCenter.X;centerY=orbitCenter.Y;centerZ=orbitCenter.Z;}else{var center=Mesh.NavigationCenter(FocusSection);centerX=center.X;centerY=center.Y;centerZ=center.Z;}
            if(needsFit){double minX=Double.PositiveInfinity,minY=minX,maxX=Double.NegativeInfinity,maxY=maxX;foreach(var f in Mesh.Faces){if(FocusSection>=0&&f.Section!=FocusSection)continue;foreach(var p in f.Outer){var q=Camera(p);minX=Math.Min(minX,q.X);maxX=Math.Max(maxX,q.X);minY=Math.Min(minY,q.Y);maxY=Math.Max(maxY,q.Y);}}
                if(Double.IsInfinity(minX))return;fitScale=Math.Min(Math.Max(1,Width-80)/Math.Max(1,maxX-minX),Math.Max(1,Height-110)/Math.Max(1,maxY-minY));fitOffsetX=(minX+maxX)/2;fitOffsetY=(minY+maxY)/2;fittedWidth=Width;fittedHeight=Height;needsFit=false;}
            scale=fitScale*Zoom;viewShiftX=-fitOffsetX*scale;viewShiftY=-fitOffsetY*scale;
        }
        Belt3DRaster RequestFrame(bool interactive){PrepareCamera();return new Belt3DRaster {Mesh=Mesh,Width=Width,Height=Height,Selected=Selected,FocusSection=FocusSection,CustomPivot=true,PivotX=centerX,PivotY=centerY,PivotZ=centerZ,Yaw=Yaw,Pitch=Pitch,Zoom=Zoom,fitScale=fitScale,fitOffsetX=fitOffsetX,fitOffsetY=fitOffsetY,panX=panX,panY=panY,BeltPatternEnabled=BeltPatternEnabled,BeltTravelMm=BeltTravelMm,BeltLoopMm=BeltLoopMm,Interactive=interactive,PixelBudget=interactiveBudget,Revision=revision};}
        void ClearFrame(){if(frame!=null)frame.Dispose();frame=null;rendered=null;selection=null;}
        void ApplyFrame(Belt3DRaster result){ClearFrame();frame=result;rendered=result.rendered;selection=result.selection;rasterWidth=result.rasterWidth;rasterHeight=result.rasterHeight;pending=result.Revision!=revision||(result.Interactive&&!navigation&&!BeltAnimating);CompletedFrames++;Invalidate();}
        // Only explicit picking/export needs a synchronous current frame; movement never calls it.
        internal void EnsureFrame(){Render();}
        void Render(){CancelWorker();var result=RequestFrame(false);try{result.Render(new Belt3DRaster.Workspace());ApplyFrame(result);}catch{result.Dispose();throw;}}
        void QueueFrame(){
            if(hardware!=null||(PreferHardware&&!attemptedHardware)||workerBusy||IsDisposed||!IsHandleCreated||Mesh==null||Width<30||Height<30)return;
            var request=RequestFrame(navigation||BeltAnimating);var cancellation=new CancellationTokenSource();var dispatcher=SynchronizationContext.Current;request.Cancellation=cancellation.Token;workerCancellation=cancellation;workerBusy=true;workerInteractive=request.Interactive;
            Task.Factory.StartNew(delegate{
                var watch=Stopwatch.StartNew();Exception failure=null;bool cancelled=false;
                try{request.Render(request.Interactive?fastBuffers:new Belt3DRaster.Workspace());}catch(OperationCanceledException){cancelled=true;}catch(Exception ex){failure=ex;}
                watch.Stop();Action complete=delegate{
                    workerBusy=false;workerCancellation=null;cancellation.Dispose();
                    if(IsDisposed||hardware!=null){request.Dispose();return;}
                    bool compatible=request.Mesh==Mesh&&request.FocusSection==FocusSection&&request.Selected==Selected;
                    bool older=frame!=null&&(request.Revision<frame.Revision||(request.Revision==frame.Revision&&!frame.Interactive&&request.Interactive));
                    if(!cancelled&&failure==null&&compatible&&!older){LastFrameMilliseconds=watch.Elapsed.TotalMilliseconds;if(request.Interactive){if(LastFrameMilliseconds>32)interactiveBudget=Math.Max(250000,interactiveBudget*.75);else if(LastFrameMilliseconds<18)interactiveBudget=Math.Min(1200000,interactiveBudget*1.1);}ApplyFrame(request);}
                    else{request.Dispose();if(failure!=null&&request.Revision==revision){Error="No se pudo actualizar la vista 3D: "+failure.Message;pending=false;Invalidate();}}
                    if(pending)frameTimer.Start();
                };try{if(dispatcher!=null)dispatcher.Post(delegate{complete();},null);else BeginInvoke(complete);}catch(InvalidOperationException){request.Dispose();cancellation.Dispose();}
            });
        }
        void DrawAnnotations(Graphics g) {
            annotationBoxes.Clear();if(!EditableAnnotations||Mesh==null||Selected<0||Selected>=Mesh.Patterns.Count||Width<300||Height<200)return;
            var p=Mesh.Profiles[Selected];if(p.CurvedWeldedProfile)return;var pattern=Mesh.Patterns[Selected];
            Point anchor=ScreenPoint(Mesh.RouteFrames!=null?Mesh.RouteFrames[Selected].Point(Mesh.Width,-p.WebHeightMm/2,p.LengthMm/2):new BeltPoint3D(Mesh.Width,-p.WebHeightMm/2,Mesh.Starts[Selected]+p.LengthMm/2));
            int width=Math.Min(430,Width-36),left=Math.Max(18,Math.Min(Width-width-18,anchor.X-width/2)),top=Math.Max(72,Math.Min(Height-155,anchor.Y+65));
            g.SmoothingMode=SmoothingMode.AntiAlias;
            using(var line=new Pen(DesignUi.Border,1)){line.DashStyle=DashStyle.Dash;if(ClientRectangle.Contains(anchor))g.DrawLine(line,anchor,new Point(left+width/2,top));}
            TextRenderer.DrawText(g,"Tramo "+(Selected+1).ToString("00")+" · toca una medida para editar",Font,new Rectangle(left,top,width,22),DesignUi.Muted,TextFormatFlags.EndEllipsis);
            string[] keys={"Length","SlotHeight","SlotGap","Combination"};
            string[] labels={"Largo  "+p.LengthMm.ToString("0.##")+" mm","Altura ranura  "+p.SlotHeightMm.ToString("0.##")+" mm","Separación  "+p.SlotGapMm.ToString("0.##")+" mm","Orden  ·  "+(pattern.Manual?"Elegido":"Automático")};
            int cell=(width-10)/2;
            for(int i=0;i<keys.Length;i++) {
                var box=new Rectangle(left+(i%2)*(cell+10),top+26+(i/2)*39,cell,33);annotationBoxes.Add(keys[i],box);
                using(var path=MinimalShape.Round(box,10)){using(var brush=new SolidBrush(Color.White))g.FillPath(brush,path);using(var pen=new Pen(DesignUi.Border,1))g.DrawPath(pen,path);}
                TextRenderer.DrawText(g,labels[i]+"  ✎",Font,new Rectangle(box.X+9,box.Y,box.Width-18,box.Height),DesignUi.Ink,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
            }
        }
    }
}
