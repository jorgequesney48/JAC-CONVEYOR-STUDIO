﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;

namespace PerfilBandas {
    // A frozen render request: no Windows controls or mutable UI state on the worker.
    internal sealed class Belt3DRaster : IDisposable {
        internal sealed class Workspace {
            internal int[] Pixels,Owners;internal float[] Depths;
            internal void Ensure(int count){if(Pixels==null||Pixels.Length<count){Pixels=new int[count];Owners=new int[count];Depths=new float[count];}}
        }
        internal Belt3DGeometry Mesh;
        internal int Width,Height,Selected,FocusSection,Revision;
        internal double Yaw,Pitch,Zoom,fitScale,fitOffsetX,fitOffsetY,PixelBudget;
        internal float panX,panY;
        internal bool Interactive;
        internal bool BeltPatternEnabled;internal double BeltTravelMm,BeltLoopMm;
        internal bool CustomPivot;
        internal double PivotX,PivotY,PivotZ;
        internal CancellationToken Cancellation;
        internal Bitmap rendered,Display,Motion;
        internal int[] selection;
        internal int rasterWidth,rasterHeight;
        internal RectangleF ContentBounds;
        Rectangle cropRaster;
        double scale,centerX,centerY,centerZ,viewShiftX,viewShiftY,cosYaw,sinYaw,cosPitch,sinPitch;
        struct P {public double X,Y,D;public P(double x,double y,double d){X=x;Y=y;D=d;}}
        sealed class Projected {public List<P[]> Loops=new List<P[]>();public int Color,Section,EdgeColor,Index;public double A,B,C,SX,SY,SC,TX,TY,TC,BeltWidth;public bool DrawEdges,Pattern;public BeltSurface3D Surface;}
        public void Dispose(){if(Display!=null&&Display!=rendered)Display.Dispose();if(Motion!=null&&Motion!=rendered&&Motion!=Display)Motion.Dispose();if(rendered!=null)rendered.Dispose();rendered=null;Display=null;Motion=null;selection=null;}
        P Camera(BeltPoint3D p) {
            double longitudinal=p.Z-centerZ,width=p.X-centerX,height=p.Y-centerY;
            double horizontal=cosYaw*longitudinal+sinYaw*width,depth=-sinYaw*longitudinal+cosYaw*width;
            return new P(horizontal,-cosPitch*height+sinPitch*depth,sinPitch*height+cosPitch*depth);
        }
        P Project(BeltPoint3D p){var q=Camera(p);q.X=q.X*scale+rasterWidth/2+viewShiftX+panX*rasterWidth/Math.Max(1,Width);q.Y=q.Y*scale+rasterHeight/2+viewShiftY+panY*rasterHeight/Math.Max(1,Height);return q;}
        internal void Render(Workspace buffers) {
            Cancellation.ThrowIfCancellationRequested();cosYaw=Math.Cos(Yaw*Math.PI/180);sinYaw=Math.Sin(Yaw*Math.PI/180);cosPitch=Math.Cos(Pitch*Math.PI/180);sinPitch=Math.Sin(Pitch*Math.PI/180);
            if(Mesh==null||Width<30||Height<30)return;
            // Never enlarge a reduced bitmap on wide screens. Supersample the resting view;
            // use an adaptive preview while navigating and restore full detail after settling.
            double ratio=Interactive?Math.Min(1,Math.Sqrt(PixelBudget/((double)Width*Height))):Math.Max(1,Math.Min(2,Math.Sqrt(16000000.0/((double)Width*Height))));rasterWidth=Math.Max(1,(int)(Width*ratio));rasterHeight=Math.Max(1,(int)(Height*ratio));
            centerX=CustomPivot?PivotX:Mesh.Width/2;centerY=CustomPivot?PivotY:-90;centerZ=CustomPivot?PivotZ:(FocusSection>=0?Mesh.Starts[FocusSection]+Mesh.Lengths[FocusSection]/2:Mesh.Length/2);
            var faces=Mesh.Faces.FindAll(delegate(BeltFace3D f){return FocusSection<0||f.Section==FocusSection;});
            scale=fitScale*Zoom*ratio;
            // Keep the orbit pivot fixed on screen; recenter only when explicitly fitting.
            viewShiftX=-fitOffsetX*scale;viewShiftY=-fitOffsetY*scale;
            int n=rasterWidth*rasterHeight;buffers.Ensure(n);var pixels=buffers.Pixels;var depths=buffers.Depths;var owners=buffers.Owners;selection=new int[n];
            for(int y=0;y<rasterHeight;y++){if((y&31)==0)Cancellation.ThrowIfCancellationRequested();for(int x=0;x<rasterWidth;x++){int i=y*rasterWidth+x;pixels[i]=0;depths[i]=Single.NegativeInfinity;selection[i]=-1;owners[i]=-1;}}
            var projected=new List<Projected>();
            double minX=rasterWidth,minY=rasterHeight,maxX=0,maxY=0;
            foreach(var face in faces) {
                Cancellation.ThrowIfCancellationRequested();
                var item=new Projected{Section=face.Section,Surface=face.Surface,DrawEdges=face.DrawEdges,Index=projected.Count};item.Loops.Add(Array.ConvertAll(face.Outer,delegate(BeltPoint3D p){return Project(p);}));foreach(var hole in face.Holes)item.Loops.Add(Array.ConvertAll(hole,delegate(BeltPoint3D p){return Project(p);}));
                var outer=item.Loops[0];bool plane=false;
                for(int j=1;j<outer.Length-1;j++) {
                    double dx1=outer[j].X-outer[0].X,dy1=outer[j].Y-outer[0].Y,dd1=outer[j].D-outer[0].D,dx2=outer[j+1].X-outer[0].X,dy2=outer[j+1].Y-outer[0].Y,dd2=outer[j+1].D-outer[0].D,den=dx1*dy2-dx2*dy1;
                    if(Math.Abs(den)<1e-7)continue;item.A=(dd1*dy2-dd2*dy1)/den;item.B=(dx1*dd2-dx2*dd1)/den;item.C=outer[0].D-item.A*outer[0].X-item.B*outer[0].Y;
                    if(BeltPatternEnabled&&face.BeltCoordinates!=null){var uv=face.BeltCoordinates;double ds1=uv[j].X-uv[0].X,ds2=uv[j+1].X-uv[0].X,dt1=uv[j].Y-uv[0].Y,dt2=uv[j+1].Y-uv[0].Y;
                        item.SX=(ds1*dy2-ds2*dy1)/den;item.SY=(dx1*ds2-dx2*ds1)/den;item.SC=uv[0].X-item.SX*outer[0].X-item.SY*outer[0].Y;
                        item.TX=(dt1*dy2-dt2*dy1)/den;item.TY=(dx1*dt2-dx2*dt1)/den;item.TC=uv[0].Y-item.TX*outer[0].X-item.TY*outer[0].Y;item.Pattern=true;item.BeltWidth=face.BeltWidthMm;}
                    plane=true;break;
                }
                if(!plane)continue;
                foreach(var point in outer){minX=Math.Min(minX,point.X);maxX=Math.Max(maxX,point.X);minY=Math.Min(minY,point.Y);maxY=Math.Max(maxY,point.Y);}
                double norm=Math.Sqrt(1+item.A*item.A+item.B*item.B),nx=-item.A/norm,ny=-item.B/norm,nz=1/norm;
                bool steel=face.Surface==BeltSurface3D.StainlessSteel;
                double diffuse=Math.Abs(nx*.4-ny*.45+nz*.8),specular=steel?45*Math.Pow(Math.Abs(nx*.15-ny*.18+nz*.972),14):0;
                double lighting=steel?.58+.30*diffuse+.10*nz:.80+.18*nz;Color c=face.Color;
                if(steel&&face.Section==Selected)c=Color.FromArgb((c.R*95+70*5)/100,(c.G*95+151*5)/100,(c.B*95+255*5)/100);
                item.Color=Color.FromArgb(Byte(c.R*lighting+specular),Byte(c.G*lighting+specular),Byte(c.B*lighting+specular)).ToArgb();
                item.EdgeColor=(steel?(face.Section==Selected?Color.FromArgb(91,117,149):Color.FromArgb(108,113,122)):Color.FromArgb(140,143,149)).ToArgb();
                if(item.Pattern&&outer.Length==4){
                    var loops=item.Loops;
                    foreach(var triangle in new[]{new[]{0,1,2},new[]{0,2,3}}){var points=Array.ConvertAll(triangle,k=>outer[k]);var uv=Array.ConvertAll(triangle,k=>face.BeltCoordinates[k]);TexturePlane(item,points,uv);item.Loops=new List<P[]>{points};Fill(item,pixels,depths,owners);}
                    item.Loops=loops;
                }else Fill(item,pixels,depths,owners);projected.Add(item);
            }
            foreach(var item in projected)if(item.DrawEdges)foreach(var loop in item.Loops)for(int i=0;i<loop.Length;i++)Edge(item,loop[i],loop[(i+1)%loop.Length],pixels,owners,projected);
            rendered=new Bitmap(rasterWidth,rasterHeight,PixelFormat.Format32bppPArgb);var data=rendered.LockBits(new Rectangle(0,0,rasterWidth,rasterHeight),ImageLockMode.WriteOnly,PixelFormat.Format32bppPArgb);
            try{Marshal.Copy(pixels,0,data.Scan0,n);}finally{rendered.UnlockBits(data);}
            Cancellation.ThrowIfCancellationRequested();
            cropRaster=Rectangle.Intersect(new Rectangle(0,0,rasterWidth,rasterHeight),Rectangle.FromLTRB((int)Math.Floor(Math.Max(-2,minX))-2,(int)Math.Floor(Math.Max(-2,minY))-2,(int)Math.Ceiling(Math.Min(rasterWidth+2,maxX))+2,(int)Math.Ceiling(Math.Min(rasterHeight+2,maxY))+2));
            if(cropRaster.Width<1||cropRaster.Height<1){ContentBounds=RectangleF.Empty;return;}
            ContentBounds=new RectangleF((float)(cropRaster.X*(double)Width/rasterWidth),(float)(cropRaster.Y*(double)Height/rasterHeight),(float)(cropRaster.Width*(double)Width/rasterWidth),(float)(cropRaster.Height*(double)Height/rasterHeight));
            if(Interactive){Display=rendered.Clone(cropRaster,PixelFormat.Format32bppPArgb);Motion=Display;}
            else{Display=Downsample((int)Math.Ceiling(ContentBounds.Width),(int)Math.Ceiling(ContentBounds.Height));double motionRatio=Math.Min(1,Math.Sqrt(1200000.0/((double)Width*Height)));Motion=motionRatio==1?Display:Downsample(Math.Max(1,(int)(ContentBounds.Width*motionRatio)),Math.Max(1,(int)(ContentBounds.Height*motionRatio)));}

        }
        Bitmap Downsample(int width,int height){Cancellation.ThrowIfCancellationRequested();var image=new Bitmap(width,height,PixelFormat.Format32bppPArgb);try{using(var g=Graphics.FromImage(image)){g.CompositingMode=CompositingMode.SourceCopy;g.InterpolationMode=InterpolationMode.HighQualityBicubic;g.PixelOffsetMode=PixelOffsetMode.HighQuality;g.DrawImage(rendered,new Rectangle(0,0,width,height),cropRaster,GraphicsUnit.Pixel);}return image;}catch{image.Dispose();throw;}}
        static int Byte(double value){return Math.Max(0,Math.Min(255,(int)Math.Round(value)));}
        static void TexturePlane(Projected item,P[] points,PointF[] uv){
            double dx1=points[1].X-points[0].X,dy1=points[1].Y-points[0].Y,dx2=points[2].X-points[0].X,dy2=points[2].Y-points[0].Y,den=dx1*dy2-dx2*dy1;if(Math.Abs(den)<1e-9)return;
            double ds1=uv[1].X-uv[0].X,ds2=uv[2].X-uv[0].X,dt1=uv[1].Y-uv[0].Y,dt2=uv[2].Y-uv[0].Y;
            item.SX=(ds1*dy2-ds2*dy1)/den;item.SY=(dx1*ds2-dx2*ds1)/den;item.SC=uv[0].X-item.SX*points[0].X-item.SY*points[0].Y;
            item.TX=(dt1*dy2-dt2*dy1)/den;item.TY=(dx1*dt2-dx2*dt1)/den;item.TC=uv[0].Y-item.TX*points[0].X-item.TY*points[0].Y;
        }
        void Fill(Projected face,int[] pixels,float[] depths,int[] owners) {
            double lo=Double.PositiveInfinity,hi=Double.NegativeInfinity;foreach(var loop in face.Loops)foreach(var p in loop){lo=Math.Min(lo,p.Y);hi=Math.Max(hi,p.Y);}
            int top=Math.Max(0,(int)Math.Floor(Math.Max(-1,lo))),bottom=Math.Min(rasterHeight-1,(int)Math.Ceiling(Math.Min(rasterHeight,hi)));
            var intersections=new List<double>();
            for(int y=top;y<=bottom;y++) {
                if((y&31)==0)Cancellation.ThrowIfCancellationRequested();
                int rowColor=face.Color;
                if(face.Surface==BeltSurface3D.StainlessSteel){double v=(double)y/rasterHeight;double band=11*Math.Exp(-Math.Pow((v-.43)*7,2))-5*Math.Exp(-Math.Pow((v-.72)*7,2));Color c=Color.FromArgb(face.Color);rowColor=Color.FromArgb(Byte(c.R+band),Byte(c.G+band),Byte(c.B+band)).ToArgb();}
                intersections.Clear();double scan=y+.5;
                foreach(var loop in face.Loops)for(int j=0;j<loop.Length;j++){var a=loop[j];var b=loop[(j+1)%loop.Length];if((a.Y<=scan&&b.Y>scan)||(b.Y<=scan&&a.Y>scan))intersections.Add(a.X+(scan-a.Y)*(b.X-a.X)/(b.Y-a.Y));}
                intersections.Sort();
                for(int j=0;j+1<intersections.Count;j+=2) {
                    int left=Math.Max(0,(int)Math.Ceiling(Math.Max(-1,intersections[j])-.5)),right=Math.Min(rasterWidth-1,(int)Math.Floor(Math.Min(rasterWidth,intersections[j+1])-.5));
                    double d=face.A*(left+.5)+face.B*scan+face.C;
                    for(int x=left;x<=right;x++,d+=face.A){int index=y*rasterWidth+x;if(d>depths[index]){int color=rowColor;if(face.Pattern){color=BeltMotionPattern.Sample(face.SX*(x+.5)+face.SY*scan+face.SC,face.TX*(x+.5)+face.TY*scan+face.TC,face.BeltWidth,BeltTravelMm,BeltLoopMm);if(color==0)continue;}depths[index]=(float)d;pixels[index]=color;selection[index]=face.Section;owners[index]=face.Index;}}
                }
            }
        }
        void Edge(Projected face,P a,P b,int[] pixels,int[] owners,List<Projected> faces) {
            Cancellation.ThrowIfCancellationRequested();
            // Clip before sampling so a deeply zoomed off-screen edge stays inexpensive.
            double t0=0,t1=1,dx=b.X-a.X,dy=b.Y-a.Y;
            if(!Clip(-dx,a.X,ref t0,ref t1)||!Clip(dx,rasterWidth-1-a.X,ref t0,ref t1)||!Clip(-dy,a.Y,ref t0,ref t1)||!Clip(dy,rasterHeight-1-a.Y,ref t0,ref t1))return;
            int steps=Math.Max(1,(int)Math.Ceiling(Math.Max(Math.Abs(dx),Math.Abs(dy))*(t1-t0)));
            // Compare real edge depth with the covering surface at the SAME subpixel point.
            // Extrapolating a grazing plate side at a rounded pixel can put it in front of steel.
            for(int j=0;j<=steps;j++){double t=t0+(t1-t0)*j/steps,qx=a.X+dx*t,qy=a.Y+dy*t;int x=(int)Math.Floor(qx),y=(int)Math.Floor(qy);if(x<0||y<0||x>=rasterWidth||y>=rasterHeight)continue;int index=y*rasterWidth+x,owner=owners[index];double depth=a.D+(b.D-a.D)*t;if(owner<0||depth>=faces[owner].A*qx+faces[owner].B*qy+faces[owner].C-.02)pixels[index]=face.EdgeColor;}
        }
        static bool Clip(double p,double q,ref double t0,ref double t1){if(Math.Abs(p)<1e-9)return q>=0;double t=q/p;if(p<0){if(t>t1)return false;t0=Math.Max(t0,t);}else{if(t<t0)return false;t1=Math.Min(t1,t);}return true;}
    }
}
