using System;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas {
    internal sealed partial class Belt3DWindow : Form {
        internal readonly Belt3DPreview Preview=new Belt3DPreview();
        readonly FlowLayoutPanel cards=new FlowLayoutPanel();
        readonly Label metrics=new Label(),title=new Label();
        internal event Action<bool> HardwarePreferenceRequested;
        internal event Action DimensionViewsRequested;
        internal event Action TrajectoryToggleRequested;
        readonly Button trajectoryButton;
        internal void SetTrajectoryVisibility(bool visible){TrajectoryVisibility.Update(trajectoryButton,visible);}
        readonly Action<int> select;
        int selected;
        Belt3DGeometry mesh;
        internal Belt3DWindow(Action<int> onSelect,Action edit) {
            select=onSelect;Text="JAC / Vista 3D del configurador";Font=new Font("Segoe UI",10);BackColor=DesignUi.Canvas;
            Size=new Size(1440,860);MinimumSize=new Size(900,600);StartPosition=FormStartPosition.CenterParent;
            var header=new Panel{Dock=DockStyle.Top,Height=68,Padding=new Padding(24,12,20,8),BackColor=DesignUi.Canvas};
            title.Dock=DockStyle.Fill;title.ForeColor=DesignUi.Ink;title.Font=new Font("Segoe UI Semibold",16,FontStyle.Bold);title.Text="JAC  /  Diseño de banda";header.Controls.Add(title);
            var toolbar=new FlowLayoutPanel{Name="Expanded3DToolbar",Dock=DockStyle.Top,Height=50,Padding=new Padding(14,6,0,8),BackColor=DesignUi.Canvas,WrapContents=true,AutoScroll=false};
            MinimalLayout.FitToolbar(toolbar);
            trajectoryButton=TrajectoryVisibility.Create(delegate{if(TrajectoryToggleRequested!=null)TrajectoryToggleRequested();});
            TrajectoryVisibility.Update(trajectoryButton,true);toolbar.Controls.Add(trajectoryButton);
            foreach(string view in new[]{"Isométrica","Lateral","Superior","Frontal"}){string preset=view;toolbar.Controls.Add(Button(view,delegate{Preview.SetView(preset);}));}
            var zoomIn=Button("+",delegate{Preview.ChangeZoom(1.15);});zoomIn.Width=38;zoomIn.AccessibleName="Acercar vista 3D";toolbar.Controls.Add(zoomIn);
            var zoomOut=Button("−",delegate{Preview.ChangeZoom(1/1.15);});zoomOut.Width=38;zoomOut.AccessibleName="Alejar vista 3D";toolbar.Controls.Add(zoomOut);
            toolbar.Controls.Add(Button("Ajustar",delegate{Preview.Fit();}));toolbar.Controls.Add(Button("Banda completa",delegate{Preview.FocusOn(-1);}));toolbar.Controls.Add(Button("Ver tramo",delegate{Preview.FocusOn(selected);}));
            var rendererButton=Button("GPU / CPU",delegate{bool enabled=!Preview.PreferHardware;if(HardwarePreferenceRequested!=null)HardwarePreferenceRequested(enabled);else Preview.SetHardwarePreference(enabled);});rendererButton.Name="ToggleRenderer";rendererButton.AccessibleName="Alternar GPU y CPU en ambos visores";toolbar.Controls.Add(rendererButton);
            toolbar.Controls.Add(Button("Más ajustes",delegate{if(edit!=null)edit();}));
            var side=new Panel{Dock=DockStyle.Right,Width=316,Padding=new Padding(16),BackColor=DesignUi.Canvas};
            var label=new Label{Dock=DockStyle.Top,Height=36,Text="Tramos",ForeColor=DesignUi.Ink,Font=new Font("Segoe UI Semibold",10,FontStyle.Bold)};
            cards.Dock=DockStyle.Fill;cards.AutoScroll=true;cards.WrapContents=false;cards.FlowDirection=FlowDirection.TopDown;
            metrics.Dock=DockStyle.Bottom;metrics.Height=164;metrics.ForeColor=DesignUi.Muted;metrics.Font=new Font("Segoe UI",9);
            var pages=new TabControl{Name="ExpandedSidebarTabs",Dock=DockStyle.Fill};var sectionPage=new TabPage("Tramos");var simulationPage=new TabPage("Simulación");
            sectionPage.Controls.Add(cards);sectionPage.Controls.Add(label);sectionPage.Controls.Add(metrics);simulationPage.Controls.Add(CreateSimulationPanel());pages.TabPages.Add(sectionPage);pages.TabPages.Add(simulationPage);pages.SelectedIndex=1;side.Controls.Add(pages);
            Preview.Dock=DockStyle.Fill;Preview.SectionSelected+=delegate(int i){if(select!=null)select(i);};
            Controls.Add(Preview);Controls.Add(side);Controls.Add(new MeasurementBar(Preview,delegate{if(DimensionViewsRequested!=null)DimensionViewsRequested();}));Controls.Add(toolbar);Controls.Add(header);
        }
        static Button Button(string text,Action action) {
            var b=new RoundedButton{Text=text,Width=text.Length>14?162:112,Height=34,BackColor=Color.White,ForeColor=DesignUi.Ink,Margin=new Padding(0,0,8,5),Font=DesignUi.NavigationRegular};
            b.FlatAppearance.BorderColor=Color.FromArgb(211,221,230);b.Click+=delegate{action();};return b;
        }
        internal void UpdateModel(Belt3DGeometry value,string error,int index) {
            bool changed=!Object.ReferenceEquals(mesh,value);if(selected!=index)Preview.EditableAnnotations=false;mesh=value;selected=index;Preview.SetModel(mesh,error,index);SimulationModelChanged(changed);
            cards.SuspendLayout();while(cards.Controls.Count>0)cards.Controls[0].Dispose();
            title.Text=mesh==null?"JAC  /  Revisa la configuración":"JAC  /  "+mesh.Patterns.Count+" tramos  ·  "+(mesh.Length/1000).ToString("0.##")+" m";
            if(mesh!=null)for(int i=0;i<mesh.Patterns.Count;i++) {
                int n=i;var p=mesh.Patterns[i];var b=Button((i+1).ToString("00")+"  /  "+mesh.Lengths[i].ToString("0.##")+" mm\n"+ProfileSlotLayout.CombinationLabel(p.Combination)+"\n"+(p.Manual?"Elección manual":"Modo automático"),delegate{if(select!=null)select(n);});
                b.Width=230;b.Height=88;b.TextAlign=ContentAlignment.MiddleLeft;b.Padding=new Padding(10,0,0,0);b.Margin=new Padding(0,0,0,10);
                b.BackColor=i==index?DesignUi.Selection:Color.White;b.ForeColor=i==index?DesignUi.Primary:DesignUi.Ink;cards.Controls.Add(b);
            }
            cards.ResumeLayout();
            metrics.Text=mesh==null?error:ProfileSlotLayout.DimensionsText(mesh.Patterns[index])+"\n\nVista de configuración a escala. Los radios de doblez y detalles de soldadura se confirman en el CAD.";
        }
    }
}
