using System;
using System.Collections.Generic;
using System.IO;
namespace PerfilBandas {
internal sealed class DesignIssue {
    public int Section=-1,Category;public bool Blocking=true;public string Message;
    public override string ToString(){return (Blocking?"Error · ":"Aviso · ")+(Section<0?"Banda":("Tramo "+(Section+1).ToString("00")))+" · "+Message;}
}
internal sealed class BeltDesignPlan {
    public readonly List<DesignIssue> Issues=new List<DesignIssue>();
    public ProfileSettings[] Profiles;public SoporteSettings[] Supports;public ReturnRollerPlan Rollers;
    public bool Valid {get{return !Issues.Exists(i=>i.Blocking);}}
    void Check(Action action,int section,int category){try{action();}catch(Exception e){Issues.Add(new DesignIssue{Section=section,Category=category,Message=e.Message});}}
    public void RequireValid(){if(!Valid)throw new InvalidOperationException(String.Join(Environment.NewLine,Issues.FindAll(i=>i.Blocking).ConvertAll(i=>i.ToString()).ToArray()));}
    public static BeltDesignPlan Build(IList<BeltSectionSpec> sections,ProfileSettings profile,SoporteSettings support,ReturnRollerSettings rollers,VerticalSupportSettings legs,BearingCatalog bearingCatalog=null,SprocketCatalog sprocketCatalog=null){
        var plan=new BeltDesignPlan();
        if(CurveRoute.HasCurves(sections)){for(int i=0;i<sections.Count;i++)if(sections[i].IsCurved){double minimum;var p=sections[i].Profile??profile;if(!CurveManualRules.TryMinimumRadius(p.BandWidthMm,out minimum))plan.Issues.Add(new DesignIssue{Section=i,Category=0,Message="Tabla E925: no hay radio mínimo confirmado para ancho "+p.BandWidthMm+" mm. E925 admite múltiplos de 20 mm desde 100 mm."});}}
        plan.Check(()=>BeltLinePlan.Validate(sections,profile),-1,0);
        plan.Check(()=>BeltLinePlan.ValidateSupports(sections,profile,support),-1,2);
        plan.Check(()=>VerticalSupportLayout.Validate(sections,profile),-1,3);
        plan.Check(()=>(legs??new VerticalSupportSettings()).Validate(),-1,3);
        plan.Check(()=>plan.Rollers=ReturnRollerLayout.Build(sections,profile,support,rollers),-1,10);
        if(plan.Rollers!=null&&plan.Rollers.SlotsInterrupted)plan.Issues.Add(new DesignIssue{Category=10,Blocking=false,Message="Solo primeras ranuras desde los extremos afectados interrumpidas; margen ajustado de "+rollers.SlotClearanceMm.ToString("0.#")+" mm; logo conservado."});
        if(sections==null)return plan;
        plan.Profiles=new ProfileSettings[sections.Count];plan.Supports=new SoporteSettings[sections.Count];
        for(int index=0;index<sections.Count;index++) {int i=index;
            plan.Check(()=>{
                var p=BeltLinePlan.ProfileFor(sections,i,profile);if(plan.Rollers!=null&&rollers!=null&&rollers.Enabled){ReturnRollerLayout.Apply(p,i,sections[i],plan.Rollers);p.ResolvedCurveRollerRiseMm=rollers.CurveRollerRiseMm;}
                var s=BeltLinePlan.SupportFor(sections[i],support,p);plan.Profiles[i]=p;plan.Supports[i]=s;
                if(!sections[i].IsCurved&&(legs??new VerticalSupportSettings()).CrossbarEnabled)plan.Check(()=>LegCrossbarLayout.Nominal(legs??new VerticalSupportSettings(),p,s,0),i,3);
                if(sections[i].IsCurved){if(p.TopFlangeMm<=p.ThicknessMm||p.BottomFlangeMm<=p.ThicknessMm)throw new InvalidOperationException("Curva: el saliente de la ceja debe superar el espesor del alma.");int minimum=CurveManualRules.MinimumCenterRails(p.BandWidthMm);if(sections[i].IncludeSlideRails&&minimum>0&&s.CenterSlotCount<minimum)throw new InvalidOperationException("Curva E925: el manual requiere al menos "+minimum+" pletinas centrales superiores para este ancho.");if(2*p.SupportHoleYMm+p.SupportHoleSizeMm>=p.WebHeightMm)throw new InvalidOperationException("El alma no deja espacio entre los barrenos de los soportes superior e inferior.");if(p.EndHolesBottom){CurveLegLayout.Settings(legs??new VerticalSupportSettings());if(Math.Abs(p.EndHoleSizeMm-11)>.01||Math.Abs(p.EndHoleSpacingMm-63.5)>.01)throw new InvalidOperationException("La placa curva requiere cuadrados de 11 mm y paso recto de 63.5 mm.");if((legs??new VerticalSupportSettings()).CrossbarEnabled)CurveLegLayout.Crossbar(legs??new VerticalSupportSettings(),p,s);if(p.EndHoleTypeRight=="empalme"){var jointFrames=CurveRoute.Frames(sections,support,profile);var next=BeltLinePlan.ProfileFor(sections,i+1,profile);CurveLegLayout.ValidateJoint(p,s,jointFrames[i],next,BeltLinePlan.SupportFor(sections[i+1],support,next),jointFrames[i+1]);}}}
                if(sections[i].IsCurved){var frame=CurveRoute.Frames(sections,support,profile)[i];foreach(double web in new[]{0.0,s.LengthMm})CurveLegHoleLayout.Centers(p,frame,CurveLegHoleLayout.RadialCenter(p,web,web==0?-1:1));if(sections[i].IncludeSlideRails)CurveReturnLayout.Rails(s,p.LengthMm,true);CurveCncExport.Build(sections[i].Curve,p,s,frame);}
                if(sections[i].IncludeSlideRails)SlideRailGeometry.Range(s,i,sections.Count,0,p.LengthMm);
                if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers&&2*rollers.SideClearanceMm>=s.LengthMm)throw new InvalidOperationException("El cuerpo del rodillo no cabe con la separación lateral seleccionada.");
                var settings=sections[i].ShaftPlates;
                if(ConveyorShaftGeometry.Active(sections[i]))ConveyorShaftGeometry.Calculate(sections[i],p,s,ShaftPlateGeometry.Nominal(sections[i],p,s));
                if(settings.Enabled&&settings.Bearing!=null&&!File.Exists((bearingCatalog??BearingCatalog.Default()).ModelPath(settings.Bearing)))throw new InvalidOperationException("Falta el modelo de la chumacera. Vuelve a asociar su referencia.");
                if(settings.Shaft.Sprocket!=null){var e=settings.Shaft.Sprocket;
                    if(e.Teeth>0&&e.Teeth!=settings.Teeth)throw new InvalidOperationException("Los dientes del sprocket de catálogo no coinciden con el cálculo de transmisión.");
                    if(e.PitchDiameterMm>0&&Math.Abs(e.PitchDiameterMm-E925Sprocket.For(settings.Teeth).PitchDiameterMm)>.05)throw new InvalidOperationException("El diámetro primitivo de catálogo no coincide con la tabla E925 seleccionada.");
                    if(!e.MatchesBand(p.BeltModelName))throw new InvalidOperationException("El sprocket pertenece a otra familia de banda.");
                    if(!File.Exists((sprocketCatalog??SprocketCatalog.Default()).ModelPath(e)))throw new InvalidOperationException("Falta el modelo del sprocket.");
                    if(e.Teeth==0)plan.Issues.Add(new DesignIssue{Section=i,Category=9,Blocking=false,Message="Sprocket antiguo: confirmar dientes y diámetro primitivo en catálogo."});
                }
                if(p.ResolvedPattern!=null&&p.ResolvedPattern.Description.Contains("adaptado"))plan.Issues.Add(new DesignIssue{Section=i,Category=4,Blocking=false,Message=p.ResolvedPattern.Description});
                double[] centers=SupportHoleLayout.CentersMm(p);double span=0;for(int j=1;j<centers.Length;j++)span=Math.Max(span,centers[j]-centers[j-1]);
                if(sections[i].MaximumSupportSpanMm>0&&span>sections[i].MaximumSupportSpanMm+1e-6)throw new InvalidOperationException("Paso de travesaños "+span.ToString("0.#")+" mm supera el máximo aprobado de "+sections[i].MaximumSupportSpanMm.ToString("0.#")+" mm.");
            },i,9);
            if(plan.Profiles[i]!=null&&plan.Supports[i]!=null&&sections[i].IsCurved&&plan.Profiles[i].ResolvedCurveReturnDropMm>0){var p=plan.Profiles[i];var s=plan.Supports[i];double lowest=CurveReturnLayout.SupportY(p,s,true)+Math.Min(0,s.ActualFlange1HeightMm-s.ActualFlange2HeightMm);if(Math.Abs(lowest-(-p.WebHeightMm+p.ThicknessMm+1))<.001)plan.Issues.Add(new DesignIssue{Section=i,Category=10,Blocking=false,Message="Retorno de curva limitado por el labio inferior: descenso "+p.ResolvedCurveReturnDropMm.ToString("0.#")+" mm. Se conserva la elevación ajustada del rodillo."});}
            if(plan.Profiles[i]!=null&&!sections[i].IsCurved)plan.Check(()=>{var settings=legs??new VerticalSupportSettings();var part=plan.Profiles[i];double mountY=VerticalSupportLayout.NominalMountMm(part)[1],length=settings.TubeLength(mountY);if(length<100)throw new InvalidOperationException("La altura de banda deja un PTR menor de 100 mm. Revisa altura y alma del perfil.");if(settings.ScrewLengthMm-VerticalSupportSettings.FootBelowTubeMm>length-10)throw new InvalidOperationException("El tornillo nivelador alcanza la placa superior. Reduce su largo o aumenta la altura de la pata.");},i,3);
        }
        if(CurveRoute.HasCurves(sections)&&Array.TrueForAll(plan.Profiles,p=>p!=null)&&Array.TrueForAll(plan.Supports,s=>s!=null))plan.Check(()=>CurveReturnTransitionLayout.Build(sections,plan.Profiles,plan.Supports,plan.Rollers,rollers),-1,10);
        if(!CurveRoute.HasCurves(sections)&&plan.Rollers!=null&&plan.Rollers.Holes.Count>0&&Array.TrueForAll(plan.Profiles,p=>p!=null)&&Array.TrueForAll(plan.Supports,s=>s!=null))plan.Check(()=>{
            int last=sections.Count-1;var firstShaft=ShaftPlateGeometry.Nominal(sections[0],plan.Profiles[0],plan.Supports[0]);var motorShaft=ShaftPlateGeometry.Nominal(sections[last],plan.Profiles[last],plan.Supports[last]);var check=ReturnOverviewGeometry.Build(sections,plan.Profiles,plan.Supports,rollers,plan.Rollers,firstShaft,motorShaft);
            if(check.CollisionCount>0)throw new InvalidOperationException("Retorno o rodillos interfieren con "+check.CollisionCount+" soportes. Revisa el abrazo y la separación en Explorar retorno.");
        },-1,10);
        return plan;
    }
}
}



