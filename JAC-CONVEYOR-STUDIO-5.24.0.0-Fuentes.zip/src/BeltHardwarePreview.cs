using System;
using System.Drawing;
using System.Windows.Forms;
namespace PerfilBandas {
internal sealed partial class Belt3DPreview {
    HardwareViewport hardware;bool attemptedHardware;internal bool PreferHardware=true;string hardwareFailure;
    internal string RendererDescription{get{return hardware==null?"CPU asíncrono"+(hardwareFailure==null?"":" · "+hardwareFailure):"GPU · "+hardware.Renderer+" · MSAA "+hardware.Samples+"×"+(hardware.Synchronized?" · VSync":"");}}
    internal int GpuGeometryBuilds{get{return hardware==null?0:hardware.GeometryBuilds;}}
    internal int GpuSamples{get{return hardware==null?0:hardware.Samples;}}
    protected override void OnPaintBackground(PaintEventArgs e){if(!PreferHardware||hardwareFailure!=null)base.OnPaintBackground(e);}
    internal bool HardwareActive{get{return hardware!=null;}}
    protected override CreateParams CreateParams{get{var p=base.CreateParams;p.ClassStyle|=0x20;return p;}}
    protected override void OnHandleDestroyed(EventArgs e){ReleaseHardware();attemptedHardware=false;base.OnHandleDestroyed(e);}
    void ReleaseHardware(){if(hardware!=null){hardware.Dispose();hardware=null;}}
    internal void SetHardwarePreference(bool enabled){
        if(PreferHardware==enabled&&(!enabled||hardwareFailure==null))return;
        PreferHardware=enabled;hardwareFailure=null;attemptedHardware=false;CancelWorker();ReleaseHardware();
        Capture=false;mouseGesture=MouseButtons.None;dragging=false;Cursor=Cursors.Default;
        SetStyle(ControlStyles.OptimizedDoubleBuffer,!enabled);
        // A Windows OpenGL pixel format belongs to the HWND and cannot be undone.
        // Give GDI a fresh window/DC when returning to CPU, and OpenGL its own surface on retry.
        if(IsHandleCreated)RecreateHandle();
        Changed();
    }
    bool PaintHardware(Graphics graphics){
        if(!PreferHardware||Mesh==null||!IsHandleCreated||Width<30||Height<30)return false;
        try{if(hardware==null){if(attemptedHardware)return false;attemptedHardware=true;SetStyle(ControlStyles.OptimizedDoubleBuffer,false);hardware=new HardwareViewport(Handle);CancelWorker();Invalidate();}
            var origin=Project(new BeltPoint3D(0,0,0));double[] matrix={scale*sinYaw,scale*sinPitch*cosYaw,cosPitch*cosYaw,0,0,-scale*cosPitch,sinPitch,0,scale*cosYaw,-scale*sinPitch*sinYaw,-cosPitch*sinYaw,0,origin.X,origin.Y,origin.D,1};
            hardware.Draw(Mesh,Width,Height,matrix,Selected,FocusSection,BackColor,navigation,Measurement,"3D / "+RendererDescription+(String.IsNullOrEmpty(Error)?"":"\n"+Error),BeltPatternEnabled,BeltTravelMm,BeltLoopMm);LastFrameMilliseconds=hardware.LastMilliseconds;pending=false;frameTimer.Stop();CompletedFrames++;
            return true;
        }catch(Exception e){hardwareFailure=e.Message;ReleaseHardware();SetStyle(ControlStyles.OptimizedDoubleBuffer,true);attemptedHardware=true;BeginInvoke((Action)delegate{if(IsDisposed)return;RecreateHandle();attemptedHardware=true;Changed();});frameTimer.Start();return false;}
    }
    internal Bitmap CaptureHardware(){if(hardware==null)throw new InvalidOperationException(RendererDescription);return hardware.Capture(Width,Height);}
    internal bool EnsureHardwareFrame(){IntPtr handle=Handle;PrepareCamera();using(var bitmap=new Bitmap(Math.Max(1,Width),Math.Max(1,Height)))using(var graphics=Graphics.FromImage(bitmap))return PaintHardware(graphics);}
}
}
