﻿using System;
using System.Collections.Generic;

namespace PerfilBandas
{
    internal enum BeltSectionType { Conducido, Intermedio, Motriz }

    internal sealed class BeltSectionSpec
    {
        public BeltSectionType Type;
        public double LengthMm;
        public CurveSectionSettings Curve=new CurveSectionSettings();
        public bool IsCurved {get{return Curve!=null&&Curve.Enabled;}}
        public int SupportCount; // 0 = estándar automático; 2 a 32 = elección por tramo
        public ProfileSettings Profile;
        public SoporteSettings Support;
        public bool AutoSupportPitch = true;
        public bool AutoSlots = true;
        public bool IncludeSlideRails = true;
        public double MaximumSupportSpanMm;
        public ShaftPlateSettings ShaftPlates = new ShaftPlateSettings();
        public BeltSectionSpec() { }
        public BeltSectionSpec(BeltSectionType type, double lengthMm, int supportCount = 0)
        {
            Type = type;
            ShaftPlates.Shaft.Keyway=type==BeltSectionType.Motriz;
            LengthMm = lengthMm;
            SupportCount = supportCount;
        }

        public BeltSectionSpec Copy()
        {
            var copy = (BeltSectionSpec)MemberwiseClone();
            copy.Profile = Profile == null ? null : Profile.Copy();
            copy.Support = Support == null ? null : Support.Copy();
            copy.ShaftPlates = ShaftPlates == null ? new ShaftPlateSettings() : ShaftPlates.Copy();
            copy.Curve=Curve==null?new CurveSectionSettings():Curve.Copy();
            return copy;
        }
    }

    internal static class BeltLinePlan
    {
        public static void Validate(IList<BeltSectionSpec> sections, ProfileSettings profile, bool functionalSlots=false)
        {
            if (sections == null || sections.Count < 2)
                throw new InvalidOperationException("La banda necesita un tramo conducido y uno motriz.");
            if (sections.Count > 24)
                throw new InvalidOperationException("El máximo del configurador es 24 tramos.");
            for (int i = 0; i < sections.Count; i++)
                if (sections[i] == null) throw new InvalidOperationException("Hay un tramo sin configurar.");
            if (sections[0].Type != BeltSectionType.Conducido ||
                sections[sections.Count - 1].Type != BeltSectionType.Motriz)
                throw new InvalidOperationException("El primer tramo debe ser conducido y el último motriz.");
            for (int i = 1; i < sections.Count - 1; i++)
                if (sections[i].Type != BeltSectionType.Intermedio)
                    throw new InvalidOperationException("Entre los extremos sólo puede haber tramos intermedios.");
            if (profile == null) throw new ArgumentNullException("profile");
            CurveRoute.Validate(sections,profile);
            if (profile.EndHoleSizeMm <= 0 || profile.EndHoleEdgeMm <= 0 || profile.EndHoleSpacingMm <= 0)
                throw new InvalidOperationException("Las cotas de los orificios de extremo deben ser positivas.");
            for (int i = 0; i < sections.Count; i++)
            {
                SettingsValidation.Numbers(sections[i], "Tramo " + (i + 1));
                if(Math.Abs((sections[i].Profile??profile).SlotGapMm-(sections[0].Profile??profile).SlotGapMm)>.00001)throw new InvalidOperationException("La separación libre de ranuras debe ser común a toda la banda.");
                ProfileSettings part = ProfileFor(sections, i, profile, functionalSlots);
                if ((!sections[i].IsCurved&&part.LengthMm < 600) || part.LengthMm > 6000)
                    throw new InvalidOperationException("El tramo " + (i + 1) + " debe medir entre 600 y 6000 mm.");
                if (!sections[i].IsCurved&&2 * (part.EndHoleEdgeMm + part.EndHoleSpacingMm + part.EndHoleSizeMm / 2.0) >= part.LengthMm)
                    throw new InvalidOperationException("Los orificios de extremo no caben en el tramo " + (i + 1) + ".");
                SupportHoleLayout.CentersMm(part);
                ValidateProfile(part, i, functionalSlots);
                if (i > 0)
                {
                    var first = ProfileFor(sections, 0, profile, functionalSlots);
                    if (Math.Abs(first.BandWidthMm - part.BandWidthMm) > .01 || first.BeltModelName != part.BeltModelName || Math.Abs(first.BeltThicknessMm-part.BeltThicknessMm) > .01)
                        throw new InvalidOperationException("Tramo " + (i + 1) + ": el modelo, ancho y espesor de banda deben coincidir con el primer tramo para formar una banda continua.");
                    if (Math.Abs(first.WebHeightMm - part.WebHeightMm) > .01 || (!sections[i].IsCurved&&(Math.Abs(first.BottomFlangeMm - part.BottomFlangeMm) > .01 || Math.Abs(first.BottomAngleDeg - part.BottomAngleDeg) > .01)))
                        throw new InvalidOperationException("Tramo " + (i + 1) + ": la altura y el doblez inferior deben coincidir para alinear las uniones de las patas.");
                }
            }
        }

        private static void ValidateProfile(ProfileSettings p, int index, bool functionalSlots)
        {
            string prefix = "Tramo " + (index + 1) + ": ";
            if (p.ThicknessMm <= 0 || p.WebHeightMm <= 0 || p.BandWidthMm <= 0 || p.BeltThicknessMm <= 0 || p.BendRadiusMm <= 0 ||
                p.TopFlangeMm <= p.ThicknessMm || p.BottomFlangeMm <= p.ThicknessMm ||
                p.TopAngleDeg <= 0 || p.TopAngleDeg >= 180 || p.BottomAngleDeg <= 0 || p.BottomAngleDeg >= 180)
                throw new InvalidOperationException(prefix + "revisa las dimensiones de los perfiles y dobleces.");
            ProfileBendGeometry.Validate(p);
            if (p.EndHoleSizeMm <= 0 || p.EndHoleEdgeMm <= p.EndHoleSizeMm / 2 || p.EndHoleSpacingMm <= p.EndHoleSizeMm ||
                p.EndHoleSizeMm + 2 * p.BendRadiusMm >= p.BottomFlangeMm || (p.EndHolesTop && p.EndHoleSizeMm + 2 * p.BendRadiusMm >= p.TopFlangeMm))
                throw new InvalidOperationException(prefix + "los orificios para patas no caben con las cotas de borde y doblez indicadas.");
            if (p.SupportHoleSizeMm <= 0 || p.SupportHoleYMm - p.SupportHoleSizeMm / 2 <= p.BendRadiusMm || p.SupportHoleYMm + p.SupportHoleSizeMm / 2 >= p.WebHeightMm - p.BendRadiusMm)
                throw new InvalidOperationException(prefix + "el orificio del soporte debe quedar dentro del alma del perfil.");
            ProfileSlotLayout.PatternFor(p);
        }

        public static SoporteSettings SupportFor(BeltSectionSpec section, SoporteSettings template, ProfileSettings part)
        {
            var s = (section.Support ?? template).Copy();
            s.BandWidthMm = part.BandWidthMm;
            s.BeltModelName = part.BeltModelName;
            if (s.AutoSyncWithBandWidth) s.LengthMm = SoporteSettings.CalculateLengthFromBand(part.BandWidthMm);
            if(section.IsCurved&&section.IncludeSlideRails)CurveUpperGuideGeometry.Configure(s,part.BeltThicknessMm);else s.CurveGuideBandThicknessMm=0;
            return s;
        }

        public static void ValidateSupports(IList<BeltSectionSpec> sections, ProfileSettings profile, SoporteSettings template, bool functionalSlots=false, bool validateShaftPlates=true)
        {
            double opening = -1;
            for (int i = 0; i < sections.Count; i++)
            {
                var p = ProfileFor(sections, i, profile, functionalSlots);
                var s = SupportFor(sections[i], template, p);
                string prefix = "Tramo " + (i + 1) + ": ";
                double[] centers = SupportHoleLayout.CentersMm(p);
                const double placementToleranceMm=0.000001;
                if (centers[0] < s.WebWidthMm / 2-placementToleranceMm || p.LengthMm - centers[centers.Length - 1] < s.WebWidthMm / 2-placementToleranceMm)
                    throw new InvalidOperationException(prefix + "el soporte sobresale del extremo; aumenta el margen del primer orificio.");
                for (int j = 1; j < centers.Length; j++)
                    if (centers[j] - centers[j - 1] < s.WebWidthMm-placementToleranceMm)
                        throw new InvalidOperationException(prefix + "los soportes se superponen; aumenta el paso o reduce su cantidad/ancho de lomo.");
                if (!s.IncludeEndPlates || Math.Abs(p.SupportHoleSizeMm - s.EndPlateHoleSizeMm) > .001)
                    throw new InvalidOperationException(prefix + "el tamaño del orificio de las plaquitas debe coincidir con el de los perfiles.");
                if (s.LengthMm < p.BandWidthMm || s.WebWidthMm <= 2 * s.ThicknessMm + s.EndPlateHoleSizeMm ||
                    s.ThicknessMm <= 0 || s.EndPlateThicknessMm <= 0 || s.BendRadiusMm <= 0 || s.KFactor <= 0 || s.KFactor >= 1)
                    throw new InvalidOperationException(prefix + "revisa el largo, lomo, espesor y factor K del soporte.");
                double halfHole = s.EndPlateHoleSizeMm / 2;
                double lowA = (s.Flange1HeightMm - s.Flange2HeightMm) * (s.WebWidthMm / 2 - halfHole - s.ThicknessMm) / (s.WebWidthMm - 2 * s.ThicknessMm);
                double lowB = (s.Flange1HeightMm - s.Flange2HeightMm) * (s.WebWidthMm / 2 + halfHole - s.ThicknessMm) / (s.WebWidthMm - 2 * s.ThicknessMm);
                if (s.EndPlateHoleYMm - halfHole <= Math.Max(lowA, lowB) || s.EndPlateHoleYMm + halfHole >= s.Flange1HeightMm - SoporteSettings.EndPlateTopReliefMm)
                    throw new InvalidOperationException(prefix + "el orificio de la plaquita no cabe entre el recorte superior y el borde inferior.");
                if (s.IncludeNylamidSlots && (s.SlotWidthMm <= 0 || s.OuterSlotDepthMm <= 0 || s.CenterSlotDepthMm <= 0 ||
                    s.CenterSlotCount < 0 || s.CenterSlotCount > 8 || s.CenterSlotDepthMm >= Math.Min(s.Flange1HeightMm, s.Flange2HeightMm) ||
                    (s.CenterSlotCount + 2) * s.SlotWidthMm >= s.LengthMm))
                    throw new InvalidOperationException(prefix + "las ranuras de Nylamid no caben en el soporte.");
                if (sections[i].IncludeSlideRails)
                {
                    try { SlideRailGeometry.Placements(s, p.LengthMm); }
                    catch (InvalidOperationException ex) { throw new InvalidOperationException(prefix + ex.Message, ex); }
                }
                double width = s.LengthMm;
                if (opening > 0 && Math.Abs(opening - width) > .01)
                    throw new InvalidOperationException(prefix + "el largo del soporte y espesor lateral generan un ancho exterior distinto al del primer tramo; iguala estas medidas para unir los perfiles.");
                opening = width;
                if (validateShaftPlates && ShaftPlateGeometry.Active(sections[i]))
                {
                    try { ShaftPlateGeometry.Validate(sections[i], p, s, ShaftPlateGeometry.Nominal(sections[i], p, s)); }
                    catch (InvalidOperationException ex) { throw new InvalidOperationException(prefix + ex.Message, ex); }
                }
            }
        }

        public static ProfileSettings ProfileFor(IList<BeltSectionSpec> sections, int index, ProfileSettings template, bool functionalSlots=false)
        {
            if (sections == null || template == null || index < 0 || index >= sections.Count)
                throw new ArgumentException("Tramo o plantilla inválidos.");
            ProfileSettings part = (sections[index].Profile ?? template).Copy();
            SettingsValidation.Numbers(part,"Perfil del tramo " + (index+1));
            SettingsValidation.Numbers(sections[index].Support??new SoporteSettings(),"Soporte del tramo " + (index+1));
            part.ResolvedRollerHoles=null;part.ResolvedPattern=null;part.ResolvedSlots=null;part.ResolvedSupportCentersMm=null;
            part.SlotGapMm=(sections[0].Profile ?? template).SlotGapMm;
            BeltWidthRules.Validate(part.BeltModelName,part.BandWidthMm);
            part.LengthMm = sections[index].IsCurved?sections[index].Curve.CenterLengthMm(part.BandWidthMm):sections[index].LengthMm;
            if(sections[index].IsCurved){part.TopAngleDeg=90;part.BottomAngleDeg=90;}
            SupportHoleLayout.SetElevation(part, SupportFor(sections[index],sections[index].Support ?? new SoporteSettings(),part));
            bool curved=sections[index].IsCurved;
            part.EndHoleTypeLeft = curved ? (index>0&&sections[index-1].IsCurved?"empalme":"ninguno") : (index==0||sections[index-1].IsCurved?"final":"empalme");
            part.EndHoleTypeRight = curved ? (index+1<sections.Count&&sections[index+1].IsCurved?"empalme":"ninguno") : (index==sections.Count-1||sections[index+1].IsCurved?"final":"empalme");
            part.EndHolesBottom = true;if(curved)part.EndHolesTop=false;part.CurvedWeldedProfile=curved;
            part.IncludeSupportHoles = true;
            int count = sections[index].SupportCount == 0 ? AutoSupportCount(part.LengthMm) : sections[index].SupportCount;
            if (count < 2 || count > SupportHoleLayout.MaximumCount)
                throw new InvalidOperationException("El tramo " + (index + 1) + " debe tener entre 2 y 32 soportes.");
            part.SupportCount = count;
            if (sections[index].AutoSupportPitch)
            {
                // Supports at internal ends are flush with the joint. Keep the
                // configured margin only at the two outside ends of the complete belt.
                double edge=part.SupportHoleEdgeMm+part.SupportHoleSizeMm/2;
                double halfWidth=(sections[index].Support??new SoporteSettings()).WebWidthMm/2;
                double first=index==0?edge:halfWidth;
                double last=part.LengthMm-(index==sections.Count-1?edge:halfWidth);
                double pitch = (last-first)/(count-1);
                if (pitch < 70)
                    throw new InvalidOperationException("El tramo " + (index + 1) + " es demasiado corto para " + count + " soportes.");
                part.SupportHoleSpacingMm = pitch;
                part.SupportHoleEdgeMm = first-part.SupportHoleSizeMm/2;
                part.ResolvedSupportCentersMm=new double[count];
                for(int j=0;j<count;j++)part.ResolvedSupportCentersMm[j]=first+j*pitch;
                part.ResolvedSupportCentersMm[count-1]=last;
            }
            if(curved)CurveSupportLayout.Resolve(sections,index,part,SupportFor(sections[index],sections[index].Support??new SoporteSettings(),part));
            double overlap=ShaftPlateGeometry.Active(sections[index])?ShaftPlateGeometry.EffectiveOverlap(sections[index],part):0;
            if(!sections[index].IsCurved)part.ResolvedSlots=ProfileSlotLayout.Resolve(part,true,sections[index].Type==BeltSectionType.Conducido?overlap:0,sections[index].Type==BeltSectionType.Motriz?overlap:0);
            if(sections[index].IsCurved)part.ResolvedSlots=new ProfileSlotSpec[0];
            return part;
        }

        private static int AutoSupportCount(double lengthMm)
        {
            if (lengthMm < 1000) return 2;
            if (lengthMm < 2000) return 4;
            return 6;
        }

        public static double TotalLengthMm(IList<BeltSectionSpec> sections)
        {
            double total = 0;
            foreach (BeltSectionSpec section in sections) total += section.IsCurved?section.Curve.ExteriorLengthMm(section.Profile.BandWidthMm):section.LengthMm;
            return total;
        }
    }
}


