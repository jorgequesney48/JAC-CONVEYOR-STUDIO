using System;using System.Drawing;
namespace PerfilBandas {
internal sealed partial class Belt3DGeometry {
 void MotionCoordinates(BeltFace3D face,double s0,double s1,double width,bool curved,bool upper){
  face.BeltWidthMm=width;
  if(!curved)face.BeltCoordinates=new[]{new PointF((float)s0,0),new PointF((float)s1,0),new PointF((float)s1,(float)width),new PointF((float)s0,(float)width)};
  else {float t0=upper?(float)width:0,t1=upper?0:(float)width;face.BeltCoordinates=new[]{new PointF((float)s0,t0),new PointF((float)s0,t1),new PointF((float)s1,t1),new PointF((float)s1,t0)};}
 }
 internal void AddTrajectory(BeltTrajectory trajectory){
  var color=Color.FromArgb(74,146,191);
  foreach(var part in trajectory.Pieces){int first=Faces.Count;
   if(part.Curved){
    SweepCurve(part.Frame,Rectangle(part.X0,part.Level,part.Width,part.Thickness),0,part.Frame.Length,part.Section,color,f=>f.IsTransportBelt=true);
    int steps=(Faces.Count-first-2)/4;
    for(int k=0;k<steps;k++)foreach(int side in new[]{0,2})MotionCoordinates(Faces[first+2+k*4+side],part.TravelAt(part.Frame.Length*k/steps),part.TravelAt(part.Frame.Length*(k+1)/steps),part.Width,true,side==2);
   }else{
    Extrude(Array.ConvertAll(part.Polygon,p=>part.Point(part.X0,p.Y,p.X)),new BeltPoint3D(part.Width*Math.Cos(part.Frame.Heading),0,-part.Width*Math.Sin(part.Frame.Heading)),part.Section,color,null,BeltSurface3D.Nylamid);
    int count=part.Polygon.Length/2;
    for(int j=0;j<part.Polygon.Length;j++){
     int next=(j+1)%part.Polygon.Length;if(j==count-1||next==0)continue;
     int a=j<count?j:part.Polygon.Length-1-j,b=next<count?next:part.Polygon.Length-1-next;
     MotionCoordinates(Faces[first+2+j],part.TravelAt(part.Distances[a]),part.TravelAt(part.Distances[b]),part.Width,false,false);
    }
   }
   for(int i=first;i<Faces.Count;i++){Faces[i].IsTransportBelt=true;Faces[i].DrawEdges=false;}
  }
 }
}
internal static class BeltMotionPattern {
 internal const double PitchMm=25;
 internal static double Mod(double value,double period){return value-Math.Floor(value/period)*period;}
 // Visual reference to the manual's staggered Flush Grid openings. The catalogue
 // specifies the 25 mm pitch, not the manufacturing outline of each opening.
 internal static int Sample(double s,double t,double width,double travel,double loop){
  double q=s-travel,row=Math.Floor(q/PitchMm),z=Mod(q,PitchMm)-PitchMm/2;
  double u=Mod(t+(Mod(row,2)>.5?10:0),20)-10;
  if(t>4&&t<width-4&&z*z/(9.5*9.5)+u*u/49<1)return 0;
  if(loop>0&&Mod(s-travel,loop)<PitchMm)return Color.FromArgb(248,180,58).ToArgb();
  double seam=Mod(q,PitchMm);return seam<1.1?Color.FromArgb(28,63,116).ToArgb():Color.FromArgb(48,88,158).ToArgb();
 }
}
}
