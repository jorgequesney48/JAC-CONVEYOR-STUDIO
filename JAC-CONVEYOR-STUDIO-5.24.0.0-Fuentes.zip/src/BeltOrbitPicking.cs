﻿using System;
using System.Drawing;
namespace PerfilBandas {
    internal static class BeltOrbitPicking {
        struct P {public double X,Y,D;public P(double x,double y,double d){X=x;Y=y;D=d;}}
        static bool Inside(P[] loop,double x,double y){bool inside=false;for(int i=0,j=loop.Length-1;i<loop.Length;j=i++){var a=loop[i];var b=loop[j];if((a.Y>y)!=(b.Y>y)&&x<(b.X-a.X)*(y-a.Y)/(b.Y-a.Y)+a.X)inside=!inside;}return inside;}
        internal static BeltPoint3D VisibleCenter(Belt3DGeometry mesh,BeltPoint3D center,double yaw,double pitch,double scale,double originX,double originY,int width,int height,int focusSection=-1){
            double cy=Math.Cos(yaw*Math.PI/180),sy=Math.Sin(yaw*Math.PI/180),cp=Math.Cos(pitch*Math.PI/180),sp=Math.Sin(pitch*Math.PI/180);
            Converter<BeltPoint3D,P> project=delegate(BeltPoint3D q){double x=q.X-center.X,y=q.Y-center.Y,z=q.Z-center.Z,d=-sy*z+cy*x;return new P((cy*z+sy*x)*scale+originX,(-cp*y+sp*d)*scale+originY,sp*y+cp*d);};
            double targetX=width/2d,targetY=height/2d,bestDistance=Double.PositiveInfinity,bestDepth=Double.NegativeInfinity,bestX=targetX,bestY=targetY;
            if(mesh!=null&&scale>0)foreach(var face in mesh.Faces){
                if(focusSection>=0&&face.Section!=focusSection)continue;
                var outer=Array.ConvertAll(face.Outer,project);if(outer.Length<3)continue;
                double a=0,b=0,c=0;bool valid=false;for(int i=1;i<outer.Length-1;i++){var u=outer[0];var v=outer[i];var w=outer[i+1];double det=(v.X-u.X)*(w.Y-u.Y)-(w.X-u.X)*(v.Y-u.Y);if(Math.Abs(det)<1e-8)continue;a=((v.D-u.D)*(w.Y-u.Y)-(w.D-u.D)*(v.Y-u.Y))/det;b=((v.X-u.X)*(w.D-u.D)-(w.X-u.X)*(v.D-u.D))/det;c=u.D-a*u.X-b*u.Y;valid=true;break;}if(!valid)continue;
                bool inside=Inside(outer,targetX,targetY);foreach(var hole in face.Holes)if(Inside(Array.ConvertAll(hole,project),targetX,targetY))inside=false;
                double px=targetX,py=targetY,distance=inside?0:Double.PositiveInfinity;
                if(!inside){var loops=new System.Collections.Generic.List<P[]>{outer};foreach(var hole in face.Holes)loops.Add(Array.ConvertAll(hole,project));foreach(var loop in loops)for(int i=0;i<loop.Length;i++){var u=loop[i];var v=loop[(i+1)%loop.Length];double dx=v.X-u.X,dy=v.Y-u.Y,length=dx*dx+dy*dy;double t=length<1e-12?0:Math.Max(0,Math.Min(1,((targetX-u.X)*dx+(targetY-u.Y)*dy)/length));double x=u.X+t*dx,y=u.Y+t*dy;if(x<0||x>width||y<0||y>height)continue;double ds=(x-targetX)*(x-targetX)+(y-targetY)*(y-targetY);if(ds<distance){distance=ds;px=x;py=y;}}}
                double depth=a*px+b*py+c;if(distance<bestDistance-1e-6||(Math.Abs(distance-bestDistance)<1e-6&&depth>bestDepth)){bestDistance=distance;bestDepth=depth;bestX=px;bestY=py;}
            }
            if(Double.IsInfinity(bestDepth))bestDepth=0;
            double h=(bestX-originX)/Math.Max(1e-9,scale),vcoord=(bestY-originY)/Math.Max(1e-9,scale),dcoord=bestDepth;
            return new BeltPoint3D(center.X+sy*h+cy*sp*vcoord+cy*cp*dcoord,center.Y-cp*vcoord+sp*dcoord,center.Z+cy*h-sy*sp*vcoord-sy*cp*dcoord);
        }
    }
}
