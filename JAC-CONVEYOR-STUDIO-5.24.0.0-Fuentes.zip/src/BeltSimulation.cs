using System;
namespace PerfilBandas {
 internal sealed class BeltSimulationSettings {
  public double Rpm=30;public bool Pattern=true,Reverse;
 }
 internal sealed class BeltSimulationClock {
  internal double TravelMm,ElapsedSeconds;internal int Teeth=16;
  internal BeltSimulationSettings Settings=new BeltSimulationSettings();
  internal double SpeedMmPerSecond {get{return Settings.Rpm*Teeth*BeltMotionPattern.PitchMm/60*(Settings.Reverse?-1:1);}}
  internal void Advance(double seconds){if(seconds<0||Double.IsNaN(seconds)||Double.IsInfinity(seconds))throw new ArgumentOutOfRangeException("seconds");TravelMm+=seconds*SpeedMmPerSecond;ElapsedSeconds+=seconds;}
  internal void Reset(){TravelMm=0;ElapsedSeconds=0;}
 }
 internal sealed partial class Belt3DPreview {
  internal bool BeltPatternEnabled,BeltAnimating;internal double BeltTravelMm,BeltLoopMm;
  internal void SetBeltMotion(bool pattern,double travel,double loop,bool moving){
   if(BeltPatternEnabled==pattern&&BeltTravelMm==travel&&BeltLoopMm==loop&&BeltAnimating==moving)return;
   BeltPatternEnabled=pattern;BeltTravelMm=travel;BeltLoopMm=loop;BeltAnimating=moving;
   // Keep the mesh and GPU lists. CPU requests snapshot the phase, and an in-flight
   // frame is allowed to complete before another request takes the latest phase.
   revision++;pending=true;if(hardware==null)frameTimer.Start();Invalidate();
  }
 }
}
