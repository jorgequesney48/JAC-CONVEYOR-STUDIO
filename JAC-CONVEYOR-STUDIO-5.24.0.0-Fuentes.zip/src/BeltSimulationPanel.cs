using System;using System.Diagnostics;using System.Drawing;using System.Linq;using System.Windows.Forms;
namespace PerfilBandas {
 internal sealed partial class Belt3DWindow {
  readonly BeltSimulationClock motion=new BeltSimulationClock();
  readonly Timer simulationTimer=new Timer{Interval=33};readonly Stopwatch simulationWatch=new Stopwatch();
  readonly NumericUpDown rpm=new NumericUpDown{Name="SimulationRpm",Minimum=0,Maximum=300,DecimalPlaces=1,Increment=1,Value=30};
  readonly CheckBox gridPattern=new CheckBox{Name="SimulationPattern",Text="Patrón E925 Flush Grid",Checked=true,AutoSize=true};
  readonly ComboBox motionDirection=new ComboBox{Name="SimulationDirection",DropDownStyle=ComboBoxStyle.DropDownList};
  readonly Label simulationStats=new Label{Name="SimulationStats",AutoSize=true},simulationStatus=new Label{Name="SimulationStatus",AutoSize=true};
  Button simulationStart;bool simulationRunning,bindingSimulation;double lastTick;
  internal event Action SimulationSettingsChanged;
  internal void BindSimulation(BeltSimulationSettings settings){
   PauseSimulation();motion.Settings=settings??new BeltSimulationSettings();bindingSimulation=true;
   try{rpm.Value=(decimal)motion.Settings.Rpm;gridPattern.Checked=motion.Settings.Pattern;motionDirection.SelectedIndex=motion.Settings.Reverse?1:0;}finally{bindingSimulation=false;}
   RefreshSimulation();
  }
  Control CreateSimulationPanel(){
   var panel=new Panel{Dock=DockStyle.Fill,AutoScroll=true,Padding=new Padding(12),BackColor=DesignUi.Canvas};
   var flow=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,FlowDirection=FlowDirection.TopDown,WrapContents=false,Padding=new Padding(0,5,0,8)};
   Action<Control> add=c=>{c.Margin=new Padding(0,0,0,12);c.Width=248;flow.Controls.Add(c);};
   add(new Label{Text="Movimiento de la banda",Height=28,Font=DesignUi.NavigationBold,ForeColor=DesignUi.Ink});
   add(new Label{Text="RPM del eje motriz",Height=22});rpm.Font=DesignUi.NavigationBold;rpm.AccessibleName="Revoluciones por minuto del eje motriz";add(rpm);
   rpm.ValueChanged+=delegate{if(bindingSimulation)return;AdvanceSimulation();motion.Settings.Rpm=(double)rpm.Value;SimulationSettingEdited();};
   add(new Label{Text="Sentido del movimiento",Height=22});motionDirection.Items.AddRange(new[]{"Carga hacia el motriz","Sentido inverso"});motionDirection.SelectedIndex=0;add(motionDirection);
   motionDirection.SelectedIndexChanged+=delegate{if(bindingSimulation)return;AdvanceSimulation();motion.Settings.Reverse=motionDirection.SelectedIndex==1;SimulationSettingEdited();};
   add(gridPattern);gridPattern.CheckedChanged+=delegate{if(bindingSimulation)return;motion.Settings.Pattern=gridPattern.Checked;SimulationSettingEdited();};
   simulationStart=Button("Iniciar simulación",ToggleSimulation);simulationStart.Name="SimulationStartPause";simulationStart.BackColor=DesignUi.Primary;simulationStart.ForeColor=Color.White;add(simulationStart);
   var reset=Button("Volver al inicio",delegate{PauseSimulation();motion.Reset();RefreshSimulation();});reset.Name="SimulationReset";add(reset);
   simulationStatus.ForeColor=DesignUi.Primary;simulationStatus.MaximumSize=new Size(248,0);add(simulationStatus);
   simulationStats.ForeColor=DesignUi.Ink;simulationStats.MaximumSize=new Size(248,0);add(simulationStats);
   add(new Label{Text="La marca naranja permite seguir un punto de la banda en toda la vuelta.",AutoSize=true,MaximumSize=new Size(248,0),ForeColor=DesignUi.Muted});
   add(new Label{Text="Patrón inspirado en el manual E925, paso de 25 mm. Simulación cinemática sin deslizamiento.",AutoSize=true,MaximumSize=new Size(248,0),ForeColor=DesignUi.Muted});
   bool fitting=false;Action fit=delegate{if(fitting)return;fitting=true;try{int width=Math.Max(160,panel.ClientSize.Width-panel.Padding.Horizontal-SystemInformation.VerticalScrollBarWidth-6);foreach(Control control in flow.Controls){control.Width=width;var label=control as Label;if(label!=null&&label.AutoSize)label.MaximumSize=new Size(width,0);}}finally{fitting=false;}};
   panel.SizeChanged+=delegate{fit();};panel.ParentChanged+=delegate{fit();};fit();
   panel.Controls.Add(flow);simulationTimer.Tick+=delegate{if(!Visible){PauseSimulation();return;}AdvanceSimulation();RefreshSimulation();};
   VisibleChanged+=delegate{if(!Visible)PauseSimulation();};FormClosing+=delegate{PauseSimulation();};Disposed+=delegate{simulationTimer.Dispose();};return panel;
  }
  void SimulationSettingEdited(){RefreshSimulation();if(SimulationSettingsChanged!=null)SimulationSettingsChanged();}
  bool MotionSupported {get{return mesh!=null&&mesh.Trajectory!=null&&BeltWidthRules.IsE925(mesh.Trajectory.BeltModelName);}}
  void ToggleSimulation(){
   if(simulationRunning){PauseSimulation();return;}if(!MotionSupported)return;
   if(!mesh.Faces.Any(f=>f.IsTransportBelt)&&TrajectoryToggleRequested!=null)TrajectoryToggleRequested();
   if(!mesh.Faces.Any(f=>f.IsTransportBelt)){simulationStatus.Text="Muestra la trayectoria para iniciar.";return;}
   if(!String.IsNullOrEmpty(Preview.Error)){simulationStatus.Text="Corrige las incidencias del modelo para simular.";return;}
   simulationWatch.Restart();lastTick=0;simulationRunning=true;simulationTimer.Start();RefreshSimulation();
  }
  void AdvanceSimulation(){if(!simulationRunning)return;double now=simulationWatch.Elapsed.TotalSeconds;motion.Advance(Math.Max(0,now-lastTick));lastTick=now;}
  void PauseSimulation(){AdvanceSimulation();simulationRunning=false;simulationTimer.Stop();simulationWatch.Stop();RefreshSimulation();}
  void SimulationModelChanged(bool changed){
   if(changed){PauseSimulation();motion.Reset();}
   if(mesh!=null&&mesh.Trajectory!=null)motion.Teeth=mesh.Trajectory.DriveTeeth;
   if(!MotionSupported||!mesh.Faces.Any(f=>f.IsTransportBelt)||!String.IsNullOrEmpty(Preview.Error)){simulationRunning=false;simulationTimer.Stop();simulationWatch.Stop();}
   RefreshSimulation();
  }
  void RefreshSimulation(){
   if(simulationStart==null)return;bool supported=MotionSupported;double loop=supported?mesh.Trajectory.LoopLengthMm:0;
   simulationStart.Enabled=supported;simulationStart.Text=simulationRunning?"Pausar simulación":"Iniciar simulación";
   simulationStatus.Text=!supported?"Simulación disponible para banda E925.":!String.IsNullOrEmpty(Preview.Error)?"Corrige las incidencias del modelo.":!mesh.Faces.Any(f=>f.IsTransportBelt)?"Trayectoria oculta · Iniciar la muestra.":simulationRunning?(rpm.Value==0?"En marcha · eje detenido a 0 RPM":"En marcha · tiempo real"):(motion.ElapsedSeconds>0?"Simulación pausada":"Lista para iniciar");
   simulationStats.Text="Sprocket motriz: Z"+motion.Teeth+" · paso 25 mm\nVelocidad: "+(Math.Abs(motion.SpeedMmPerSecond)*.06).ToString("0.00")+" m/min\nRecorrido por vuelta: "+(motion.Teeth*25/1000d).ToString("0.000")+" m\nCircuito: "+(loop/1000).ToString("0.00")+" m\nAvance: "+(motion.TravelMm/1000).ToString("0.00")+" m · "+motion.ElapsedSeconds.ToString("0.0")+" s\nVuelta de banda: "+(Math.Abs(motion.SpeedMmPerSecond)>0? (loop/Math.Abs(motion.SpeedMmPerSecond)).ToString("0.0")+" s":"eje detenido");
   Preview.SetBeltMotion(supported&&motion.Settings.Pattern,motion.TravelMm,loop,simulationRunning);
  }
 }
}
