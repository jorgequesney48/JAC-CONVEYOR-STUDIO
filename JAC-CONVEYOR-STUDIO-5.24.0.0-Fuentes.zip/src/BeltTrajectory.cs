using System;using System.Collections.Generic;using System.Drawing;
using System.Linq;
namespace PerfilBandas {
internal sealed class BeltTrajectoryPiece {
 public int Section;public string Name;public CurveFrame Frame;public double X0,Width,Thickness,Level;public bool Curved;public PointF[] Polygon;
 internal double TravelStartMm,TravelLengthMm;internal double[] Distances;internal bool ReverseTravel;
 internal double TravelAt(double local){return TravelStartMm+(ReverseTravel?TravelLengthMm-local:local);}
 public BeltPoint3D Point(double u,double y,double z){return Frame.Point(u,y,z);}
}
internal sealed class BeltTrajectory {
 public readonly List<BeltSagReference> Sags=new List<BeltSagReference>();
 public readonly List<BeltTrajectoryPiece> Pieces=new List<BeltTrajectoryPiece>();
 internal double LoopLengthMm;internal int DriveTeeth;internal string BeltModelName;
 internal void PrepareMotion(){
  var ordered=Pieces.Where(p=>p.Name.StartsWith("Trabajo")).OrderBy(p=>p.Section)
   .Concat(Pieces.Where(p=>p.Name=="Abrazo_motriz"))
   .Concat(Pieces.Where(p=>p.Name.StartsWith("Retorno")).OrderByDescending(p=>p.Section))
   .Concat(Pieces.Where(p=>p.Name=="Abrazo_conducido"));double start=0;
  foreach(var p in ordered){p.ReverseTravel=p.Name.StartsWith("Retorno")||p.Name=="Abrazo_conducido";p.TravelStartMm=start;
   if(p.Curved)p.TravelLengthMm=p.Frame.Length;
   else {int count=p.Polygon.Length/2;p.Distances=new double[count];for(int j=1;j<count;j++){var a=p.Polygon[j-1];var b=p.Polygon[p.Polygon.Length-j];var c=p.Polygon[j];var d=p.Polygon[p.Polygon.Length-1-j];double dz=(c.X+d.X-a.X-b.X)/2,dy=(c.Y+d.Y-a.Y-b.Y)/2;p.Distances[j]=p.Distances[j-1]+Math.Sqrt(dz*dz+dy*dy);}p.TravelLengthMm=p.Distances[count-1];}start+=p.TravelLengthMm;
  }LoopLengthMm=start;
 }
 sealed class Node {public double Z,Y,R;public string Role;public Node(double z,double y,double r){Z=z;Y=y;R=r;}}
 struct Normal {public double Z,Y;public Normal(double z,double y){Z=z;Y=y;}}
 static Normal Tangent(Node a,Node b){double dz=b.Z-a.Z,dy=b.Y-a.Y,d=Math.Sqrt(dz*dz+dy*dy),k=(a.R-b.R)/d;if(d<1e-6||Math.Abs(k)>=1)throw new InvalidOperationException("La trayectoria de banda no puede conectar los rodillos y extremos con estas posiciones.");double h=Math.Sqrt(1-k*k);var p=new Normal(k*dz/d-h*dy/d,k*dy/d+h*dz/d);var q=new Normal(k*dz/d+h*dy/d,k*dy/d-h*dz/d);return p.Y>=q.Y?p:q;}
 sealed class SagLink {public Normal Start,End;public CatenaryCurve Curve;public double Sag;}
 static Normal SlopeNormal(double slope){double length=Math.Sqrt(1+slope*slope);return new Normal(-slope/length,1/length);}
 static SagLink Link(Node a,Node b,ReturnRollerSettings settings){var n=Tangent(a,b);double sag=a.R>0&&b.R>0&&settings!=null?(a.Role!=null&&a.Role.Contains("Segundo motriz")&&b.Role=="Primero motriz"?settings.CatenarySagMm:settings.NormalSagMm):0;var result=new SagLink{Start=n,End=n,Sag=sag};if(sag<=1e-8)return result;
  if(sag>(b.Z-a.Z-Math.Abs(a.R)-Math.Abs(b.R))/4)throw new InvalidOperationException("La caída solicitada de "+sag.ToString("0.##")+" mm es demasiado grande para este espacio libre entre rodillos. Reduce la caída o aumenta su separación.");
  var na=n;var nb=n;bool converged=false;for(int i=0;i<160;i++){double z0=a.Z+a.R*na.Z,y0=a.Y+a.R*na.Y,z1=b.Z+b.R*nb.Z,y1=b.Y+b.R*nb.Y;var c=CatenaryCurve.Solve(z0,y0,z1,y1,sag);var va=SlopeNormal(c.Slope(z0));var vb=SlopeNormal(c.Slope(z1));double error=Math.Abs(va.Z-na.Z)+Math.Abs(va.Y-na.Y)+Math.Abs(vb.Z-nb.Z)+Math.Abs(vb.Y-nb.Y);if(error<1e-9){result.Start=va;result.End=vb;result.Curve=c;converged=true;break;}na=new Normal((na.Z+va.Z)/2,(na.Y+va.Y)/2);nb=new Normal((nb.Z+vb.Z)/2,(nb.Y+vb.Y)/2);}
  if(!converged)throw new InvalidOperationException("No convergió la catenaria tangente a los rodillos. Reduce la caída solicitada.");return result;
 }
 static PointF P(double z,double y){return new PointF((float)z,(float)y);}
 static PointF[] Outline(List<PointF> centers,List<Normal> normals,double thickness){var p=new List<PointF>();for(int i=0;i<centers.Count;i++)p.Add(P(centers[i].X+normals[i].Z*thickness/2,centers[i].Y+normals[i].Y*thickness/2));for(int i=centers.Count-1;i>=0;i--)p.Add(P(centers[i].X-normals[i].Z*thickness/2,centers[i].Y-normals[i].Y*thickness/2));return p.ToArray();}
 static void Add(List<PointF> p,List<Normal> n,PointF point,Normal normal){if(p.Count>0&&Math.Abs(p[p.Count-1].X-point.X)+Math.Abs(p[p.Count-1].Y-point.Y)<1e-5){n[n.Count-1]=normal;return;}p.Add(point);n.Add(normal);}
 static void Arc(List<PointF> p,List<Normal> n,Node node,double start,double sweep,bool inverse){int count=Math.Max(1,(int)Math.Ceiling(Math.Abs(sweep)*180/Math.PI));for(int i=0;i<=count;i++){double a=start+sweep*i/count,c=Math.Cos(a),s=Math.Sin(a);Add(p,n,P(node.Z+Math.Abs(node.R)*c,node.Y+Math.Abs(node.R)*s),new Normal(inverse?-c:c,inverse?-s:s));}}
 void Planar(int section,CurveFrame frame,string name,double x0,double width,double thickness,List<PointF> p,List<Normal> n){Pieces.Add(new BeltTrajectoryPiece{Section=section,Frame=frame,Name=name,X0=x0,Width=width,Thickness=thickness,Polygon=Outline(p,n,thickness)});}
 public static BeltTrajectory Build(IList<BeltSectionSpec> sections,BeltDesignPlan plan,SoporteSettings template,ReturnRollerSettings settings){
  plan.RequireValid();var result=new BeltTrajectory();var frames=CurveRoute.Frames(sections,template);int last=sections.Count-1;var driven=ShaftPlateGeometry.Nominal(sections[0],plan.Profiles[0],plan.Supports[0]);var motor=ShaftPlateGeometry.Nominal(sections[last],plan.Profiles[last],plan.Supports[last]);
  for(int i=0;i<sections.Count;i++){var p=plan.Profiles[i];var s=plan.Supports[i];var f=frames[i];double thickness=p.BeltThicknessMm,width=p.BandWidthMm,x0=(f.Width-width)/2,contact=ShaftPlateGeometry.RunningY(p,s,s.ActualFlange1HeightMm);
   if(sections[i].IsCurved){result.Pieces.Add(new BeltTrajectoryPiece{Section=i,Frame=f,Name="Trabajo_curva",Curved=true,X0=x0,Width=width,Thickness=thickness,Level=contact});result.Pieces.Add(new BeltTrajectoryPiece{Section=i,Frame=f,Name="Retorno_curva",Curved=true,X0=x0,Width=width,Thickness=thickness,Level=CurveReturnTransitionLayout.ContactY(p,s)});}
   else {double start=i==0?driven.AxisZ:0,end=i==last?motor.AxisZ:f.Length;result.Planar(i,f,"Trabajo_recto",x0,width,thickness,new List<PointF>{P(start,contact+thickness/2),P(end,contact+thickness/2)},new List<Normal>{new Normal(0,1),new Normal(0,1)});}
  }
  for(int first=0;first<sections.Count;first++){if(sections[first].IsCurved)continue;int end=first;while(end+1<sections.Count&&!sections[end+1].IsCurved)end++;var f=frames[first];double width=plan.Profiles[first].BandWidthMm,t=plan.Profiles[first].BeltThicknessMm,x0=(f.Width-width)/2,length=0;var nodes=new List<Node>();
   if(first==0)nodes.Add(new Node(driven.AxisZ,driven.AxisY,-(driven.Sprocket.AMm+t/2)));else nodes.Add(new Node(0,CurveReturnTransitionLayout.ContactY(plan.Profiles[first-1],plan.Supports[first-1])+t/2,0));
   for(int i=first;i<=end;i++){if(settings!=null&&settings.Enabled&&plan.Rollers!=null)foreach(var roller in plan.Rollers.Holes)if(roller.SectionIndex==i)nodes.Add(new Node(length+roller.LocalZMm,roller.YMm,settings.RollerDiameterMm/2+t/2){Role=roller.Role});length+=frames[i].Length;}
   if(end==last)nodes.Add(new Node(length-frames[last].Length+motor.AxisZ,motor.AxisY,-(motor.Sprocket.AMm+t/2)));else nodes.Add(new Node(length,CurveReturnTransitionLayout.ContactY(plan.Profiles[end+1],plan.Supports[end+1])+t/2,0));
   nodes.Sort((a,b)=>a.Z.CompareTo(b.Z));
   // A taut return touches the upper envelope of the rollers. Skip supports
   // below a common tangent instead of creating a backwards arc or self-crossing.
   bool removed=true;while(removed){removed=false;for(int j=1;j<nodes.Count-1;j++)if(nodes[j].R>0){var incoming=Link(nodes[j-1],nodes[j],settings).End;var outgoing=Link(nodes[j],nodes[j+1],settings).Start;if(Math.Atan2(outgoing.Y,outgoing.Z)>=Math.Atan2(incoming.Y,incoming.Z)-1e-7){nodes.RemoveAt(j);removed=true;break;}}}
   var links=new List<SagLink>();for(int i=1;i<nodes.Count;i++)links.Add(Link(nodes[i-1],nodes[i],settings));var pts=new List<PointF>();var normals=new List<Normal>();
   for(int i=0;i<links.Count;i++){var a=nodes[i];var b=nodes[i+1];var link=links[i];var n=link.Start;var exit=link.End;if(i>0&&a.R>0){var previous=links[i-1].End;double start=Math.Atan2(previous.Y,previous.Z),sweep=Math.Atan2(n.Y,n.Z)-start;Arc(pts,normals,a,start,sweep,false);}Add(pts,normals,P(a.Z+a.R*n.Z,a.Y+a.R*n.Y),a.R==0?new Normal(0,1):n);
    if(link.Curve!=null){var c=link.Curve;int steps=Math.Max(16,(int)Math.Ceiling((c.Z1-c.Z0)/25));for(int j=1;j<steps;j++){double z=c.Z0+(c.Z1-c.Z0)*j/steps;Add(pts,normals,P(z,c.Y(z)),SlopeNormal(c.Slope(z)));}result.Sags.Add(new BeltSagReference{Section=first,Type=a.Role!=null&&a.Role.Contains("Segundo motriz")&&b.Role=="Primero motriz"?"Motriz":"Normal",StartMm=c.Z0,EndMm=c.Z1,SagMm=c.SagMm,ExtraLengthMm=c.ExtraLengthMm});}
    Add(pts,normals,P(b.Z+b.R*exit.Z,b.Y+b.R*exit.Y),b.R==0?new Normal(0,1):exit); }
   result.Planar(first,f,"Retorno_rectos",x0,width,t,pts,normals);
   if(first==0){pts=new List<PointF>();normals=new List<Normal>();var n=links[0].Start;double angle=Math.Atan2(-n.Y,-n.Z);while(angle<Math.PI/2)angle+=2*Math.PI;Arc(pts,normals,nodes[0],Math.PI/2,angle-Math.PI/2,true);result.Planar(0,f,"Abrazo_conducido",x0,width,t,pts,normals);}
   if(end==last){pts=new List<PointF>();normals=new List<Normal>();var n=links[links.Count-1].End;double angle=Math.Atan2(-n.Y,-n.Z);while(angle>Math.PI/2)angle-=2*Math.PI;Arc(pts,normals,nodes[nodes.Count-1],Math.PI/2,angle-Math.PI/2,true);result.Planar(last,f,"Abrazo_motriz",x0,width,t,pts,normals);}
   first=end;
  }result.DriveTeeth=sections[last].ShaftPlates.Teeth;result.BeltModelName=plan.Profiles[last].BeltModelName;result.PrepareMotion();return result;
 }
}
}
