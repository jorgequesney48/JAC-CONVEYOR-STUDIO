using System;
namespace PerfilBandas {
internal static class BeltWidthRules {
 internal static bool IsE925(string model){return model!=null&&model.StartsWith("E925",StringComparison.OrdinalIgnoreCase);}
 internal static bool IsValidE925(double width){return !Double.IsNaN(width)&&!Double.IsInfinity(width)&&width>=100&&Math.Abs(width/20-Math.Round(width/20))<1e-9;}
 internal static void Validate(string model,double width){if(IsE925(model)&&!IsValidE925(width))throw new InvalidOperationException("E925: el ancho nominal debe ser múltiplo de 20 mm desde 100 mm (100, 120, 140…). El ancho "+width+" mm no es válido; selecciona un ancho disponible.");}
}
}
