using System;
using System.IO;
using System.Collections.Generic;
using SolidWorks.Interop.sldworks;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
    static void WriteCadInterferences(AssemblyDoc assembly,string folder){
        var entries=new List<object>();string status="Comprobado";string error=null;
        InterferenceDetectionMgr manager=null;
        try{manager=assembly.InterferenceDetectionManager;manager.TreatCoincidenceAsInterference=false;manager.TreatSubAssembliesAsComponents=false;manager.IncludeMultibodyPartInterferences=true;manager.MakeInterferingPartsTransparent=false;
            var found=manager.GetInterferences() as object[];
            if(found!=null)foreach(Interference item in found){var names=new List<string>();var components=item.Components as object[];if(components!=null)foreach(Component2 c in components)names.Add(c.Name2);entries.Add(new{Componentes=names,VolumenMm3=item.Volume*1e9,Posible=item.IsPossibleInterference,Estado="Revisar contacto o interferencia"});}
        }catch(Exception e){status="No comprobado";error=e.Message;}finally{if(manager!=null)try{manager.Done();}catch{}}
        File.WriteAllText(Path.Combine(folder,"INTERFERENCIAS_CAD.json"),new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new{Estado=status,Error=error,ContactosCoincidentesExcluidos=true,Incidencias=entries,Nota="No sustituye comprobar acceso de herramientas, retención, carrera de ajuste ni resistencia."}));
    }
}
}
