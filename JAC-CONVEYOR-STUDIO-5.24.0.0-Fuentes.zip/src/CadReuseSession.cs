﻿using System;using System.Collections.Generic;using System.IO;using System.Web.Script.Serialization;
namespace PerfilBandas {
// Only successful artifacts from the current generation are eligible for reuse.
internal sealed class CadReuseSession:IDisposable {
 [ThreadStatic] static CadReuseSession current;
 readonly CadReuseSession previous;readonly Dictionary<string,object> values=new Dictionary<string,object>();
 readonly Dictionary<string,object> records=new Dictionary<string,object>(StringComparer.OrdinalIgnoreCase);int reused;
 internal CadReuseSession(){previous=current;current=this;}
 internal static bool Active {get{return current!=null;}}
 internal static void Record(string kind,string path){if(!File.Exists(path))throw new InvalidOperationException("No se guardó la pieza compartida: "+path);if(current!=null)current.records[path]=new{Tipo=kind,Archivo=path};}
 // Project serialization omits resolved holes/slots; geometry comparison must include them.
 static object GeometryData(object source){
  if(source==null)return null;var type=source.GetType();if(type.IsPrimitive||type.IsEnum||source is string||source is decimal||source is DateTime)return source;
  var sequence=source as System.Collections.IEnumerable;if(sequence!=null){var items=new List<object>();foreach(var item in sequence)items.Add(GeometryData(item));return items;}
  var result=new SortedDictionary<string,object>(StringComparer.Ordinal);foreach(var field in type.GetFields(System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance))result[field.Name]=GeometryData(field.GetValue(source));foreach(var prop in type.GetProperties(System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance))if(prop.CanRead&&prop.GetIndexParameters().Length==0)result[prop.Name]=GeometryData(prop.GetValue(source,null));return result;
 }
 internal static string Key(string kind,object geometry){return kind+"\n"+new JavaScriptSerializer{MaxJsonLength=Int32.MaxValue}.Serialize(GeometryData(geometry));}
 internal static T Value<T>(string kind,object geometry,Func<T> create){var session=current;if(session==null)return create();string key=Key(kind,geometry);object found;if(session.values.TryGetValue(key,out found)){string path=found as string;var profile=found as GeneratedProfile;if(profile!=null)path=profile.Path;if(path==null||File.Exists(path)){session.reused++;return (T)found;}session.values.Remove(key);}T value=create();session.values.Add(key,value);return value;}
 internal static string Part(string kind,object geometry,string target,Action create){return Value(kind,geometry,()=>{create();Record(kind,target);return target;});}
 internal void Write(string folder){File.WriteAllText(Path.Combine(folder,"REUTILIZACION_PIEZAS.json"),new JavaScriptSerializer{MaxJsonLength=Int32.MaxValue}.Serialize(new{Version=1,PiezasUnicas=records.Count,Reutilizaciones=reused,Piezas=records.Values}));}
 public void Dispose(){current=previous;values.Clear();}
 internal static ProfileSettings ProfileGeometry(ProfileSettings source){var p=source.Copy();if(p.ResolvedRollerHoles!=null)foreach(var h in p.ResolvedRollerHoles){h.SectionIndex=0;h.GlobalZMm=h.LocalZMm;h.Role=null;}return p;}
}
internal sealed class GeneratedProfile {internal string Path;internal ProfilePlateDatums Datums;internal ShaftPlateLayout Plate;}
internal static partial class SolidWorksEnsambleGenerator {
 static GeneratedProfile GenerateReusableProfile(SolidWorks.Interop.sldworks.SldWorks sw,BeltSectionSpec section,ProfileSettings p,SoporteSettings support,double supportTop,bool right,string path,string folder){
  return CadReuseSession.Value("Perfil_terminado",new{Perfil=CadReuseSession.ProfileGeometry(p),Soporte=support,AlturaSoporte=supportTop,Derecho=right,Tipo=section.Type,Placa=section.ShaftPlates},()=>{
   var result=new GeneratedProfile{Path=path};SolidWorksProfileGenerator.Create(p,right?"RH":"LH",folder,System.IO.Path.GetFileNameWithoutExtension(path),sw);var doc=(SolidWorks.Interop.sldworks.ModelDoc2)sw.ActiveDoc;
   try{if(ShaftPlateGeometry.Active(section)){var d=SolidWorksShaftPlateGenerator.Measure(doc,p,right);var l=ShaftPlateGeometry.Calculate(section,p,support,supportTop,d.TopY,d.WebTopY-d.WebBottomY);l.WebTopY=d.WebTopY;l.WebBottomY=d.WebBottomY;ShaftPlateGeometry.Validate(section,p,support,l);SolidWorksShaftPlateGenerator.CutLapHoles(sw,doc,p,section,l,d,path);result.Datums=d;result.Plate=l;}SolidWorksReturnRollerGenerator.Cut(sw,doc,p,right,path);CadReuseSession.Record("Perfil_terminado",path);return result;}finally{sw.CloseDoc(doc.GetTitle());}
  });
 }
 static void ReleaseTemporaryCadObjects(){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
 static string ReusableSupport(SolidWorks.Interop.sldworks.SldWorks sw,SoporteSettings s,string path){return CadReuseSession.Part("Soporte_C",s,path,()=>{SolidWorksSoporteGenerator.Create(s,System.IO.Path.GetDirectoryName(path),System.IO.Path.GetFileNameWithoutExtension(path),sw);sw.CloseDoc(System.IO.Path.GetFileName(path));});}
}
}
