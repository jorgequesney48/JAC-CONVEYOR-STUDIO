﻿using System;
namespace PerfilBandas {
internal sealed class CatenaryCurve {
 public double Z0,Z1,Y0,Y1,A,CenterZ,SagMm;public bool Straight;
 static double Asinh(double value){return Math.Sign(value)*Math.Log(Math.Abs(value)+Math.Sqrt(value*value+1));}
 static double SagFor(double a,double span,double rise){double u=Asinh(rise/(2*a*Math.Sinh(span/(2*a)))),v=span/(4*a);return 2*a*Math.Cosh(u)*Math.Sinh(v)*Math.Sinh(v);}
 public static CatenaryCurve Solve(double z0,double y0,double z1,double y1,double sag){double span=z1-z0;if(span<=0||sag<0||Double.IsNaN(sag)||Double.IsInfinity(sag))throw new InvalidOperationException("Catenaria: separación y caída no válidas.");var curve=new CatenaryCurve{Z0=z0,Z1=z1,Y0=y0,Y1=y1,SagMm=sag,Straight=sag<1e-8};if(curve.Straight)return curve;
  double low=span/40,high=Math.Max(span,span*span/(8*sag));while(SagFor(high,span,y1-y0)>sag)high*=2;for(int i=0;i<100;i++){double mid=(low+high)/2;if(SagFor(mid,span,y1-y0)>sag)low=mid;else high=mid;}curve.A=(low+high)/2;curve.CenterZ=(z0+z1)/2-curve.A*Asinh((y1-y0)/(2*curve.A*Math.Sinh(span/(2*curve.A))));return curve;
 }
 public double Y(double z){if(Straight)return Y0+(Y1-Y0)*(z-Z0)/(Z1-Z0);return Y0+2*A*Math.Sinh((z-Z0)/(2*A))*Math.Sinh((z+Z0-2*CenterZ)/(2*A));}
 public double Slope(double z){return Straight?(Y1-Y0)/(Z1-Z0):Math.Sinh((z-CenterZ)/A);}
 public double LengthMm {get{return Straight?Math.Sqrt(Math.Pow(Z1-Z0,2)+Math.Pow(Y1-Y0,2)):2*A*Math.Cosh(((Z0+Z1)/2-CenterZ)/A)*Math.Sinh((Z1-Z0)/(2*A));}}
 public double ExtraLengthMm {get{return LengthMm-Math.Sqrt(Math.Pow(Z1-Z0,2)+Math.Pow(Y1-Y0,2));}}
}
internal sealed class BeltSagReference {public int Section;public string Type;public double StartMm,EndMm,SagMm,ExtraLengthMm;}
}
