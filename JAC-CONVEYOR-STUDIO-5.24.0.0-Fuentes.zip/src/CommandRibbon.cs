using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas {
    internal sealed partial class CompleteBeltView {
        readonly List<ToolStripButton> ribbonGroups=new List<ToolStripButton>();

        ToolStripMenuItem Command(string title,Action action,Keys shortcut=Keys.None){
            var item=new ToolStripMenuItem(title){ShortcutKeys=shortcut};item.Click+=delegate{action();};return item;
        }
        Control CreateCommandRibbon(){
            var host=new Panel{Name="CommandRibbon",Dock=DockStyle.Top,Height=94,BackColor=Color.White,Padding=new Padding(12,0,12,3)};
            var menu=new MenuStrip{Name="ProjectMenu",Dock=DockStyle.Top,AutoSize=false,Height=40,BackColor=Color.White,ForeColor=DesignUi.Ink,Font=DesignUi.NavigationRegular,Renderer=new StudioMenuRenderer()};
            var brand=new ToolStripLabel("JAC  Conveyor Studio"){Font=DesignUi.NavigationBold,ForeColor=DesignUi.Primary,Margin=new Padding(8,0,24,0)};menu.Items.Add(brand);
            var file=new ToolStripMenuItem("Archivo");file.DropDownItems.Add(Command("Abrir proyecto…",LoadProject,Keys.Control|Keys.O));file.DropDownItems.Add(Command("Guardar proyecto…",SaveProject,Keys.Control|Keys.S));file.DropDownItems.Add(new ToolStripSeparator());file.DropDownItems.Add(Command("Opciones de generación",delegate{OpenDetails(11);}));menu.Items.Add(file);var partsMenu=new ToolStripMenuItem("Piezas");partsMenu.DropDownItems.Add(Command("Listado del ensamble / generar pieza…",ShowAssemblyParts));menu.Items.Add(partsMenu);
            var section=new ToolStripMenuItem("Tramos");section.DropDownItems.Add(Command("Agregar tramo intermedio",delegate{AddIntermediate();}));section.DropDownItems.Add(Command("Duplicar tramo seleccionado",delegate{AddIntermediate(true);}));section.DropDownItems.Add(Command("Agregar tramo curvo",AddCurve));var delete=Command("Eliminar tramo seleccionado",RemoveIntermediate);section.DropDownItems.Add(delete);section.DropDownOpening+=delegate{delete.Enabled=selected>0&&selected<sections.Count-1&&!generating;};menu.Items.Add(section);
            var edit=new ToolStripMenuItem("Editar");edit.DropDownItems.Add(Command("Deshacer diseño",()=>UndoDesign(),Keys.Control|Keys.Z));edit.DropDownItems.Add(Command("Rehacer diseño",()=>UndoDesign(true),Keys.Control|Keys.Y));edit.DropDownItems.Add(Command("Buscar parámetros…",SearchParameters,Keys.Control|Keys.F));edit.DropDownItems.Add(Command("Revisar incidencias",ShowIssues));menu.Items.Add(edit);
            var view=new ToolStripMenuItem("Vista");foreach(string name in new[]{"Isométrica","Lateral","Superior","Frontal"}){string direction=name;view.DropDownItems.Add(Command(name,delegate{WorldPreview.SetView(direction);}));}view.DropDownItems.Add(new ToolStripSeparator());view.DropDownItems.Add(Command("Ajustar modelo",delegate{WorldPreview.Fit();}));view.DropDownItems.Add(Command("Ver tramo seleccionado",delegate{WorldPreview.FocusOn(selected);}));view.DropDownItems.Add(Command("Ver banda completa",delegate{WorldPreview.FocusOn(-1);}));view.DropDownItems.Add(Command("Ampliar visor 3D",Open3D));view.DropDownItems.Add(Command("Medir entre caras",delegate{WorldPreview.SetMeasuring(!WorldPreview.Measuring);}));view.DropDownItems.Add(Command("Vistas acotadas",ShowDimensionViews));view.DropDownItems.Add(Command("Diagnóstico de rendimiento",ShowPerformance));view.DropDownItems.Add(Command("Alternar GPU / CPU",delegate{ChangeRenderer(!WorldPreview.PreferHardware);}));view.DropDownItems.Add(Command("Mostrar / ocultar parámetros",delegate{SetInspectorVisible(!InspectorVisible);}));menu.Items.Add(view);
            var strip=new ToolStrip{Name="ParameterRibbon",Dock=DockStyle.Fill,GripStyle=ToolStripGripStyle.Hidden,AutoSize=false,Height=56,BackColor=Color.White,Renderer=new StudioMenuRenderer(),Padding=new Padding(6,5,6,5),Font=DesignUi.NavigationRegular};
            for(int i=0;i<componentNames.Length;i++){int component=i;var button=new ToolStripButton(componentNames[i]){Name="Subsystem_"+i,Tag=componentCategories[i],Margin=new Padding(3,0,3,0),Padding=new Padding(5,3,5,3),AutoSize=true,ToolTipText="Abrir ajustes de "+componentNames[i]};button.Click+=delegate{OpenDetails(rememberedCategories[component]);};ribbonGroups.Add(button);strip.Items.Add(button);}
            strip.Items.Add(new ToolStripButton("Buscar…",null,(sender,args)=>SearchParameters()){Alignment=ToolStripItemAlignment.Right,ToolTipText="Buscar parámetros · Ctrl+F"});
            var accent=new Panel{Dock=DockStyle.Bottom,Height=3,BackColor=DesignUi.Petronas};host.Controls.Add(strip);host.Controls.Add(menu);host.Controls.Add(accent);return host;
        }
        void RefreshRibbonSelection(){foreach(var group in ribbonGroups){bool selectedGroup=Array.IndexOf((int[])group.Tag,category)>=0;group.Checked=selectedGroup;group.BackColor=selectedGroup?DesignUi.Selection:Color.White;group.ForeColor=selectedGroup?DesignUi.Primary:DesignUi.Ink;group.Font=selectedGroup?DesignUi.NavigationBold:DesignUi.NavigationRegular;}}
    }
    internal sealed class StudioMenuRenderer:ToolStripProfessionalRenderer {
        public StudioMenuRenderer():base(new StudioMenuColors()){RoundedEdges=false;}
        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e){
            var button=e.Item as ToolStripButton;if(button==null||(!button.Checked&&!button.Selected))return;
            var rectangle=new Rectangle(1,2,button.Width-3,button.Height-4);
            using(var path=new System.Drawing.Drawing2D.GraphicsPath())using(var brush=new SolidBrush(DesignUi.Selection)){
                int d=16;path.AddArc(rectangle.Left,rectangle.Top,d,d,180,90);path.AddArc(rectangle.Right-d,rectangle.Top,d,d,270,90);path.AddArc(rectangle.Right-d,rectangle.Bottom-d,d,d,0,90);path.AddArc(rectangle.Left,rectangle.Bottom-d,d,d,90,90);path.CloseFigure();
                var smoothing=e.Graphics.SmoothingMode;e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;e.Graphics.FillPath(brush,path);e.Graphics.SmoothingMode=smoothing;
            }
        }
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e){if(e.ToolStrip is ToolStripDropDown)base.OnRenderToolStripBorder(e);}
    }
    internal sealed class StudioMenuColors:ProfessionalColorTable {
        public override Color ButtonSelectedHighlight{get{return DesignUi.Selection;}}
        public override Color ButtonSelectedGradientBegin{get{return DesignUi.Selection;}}
        public override Color ButtonSelectedGradientMiddle{get{return DesignUi.Selection;}}
        public override Color ButtonSelectedGradientEnd{get{return DesignUi.Selection;}}
        public override Color ButtonCheckedGradientBegin{get{return DesignUi.Selection;}}
        public override Color ButtonCheckedGradientMiddle{get{return DesignUi.Selection;}}
        public override Color ButtonCheckedGradientEnd{get{return DesignUi.Selection;}}
        public override Color ButtonSelectedBorder{get{return DesignUi.Petronas;}}
        public override Color MenuItemSelected{get{return DesignUi.Selection;}}
        public override Color MenuItemBorder{get{return DesignUi.Border;}}
        public override Color MenuItemSelectedGradientBegin{get{return DesignUi.Selection;}}
        public override Color MenuItemSelectedGradientEnd{get{return DesignUi.Selection;}}
        public override Color ImageMarginGradientBegin{get{return Color.White;}}
        public override Color ImageMarginGradientMiddle{get{return Color.White;}}
        public override Color ImageMarginGradientEnd{get{return Color.White;}}
    }
}



