﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal static partial class SolidWorksEnsambleGenerator
    {
        private static void FixPlacedComponent(ModelDoc2 model, AssemblyDoc assembly, Component2 component,
            MathUtility mathUtil, double[] transform, string name)
        {
            if (component == null) throw new InvalidOperationException("No se pudo insertar " + name + ".");
            model.ClearSelection2(true);
            if (!component.Select4(false, null, false))
                throw new InvalidOperationException("No se pudo seleccionar " + name + ".");
            assembly.UnfixComponent();
            model.ClearSelection2(true);
            PlaceComponent(component, mathUtil, transform, name);
            if (!component.Select4(false, null, false))
                throw new InvalidOperationException("No se pudo fijar " + name + ".");
            assembly.FixComponent();
            model.ClearSelection2(true);
        }

        private static double[] Translation(double x, double y, double z)
        {
            return new double[] { 1, 0, 0, 0, 1, 0, 0, 0, 1, x, y, z, 1, 0, 0, 0 };
        }

        private static string GenerateCompleteBeltCore(IList<BeltSectionSpec> sections, ProfileSettings profile,
            SoporteSettings support, string customFolder, Action<string> progress = null, ReturnRollerSettings rollers = null, bool shaded3D = true, BearingCatalog bearings = null, string filePrefix = "",VerticalSupportSettings verticalSupports=null,bool exportFlatPatterns=true)
        {
            var designPlan=BeltDesignPlan.Build(sections,profile,support,rollers,verticalSupports,bearings);designPlan.RequireValid();
            BeltLinePlan.Validate(sections, profile, rollers!=null && rollers.Enabled && rollers.OpenSeats);
            if (support == null) throw new ArgumentNullException("support");
            BeltLinePlan.ValidateSupports(sections, profile, support, rollers!=null && rollers.Enabled && rollers.OpenSeats);
            VerticalSupportLayout.Validate(sections,profile);
            var legSettings=verticalSupports??new VerticalSupportSettings();legSettings.Validate();
            var rollerPlan=ReturnRollerLayout.Build(sections,profile,support,rollers);

            if(filePrefix==null||filePrefix.IndexOfAny(Path.GetInvalidFileNameChars())>=0)throw new ArgumentException("Prefijo de archivos no válido.");
            var bearingCatalog=bearings ?? BearingCatalog.Default();
            var bearingSources=new Dictionary<string,string>();
            var sprocketCatalog=SprocketCatalog.Default();var sprocketSources=new Dictionary<string,string>();
            foreach(var section in sections)if(ConveyorShaftGeometry.Active(section)&&section.ShaftPlates.Shaft.Sprocket!=null){var entry=section.ShaftPlates.Shaft.Sprocket;entry.Validate();string source=sprocketCatalog.ModelPath(entry);if(!File.Exists(source))throw new FileNotFoundException("Falta el modelo del sprocket "+entry.Label,source);sprocketSources[entry.Id]=source;}
            foreach(var section in sections)if(ShaftPlateGeometry.Active(section) && section.ShaftPlates.Bearing!=null){
                var entry=section.ShaftPlates.Bearing;entry.Validate();string source=bearingCatalog.ModelPath(entry);
                if(!File.Exists(source))throw new FileNotFoundException("Falta el modelo de la chumacera "+entry.Label+". Regístrala otra vez en el catálogo.",source);
                bearingSources[entry.Id]=source;
            }
            string stage = "conectar con SOLIDWORKS";
            try
            {
                Type swType = Type.GetTypeFromProgID("SldWorks.Application");
                if (swType == null) throw new InvalidOperationException("SOLIDWORKS no está instalado o no registró su interfaz COM.");
                SldWorks sw;
                try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
                catch { sw = (SldWorks)Activator.CreateInstance(swType); }
                if (sw == null) throw new InvalidOperationException("No se pudo conectar con SOLIDWORKS.");
                sw.Visible = true;

                string folder = string.IsNullOrWhiteSpace(customFolder) ? ProjectPaths.GetDefaultPiecesFolder() : customFolder;
                Directory.CreateDirectory(folder);
                string outputPath = Path.Combine(folder, filePrefix+"BANDA_COMPLETA.SLDASM");
                bool curvedRoute=CurveRoute.HasCurves(sections);var curveFrames=curvedRoute?CurveRoute.Frames(sections,support,profile):null;var curveParts=new CurveCadParts[sections.Count];
                string[] verticalPaths=new string[sections.Count],crossbarPaths=new string[sections.Count];double[] legMountYs=new double[sections.Count],crossbarLengths=new double[sections.Count];
                string[] supportPaths = new string[sections.Count];
                string[,] returnPaths=new string[sections.Count,2];
                string[,] railPaths = new string[sections.Count, 3];
                SoporteSettings[] supports = new SoporteSettings[sections.Count];
                string[] leftPaths = new string[sections.Count];
                string[] rightPaths = new string[sections.Count];
                ProfileSettings[] partSettings = new ProfileSettings[sections.Count];
                ShaftPlateLayout[] plateLayouts = new ShaftPlateLayout[sections.Count];
                ShaftPlateLayout[] rightPlateLayouts = new ShaftPlateLayout[sections.Count];
                ProfilePlateDatums[,] plateDatums = new ProfilePlateDatums[sections.Count, 2];
                string[] shaftPaths=new string[sections.Count];
                ConveyorShaftLayout[] shaftLayouts=new ConveyorShaftLayout[sections.Count];
                string[,] platePaths = new string[sections.Count, 2];

                // Proposed filenames identify the first occurrence; identical geometry
                // resolves to its canonical file within this generation.
                for (int i = 0; i < sections.Count; i++)
                {
                    string stem = filePrefix+"TRAMO_" + (i + 1).ToString("00") + "_" + sections[i].Type.ToString().ToUpperInvariant();
                    verticalPaths[i]=Path.Combine(folder,stem+"_PATA.SLDASM");crossbarPaths[i]=Path.Combine(folder,stem+"_PTR_UNION_H.SLDPRT");
                    leftPaths[i] = Path.Combine(folder, stem + "_LH.SLDPRT");
                    rightPaths[i] = Path.Combine(folder, stem + "_RH.SLDPRT");
                    partSettings[i] = designPlan.Profiles[i].Copy();
                    supports[i] = designPlan.Supports[i].Copy();
                    supportPaths[i] = Path.Combine(folder, stem + "_SOPORTE_C.SLDPRT");
                    returnPaths[i,0]=Path.Combine(folder,stem+"_RODILLO_RETORNO.SLDPRT");returnPaths[i,1]=Path.Combine(folder,stem+"_EJE_RETORNO.SLDPRT");
                    railPaths[i, 0] = Path.Combine(folder, stem + "_PLETINA_LH.SLDPRT");
                    railPaths[i, 1] = Path.Combine(folder, stem + "_PLETINA_CENTRAL.SLDPRT");
                    railPaths[i, 2] = Path.Combine(folder, stem + "_PLETINA_RH.SLDPRT");
                    shaftPaths[i]=Path.Combine(folder,stem+"_FLECHA.SLDPRT");
                    platePaths[i, 0] = Path.Combine(folder, stem + "_PLACA_FLECHA_LH.SLDPRT");
                    platePaths[i, 1] = Path.Combine(folder, stem + "_PLACA_FLECHA_RH.SLDPRT");
                }
                var bearingPaths=new Dictionary<string,string>();
                foreach(var entry in bearingSources)bearingPaths[entry.Key]=Path.Combine(folder,"CHUMACERAS",filePrefix+"CHUMACERA_"+entry.Key+".SLDPRT");
                var targets=new List<string>{outputPath};
                var sprocketPaths=new Dictionary<string,string>();foreach(var entry in sprocketSources){var path=Path.Combine(folder,"SPROCKETS",filePrefix+"SPROCKET_"+entry.Key+".SLDPRT");sprocketPaths[entry.Key]=path;targets.Add(path);}
                foreach(var bearingPath in bearingPaths.Values)targets.Add(bearingPath);
                for(int i=0;i<sections.Count;i++){
                    if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers&&rollerPlan.Holes.Count>0){targets.Add(returnPaths[i,0]);targets.Add(returnPaths[i,1]);}
                    targets.AddRange(VerticalPaths(folder,Path.GetFileNameWithoutExtension(verticalPaths[i])));if(legSettings.CrossbarEnabled)targets.Add(crossbarPaths[i]);
                    if(ConveyorShaftGeometry.Active(sections[i]))targets.Add(shaftPaths[i]);
                    targets.Add(leftPaths[i]);targets.Add(rightPaths[i]);targets.Add(supportPaths[i]);
                    for(int r=0;r<3;r++)targets.Add(railPaths[i,r]);
                    for(int r=0;r<2;r++)targets.Add(platePaths[i,r]);
                }
                SolidWorksDocumentSafety.Check(sw,targets);
                sw.CloseDoc(Path.GetFileName(outputPath));
                foreach(var entry in sprocketPaths){sw.CloseDoc(Path.GetFileName(entry.Value));Directory.CreateDirectory(Path.GetDirectoryName(entry.Value));File.Copy(sprocketSources[entry.Key],entry.Value,true);}
                foreach(var entry in bearingPaths){sw.CloseDoc(Path.GetFileName(entry.Value));Directory.CreateDirectory(Path.GetDirectoryName(entry.Value));File.Copy(bearingSources[entry.Key],entry.Value,true);}
                for (int i = 0; i < sections.Count; i++)
                {
                    sw.CloseDoc(Path.GetFileName(leftPaths[i]));
                    sw.CloseDoc(Path.GetFileName(rightPaths[i]));
                    sw.CloseDoc(Path.GetFileName(supportPaths[i]));
                    for (int r = 0; r < 3; r++) sw.CloseDoc(Path.GetFileName(railPaths[i, r]));
                    if (ShaftPlateGeometry.Active(sections[i])) for (int r=0;r<2;r++) sw.CloseDoc(Path.GetFileName(platePaths[i,r]));
                }

                for (int i = 0; i < sections.Count; i++)
                {
                    if(sections[i].IsCurved){stage="generar curva soldada del tramo "+(i+1);if(progress!=null)progress(stage);curveParts[i]=CreateCurveParts(sw,sections[i],partSettings[i],supports[i],curveFrames[i],folder,filePrefix+"CURVA_TRAMO_"+(i+1).ToString("00"),CurveReturnTransitionLayout.Resolve(sections,i,partSettings[i],supports[i],rollerPlan,rollers));ReleaseTemporaryCadObjects();continue;}
                    stage = "generar soporte C del tramo " + (i + 1);
                    if (progress != null) progress(stage);
                    if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers&&rollerPlan.Holes.Count>0){
                        returnPaths[i,0]=CreateReturnCylinder(sw,returnPaths[i,0],rollers.RollerDiameterMm,rollers.ShaftDiameterMm,supports[i].LengthMm-2*rollers.SideClearanceMm,"Rodillo_Retorno_Simplificado");
                        if(rollers.KeyholeSeats)returnPaths[i,1]=CreateReturnAxle(sw,returnPaths[i,1],rollers,partSettings[i],supports[i]);else returnPaths[i,1]=CreateReturnCylinder(sw,returnPaths[i,1],rollers.ShaftDiameterMm,0,supports[i].LengthMm+2*(rollers.ShaftProjectionMm+partSettings[i].ThicknessMm),"Eje_Retorno_Sin_Retencion");
                    }
                    supportPaths[i]=ReusableSupport(sw,supports[i],supportPaths[i]);
                    double measuredSupportTop = supports[i].ActualFlange1HeightMm;
                    if (sections[i].IncludeSlideRails || ShaftPlateGeometry.Active(sections[i])) {
                        int supportError=0,supportWarning=0;var supportDoc=sw.OpenDoc6(supportPaths[i],1,1,"",ref supportError,ref supportWarning);if(supportDoc==null)throw new InvalidOperationException("No se pudo medir el soporte compartido.");
                        measuredSupportTop = Double.NegativeInfinity;
                        foreach (object body in (object[])((PartDoc)supportDoc).GetBodies2((int)swBodyType_e.swSolidBody,true))
                            measuredSupportTop = Math.Max(measuredSupportTop, ((double[])((Body2)body).GetBodyBox())[4]*1000);
                    }
                    sw.CloseDoc(Path.GetFileName(supportPaths[i]));
                    stage = "generar perfiles del tramo " + (i + 1);
                    if (progress != null) progress(stage);
                    var lh=GenerateReusableProfile(sw,sections[i],partSettings[i],supports[i],measuredSupportTop,false,leftPaths[i],folder);
                    var rh=GenerateReusableProfile(sw,sections[i],partSettings[i],supports[i],measuredSupportTop,true,rightPaths[i],folder);
                    leftPaths[i]=lh.Path;rightPaths[i]=rh.Path;plateDatums[i,0]=lh.Datums;plateDatums[i,1]=rh.Datums;plateLayouts[i]=lh.Plate;rightPlateLayouts[i]=rh.Plate;
                    if(lh.Plate!=null&&(Math.Abs(rh.Plate.AxisY-lh.Plate.AxisY)>.02||Math.Abs(rh.Plate.AxisZ-lh.Plate.AxisZ)>.02))throw new InvalidOperationException("Las placas LH/RH no comparten un eje transversal.");
                    if (plateLayouts[i] != null) for (int side=0;side<2;side++) {
                        stage="generar placa de flecha del tramo " + (i+1);
                        if (progress != null) progress(stage);
                        platePaths[i,side]=SolidWorksShaftPlateGenerator.Create(sw,sections[i],side==0 ? plateLayouts[i] : rightPlateLayouts[i],side==1,folder,Path.GetFileNameWithoutExtension(platePaths[i,side]));
                        sw.CloseDoc(Path.GetFileName(platePaths[i,side]));
                    }
                    if(ConveyorShaftGeometry.Active(sections[i])){
                        stage="generar flecha del tramo "+(i+1);if(progress!=null)progress(stage);
                        double left=sections[i].ShaftPlates.Mounting==2?plateDatums[i,0].OuterX:plateDatums[i,0].InnerX;
                        double right=supports[i].LengthMm+(sections[i].ShaftPlates.Mounting==2?plateDatums[i,1].OuterX:plateDatums[i,1].InnerX);
                        shaftLayouts[i]=ConveyorShaftGeometry.Calculate(sections[i],partSettings[i],supports[i],plateLayouts[i],left,right);
                        sw.CloseDoc(Path.GetFileName(shaftPaths[i]));shaftPaths[i]=SolidWorksConveyorShaftGenerator.Create(sw,shaftLayouts[i],shaftPaths[i]);sw.CloseDoc(Path.GetFileName(shaftPaths[i]));
                    }
                    if (sections[i].IncludeSlideRails)
                    {
                        double railLength = plateLayouts[i] == null ? sections[i].LengthMm : plateLayouts[i].RailLengthMm;
                        double railStart = plateLayouts[i] == null ? 0 : plateLayouts[i].RailStartZ;
                        var range=SlideRailGeometry.Range(supports[i],i,sections.Count,railStart,railLength);railStart=range[0];railLength=range[1];
                        stage = "generar pletinas de deslizamiento del tramo " + (i + 1);
                        if (progress != null) progress(stage);
                        railPaths[i,0]=SolidWorksSlideRailGenerator.Create(railLength, folder,
                            Path.GetFileNameWithoutExtension(railPaths[i, 0]), SlideRailPosition.Left, sw,
                            SlideRailGeometry.EndPlateReliefs(partSettings[i],supports[i],SlideRailPosition.Left,measuredSupportTop,railStart));
                        sw.CloseDoc(Path.GetFileName(railPaths[i, 0]));
                        if (supports[i].CenterSlotCount > 0)
                        {
                            railPaths[i,1]=SolidWorksSlideRailGenerator.CreateCenter(railLength, folder,
                                Path.GetFileNameWithoutExtension(railPaths[i, 1]), sw);
                            sw.CloseDoc(Path.GetFileName(railPaths[i, 1]));
                        }
                        railPaths[i,2]=SolidWorksSlideRailGenerator.Create(railLength, folder,
                            Path.GetFileNameWithoutExtension(railPaths[i, 2]), SlideRailPosition.Right, sw,
                            SlideRailGeometry.EndPlateReliefs(partSettings[i],supports[i],SlideRailPosition.Right,measuredSupportTop,railStart));
                        sw.CloseDoc(Path.GetFileName(railPaths[i, 2]));
                    }
                    ReleaseTemporaryCadObjects();
                }

                for(int i=0;i<sections.Count;i++){
                    if(sections[i].IsCurved){stage="generar patas de curva "+(i+1);if(progress!=null)progress(stage);GenerateCurveLegs(sw,curveParts[i],partSettings[i],supports[i],curveFrames[i],legSettings,folder,filePrefix+"CURVA_TRAMO_"+(i+1).ToString("00"),i+1<sections.Count?partSettings[i+1]:null,i+1<sections.Count?supports[i+1]:null,i+1<sections.Count?curveFrames[i+1]:null);ReleaseTemporaryCadObjects();continue;}
                    stage="generar pata paramétrica del tramo "+(i+1);if(progress!=null)progress(stage);
                    int e=0,w=0;var lateral=sw.OpenDoc6(leftPaths[i],1,1,"",ref e,ref w);if(lateral==null)throw new InvalidOperationException("No se pudo medir el montaje de la pata.");
                    var legMount=VerticalSupportLayout.MountOrigin(lateral,partSettings[i]);legMountYs[i]=legMount[1]*1000;sw.CloseDoc(lateral.GetTitle());if(legSettings.CrossbarEnabled){var crossbar=LegCrossbarLayout.Build(legSettings,legMount[0]*1000,supports[i].LengthMm-legMount[0]*1000,legMountYs[i],legMountYs[i],0);crossbarLengths[i]=crossbar.LengthMm;crossbarPaths[i]=GenerateLegCrossbar(sw,legSettings,crossbar.LengthMm,crossbarPaths[i]);}
                    verticalPaths[i]=GenerateVerticalSupport(sw,legSettings,legMountYs[i],folder,Path.GetFileNameWithoutExtension(verticalPaths[i]));
                    ReleaseTemporaryCadObjects();
                }
                stage = "modelar trayectoria completa de banda";if(progress!=null)progress(stage);
                string trajectoryPath=GenerateBeltTrajectory(sw,BeltTrajectory.Build(sections,designPlan,support,rollers),Path.Combine(folder,filePrefix+"TRAYECTORIA_BANDA.SLDPRT"));ReleaseTemporaryCadObjects();
                stage = "crear ensamble de banda completa";
                if (progress != null) progress(stage);
                string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplateAssembly);
                if (string.IsNullOrWhiteSpace(template) || !File.Exists(template))
                    throw new InvalidOperationException("No se encontró la plantilla predeterminada de ensamble.");
                AssemblyDoc assembly = (AssemblyDoc)sw.NewDocument(template, 0, 0, 0);
                if (assembly == null) throw new InvalidOperationException("SOLIDWORKS no creó el ensamble.");
                ModelDoc2 model = (ModelDoc2)assembly;
                MathUtility mathUtil = (MathUtility)sw.GetMathUtility();
                double offset = 0;
                int count = 0;
                var trajectoryComponent=InsertComponentHelper(sw,assembly,trajectoryPath,0,0,0);FixPlacedComponent(model,assembly,trajectoryComponent,mathUtil,Translation(0,0,0),"trayectoria completa de banda");count++;

                for (int i = 0; i < sections.Count; i++)
                {
                    if(sections[i].IsCurved){count+=PlaceCurveParts(sw,assembly,model,mathUtil,curveParts[i],partSettings[i],supports[i],curveFrames[i]);count+=PlaceCurveLegs(sw,assembly,model,mathUtil,curveParts[i],partSettings[i],supports[i],curveFrames[i],legSettings);offset+=partSettings[i].LengthMm/1000;continue;}
                    var before=curvedRoute?ComponentNames(assembly):null;
                    double supportLength = supports[i].LengthMm / 1000.0;
                    double thickness = partSettings[i].ThicknessMm / 1000.0;
                    double txRight = supportLength;
                    double hcx = supports[i].WebWidthMm / 2000.0;
                    double hcy = supports[i].EndPlateHoleYMm / 1000.0;
                    double holeY = partSettings[i].SupportHoleYMm / 1000.0;
                    double supportY = -holeY - hcy;
                    double supportTopLocalY = Double.NaN;
                    stage = "colocar tramo " + (i + 1);
                    Component2 left = InsertComponentHelper(sw, assembly, leftPaths[i], 0, 0, offset);
                    FixPlacedComponent(model, assembly, left, mathUtil, Translation(0, 0, offset), "perfil LH del tramo " + (i + 1));
                    Component2 right = InsertComponentHelper(sw, assembly, rightPaths[i], txRight, 0, offset);
                    FixPlacedComponent(model, assembly, right, mathUtil, Translation(txRight, 0, offset), "perfil RH del tramo " + (i + 1));
                    AssertBendsOutward(left, right, thickness);
                    count += 2;
                    if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers&&rollerPlan.Holes.Count>0)foreach(var h in rollerPlan.Holes)if(h.SectionIndex==i){
                        var drum=InsertComponentHelper(sw,assembly,returnPaths[i,0],0,0,offset);
                        FixPlacedComponent(model,assembly,drum,mathUtil,ReturnCylinderTransform(rollers.SideClearanceMm,h.YMm,offset*1000+h.LocalZMm),"rodillo retorno");
                        var axle=InsertComponentHelper(sw,assembly,returnPaths[i,1],0,0,offset);
                        FixPlacedComponent(model,assembly,axle,mathUtil,ReturnCylinderTransform(-rollers.ShaftProjectionMm-partSettings[i].ThicknessMm,h.YMm,offset*1000+h.LocalZMm),"eje retorno");count+=2;
                    }

                    double[] holes = SupportHoleLayout.CentersMm(partSettings[i]);
                    for (int j = 0; j < holes.Length; j++)
                    {
                        double holeZ = holes[j] / 1000.0;
                        Component2 transverse = InsertComponentHelper(sw, assembly, supportPaths[i], 0, 0, offset + holeZ);
                        double[] transform = new double[] {
                            0, 0, -1, 0, 1, 0, 1, 0, 0,
                            0, supportY, offset + holeZ + hcx, 1, 0, 0, 0
                        };
                        FixPlacedComponent(model, assembly, transverse, mathUtil, transform,
                            "soporte " + (j + 1) + " del tramo " + (i + 1));
                        if (j == 0 && sections[i].IncludeSlideRails)
                        {
                            PartDoc supportPart = (PartDoc)transverse.GetModelDoc2();
                            object[] bodies = supportPart == null ? null : (object[])supportPart.GetBodies2((int)swBodyType_e.swSolidBody, true);
                            if (bodies == null || bodies.Length == 0) throw new InvalidOperationException("No se encontró el sólido del soporte para nivelar las pletinas del tramo " + (i + 1));
                            foreach (object item in bodies)
                            {
                                double[] box = (double[])((Body2)item).GetBodyBox();
                                if (box != null) supportTopLocalY = Double.IsNaN(supportTopLocalY) ? box[4] : Math.Max(supportTopLocalY, box[4]);
                            }
                            if (Double.IsNaN(supportTopLocalY)) throw new InvalidOperationException("No se pudo medir la cara superior del soporte.");
                        }
                        AssertHoleAlignment(mathUtil, left, transverse, 0, -holeY, holeZ,
                            hcx, hcy, 0, 0, "LH del tramo " + (i + 1));
                        AssertHoleAlignment(mathUtil, right, transverse, 0, -holeY, holeZ,
                            hcx, hcy, supportLength, 0, "RH del tramo " + (i + 1));
                        count++;
                    }
                    if (sections[i].IncludeSlideRails)
                    {
                        stage = "colocar pletinas del tramo " + (i + 1);
                        double railTop = Double.NaN;
                        foreach (SlideRailPlacement rail in SlideRailGeometry.Placements(supports[i], sections[i].LengthMm))
                        {
                            int pathIndex = rail.Position == SlideRailPosition.Left ? 0 : rail.Position == SlideRailPosition.Center ? 1 : 2;
                            double depth = rail.Position == SlideRailPosition.Center ? supports[i].CenterSlotDepthMm : supports[i].OuterSlotDepthMm;
                            double y = supportY + supportTopLocalY - depth / 1000.0;
                            double runningFace = y + (rail.Position == SlideRailPosition.Center ? 38.10 : 31.75) / 1000.0;
                            if (!Double.IsNaN(railTop) && Math.Abs(railTop - runningFace) > .00002)
                                throw new InvalidOperationException("Las caras de rodadura no están niveladas en el tramo " + (i + 1));
                            railTop = runningFace;
                            if(partSettings[i].AutoSupportHeight && Math.Abs(runningFace*1000+partSettings[i].BeltThicknessMm+CurveUpperGuideGeometry.BandTopBelowProfileMm)>.02)
                                throw new InvalidOperationException("El nylamid no deja el espacio solicitado para el espesor de banda.");
                            var range=SlideRailGeometry.Range(supports[i],i,sections.Count,plateLayouts[i]==null?0:plateLayouts[i].RailStartZ,plateLayouts[i]==null?sections[i].LengthMm:plateLayouts[i].RailLengthMm);
                            double railZ = offset + range[0]/1000;
                            if (plateLayouts[i] != null && Math.Abs(runningFace*1000-plateLayouts[i].RunningY)>.02)
                                throw new InvalidOperationException("El eje y las pletinas no comparten el nivel de rodadura medido.");
                            Component2 guide = InsertComponentHelper(sw, assembly, railPaths[i, pathIndex], rail.FromLeftMm / 1000.0, y, railZ);
                            FixPlacedComponent(model, assembly, guide, mathUtil,
                                Translation(rail.FromLeftMm / 1000.0, y, railZ),
                                "pletina " + rail.Position + " del tramo " + (i + 1));
                            count++;
                        }
                    }
                    if (plateLayouts[i] != null) {
                        for (int side=0;side<2;side++) {
                            var layout=side==0 ? plateLayouts[i] : rightPlateLayouts[i];
                            var d=plateDatums[i,side];
                            double direction=side==0 ? 1 : -1;
                            double faceX=sections[i].ShaftPlates.Mounting==2 ? d.OuterX : d.InnerX;
                            double x=faceX/1000+(side==1 ? txRight : 0);
                            double y=layout.TopY/1000, z=offset+layout.PlateCenterZ/1000;
                            var plate=InsertComponentHelper(sw,assembly,platePaths[i,side],x,y,z);
                            double[] transform={0,0,direction, 0,1,0, -direction,0,0, x,y,z, 1,0,0,0};
                            FixPlacedComponent(model,assembly,plate,mathUtil,transform,"placa de flecha del tramo " + (i+1));
                            double localX=direction*(layout.AxisZ-layout.PlateCenterZ)/1000;
                            double[] center=HoleCenter(mathUtil,plate,localX,(layout.AxisY-layout.TopY)/1000,0);
                            if (Math.Abs(center[1]*1000-layout.AxisY)>.02 || Math.Abs((center[2]-offset)*1000-layout.AxisZ)>.02)
                                throw new InvalidOperationException("El centro de la placa no coincide con el eje calculado.");
                            count++;
                            var bearing=sections[i].ShaftPlates.Bearing;
                            if(bearing!=null){
                                if(progress!=null)progress("colocar chumacera "+(side==0?"LH":"RH")+" del tramo "+(i+1));
                                double outward=side==0?-1:1;
                                double bearingX=x+outward*ShaftPlateLayout.ThicknessMm/1000;
                                var bearingComponent=InsertComponentHelper(sw,assembly,bearingPaths[bearing.Id],bearingX,layout.AxisY/1000,offset+layout.AxisZ/1000);
                                var bearingTransform=BearingMath.Placement(bearing,side==1,bearingX,layout.AxisY/1000,offset+layout.AxisZ/1000);
                                FixPlacedComponent(model,assembly,bearingComponent,mathUtil,bearingTransform,"chumacera "+bearing.Label+" del tramo "+(i+1));
                                var mountCenter=HoleCenter(mathUtil,bearingComponent,bearing.Origin[0],bearing.Origin[1],bearing.Origin[2]);
                                if(Math.Abs(mountCenter[0]-bearingX)>.00002 || Math.Abs(mountCenter[1]-layout.AxisY/1000)>.00002 || Math.Abs(mountCenter[2]-offset-layout.AxisZ/1000)>.00002)
                                    throw new InvalidOperationException("La chumacera no coincide con el eje de la placa.");
                                count++;
                            }
                        }
                    }
                    if(shaftLayouts[i]!=null){
                        var shaft=shaftLayouts[i];if(progress!=null)progress("colocar flecha del tramo "+(i+1));
                        var component=InsertComponentHelper(sw,assembly,shaftPaths[i],shaft.CenterX/1000,shaft.AxisY/1000,offset+shaft.AxisZ/1000);
                        FixPlacedComponent(model,assembly,component,mathUtil,shaft.Transform(offset*1000),"flecha del tramo "+(i+1));
                        var center=HoleCenter(mathUtil,component,0,0,shaft.SquareLengthMm/2000);
                        if(Math.Abs(center[0]*1000-shaft.CenterX)>.02||Math.Abs(center[1]*1000-shaft.AxisY)>.02||Math.Abs((center[2]-offset)*1000-shaft.AxisZ)>.02)throw new InvalidOperationException("La sección cuadrada de la flecha no quedó centrada sobre el eje de la banda.");count++;
                        if(shaft.Settings.Sprocket!=null){var entry=shaft.Settings.Sprocket;foreach(double x in SprocketGeometry.Centers(shaft)){var sprocket=InsertComponentHelper(sw,assembly,sprocketPaths[entry.Id],x/1000,shaft.AxisY/1000,offset+shaft.AxisZ/1000);FixPlacedComponent(model,assembly,sprocket,mathUtil,SprocketGeometry.Placement(entry,x,shaft.AxisY,offset*1000+shaft.AxisZ),"sprocket del tramo "+(i+1));var color=ViewerMaterials.Nylamid(shaft.Settings.SprocketColor??"Amarillo");sprocket.MaterialPropertyValues=new double[]{color.R/255d,color.G/255d,color.B/255d,1,.7,.15,.15,0,0};count++;}}
                    }
                    stage="colocar patas del tramo "+(i+1);
                    for(int side=0;side<2;side++) {
                        Component2 lateral=side==0?left:right;
                        var mount=VerticalSupportLayout.MountOrigin((ModelDoc2)lateral.GetModelDoc2(),partSettings[i]);
                        double cx=mount[0],cy=mount[1];
                        var stations=VerticalSupportLayout.LocalStations(partSettings[i],i,sections.Count);
                        foreach(double station in stations){
                            var target=HoleCenter(mathUtil,lateral,cx,cy,station/1000);
                            var leg=InsertComponentHelper(sw,assembly,verticalPaths[i],target[0],target[1],target[2]);
                            FixPlacedComponent(model,assembly,leg,mathUtil,VerticalSupportLayout.Placement(side==1,target[0],target[1],target[2]),"pata "+(side==0?"LH":"RH")+" del tramo "+(i+1));
                            count++;
                        }
                    }
                    if(legSettings.CrossbarEnabled){var lm=VerticalSupportLayout.MountOrigin((ModelDoc2)left.GetModelDoc2(),partSettings[i]);var rm=VerticalSupportLayout.MountOrigin((ModelDoc2)right.GetModelDoc2(),partSettings[i]);foreach(double station in VerticalSupportLayout.LocalStations(partSettings[i],i,sections.Count)){var lp=HoleCenter(mathUtil,left,lm[0],lm[1],station/1000);var rp=HoleCenter(mathUtil,right,rm[0],rm[1],station/1000);var crossbar=LegCrossbarLayout.Build(legSettings,lp[0]*1000,rp[0]*1000,lp[1]*1000,rp[1]*1000,lp[2]*1000);if(Math.Abs(crossbar.LengthMm-crossbarLengths[i])>.05)throw new InvalidOperationException("El largo del travesaño H no coincide con el espacio real entre patas.");var c=InsertComponentHelper(sw,assembly,crossbarPaths[i],crossbar.StartX/1000,crossbar.CenterY/1000,crossbar.StationZ/1000);FixPlacedComponent(model,assembly,c,mathUtil,crossbar.Transform(),"travesaño H del tramo "+(i+1));count++;}}
                    if(curvedRoute)MoveStraightSection(assembly,model,mathUtil,before,curveFrames[i],offset);
                    offset += sections[i].LengthMm / 1000.0;
                }

                stage = "reconstruir y guardar banda completa";
                if (progress != null) progress(stage);
                model.EditRebuild3();
                if(progress!=null)progress("Comprobar interferencias entre sólidos CAD");
                WriteCadInterferences(assembly,folder);
                object[] components = (object[])assembly.GetComponents(true);
                if (components == null || components.Length != count)
                    throw new InvalidOperationException("Faltan componentes en el ensamble completo.");
                int activateError=0;
                sw.ActivateDoc3(model.GetTitle(),false,0,ref activateError);
                try { SolidWorksPresentation.Apply(model,shaded3D); }
                catch(Exception viewError) { if(progress!=null)progress("Ensamble generado; no se pudo aplicar la presentación: "+viewError.Message); }
                int saveError = 0, saveWarning = 0;
                if (!model.SaveAs4(outputPath, (int)swSaveAsVersion_e.swSaveAsCurrentVersion,
                    (int)swSaveAsOptions_e.swSaveAsOptions_Silent, ref saveError, ref saveWarning) || saveError != 0)
                    throw new InvalidOperationException("No se guardó BANDA_COMPLETA.SLDASM (error " + saveError + ").");
                File.WriteAllText(Path.Combine(folder,"AVISOS_GUARDADO.txt"),"SOLIDWORKS SaveAs: "+saveWarning+". Revisar INTERFERENCIAS_CAD.json antes de liberar fabricación.");
                var axes = new System.Collections.Generic.List<object>();
                double axisOffset = 0;
                for (int i=0;i<sections.Count;i++) {
                    var l=plateLayouts[i]; var settings=sections[i].ShaftPlates;
                    if (l!=null) axes.Add(new { Tramo=i+1, Tipo=sections[i].Type.ToString(), Dientes=l.Sprocket.Teeth,
                        AsientoIn=settings.ShaftSeatInches, AsientoMm=settings.ShaftSeatInches*25.4,
                        EjeYMm=l.AxisY, EjeZMm=axisOffset+l.AxisZ, RodaduraYMm=l.RunningY,
                        EspesorBandaMm=partSettings[i].BeltThicknessMm, SeparacionNylamidDoblezMm=l.TopY-l.RunningY,
                        CentroBarrenosSolapeZMm=axisOffset+l.LapHoleZ, MargenCoberturaRealMm=l.EffectiveCoverMarginMm,
                        AMm=l.Sprocket.AMm, BMm=settings.BMm, BMaxMm=l.Sprocket.BMaxMm,
                        EjeAlPerfilMm=ShaftPlateGeometry.AxisDistanceFromProfile(sections[i],l),
                        BarrenoAlPerfilMm=ShaftPlateGeometry.BearingHoleClearance(sections[i],l),
                        ExtensionNylamidMm=l.RailLengthMm-sections[i].LengthMm,
                        DescensoPlaquitaMm=supports[i].EndPlateDropMm,
                        PasoCabezaSoporteMm=l.IncludeSupportHeadClearance ? ShaftPlateGeometry.SupportHeadClearanceDiameterMm : 0,
                        CentroPasoCabezaZMm=axisOffset+l.SupportHeadZ, CentroPasoCabezaYMm=l.SupportHeadY,
                        DescensoBarrenosSolapeMm=ShaftPlateGeometry.LapHoleDropMm,
                        PletinaInicioZMm=axisOffset+l.RailStartZ, PletinaFinZMm=axisOffset+l.RailEndZ,
                        PlacaLargoMm=l.PlateLengthMm, PlacaAltoMm=l.HeightMm, PlacaEspesorMm=ShaftPlateLayout.ThicknessMm,
                        PlacaRHAltoMm=rightPlateLayouts[i].HeightMm, BordeLHYMm=l.TopY, BordeRHYMm=rightPlateLayouts[i].TopY,
                        PlacaLHInteriorXMm=settings.Mounting==2 ? plateDatums[i,0].OuterX : plateDatums[i,0].InnerX,
                        PlacaRHInteriorXMm=supports[i].LengthMm+(settings.Mounting==2 ? plateDatums[i,1].OuterX : plateDatums[i,1].InnerX),
                        Flecha=shaftLayouts[i]==null?null:shaftPaths[i], CuadradoLargoMm=shaftLayouts[i]==null?0:shaftLayouts[i].SquareLengthMm, CuadradoInicioXMm=shaftLayouts[i]==null?0:shaftLayouts[i].SquareLeftX, CuadradoFinXMm=shaftLayouts[i]==null?0:shaftLayouts[i].SquareRightX, SeparacionCuadradoPlacaMm=10, ConfiguracionFlecha=settings.Shaft, Chumacera=settings.BearingReference, ModeloChumacera=settings.Bearing==null?null:bearingPaths[settings.Bearing.Id], CatalogoChumacera=settings.Bearing==null?null:settings.Bearing.Id, SolapeMm=l.OverlapMm });
                    axisOffset+=partSettings[i].LengthMm;
                }
                File.WriteAllText(Path.Combine(folder,"REFERENCIAS_FLECHAS.json"),
                    new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new { Version=1, Unidades="mm", EjeLongitudinal="Z", EjeVertical="Y", Flechas=axes }),System.Text.Encoding.UTF8);
                File.WriteAllText(Path.Combine(folder,"REFERENCIAS_RODILLOS.json"),
                    new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new {Version=5,Unidades="mm",Configuracion=rollers, Patrones=Array.ConvertAll(partSettings,delegate(ProfileSettings p){return p.ResolvedPattern;}),
                        ModeloAltura="Tangencia con envolvente exterior A + espesor de banda",ReferenciaManual=ReturnRollerRules.ReferenceId,PasoReferenciaLMm=rollerPlan.ReferencePitchMm,CatenariaResueltaMm=rollerPlan.ResolvedCatenaryMm,RepartoAutomatico=rollerPlan.AutomaticSpacing,PasoNormalMinimoMm=rollerPlan.MinimumNormalPitchMm,PasoNormalMaximoMm=rollerPlan.MaximumNormalPitchMm,PasoUniformeMm=rollerPlan.UniformPitchMm,PrimeroConducidoZMm=rollerPlan.FirstDrivenZMm,
                        PrimeroMotrizZMm=rollerPlan.FirstMotorZMm,SegundoMotrizZMm=rollerPlan.SecondMotorZMm,Rodillos=rollerPlan.Holes}),System.Text.Encoding.UTF8);
                File.WriteAllText(Path.Combine(folder,"DISTRIBUCION_LOGO_RANURAS.json"),new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new{Version=4,Unidades="mm",Aplicacion="JAC v5 · Diseño 3D",Patrones=Array.ConvertAll(partSettings,delegate(ProfileSettings p){return p.ResolvedPattern;})}),System.Text.Encoding.UTF8);
                File.WriteAllText(Path.Combine(folder,"REFERENCIAS_PATAS.json"),new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new{Version=4,Unidades="mm",TravesanosH=legSettings.CrossbarEnabled?Array.ConvertAll(crossbarPaths,Path.GetFileName):new string[0],LargosTravesanosHMm=crossbarLengths,AlturaEjeTravesanoHDesdeBaseMm=legSettings.CrossbarHeightMm,Configuracion=legSettings,Tornillo="Cilindro sin rosca",AgujeroTapaMm=legSettings.CapHoleDiameterMm,Modelos=Array.ConvertAll(verticalPaths,Path.GetFileName),LargosPTRMm=Array.ConvertAll(legMountYs,legSettings.TubeLength),EstacionesZMm=VerticalSupportLayout.Stations(sections,profile),PatasPorEstacion=2,CuadradoMm=11,PasoMm=63.5,ReglaCentral="Longitud del tramo > 2000 mm"}),System.Text.Encoding.UTF8);
                if(curvedRoute)WriteCurveReferences(folder,sections,designPlan,curveFrames,plateLayouts,legSettings,rollers);
                if(exportFlatPatterns){if(progress!=null)progress("Documentar desplegados pendientes");ExportFlatPatterns(sw,Array.FindAll(Directory.GetFiles(folder,"*.SLDPRT",SearchOption.AllDirectories),path=>!Path.GetFileName(path).StartsWith("~$",StringComparison.Ordinal)),folder);int active=0;sw.ActivateDoc3(model.GetTitle(),false,0,ref active);}
                return outputPath;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Fallo durante " + stage + ": " + ex.Message, ex);
            }
        }
    }
}


