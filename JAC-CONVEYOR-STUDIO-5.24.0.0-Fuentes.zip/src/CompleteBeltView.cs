using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace PerfilBandas
{
    // Plain project data, independent of Windows Forms and the CAD connection.
    internal sealed class BeltProject
    {
        public int Version = 16;
        public VerticalSupportSettings VerticalSupports=new VerticalSupportSettings();
        public bool IndependentRailCounts;public bool IndependentSprocketCounts;
        public bool ApplyToAllChanges=true;
        public double SlotGapMm=200;
        public bool Shaded3D=true;
        public bool ShowBeltTrajectory=true;
        public BeltSimulationSettings Simulation=new BeltSimulationSettings();
        public bool PreferHardware=true,ExportFlatPatterns=true;
        public string NylamidColor="Blanco";
        public List<BeltSectionSpec> Sections = new List<BeltSectionSpec>();
        public string OutputFolder;
        public ReturnRollerSettings Rollers = new ReturnRollerSettings();
    }

    internal sealed partial class CompleteBeltView : UserControl
    {
        private readonly ProfileSettings profile;
        private readonly SoporteSettings supportTemplate;
        internal bool showBeltTrajectory=true;
        internal BeltSimulationSettings simulationSettings=new BeltSimulationSettings();
        internal VerticalSupportSettings verticalSupports=new VerticalSupportSettings();
        internal readonly List<BeltSectionSpec> sections = new List<BeltSectionSpec>();
        private readonly FlowLayoutPanel cards = new FlowLayoutPanel();
        private readonly List<Button> cardButtons = new List<Button>();
        private readonly List<Button> categoryButtons = new List<Button>();
        private readonly CompleteBeltPreview preview = new CompleteBeltPreview();
        private readonly Panel fields = new Panel();
        private readonly TableLayoutPanel detailHost = new TableLayoutPanel();
        private readonly Label selectionTitle = new Label();
        private readonly Label summary = new Label();
        private readonly Label status = new Label();
        private readonly Label previewTitle = new Label();
        private readonly Label derived = new Label();
        private readonly Label saveState = new Label();
        private readonly Button generate;
        private readonly Button remove;
        private readonly ToolTip tips = new ToolTip();
        private readonly string[] categories = { "Dimensiones de banda", "Geometría del perfil", "Distribución de travesaños", "Patas y uniones", "Logo y aberturas", "Geometría del travesaño", "Ranuras para nylamid", "Guías de nylamid", "Plaquitas de fijación", "Placas y transmisión", "Rodillos de retorno", "Opciones de generación" };
        private TableLayoutPanel form;
        private Control detail;
        private int selected;
        private int category;
        private bool dirty;
        private bool generating;
        private bool shaded3D=true;
        private bool exportFlatPatterns=true;
        internal bool independentSprocketCounts;
        internal void SetSprocketCount(int count){if(count<1||count>50)throw new ArgumentOutOfRangeException("count");foreach(var part in sections)if(part.Type!=BeltSectionType.Intermedio&&(!independentSprocketCounts||part==sections[selected]))part.ShaftPlates.Shaft.SprocketCount=count;}
        internal void SetIndependentSprocketCounts(bool enabled){independentSprocketCounts=enabled;if(!enabled)SetSprocketCount(sections[selected].ShaftPlates.Shaft.SprocketCount);}
        internal bool independentRailCounts;
        internal void SetRailCount(int count) {
            if(count<0 || count>8)throw new ArgumentOutOfRangeException("count");
            if(independentRailCounts)sections[selected].Support.CenterSlotCount=count;
            else {supportTemplate.CenterSlotCount=count;foreach(var part in sections)part.Support.CenterSlotCount=count;}
        }
        internal void SetIndependentRailCounts(bool enabled) {
            independentRailCounts=enabled;
            if(!enabled)SetRailCount(sections[selected].Support.CenterSlotCount);
        }
        private string nylamidColor="Blanco";bool syncingSlotFields;
        private Belt3DWindow preview3D;
        private Form closingOwner;
        private string projectPath;
        private BearingCatalogEntry defaultBearing;
        private string outputFolder = Path.Combine(ProjectPaths.GetDefaultPiecesFolder(), "BANDA_COMPLETA");

        public CompleteBeltView(ProfileSettings template, Func<SoporteSettings> getSupport)
        {
            profile = template.Copy();
            var defaultCatalog=BearingCatalog.Default();
            defaultBearing=defaultCatalog.All().FirstOrDefault(e=>File.Exists(defaultCatalog.ModelPath(e))&&File.Exists(BearingModelMesh.PathFor(defaultCatalog,e)));
            var initialSupport = getSupport == null ? null : getSupport();
            supportTemplate = initialSupport == null ? new SoporteSettings {
                BandWidthMm = profile.BandWidthMm,
                LengthMm = SoporteSettings.CalculateLengthFromBand(profile.BandWidthMm),
                CenterSlotCount = 2,
                EndPlateHoleSizeMm = profile.SupportHoleSizeMm
            } : initialSupport.Copy();
            Dock = DockStyle.Fill;
            BackColor = DesignUi.Canvas;
            Font = new Font("Segoe UI", 10f);
            Padding = new Padding(0, 0, 0, 0);

            var sidebar = new Panel { Dock = DockStyle.Left, Width = 182, BackColor = DesignUi.Canvas, Padding = new Padding(12) };
            var sidebarTitle = L("Tramos", 15, DesignUi.Ink); sidebarTitle.Dock = DockStyle.Top; sidebarTitle.Height = 52;sidebarTitle.Font=DesignUi.NavigationBold;
            cards.Dock = DockStyle.Fill; cards.FlowDirection = FlowDirection.TopDown; cards.WrapContents = false; cards.AutoScroll = true;
            cards.SizeChanged += delegate { foreach (var card in cardButtons) card.Width = Math.Max(120, cards.ClientSize.Width - 20); };
            var sideActions = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 198, FlowDirection = FlowDirection.TopDown };
            var add = B("+ Agregar tramo", DesignUi.Accent, delegate { AddIntermediate(); }); add.Width = 156;
            var duplicate = B("Duplicar tramo", DesignUi.Violet, delegate { AddIntermediate(true); }); duplicate.Width = 156;
            remove = B("Eliminar tramo", DesignUi.Danger, delegate { RemoveIntermediate(); }); remove.Name="RemoveTramoButton";remove.Width = 156;
            var addCurve=B("+ Agregar curva",DesignUi.Primary,AddCurve);addCurve.Name="AddCurveSection";addCurve.Width=156;sideActions.Controls.AddRange(new Control[] { add, addCurve, duplicate, remove });
            sidebar.Controls.Add(cards); sidebar.Controls.Add(sideActions); sidebar.Controls.Add(sidebarTitle);

            var main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(12, 10, 12, 8) };
            main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            main.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            main.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            Controls.Add(main); Controls.Add(sidebar);
            var header = new Panel { Dock = DockStyle.Fill };
            var tools = new Panel {Name="ProjectHeaderActions",Dock = DockStyle.Right,Width=112,Padding=new Padding(0,2,0,0)};
            var saveButton=B("Guardar",DesignUi.Accent,SaveProject);saveButton.Name="SaveProjectButton";saveButton.Dock=DockStyle.Top;saveButton.Height=36;saveButton.Font=new Font("Segoe UI",10f,FontStyle.Bold);tools.Controls.Add(saveButton);
            summary.Dock = DockStyle.Fill; summary.Font = new Font("Bahnschrift", 15f, FontStyle.Bold); summary.ForeColor = DesignUi.Ink;
            summary.TextAlign=ContentAlignment.MiddleLeft;
            saveState.Dock = DockStyle.Bottom; saveState.Height = 22; saveState.ForeColor = DesignUi.Muted; saveState.Font = new Font("Segoe UI", 9f);
            header.Controls.Add(summary); header.Controls.Add(tools); header.Controls.Add(saveState); main.Controls.Add(header, 0, 0);
            preview.Dock = DockStyle.Fill; preview.Profile = profile; preview.Sections = sections;
            preview.SectionSelected += SelectSection;
            fields.Dock = DockStyle.Fill; fields.AutoScroll = true; fields.Padding = new Padding(16, 12, 12, 16);
            detailHost.Dock = DockStyle.Fill; detailHost.BackColor = Color.White; detailHost.Padding = new Padding(12);
            detailHost.ColumnCount = 1; detailHost.RowCount = 3;
            detailHost.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            detailHost.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
            detailHost.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            detailHost.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
            previewTitle.Dock = DockStyle.Top; previewTitle.Height = 44; previewTitle.ForeColor = DesignUi.Ink; previewTitle.Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold);
            derived.Dock = DockStyle.Bottom; derived.Height = 112; derived.ForeColor = DesignUi.Muted; derived.Font = new Font("Segoe UI", 9f);
            detailHost.Controls.Add(derived, 0, 2); detailHost.Controls.Add(previewTitle, 0, 0);
            var workspace = new Panel { Dock=DockStyle.Fill,Margin=Padding.Empty };
            workspace.Controls.Add(Create3DWorkspace());workspace.Controls.Add(CreateInspector());main.Controls.Add(workspace,0,1);
            var footer = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 10, 0, 0) };
            generate = B("Generar SolidWorks", DesignUi.Accent, Generate); generate.Name="GenerateCadButton";generate.Dock = DockStyle.Right; generate.Width = 188;
            status.Dock = DockStyle.Fill; status.ForeColor = DesignUi.Muted; status.Font = new Font("Segoe UI", 9f); status.Padding = new Padding(0, 0, 12, 0);
            var partsButton=B("Piezas del ensamble",DesignUi.Primary,ShowAssemblyParts);partsButton.Name="AssemblyPartsButton";partsButton.Dock=DockStyle.Right;partsButton.Width=170;footer.Controls.Add(status);footer.Controls.Add(partsButton); footer.Controls.Add(generate); footer.Controls.Add(CreateIssueButton());footer.Controls.Add(CreateDesignNotice());main.Controls.Add(footer, 0, 2);
            sections.Add(NewSection(BeltSectionType.Conducido)); sections.Add(NewSection(BeltSectionType.Motriz));
            RebuildCards(); SelectSection(0);
            Controls.Add(CreateCommandRibbon());OpenDetails(0);
            ResetDesignHistory();
            ParentChanged += delegate { var window=FindForm();if(window==closingOwner)return;if(closingOwner!=null)closingOwner.FormClosing-=OnClosing;closingOwner=window;if(window!=null)window.FormClosing+=OnClosing; };
        }

        private BeltSectionSpec NewSection(BeltSectionType type)
        {
            var p=profile.Copy();var s=supportTemplate.Copy();
            if(sections.Count>0){var common=sections[0].Profile;p.BandWidthMm=common.BandWidthMm;p.BeltModelName=common.BeltModelName;p.BeltThicknessMm=common.BeltThicknessMm;p.SlotGapMm=common.SlotGapMm;p.WebHeightMm=common.WebHeightMm;p.BottomFlangeMm=common.BottomFlangeMm;p.BottomAngleDeg=common.BottomAngleDeg;if(!s.AutoSyncWithBandWidth)s.LengthMm=sections[0].Support.LengthMm;}
            if(!independentRailCounts && sections.Count>0)s.CenterSlotCount=sections[0].Support.CenterSlotCount;
            var section=new BeltSectionSpec(type, profile.LengthMm) { Profile = p, Support = s };
            if(type!=BeltSectionType.Intermedio&&defaultBearing!=null){defaultBearing.Apply(section.ShaftPlates);section.ShaftPlates.Enabled=true;section.ShaftPlates.Shaft.Enabled=true;}
            return section;
        }
        internal void SelectSection(int index)
        {
            if (index < 0 || index >= sections.Count || generating) return;
            selected = index; preview.SelectedIndex = index;
            selectionTitle.Text = "Tramo " + (index + 1).ToString("00") + "  /  " + (sections[index].IsCurved?"Curva":sections[index].Type.ToString());
            remove.Enabled = index > 0 && index < sections.Count - 1;
            bool keepInspector=inspectorHost.Visible;int keepPage=inspectorTabs.SelectedIndex;
            CloseModelEditor();BuildQuickEditor();ShowCategory(category);inspectorTabs.SelectedIndex=keepPage;SetInspectorVisible(keepInspector);
            if (cardButtons.Count > index) cards.ScrollControlIntoView(cardButtons[index]);
        }
        internal void AddIntermediate(bool duplicate = false)
        {
            if(generating)return;
            if (sections.Count >= 24) { status.Text = "El máximo es 24 tramos."; return; }
            var section = duplicate ? sections[selected].Copy() : NewSection(BeltSectionType.Intermedio);
            section.Type = BeltSectionType.Intermedio;
            if (section.ShaftPlates != null) section.ShaftPlates.Enabled = false;
            int index = Math.Min(selected + 1, sections.Count - 1);
            sections.Insert(index, section); dirty = true; RebuildCards(); SelectSection(index);RecordDesignChange();
        }
        private void RemoveIntermediate()
        {
            if (generating || selected <= 0 || selected >= sections.Count - 1) return;
            sections.RemoveAt(selected); dirty = true; RebuildCards(); SelectSection(Math.Min(selected, sections.Count - 1));RecordDesignChange();
        }
        private void RebuildCards()
        {
            cards.SuspendLayout();
            foreach (var b in cardButtons) b.Dispose(); cardButtons.Clear(); cards.Controls.Clear();
            for (int i = 0; i < sections.Count; i++)
            {
                int index = i;
                var card = B("", Color.White, delegate { SelectSection(index); });
                card.Name="Section_"+(i+1).ToString("00");
                card.Width = Math.Max(120, cards.ClientSize.Width - 20); card.Height = 78; card.TextAlign = ContentAlignment.MiddleLeft; card.Padding = new Padding(4); card.Margin = new Padding(0, 0, 0, 9);
                cardButtons.Add(card); cards.Controls.Add(card);
            }
            cards.ResumeLayout();
        }
        public void RefreshProfile() { RefreshState(); } // Existing sections never inherit subsequent template edits.
        private void Changed(int editedCategory=-2) { if(editedCategory==-2)editedCategory=inspectorTabs.SelectedIndex==1?category:-1;if(applyToAllChanges&&editedCategory>=0)CopyCategoryToAll(editedCategory);if(inspectorTabs.SelectedIndex==1)pendingQuickErrors.Clear();RecordDesignChange();dirty = true; RefreshState(); }
        internal void RefreshState()
        {
            SyncTrajectoryButtons();
            if (sections.Count == 0) return;
            summary.Text = "Banda   /   " + sections.Count + " tramos   /   " + F(BeltLinePlan.TotalLengthMm(sections) / 1000) + " m";
            saveState.Text = (projectPath == null ? "Proyecto nuevo" : Path.GetFileName(projectPath)) + (dirty ? "  ·  Cambios sin guardar" : "  ·  Configuración por tramo");
            for (int i = 0; i < cardButtons.Count; i++)
            {
                var s = sections[i];
                cardButtons[i].Text = (i + 1).ToString("00") + "  " + (s.IsCurved?"Curva "+(s.Curve.TurnRight?"derecha":"izquierda"):s.Type.ToString()) + "\n" + F(s.IsCurved?s.Curve.ExteriorLengthMm(s.Profile.BandWidthMm):s.LengthMm) + " mm";
                cardButtons[i].BackColor = i == selected ? DesignUi.Selection : Color.White;
                cardButtons[i].ForeColor = i == selected ? DesignUi.Primary : DesignUi.Ink;
                cardButtons[i].AccessibleName = "Tramo " + (i + 1) + ", " + s.Type + ", " + F(s.LengthMm) + " milímetros";
            }
            currentPlan=BeltDesignPlan.Build(sections,profile,supportTemplate,rollers,verticalSupports);
            bool valid=currentPlan.Valid;
            status.ForeColor=valid?DesignUi.Muted:Color.Firebrick;
            status.Text=valid?"Tramo "+(selected+1).ToString("00")+" · Ctrl+F buscar ajustes · Ctrl+Z deshacer":"Corrige las incidencias para actualizar el modelo y generar.";
            ReturnRollerPlan rollerPlan=currentPlan.Rollers;
            RefreshIssueButton();RefreshDesignNotice();
            generate.Enabled = valid || generating;
            ProfileSettings p;
            try { p = BeltLinePlan.ProfileFor(sections, selected, profile, rollers!=null && rollers.Enabled && rollers.OpenSeats); }
            catch { p = sections[selected].Profile.Copy(); p.LengthMm = sections[selected].LengthMm; }
            if(rollers.Enabled && rollerPlan!=null){ReturnRollerLayout.Apply(p,selected,sections[selected],rollerPlan);p.ResolvedCurveRollerRiseMm=rollers.CurveRollerRiseMm;}
            SoporteSettings support;
            try {support=BeltLinePlan.SupportFor(sections[selected],supportTemplate,p);}catch{support=sections[selected].Support.Copy();}
            if (detail is ProfilePreview) ((ProfilePreview)detail).Settings = p;
            if (detail is FrontProfilePreview) ((FrontProfilePreview)detail).Settings = p;
            if (detail is AssemblyPreview) ((AssemblyPreview)detail).Settings = p;
            if (detail is SectionHoleReference) ((SectionHoleReference)detail).Settings = p;
            if (detail is SoporteCrossSectionPreview) ((SoporteCrossSectionPreview)detail).Settings = support;
            if (detail is SoporteLongitudinalPreview) ((SoporteLongitudinalPreview)detail).Settings = support;
            if (detail is SlideRailPreview) ((SlideRailPreview)detail).Support = support;
            if(detail is ReturnRollerPreview) {
                var v=(ReturnRollerPreview)detail;v.Plan=rollerPlan;v.Settings=rollers;v.Sections=sections;v.Selected=selected;
            }
            if (detail is ShaftPlatePreview) {
                var platePreview = (ShaftPlatePreview)detail;
                platePreview.Section = sections[selected]; platePreview.Profile = p; platePreview.Support = support;
                platePreview.CrossSection=plateCrossSection;
            }
            if (detail != null) detail.Invalidate();
            derived.Text = "RESULTADO DE ESTE TRAMO\n" + p.SupportCount + " soportes C · paso " + (p.SupportCount == 2 ? "no aplica" : F(p.SupportHoleSpacingMm) + " mm") + "\n" + (p.ResolvedSlots==null ? 0 : p.ResolvedSlots.Length) + " ranuras · " + (String.IsNullOrEmpty(p.SlotCombination)?"patrón automático":"composición elegida") + "\nPletinas: " + (sections[selected].IncludeSlideRails ? (support.CenterSlotCount + 2) + " de " + F(p.LengthMm) + " mm" : "desactivadas") + "\nOrificios inicio / final: " + (p.EndHoleTypeLeft=="ninguno"?"0":p.EndHoleTypeLeft=="final"?"2":"1") + " / " + (p.EndHoleTypeRight=="ninguno"?"0":p.EndHoleTypeRight=="final"?"2":"1");
            if(category==4) {try {var pattern=ProfileSlotLayout.PatternFor(p);derived.Text=pattern.Description+"\n"+ProfileSlotLayout.DimensionsText(pattern);} catch(Exception ex){derived.Text=ex.Message;}}
            if(category==0 || category==2 || category==7) derived.Text = derived.Text.Substring(0,derived.Text.LastIndexOf("\n")) + "\nCentro barreno: " + F(p.SupportHoleYMm) + " mm · banda: " + F(p.BeltThicknessMm) + " mm";
            if(sections[selected].IsCurved)derived.Text="CURVA · "+F(sections[selected].Curve.AngleDeg)+"° · R interior "+F(sections[selected].Curve.RadiusFor(p.BandWidthMm))+" mm\nArco exterior: "+F(sections[selected].Curve.ExteriorLengthMm(p.BandWidthMm))+" mm\nSoportes: "+p.SupportCount+" arriba + "+p.SupportCount+" abajo\nPletinas: "+(sections[selected].IncludeSlideRails?(support.CenterSlotCount+2)+" arriba + 3 abajo":"desactivadas");
            if(sections[selected].IsCurved)derived.Text+="\nRanuras: "+(2*(p.SupportCount-1))+" exterior + "+(p.SupportCount-1)+" interior · debajo del soporte hasta nylamid inferior";
            preview.SelectedIndex = selected; preview.Invalidate();
            if (ShaftPlateGeometry.Active(sections[selected]) && category != 9) {
                try { derived.Text = derived.Text.Replace(F(p.LengthMm) + " mm", F(ShaftPlateGeometry.RailLength(sections[selected],p,support)) + " mm"); } catch { }
            }
            if(category==1&&!sections[selected].IsCurved)derived.Text="DOBLECES DEL PERFIL\nRadio interior: "+F(p.BendRadiusMm)+" mm · exterior: "+F(p.BendRadiusMm+p.ThicknessMm)+" mm\nFactor K: "+F(p.KFactor)+" · fibra neutra: "+F(p.BendRadiusMm+p.KFactor*p.ThicknessMm)+" mm\nDesarrollo transversal: "+F(ProfileBendGeometry.DevelopedWidth(p))+" mm";
            RefreshPlateSummary(p, support);
            RefreshRollerSummary(rollerPlan);
            RefreshRollerExplorer(rollerPlan);
            RefreshQuickValues(p,support);
            Refresh3D();
            ShowPendingQuickErrors();
        }

        internal void Open3D() {
            if(preview3D==null||preview3D.IsDisposed){preview3D=new Belt3DWindow(SelectSection,delegate{OpenDetails(4);var owner=FindForm();if(owner!=null)owner.Activate();});preview3D.BindSimulation(simulationSettings);preview3D.SimulationSettingsChanged+=delegate{dirty=true;RecordDesignChange();};preview3D.TrajectoryToggleRequested+=ToggleBeltTrajectory;preview3D.HardwarePreferenceRequested+=ChangeRenderer;preview3D.DimensionViewsRequested+=ShowDimensionViews;preview3D.Preview.ParameterEditRequested+=delegate(string key,Rectangle anchor){OpenModelEditor(preview3D.Preview,key,anchor);};}
            preview3D.SetTrajectoryVisibility(showBeltTrajectory);SetRendererPreference(WorldPreview.PreferHardware);Refresh3D();if(!preview3D.Visible)preview3D.Show(FindForm());preview3D.Activate();
        }
        protected override void Dispose(bool disposing) {
            if(disposing){if(rollerExplorer!=null)rollerExplorer.Dispose();if(closingOwner!=null)closingOwner.FormClosing-=OnClosing;if(preview3D!=null)preview3D.Dispose();preview.Dispose();tips.Dispose();}
            base.Dispose(disposing);
        }
        void Refresh3D() {
            if(currentPlan!=null&&!currentPlan.Valid&&!(CurveRoute.HasCurves(sections)&&currentPlan.Issues.TrueForAll(i=>!i.Blocking||i.Message.StartsWith("Tabla E925:")))){string error="Vista anterior · corrige las incidencias para actualizar.";WorldPreview.SetModel(lastValidMesh,error,selected);return;}
            try{string signature=new JavaScriptSerializer().Serialize(new{Tramos=sections,Patas=verticalSupports,Rodillos=rollers,ColorNylamid=nylamidColor,MostrarBanda=showBeltTrajectory});if(signature!=meshSignature){var watch=System.Diagnostics.Stopwatch.StartNew();lastValidMesh=Belt3DGeometry.Build(sections,profile,supportTemplate,rollers,nylamidColor,null,null,verticalSupports,currentPlan,showBeltTrajectory);meshBuildMs=watch.ElapsedMilliseconds;meshSignature=signature;}WorldPreview.SetModel(lastValidMesh,null,selected);if(preview3D!=null&&!preview3D.IsDisposed)preview3D.UpdateModel(lastValidMesh,null,selected);}
            catch(Exception ex){WorldPreview.SetModel(lastValidMesh,"Vista anterior · "+ex.Message,selected);if(preview3D!=null&&!preview3D.IsDisposed)preview3D.UpdateModel(lastValidMesh,"Vista anterior · "+ex.Message,selected);}
        }

        internal void ShowCategory(int index)
        {
            category = index;
            RefreshRibbonSelection();
            SyncCategoryNavigation(index);
            detailHost.RowStyles[2].Height = index==9 || index==10 ? 144 : 112;
            rollerTable=null;
            derived.Height = index==9 ? 144 : 112;
            fields.SuspendLayout();
            while (fields.Controls.Count > 0) fields.Controls[0].Dispose();
            form = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1, Margin = Padding.Empty };
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); fields.Controls.Add(form);
            for (int i = 0; i < categoryButtons.Count; i++) { categoryButtons[i].BackColor = i == index ? DesignUi.Primary : Color.White; categoryButtons[i].ForeColor = i == index ? Color.White : DesignUi.Ink; }
            var section = sections[selected]; var p = section.Profile; var s = section.Support;
            if (index == 0)
            {
                Field("Trayectoria de la banda", "Ocúltala para inspeccionar las piezas. Este control también está en la barra superior del visor 3D.",CreateTrajectoryButton());
                Note("Dimensiones del tramo", "El largo es independiente. Modelo y ancho deben ser compatibles en toda la banda.");
                if(!section.IsCurved)Choice("Extremo recortado", "Se conserva el patrón desde el extremo opuesto.",new[]{"Inicio del tramo","Final del tramo"},p.SlotTrimFromRight?"Final del tramo":"Inicio del tramo",delegate(string v){p.SlotTrimFromRight=v=="Final del tramo";});
                if(section.IsCurved)CurveEditor(section);else N("Largo del tramo · mm", "De la cara de inicio a la cara final; sin sumar otros tramos.", section, "LengthMm", 600, 6000);
                var models = BeltCatalog.Load(AppDomain.CurrentDomain.BaseDirectory); var names = new List<string>(); foreach (var m in models) names.Add(m.Name); if (!names.Contains(p.BeltModelName)) names.Add(p.BeltModelName);
                Choice("Modelo de banda", "Modelo de la correa que transporta el producto.", names.ToArray(), p.BeltModelName, delegate(string v) { p.BeltModelName = v; });
                if(BeltWidthRules.IsE925(p.BeltModelName)){var widths=new List<string>();for(int w=100;w<=1320;w+=20)widths.Add(w.ToString());Choice("Ancho de la correa · mm", "E925: múltiplos de 20 mm. El soporte automático mide el ancho elegido + 20 mm.",widths.ToArray(),F(p.BandWidthMm),v=>{p.BandWidthMm=Double.Parse(v);});if(!BeltWidthRules.IsValidE925(p.BandWidthMm))Note("Ancho E925 no válido: "+F(p.BandWidthMm)+" mm","Selecciona un múltiplo de 20 mm para generar el proyecto.");}else N("Ancho de la correa · mm", "El soporte automático mide este ancho + 20 mm.", p, "BandWidthMm", 100, 1320);
                N("Espesor de la banda · mm", "E925: 12 mm. La cara superior de la banda queda 7.9375 mm bajo el perfil (cubierta de 6.35 mm + holgura de 1.5875 mm); el apoyo se ajusta al espesor configurado.", p, "BeltThicknessMm", 1, 100);
                Action("Usar esta banda en todos los tramos", delegate { foreach (var t in sections) { t.Profile.BandWidthMm = p.BandWidthMm; t.Profile.BeltModelName = p.BeltModelName; t.Profile.BeltThicknessMm=p.BeltThicknessMm; } Changed(); });
                Note("Función: " + section.Type, section.Type == BeltSectionType.Conducido ? "Extremo de retorno. Dos orificios al inicio y uno para la unión siguiente." : section.Type == BeltSectionType.Motriz ? "Extremo de salida hacia el motor. Uno en la unión anterior y dos al final." : "Une dos tramos. Un orificio en cada extremo se complementa con el del tramo vecino.");
            }
            else if (index == 1)
            {
                Note("Perfiles laterales",section.IsCurved?"Alma plana curvada y cejas independientes soldadas a 90°. La altura del alma coincide con el tramo recto.":"Se genera un par izquierdo / derecho, con los dobleces hacia afuera.");
                N("Altura del alma · mm", "Cara vertical del lateral, entre sus bordes superior e inferior.", p, "WebHeightMm", 40, 1000);
                Gauge(p);
                N("Espesor de lámina · mm", "Permite ajustar el valor nominal del calibre.", p, "ThicknessMm", .5, 6);
                if(!section.IsCurved)N("Radio interior de doblez · mm", "Curvatura interior de la lámina en ambos pliegues.", p, "BendRadiusMm", .1, 25);
                if(!section.IsCurved)N("Factor K del perfil", "Posición de la fibra neutra dentro del espesor. Modifica el desarrollo; la curvatura visible depende del radio interior y del espesor.", p, "KFactor", .01, .99);
                N(section.IsCurved?"Saliente de ceja superior · mm":"Pestaña superior · mm", "Ancho del doblez superior hacia afuera.", p, "TopFlangeMm", 5, 250);
                if(!section.IsCurved)N("Ángulo superior · °", "90° forma un doblez en escuadra.", p, "TopAngleDeg", 1, 179);
                N(section.IsCurved?"Saliente de ceja inferior · mm":"Pestaña inferior · mm",section.IsCurved?"Saliente total; el ancho neto de la ceja soldada excluye el espesor del alma.":"Ancho del doblez donde se sujetan las patas.", p, "BottomFlangeMm", 5, 250);
                if(!section.IsCurved)N("Ángulo inferior · °", "135° es el valor actual de la pestaña para las patas.", p, "BottomAngleDeg", 1, 179);
                if(!section.IsCurved)Note("Fibra neutra: R + K × espesor", "El desarrollo transversal se actualiza en el resultado de este tramo.");
            }
            else if (index == 2)
            {
                Note("Orificios para soportes C", "El soporte y su orificio usan la misma posición. En automático el paso es uniforme dentro del tramo y los soportes quedan pegados en las uniones.");
                SupportCountEditor(section);
                Action("Quitar un soporte interior",delegate{string error;if(TryRemoveInteriorSupport(out error)){Changed();BeginInvoke((Action)delegate{ShowCategory(category);});}else{status.Text=error;status.ForeColor=Color.Firebrick;}});
                Toggle("Repartir uniformemente", "Mantiene juntos los soportes de las uniones y reparte los demás entre el primero y el último. Desactívalo para usar el reparto manual desde los extremos.", section.AutoSupportPitch, delegate(bool v) { section.AutoSupportPitch = v; BeginInvoke((Action)delegate { ShowCategory(category); }); });
                if(section.AutoSupportPitch)
                    Note("Paso automático", "En las juntas cada centro queda a medio ancho del travesaño respecto al extremo. El margen configurado se conserva sólo en los extremos exteriores de la banda.");
                else {
                    N("Paso solicitado · mm", "Distancia entre centros dentro de cada grupo desde los extremos. Con 2 soportes no se utiliza.", p, "SupportHoleSpacingMm", 70, 2000);
                }
                N("Margen exterior al primer orificio · mm", "En automático se usa sólo en los extremos exteriores de la banda; en manual, en ambos extremos de cada tramo. Se mide hasta el borde del cuadrado.", p, "SupportHoleEdgeMm", 10, 300);
                N("Paso máximo aprobado · mm", "0 = sin criterio mecánico definido. Introduce el máximo autorizado para la carga de este proyecto; la app no calcula resistencia.",section,"MaximumSupportSpanMm",0,6000);
                Toggle("Nivelar según espesor de banda", "Sube o baja soportes, barrenos y flecha para que la cara superior de la banda quede 7.9375 mm bajo el doblez superior de 90°; el nylamid curvo queda al ras del perfil.", p.AutoSupportHeight, delegate(bool v) { p.AutoSupportHeight=v; BeginInvoke((Action)delegate { ShowCategory(category); }); });
                if(p.AutoSupportHeight)
                    Note("Altura automática del soporte", "El resultado calculado muestra el centro del barreno. Cambia el espesor en Dimensiones del tramo.");
                else N("Altura manual de referencia · mm", "Desde el borde superior del alma hacia abajo. Se suma el descenso de la plaquita.", p, "SupportHoleYMm", 10, 900);
                N("Lado del orificio cuadrado · mm", "Debe coincidir con el cuadrado de la plaquita del soporte.", p, "SupportHoleSizeMm", 6, 30);
                Action("Igualar orificio de las plaquitas", delegate { s.EndPlateHoleSizeMm = p.SupportHoleSizeMm; Changed(); });
            }
            else if (index == 3)
            {
                if(section.IsCurved){Note("Patas y uniones de la curva", "Dos patas con placa de chapa de 2.7 mm doblada a 45°, borde adaptado al radio y dos cuadrados de 11 mm a paso recto de 63.5 mm. Disponible con PTR de 1½ pulgadas. En la unión con un recto, la pata queda del lado recto. La unión entre dos curvas lleva un único par de patas compartidas y un travesaño H si está activado.");}else{
                Note("Patas verticales · toda la banda", "El PTR, la placa y la tapa se ajustan juntos. La altura se mide desde el piso hasta la superficie de la banda.");
                Choice("Tamaño del PTR", "Se aplica a las patas de ambos laterales y de todos los tramos.",new[]{"1½ pulgadas","2 pulgadas"},verticalSupports.TubeSideInches==2?"2 pulgadas":"1½ pulgadas",delegate(string v){verticalSupports.TubeSideInches=v=="2 pulgadas"?2:1.5;});
                N("Altura de banda desde piso · mm", "El largo del PTR se calcula considerando el montaje superior y la base niveladora.",verticalSupports,"BeltHeightMm",450,3000);
                Toggle("Unir cada par de patas en H", "Un PTR transversal une las caras interiores de las dos patas. Usa el mismo tamaño de PTR y aparece en el visor y en SolidWorks.",verticalSupports.CrossbarEnabled,v=>verticalSupports.CrossbarEnabled=v);
                N("Altura del eje del travesaño desde la base · in", "10 in = 254 mm. Se mide desde el piso de la base niveladora al centro del PTR; debe caber entre la tapa inferior y el montaje superior.",verticalSupports,"CrossbarHeightInches",0.1,120);
                N("Diámetro del tornillo · pulgadas", "Tornillo cilíndrico de ½ a 1 pulgada; también actualiza la tapa y las tuercas en SolidWorks.",verticalSupports,"ScrewDiameterInches",0.5,1);
                N("Radio exterior de placa · mm","Suaviza los vértices inferiores sin modificar apoyo del PTR ni barrenos. 0 conserva el contorno original.",verticalSupports,"PlateCornerRadiusMm",0,3);
                N("Largo del tornillo nivelador · mm","Comprueba el paso de las tuercas y el saliente disponible. La rosca se representa con un cilindro.",verticalSupports,"ScrewLengthMm",70,300);
                N("Tuerca: ancho entre caras · mm","0 = aproximación automática de 1.5 × diámetro. Introduce la medida de la referencia real para comprobar el ajuste en PTR.",verticalSupports,"NutAcrossFlatsMm",0,60);
                N("Espesor de tuerca · mm","Actualiza las tres tuercas y el montaje inferior de la tapa.",verticalSupports,"NutThicknessMm",5,30);
                Note("Placa superior: fija de 45°", "La placa articulada para desniveles y la placa para curvas se incorporarán cuando se definan sus geometrías.");
                Note("Uniones para las patas", "Dos cuadrados en los extremos exteriores; uno por perfil en las juntas. Los tramos mayores de 2000 mm llevan otro par al centro, en ambos laterales.");
                Note("Inicio: " + (selected == 0 ? "2 orificios" : "1 orificio") + "   /   Final: " + (selected == sections.Count - 1 ? "2 orificios" : "1 orificio"), "Los orificios inferiores siempre se generan para sujetar las patas.");
                Toggle("También en la pestaña superior", "Activa orificios para aditamentos sobre el doblez superior.", p.EndHolesTop, delegate(bool v) { p.EndHolesTop = v; });
                N("Lado del cuadrado · mm", "Tamaño de cada orificio en las pestañas.", p, "EndHoleSizeMm", 6, 30);
                N("Extremo a centro · mm", "Distancia desde el corte final del perfil al centro del primer cuadrado.", p, "EndHoleEdgeMm", 10, 300);
                N("Paso del par exterior · mm", "Distancia entre centros de los dos orificios del extremo de la banda.", p, "EndHoleSpacingMm", 15, 300);
                Note("Referencia de la unión", "La separación de los dos tornillos en una junta es la suma de las cotas extremo a centro de los tramos vecinos.");

                }
            }
            else if (index == 4)
            {
                if(section.IsCurved){Note("Alma curva", "Esta fase incluye los barrenos de los soportes superiores e inferiores. Los recortes y el logo de los perfiles rectos se conservan en sus tramos.");}else{
                Toggle("Adaptar recortes a fijaciones y rodillos","Acorta o elimina aberturas conflictivas conservando los centros funcionales. Los ajustes se muestran en Incidencias.",p.AdaptFunctionalCuts,v=>p.AdaptFunctionalCuts=v);
                Toggle("Patrón centrado y simétrico","En automático centra el logo y conserva recortes reflejados libres de obstáculos. Desactivar conserva el sentido de recorte original.",p.CenteredCuts,v=>p.CenteredCuts=v);
                Note("Composición del perfil", "Elige el orden de las aberturas o usa el cálculo por recorte. Los largos se calculan conservando la separación libre.");
                string[] codes=ProfileSlotLayout.Combinations();string[] names=Array.ConvertAll(codes,ProfileSlotLayout.CombinationLabel);
                Choice("Combinación de este tramo", "El orden se lee desde el inicio hacia el final del tramo. Una elección explícita no se elimina ni se invierte al cambiar el largo.",names,ProfileSlotLayout.CombinationLabel(p.SlotCombination),delegate(string v){p.SlotCombination=codes[Array.IndexOf(names,v)];});
                Choice("Marca", "El logo puede omitirse por recorte y vuelve al alargar el tramo.",new[]{"Logo JAC","Marca hexagonal","Sin marca"},p.MarkA?"Logo JAC":p.MarkB?"Marca hexagonal":"Sin marca",delegate(string v){p.MarkA=v=="Logo JAC";p.MarkB=v=="Marca hexagonal";});
                N("Escala de la marca · %","100% equivale a 140 mm de ancho para el logo JAC.",p,"MarkScale",10,300);
                Note("Ranuras siempre debajo de los soportes", "Su borde superior queda al menos 10 mm bajo la parte más baja del soporte C. La app baja el patrón si hace falta; si no cabe sobre el doblez inferior, indica el conflicto. Separación libre predeterminada: 200 mm.");
                N("Altura de ranura · mm","Abertura de arriba abajo. Radio de extremos = mitad de esta altura.",p,"SlotHeightMm",2,150);
                N("Separación libre · mm","Aplica a toda la banda. Con ranuras, margen = mitad; sólo logo conserva ese mínimo y muestra el margen real.",p,"SlotGapMm",20,450);
                N("Borde inferior sobre doblez · mm","Distancia solicitada desde el doblez inferior. Se limita automáticamente para que la ranura quede 10 mm debajo del soporte.",p,"SlotBottomOffsetMm",10,200);
                Note("Recorte y referencias", "Automático: referencia de 2400 mm y sentido de recorte en Dimensiones. Elegido: se conserva el orden indicado. Sólo logo: se centra sin cambiar su tamaño.");
                }
            }
            else if (index == 5)
            {
                Note("Soportes transversales C", "Estos ajustes pertenecen sólo a los soportes del tramo seleccionado.");
                Toggle("Calcular largo con el ancho de banda", "Automático = ancho de correa + 20 mm. Desactiva para usar el largo manual.", s.AutoSyncWithBandWidth, delegate(bool v) { s.AutoSyncWithBandWidth = v; });
                N("Largo manual del soporte · mm", "Se usa únicamente al desactivar el cálculo automático.", s, "LengthMm", 100, 2000);
                N("Ancho del lomo · mm", "Superficie transversal entre las dos pestañas del canal C.", s, "WebWidthMm", 20, 200);
                N("Pestaña frontal de referencia · mm", "Se añade el descenso de la plaquita para conservar su geometría y el nivel del nylamid.", s, "Flange1HeightMm", 20, 250);
                N("Pestaña posterior de referencia · mm", "Se alarga la misma cantidad que la frontal.", s, "Flange2HeightMm", 20, 250);
                Gauge(s); N("Espesor del soporte · mm", "Espesor de la lámina del canal C.", s, "ThicknessMm", .5, 6);
                N("Radio interior · mm", "Radio de los dobleces del soporte.", s, "BendRadiusMm", .1, 25);
                N("Factor K", "Posición de la fibra neutra para el desarrollo de lámina.", s, "KFactor", .1, .9);
            }
            else if (index == 6)
            {
                Toggle("Permitir cantidades distintas por tramo", "Desactivado: la cantidad aplica a toda la banda. Al desactivarlo se igualan los tramos con la cantidad del tramo seleccionado.", independentRailCounts, delegate(bool v) { SetIndependentRailCounts(v); });
                Note("Guías de Nylamid", "Recortes en el soporte C para alojar las pistas de deslizamiento.");
                Toggle("Crear ranuras de Nylamid", "Incluye los recortes laterales y las pistas centrales.", s.IncludeNylamidSlots, delegate(bool v) { s.IncludeNylamidSlots = v; });
                N("Ancho de cada ranura · mm", "20.05 mm por defecto: nylamid de 19.05 mm más 1 mm de holgura total.", s, "SlotWidthMm", 19.05, 24.05);
                N("Holgura total de ranura · mm","1 mm por defecto: 0.5 mm por lado en tiras centrales. Las laterales permanecen pegadas al perfil.",s,"SlotAllowanceMm",0,5);
                Action("Calcular ancho con holgura",delegate{s.SlotWidthMm=SlideRailGeometry.WidthMm+s.SlotAllowanceMm;Changed();ShowCategory(category);});
                N("Profundidad lateral · mm", "19.05 mm estándar. La cara rebajada de la pletina lateral queda nivelada con la central.", s, "OuterSlotDepthMm", 1, 80);
                N("Profundidad central · mm", "25.4 mm estándar. Debe superar la lateral por 6.35 mm.", s, "CenterSlotDepthMm", 1, 100);
                N("Cantidad de pistas centrales", "Por defecto aplica a todos los tramos. El total incluye dos tiras laterales adicionales.", s, "CenterSlotCount", 0, 8);
            }
            else if (index == 7)
            {
                N("Separación nominal en juntas · mm","Se reparte entre las guías de ambos tramos. 0 conserva el encuentro original.",s,"GuideJointGapMm",0,20);
                N("Coeficiente de expansión · 1/K","0 = sin cálculo térmico. Usar dato del proveedor del nylamid.",s,"GuideExpansionPerK",0,.01);
                N("Aumento de temperatura · K","Respecto a la temperatura de montaje. Se añade L × coeficiente × temperatura a la junta.",s,"GuideTemperatureRiseK",0,200);
                Note("Pletinas de deslizamiento", "En extremos con placas activadas, se prolongan hacia la flecha para conservar B y separar los barrenos del perfil 2 pulgadas. En los demás tramos mantienen el largo del perfil.");
                Toggle("Incluir pletinas en este tramo", "Dos laterales en espejo y una por cada ranura central.", section.IncludeSlideRails, delegate(bool v) { section.IncludeSlideRails = v; });
                Note(section.IsCurved?"Laterales de curva · 19.05 × 50.8 mm (2 pulgadas)":"Lateral izquierda y derecha · 19.05 × 38.1 mm", section.IsCurved?"Arriba y en retorno: cubierta y pared lateral de 6.35 mm; ranura igual al espesor de banda + 1.5875 mm. La mayor altura aumenta el agarre dentro del soporte.":"Rebaje superior interior: 12.7 mm de ancho × 6.35 mm de profundidad. Queda una ceja exterior de 6.35 mm.");
                Note("Pletinas centrales · 19.05 × 38.1 mm", "Sección rectangular. Su cara superior coincide con la cara rebajada de ambas laterales.");
                Note("Nivelación", section.IsCurved?"La parte superior de la tira ranurada queda al ras del perfil. La cara superior de la banda queda 7.9375 mm debajo, conservando cubierta de 6.35 mm y holgura de 1.5875 mm. La profundidad lateral del soporte se calcula según el espesor de banda.":"Con ranuras centrales de 25.4 mm, las laterales deben tener 19.05 mm de profundidad. La ceja lateral sobresale 6.35 mm sobre su apoyo. La plaquita queda al nivel inferior de las tiras laterales, sin alojamientos en el nylamid.");
                Note("Alojamientos de plaquitas", "Las laterales llevan alivios inferiores locales donde pasan las plaquitas originales del soporte. Sus extremos y plano de rodadura permanecen completos.");
            }
            else if (index == 8)
            {
                Note("Plaquitas de fijación", "Se requieren en ambos extremos de cada soporte C para atornillarlo a los laterales.");
                Toggle("Incluir plaquitas de fijación", "Obligatorio para generar el ensamble completo con soportes atornillados.", s.IncludeEndPlates, delegate(bool v) { s.IncludeEndPlates = v; });
                N("Lado del orificio cuadrado · mm", "Debe ser igual al orificio del lateral en la categoría Orificios C.", s, "EndPlateHoleSizeMm", 6, 30);
                N("Altura del centro · mm", "Desde el borde inferior de la pestaña frontal del soporte, hacia arriba.", s, "EndPlateHoleYMm", 6, 100);
                N("Espesor de plaquita · mm", "Espesor de las placas soldadas en los extremos.", s, "EndPlateThicknessMm", .5, 10);
                Note("Plaquita al nivel inferior del nylamid", "Se conserva su contorno. El descenso y el alargamiento de ambos dobleces son " + F(s.EndPlateDropMm) + " mm; los orificios del perfil compensan ese descenso.");
                Action("Tomar tamaño del orificio lateral", delegate { s.EndPlateHoleSizeMm = p.SupportHoleSizeMm; ShowCategory(category); Changed(); });
            }
            else if (index == 9) { BuildPlateEditor(section); }
            else if (index == 10) {BuildRollerEditor();}
            else
            {
                Note("Generación del proyecto", "Se crean perfiles y soportes propios para cada tramo y un ensamble BANDA_COMPLETA.SLDASM.");
                Toggle("Incluir guía de desplegados restantes","Las curvas siempre generan sus seis DXF en CNC_CURVAS. Esta opción añade una guía para exportar manualmente las otras piezas de chapa en SOLIDWORKS.",exportFlatPatterns,v=>exportFlatPatterns=v);
                Action("Abrir vista 3D del configurador",Open3D);
                Choice("Presentación en SOLIDWORKS", "Isométrica ajustada, fondo limpio y sin reflejo de piso. Se guarda con el ensamble.",new[]{"Sombreado con aristas","Vista técnica sin sombreado"},shaded3D?"Sombreado con aristas":"Vista técnica sin sombreado",delegate(string v){shaded3D=v=="Sombreado con aristas";});
                Action("Ver última revisión en SOLIDWORKS",delegate{try{SolidWorksPresentation.Open(SolidWorksEnsambleGenerator.LastRevisionAssembly(outputFolder),shaded3D);}catch(Exception ex){status.ForeColor=Color.Firebrick;status.Text=ex.Message;}});
                var pathBox = new TextBox { Text = outputFolder, Dock = DockStyle.Top, Margin = new Padding(0, 6, 0, 12), AccessibleName = "Carpeta de salida", Multiline = true, Height = 60 };
                pathBox.TextChanged += delegate { outputFolder = pathBox.Text; dirty = true; }; Row(pathBox);
                Action("Elegir carpeta de salida", delegate { using (var picker = new FolderBrowserDialog()) { picker.SelectedPath = outputFolder; if (picker.ShowDialog() == DialogResult.OK) { outputFolder = picker.SelectedPath; pathBox.Text = outputFolder; Changed(); } } });
                Note("Contenido generado", "Perfiles, travesaños, guías, patas, transmisión y retorno activados; modelos comerciales seleccionados. Incluye lista de piezas e informe de interferencias CAD.");
                Note("Revisiones del proyecto", "Cada generación crea una carpeta nueva. Una operación incompleta conserva la última revisión terminada y registra su causa.");
            }
            fields.ResumeLayout(); fields.AutoScrollPosition = Point.Empty;
            if (detail != null) { detailHost.Controls.Remove(detail); detail.Dispose(); }
            detail = index == 1 ? (Control)new ProfilePreview() : index == 4 ? new FrontProfilePreview() : index == 5 || index == 8 ? (Control)new SoporteCrossSectionPreview() : index == 6 ? (Control)new SoporteLongitudinalPreview() : index == 7 ? (Control)new SlideRailPreview() : new AssemblyPreview();
            if (index == 2 || index == 3) { detail.Dispose(); detail = new SectionHoleReference { ForLegs = index == 3 }; }
            if (detail is AssemblyPreview) ((AssemblyPreview)detail).Compact = true;
            if(section.IsCurved&&(index==0||index==1||index==2||index==3||index==4)){detail.Dispose();detail=new Label{Text="Geometría curva en el visor 3D.\nLos soportes superiores e inferiores siguen el giro del tramo.",TextAlign=ContentAlignment.MiddleCenter};}
            detail.Dock = DockStyle.Fill; detail.BackColor = Color.White; detailHost.Controls.Add(detail, 0, 1);
            previewTitle.Text = index == 1 ? "REFERENCIA / SECCIÓN DEL LATERAL" : index == 4 ? "REFERENCIA / VISTA DEL LATERAL" : index == 5 || index == 8 ? "REFERENCIA / SECCIÓN DEL SOPORTE" : index == 6 ? "REFERENCIA / GUÍAS DEL SOPORTE" : index == 7 ? "REFERENCIA / NIVEL DE RODADURA" : "REFERENCIA / PLANTA DEL TRAMO";
            if (index == 2) previewTitle.Text = "REFERENCIA / ORIFICIOS EN EL ALMA";
            if (index == 3) previewTitle.Text = "REFERENCIA / ORIFICIOS PARA PATAS";
            if (index == 9) {
                detailHost.Controls.Remove(detail); detail.Dispose();
                detail = new ShaftPlatePreview { Dock = DockStyle.Fill };
                detailHost.Controls.Add(detail, 0, 1);
                previewTitle.Text = "PLACA / EJE Y APOYO DE BANDA";
            }
            if(index==10) {
                detailHost.Controls.Remove(detail);detail.Dispose();detail=rollerAccessPreview?(Control)new FrontProfilePreview():new ReturnRollerPreview();detail.Dock=DockStyle.Fill;detailHost.Controls.Add(detail,0,1);
                previewTitle.Text=rollerAccessPreview?"RODILLOS / BARRENOS CIRCULARES":"RODILLOS / DISTRIBUCIÓN Y CATENARIA";
            }
            RefreshState();
        }

        private void Row(Control control) { int row = form.RowCount++; form.RowStyles.Add(new RowStyle(SizeType.AutoSize)); form.Controls.Add(control, 0, row); }
        private void Note(string title, string hint)
        {
            var l = L(title, 11, DesignUi.Ink); l.Font = new Font("Segoe UI Semibold", 11f, FontStyle.Bold); l.AutoSize = true; l.Dock = DockStyle.Top; l.Margin = new Padding(0, 4, 0, 8); Row(l);
            var h = L(hint, 9, DesignUi.Muted); h.AutoSize = true; h.Dock = DockStyle.Top; h.Margin = new Padding(0, 0, 0, 18); Row(h);
        }
        private void Field(string label, string hint, Control input)
        {
            var l = L(label, 10, DesignUi.Ink); l.AutoSize = true; l.Dock = DockStyle.Top; l.Margin = new Padding(0, 4, 0, 5); Row(l);
            input.Dock = DockStyle.Top; input.Margin = new Padding(0, 0, 0, 5); input.AccessibleName = label; input.AccessibleDescription = hint; Row(input); tips.SetToolTip(input, hint);
            var h = L(hint, 9, DesignUi.Muted); h.Dock = DockStyle.Top; h.AutoSize = true; h.Margin = new Padding(0, 0, 0, 16); Row(h);
        }
        private void SupportCountEditor(BeltSectionSpec section)
        {
            Note("Cantidad de soportes de este tramo", section.IsCurved ? "La cantidad elegida se coloca arriba y abajo de la curva. Los barrenos y las posiciones se actualizan juntos." : "La cantidad elegida actualiza los soportes y sus barrenos en este tramo.");
            Toggle("Cantidad automática", "2 hasta 999 mm; 4 hasta 1999 mm; 6 desde 2000 mm. Desactiva para aumentar o disminuir la cantidad.", section.SupportCount == 0, delegate(bool value) {
                if(value) section.SupportCount=0;
                else { double length=section.IsCurved?section.Curve.CenterLengthMm(section.Profile.BandWidthMm):section.LengthMm; section.SupportCount=length<1000?2:length<2000?4:6; }
                BeginInvoke((Action)delegate { ShowCategory(category); });
            });
            if(section.SupportCount!=0) N("Soportes por nivel · cantidad", "Usa las flechas para aumentar o disminuir, de 2 a 32. Se comprueba que caben y no se superponen; activa Repartir uniformemente para redistribuirlos.", section, "SupportCount", 2, SupportHoleLayout.MaximumCount);
        }
        private void N(string label, string hint, object target, string field, double min, double max)
        {
            FieldInfo member = target.GetType().GetField(field); double value = Convert.ToDouble(member.GetValue(target));
            var n = new NumericUpDown { Name = field, AccessibleName=label, Minimum = (decimal)min, Maximum = (decimal)max, DecimalPlaces = member.FieldType == typeof(int) ? 0 : max<=.01?6:2, Increment = max<=.01?.000001m:max <= 1 ? .01m : 1m, Value = (decimal)Math.Max(min, Math.Min(max, value)), Font = new Font("Segoe UI", 11f) };
            // An imported out-of-range value remains invalid in the model until explicitly corrected.
            if (value < min || value > max) n.BackColor = Color.MistyRose;
            n.ValueChanged += delegate { if(syncingSlotFields)return;member.SetValue(target, member.FieldType == typeof(int) ? (object)(int)n.Value : (object)(double)n.Value); n.BackColor = Color.White; var slotSettings=target as SoporteSettings;if(slotSettings!=null){if(field=="SlotAllowanceMm")slotSettings.SlotWidthMm=SlideRailGeometry.WidthMm+slotSettings.SlotAllowanceMm;else if(field=="SlotWidthMm")slotSettings.SlotAllowanceMm=slotSettings.SlotWidthMm-SlideRailGeometry.WidthMm;if(field=="SlotAllowanceMm"||field=="SlotWidthMm"){string otherField=field=="SlotAllowanceMm"?"SlotWidthMm":"SlotAllowanceMm";var controls=fields.Controls.Find(otherField,true);if(controls.Length>0){var other=controls[0] as NumericUpDown;if(other!=null){syncingSlotFields=true;try{other.Value=(decimal)(field=="SlotAllowanceMm"?slotSettings.SlotWidthMm:slotSettings.SlotAllowanceMm);}finally{syncingSlotFields=false;}}}}} if(field=="CenterSlotCount")SetRailCount((int)n.Value); if(field=="SlotGapMm"){profile.SlotGapMm=(double)n.Value;foreach(var part in sections)if(part.Profile!=null)part.Profile.SlotGapMm=(double)n.Value;} Changed(); };
            Field(label, hint, n);
        }
        private void Toggle(string label, string hint, bool value, Action<bool> set)
        {
            var check = new CheckBox { Text = label, Checked = value, AutoSize = true, Dock = DockStyle.Top, Margin = new Padding(0, 6, 0, 6), AccessibleName = label };
            check.CheckedChanged += delegate { set(check.Checked); Changed(); }; Row(check);
            var h = L(hint, 9, DesignUi.Muted); h.AutoSize = true; h.Dock = DockStyle.Top; h.Margin = new Padding(0, 0, 0, 16); Row(h);
        }
        private void Choice(string label, string hint, string[] items, string value, Action<string> set)
        {
            var combo = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10f) }; combo.Items.AddRange(items); combo.SelectedItem = value;
            combo.SelectedIndexChanged += delegate { set(combo.Text); Changed(); }; Field(label, hint, combo);
        }
        private void Gauge(object target)
        {
            var field = target.GetType().GetField("Gauge");
            Choice("Calibre de lámina", "Seleccionarlo actualiza el espesor nominal. Después puedes ajustar el espesor.", new[] { "10", "12", "14", "16", "18" }, (string)field.GetValue(target), delegate(string v) { field.SetValue(target, v); target.GetType().GetField("ThicknessMm").SetValue(target, ProfileSettings.GaugeThickness(v)); BeginInvoke((Action)delegate { ShowCategory(category); }); });
        }
        private void Action(string text, Action click) { var b = B(text, DesignUi.Primary, click); b.Dock = DockStyle.Top; b.Height = 48; b.Margin = new Padding(0, 4, 0, 16); Row(b); }
        private static Label L(string text, float size, Color color) { return new Label { Text = text, ForeColor = color, Font = new Font("Segoe UI", size) }; }
        private static Button B(string text, Color color, Action click)
        {
            var b = new RoundedButton { Text = text, Height = 40, Width = 98, BackColor = color, ForeColor = color==Color.White?DesignUi.Ink:Color.White, FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand, Margin = new Padding(0, 0, 8, 8), Font = DesignUi.NavigationRegular };
            b.FlatAppearance.BorderSize = 0; b.Click += delegate { click(); }; return b;
        }
        private static string F(double value) { return value.ToString("0.##", CultureInfo.CurrentCulture); }
        private void SaveProject()
        {
            using (var dialog = new SaveFileDialog { Filter = "Proyecto de banda (*.jacband)|*.jacband", FileName = projectPath == null ? "Mi banda.jacband" : Path.GetFileName(projectPath) })
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;
                try { WriteProject(dialog.FileName); } catch (Exception ex) { MessageBox.Show(ex.Message, "No se pudo guardar"); }
            }
        }
        internal void WriteProject(string path)
        {
            rollers.OpenSeats=false;
            string json = DesignJson();
            string temporary = path + ".tmp"; File.WriteAllText(temporary, json, System.Text.Encoding.UTF8);
            if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
            projectPath = path; dirty = false; RefreshState();
        }
        private bool CanDiscard()
        {
            if (!dirty) return true;
            var answer = MessageBox.Show("Hay cambios sin guardar. ¿Quieres guardarlos antes de continuar?", "Proyecto de banda", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (answer == DialogResult.Cancel) return false;
            if (answer == DialogResult.Yes) { SaveProject(); return !dirty; }
            return true;
        }
        private void OnClosing(object sender, FormClosingEventArgs e) { if (generating || !CanDiscard()) e.Cancel = true; }
        private void LoadProject()
        {
            if(generating)return;
            if (!CanDiscard()) return;
            using (var dialog = new OpenFileDialog { Filter = "Proyecto de banda (*.jacband)|*.jacband" })
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;
                try { ReadProject(dialog.FileName); } catch (Exception ex) { MessageBox.Show(ex.Message, "No se pudo abrir"); }
            }
        }
        internal void ReadProject(string path)
        {
            ApplyProjectJson(File.ReadAllText(path),path);
            ResetDesignHistory();
        }
        void ApplyProjectJson(string json,string path) {
            bool previousProject = !json.Contains("\"IncludeSlideRails\"");
            bool previousElevation = !json.Contains("\"BeltThicknessMm\"");
            var project = new JavaScriptSerializer().Deserialize<BeltProject>(json);
            if (project == null || project.Version<1 || project.Version>16 || project.Sections == null || project.Sections.Count < 2 || project.Sections.Count > 24) throw new InvalidDataException("El archivo no es un proyecto de banda compatible.");
            var importedSimulation=project.Simulation??new BeltSimulationSettings();if(Double.IsNaN(importedSimulation.Rpm)||Double.IsInfinity(importedSimulation.Rpm)||importedSimulation.Rpm<0||importedSimulation.Rpm>300)throw new InvalidDataException("RPM de simulación fuera del rango de 0 a 300.");
            var importedVertical=(project.VerticalSupports??new VerticalSupportSettings()).Copy();SettingsValidation.Numbers(importedVertical,"Patas");
            if(project.Version>=3 && (Double.IsNaN(project.SlotGapMm)||Double.IsInfinity(project.SlotGapMm)||project.SlotGapMm<=0||project.SlotGapMm>100000))throw new InvalidDataException("El proyecto contiene una separación global inválida.");
            string importedColor=project.NylamidColor??"Blanco";ViewerMaterials.Nylamid(importedColor);
            var importedRollers=project.Rollers ?? new ReturnRollerSettings();
            importedRollers.OpenSeats=false;
            if(project.Version<14){importedRollers.SlotClearanceMm=10;importedRollers.CurveRollerRiseMm=10;}
            if(project.Version<15)importedRollers.AllowSlotInterruption=true;
            SettingsValidation.Numbers(importedRollers,"Rodillos");
            for (int i = 0; i < project.Sections.Count; i++)
            {
                var s = project.Sections[i];
                if (s == null || s.Profile == null || s.Support == null || Double.IsNaN(s.LengthMm) || Double.IsInfinity(s.LengthMm) || s.LengthMm < 600 || s.LengthMm > 6000) throw new InvalidDataException("El proyecto contiene un tramo incompleto o un largo fuera del rango 600–6000 mm.");
                if ((s.SupportCount != 0 && (s.SupportCount < 2 || s.SupportCount > SupportHoleLayout.MaximumCount)) || s.Support.CenterSlotCount < 0 || s.Support.CenterSlotCount > 8) throw new InvalidDataException("El proyecto contiene una cantidad de soportes o ranuras no admitida.");
                if (s.Type != (i == 0 ? BeltSectionType.Conducido : i == project.Sections.Count - 1 ? BeltSectionType.Motriz : BeltSectionType.Intermedio)) throw new InvalidDataException("El orden de los tipos de tramo no es válido.");
                foreach (object settings in new object[] { s.Profile, s.Support }) foreach (var field in settings.GetType().GetFields()) if (field.FieldType == typeof(double)) { double v = (double)field.GetValue(settings); if (Double.IsNaN(v) || Double.IsInfinity(v) || v < 0 || v > 100000) throw new InvalidDataException("El proyecto contiene una medida no válida: " + field.Name); }
                if(project.Version<16&&Math.Abs(s.Support.SlotWidthMm-SlideRailGeometry.WidthMm)<.01&&s.Support.SlotAllowanceMm<=SlideRailGeometry.DefaultSlotAllowanceMm){s.Support.SlotAllowanceMm=SlideRailGeometry.DefaultSlotAllowanceMm;s.Support.SlotWidthMm=SlideRailGeometry.WidthMm+s.Support.SlotAllowanceMm;}
                if (previousProject) { s.IncludeSlideRails = true; s.Support.OuterSlotDepthMm = s.Support.CenterSlotDepthMm - 6.35; }
                s.Profile.ResolvedSlots=null;s.Profile.ResolvedPattern=null;
                if(project.Version<13){s.Profile.AdaptFunctionalCuts=true;s.Profile.CenteredCuts=false;}
                if(project.Version<4)s.Profile.SlotCombination="";
                if(Array.IndexOf(ProfileSlotLayout.Combinations(),s.Profile.SlotCombination??"")<0)throw new InvalidDataException("El proyecto contiene una combinación no admitida.");
                s.Profile.SlotGapMm=project.Version<3?200:project.SlotGapMm;
                if(project.Version<3) {
                    s.Profile.SlotHeightMm=2*s.Profile.SlotEndRadiusMm;
                    double tangent=-s.Profile.WebHeightMm+(s.Profile.BendRadiusMm+s.Profile.ThicknessMm)*Math.Tan((180-s.Profile.BottomAngleDeg)*Math.PI/360);
                    s.Profile.SlotBottomOffsetMm=-s.Profile.WebHeightMm/2-s.Profile.SlotHeightMm/2-tangent;
                    s.Profile.SlotReferenceLengthMm=2400;
                }
                if(s.Curve==null)s.Curve=new CurveSectionSettings();
                if (s.ShaftPlates == null) s.ShaftPlates = new ShaftPlateSettings();
                if(project.Version==1) s.ShaftPlates.SculptedContour=false;
                if(s.ShaftPlates.Shaft==null)s.ShaftPlates.Shaft=new ConveyorShaftSettings();
                if(project.Version<7)s.ShaftPlates.Shaft.Keyway=s.Type==BeltSectionType.Motriz;
                SettingsValidation.Numbers(s.ShaftPlates.Shaft,"Flecha");
                s.ShaftPlates.Shaft.SprocketColor=s.ShaftPlates.Shaft.SprocketColor??"Amarillo";ViewerMaterials.Nylamid(s.ShaftPlates.Shaft.SprocketColor);
                if(s.ShaftPlates.Shaft.Sprocket!=null){s.ShaftPlates.Shaft.Sprocket.Validate();SprocketCatalog.Default().ModelPath(s.ShaftPlates.Shaft.Sprocket);}
                ShaftPlateGeometry.FiniteSettings(s.ShaftPlates);
                if(s.ShaftPlates.Bearing!=null){s.ShaftPlates.Bearing.Validate();var savedCatalog=BearingCatalog.Default();if(File.Exists(savedCatalog.ModelPath(s.ShaftPlates.Bearing)))BearingModelMesh.Ensure(savedCatalog,s.ShaftPlates.Bearing);}
                E925Sprocket.For(s.ShaftPlates.Teeth);
                if (s.ShaftPlates.ShaftSeatInches != 1.125 && s.ShaftPlates.ShaftSeatInches != 1.25 && s.ShaftPlates.ShaftSeatInches != 1.5)
                    throw new InvalidDataException("El proyecto contiene un diámetro de asiento no admitido.");
                if (s.ShaftPlates.Mounting != 1 && s.ShaftPlates.Mounting != 2)
                    throw new InvalidDataException("El proyecto contiene una unión de placa no admitida.");
            }
            if(!project.IndependentRailCounts)foreach(var part in project.Sections)part.Support.CenterSlotCount=project.Sections[0].Support.CenterSlotCount;
            independentRailCounts=project.IndependentRailCounts;
            applyToAllChanges=project.ApplyToAllChanges;SyncApplyAllSwitch();
            independentSprocketCounts=project.IndependentSprocketCounts;
            if(project.Version<9)independentSprocketCounts=project.Sections.Where(s=>s.Type!=BeltSectionType.Intermedio).Select(s=>s.ShaftPlates.Shaft.SprocketCount).Distinct().Count()>1;
            if(!independentSprocketCounts){int commonCount=project.Sections.First(s=>s.Type!=BeltSectionType.Intermedio).ShaftPlates.Shaft.SprocketCount;foreach(var end in project.Sections.Where(s=>s.Type!=BeltSectionType.Intermedio))end.ShaftPlates.Shaft.SprocketCount=commonCount;}
            supportTemplate.CenterSlotCount=project.Sections[0].Support.CenterSlotCount;
            profile.SlotGapMm=project.Version<3?200:project.SlotGapMm;
            verticalSupports=importedVertical;
            shaded3D=project.Shaded3D;showBeltTrajectory=project.ShowBeltTrajectory;simulationSettings=importedSimulation;if(preview3D!=null&&!preview3D.IsDisposed)preview3D.BindSimulation(simulationSettings);
            exportFlatPatterns=project.ExportFlatPatterns;SetRendererPreference(project.PreferHardware);
            nylamidColor=importedColor;
            sections.Clear(); sections.AddRange(project.Sections);rollers=importedRollers; outputFolder = project.OutputFolder ?? outputFolder; projectPath = path; dirty = project.Version<16 || previousProject || previousElevation; RebuildCards(); SelectSection(0);
        }
        private void Generate()
        {
            StartCadGeneration();
        }
    }

    internal sealed class CompleteBeltPreview : Control
    {
        public IList<BeltSectionSpec> Sections { get; set; }
        public ProfileSettings Profile { get; set; }
        public int SelectedIndex { get; set; }
        public event Action<int> SectionSelected;
        private readonly List<RectangleF> targets = new List<RectangleF>();
        public CompleteBeltPreview() { DoubleBuffered = true; ResizeRedraw = true; BackColor = Color.White; Cursor = Cursors.Hand; TabStop = true; AccessibleName = "Esquema de banda. Selecciona un tramo o usa las flechas izquierda y derecha."; }
        protected override bool IsInputKey(Keys key) { return key == Keys.Left || key == Keys.Right || base.IsInputKey(key); }
        protected override void OnKeyDown(KeyEventArgs e) { base.OnKeyDown(e); if (Sections != null && (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right) && SectionSelected != null) { SectionSelected(Math.Max(0, Math.Min(Sections.Count - 1, SelectedIndex + (e.KeyCode == Keys.Right ? 1 : -1)))); e.Handled = true; } }
        protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e); Focus(); for (int i = 0; i < targets.Count; i++) if (targets[i].Contains(e.Location) && SectionSelected != null) { SectionSelected(i); break; } }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); targets.Clear();
            if (Sections == null || Sections.Count == 0 || Width < 100) return;
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var small = new Font("Segoe UI", 9f))
            using (var bold = new Font("Segoe UI Semibold", 9f, FontStyle.Bold))
            using (var muted = new SolidBrush(DesignUi.Muted))
            using (var ink = new SolidBrush(DesignUi.Ink))
            {
                g.DrawString("RECORRIDO DE LA BANDA   /   Selecciona un tramo para editarlo", bold, ink, 16, 12);
                string arrow = "Retorno  →  Avance hacia motriz"; var size = g.MeasureString(arrow, small); if (Width > 950) g.DrawString(arrow, small, muted, Width - size.Width - 16, 12);
                double total = Math.Max(1, BeltLinePlan.TotalLengthMm(Sections)), offset = 0;
                for (int i = 0; i < Sections.Count; i++)
                {
                    double displayLength=Sections[i].IsCurved?Sections[i].Curve.ExteriorLengthMm(Sections[i].Profile.BandWidthMm):Sections[i].LengthMm;float x = 18 + (float)(offset / total * (Width - 36)); float w = (float)(displayLength / total * (Width - 36));
                    var rect = new RectangleF(x + 2, 40, Math.Max(2, w - 4), Math.Max(32, Height - 86)); targets.Add(rect);
                    Color color = i == SelectedIndex ? DesignUi.Accent : DesignUi.Primary;
                    using (var fill = new SolidBrush(i == SelectedIndex ? Color.FromArgb(224, 244, 236) : DesignUi.Canvas))
                    using (var pen = new Pen(color, i == SelectedIndex ? 3 : 1))
                    using (var rails = new Pen(color, 5))
                    using (var supports = new Pen(Color.FromArgb(143, 166, 180), 2))
                    {
                        g.FillRectangle(fill, rect); g.DrawRectangle(pen, rect.X, rect.Y, rect.Width, rect.Height);
                        g.DrawLine(rails, rect.Left, rect.Top + 3, rect.Right, rect.Top + 3); g.DrawLine(rails, rect.Left, rect.Bottom - 3, rect.Right, rect.Bottom - 3);
                        try { var p = BeltLinePlan.ProfileFor(Sections, i, Profile); foreach (double center in SupportHoleLayout.CentersMm(p)) { float hx = x + (float)(center / total * (Width - 36)); g.DrawLine(supports, hx, rect.Top + 8, hx, rect.Bottom - 8); } } catch { }
                    }
                    string text = (i + 1).ToString("00") + "  " + (Sections[i].IsCurved?"Curva":Sections[i].Type.ToString());
                    if (g.MeasureString(text, bold).Width > rect.Width - 12) text = (i + 1).ToString("00");
                    var labelRect = new RectangleF(rect.X, rect.Y + (rect.Height - 30) / 2, rect.Width, 30);
                    using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center }) g.DrawString(text, bold, ink, labelRect, sf);
                    if (rect.Width > 75) g.DrawString(displayLength.ToString("0") + " mm", small, muted, rect.X + 5, rect.Bottom + 6);
                    offset += displayLength;
                }
                if (Focused) ControlPaint.DrawFocusRectangle(g, new Rectangle(3, 3, Width - 7, Height - 7));
            }
        }
    }
}







