using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
namespace PerfilBandas {
internal sealed partial class CompleteBeltView {
    static readonly string[] componentNames={"Banda y perfil","Soportes y guías","Patas","Placas y flechas","Rodillos","Fabricación"};
    static readonly int[][] componentCategories={new[]{0,1,4},new[]{2,5,6,7,8},new[]{3},new[]{9},new[]{10},new[]{11}};
    static readonly string[] shortCategoryNames={"Dimensiones","Perfil","Distribución","Patas y uniones","Logo y aberturas","Geometría","Ranuras","Guías","Fijaciones","Placas y flechas","Rodillos de retorno","Fabricación"};
    readonly int[] rememberedCategories={0,2,3,9,10,11};
    readonly List<Button> localCategoryButtons=new List<Button>();
    Panel categoryNavigation;Label componentHeading,scopeLabel;TableLayoutPanel categoryLinks;CheckBox applyGroupButton;
    bool applyToAllChanges=true,synchronizingApplyAll;
    void SyncApplyAllSwitch(){if(applyGroupButton==null)return;synchronizingApplyAll=true;try{applyGroupButton.Checked=applyToAllChanges;applyGroupButton.Text=applyToAllChanges?"Aplicar a todos: sí":"Aplicar a todos: no";}finally{synchronizingApplyAll=false;}}
    int navigationGroup=-1;
    static int ComponentFor(int index){for(int i=0;i<componentCategories.Length;i++)if(Array.IndexOf(componentCategories[i],index)>=0)return i;throw new ArgumentOutOfRangeException("index");}
    Control CreateCategoryNavigation(){
        categoryNavigation=new Panel{Name="ComponentNavigation",Dock=DockStyle.Top,BackColor=Color.White,Padding=new Padding(4,4,4,8)};
        componentHeading=new Label{Name="ComponentHeading",Dock=DockStyle.Top,Height=30,TextAlign=ContentAlignment.MiddleLeft,Font=DesignUi.NavigationBold,ForeColor=DesignUi.Ink};
        categoryLinks=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,Margin=Padding.Empty,Padding=Padding.Empty};
        categoryLinks.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));categoryLinks.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
        categoryNavigation.Controls.Add(categoryLinks);categoryNavigation.Controls.Add(componentHeading);return categoryNavigation;
    }
    void SyncCategoryNavigation(int index){
        int group=ComponentFor(index);rememberedCategories[group]=index;
        if(categoryNavigation!=null&&navigationGroup!=group){
            categoryNavigation.SuspendLayout();categoryLinks.SuspendLayout();
            foreach(var button in localCategoryButtons){categoryLinks.Controls.Remove(button);button.Dispose();}localCategoryButtons.Clear();categoryLinks.RowStyles.Clear();
            var entries=componentCategories[group];int rows=entries.Length>1?(entries.Length+1)/2:0;
            categoryLinks.RowCount=rows;categoryLinks.Visible=rows>0;categoryNavigation.Height=42+rows*34;componentHeading.Text=componentNames[group];
            for(int row=0;row<rows;row++)categoryLinks.RowStyles.Add(new RowStyle(SizeType.Absolute,34));
            if(rows>0)for(int i=0;i<entries.Length;i++){
                int target=entries[i];var button=ViewButton(shortCategoryNames[target],()=>OpenDetails(target),150);
                button.Name="CategoryLink_"+target;button.Tag=target;button.Dock=DockStyle.Fill;button.Margin=new Padding(1,1,4,3);button.TextAlign=ContentAlignment.MiddleLeft;button.Padding=new Padding(8,0,0,0);button.AccessibleName=categories[target];tips.SetToolTip(button,categories[target]);
                localCategoryButtons.Add(button);categoryLinks.Controls.Add(button,i%2,i/2);
            }
            navigationGroup=group;categoryLinks.ResumeLayout();categoryNavigation.ResumeLayout();
        }
        foreach(var button in localCategoryButtons){bool active=(int)button.Tag==index;button.BackColor=active?DesignUi.Selection:DesignUi.Canvas;button.ForeColor=active?DesignUi.Primary:DesignUi.Ink;button.Font=active?DesignUi.NavigationBold:DesignUi.NavigationRegular;}
        if(scopeLabel!=null)scopeLabel.Text=index==3||index==10?"Toda la banda":applyToAllChanges&&Array.IndexOf(new[]{0,1,2,4,5,6,7,8},index)>=0?"Todos los tramos":"Este tramo";
        SyncApplyAllSwitch();
        if(applyGroupButton!=null)applyGroupButton.Visible=Array.IndexOf(new[]{0,1,2,4,5,6,7,8},index)>=0;
    }
}
}
