﻿using System;
using System.IO;
using System.Globalization;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
namespace PerfilBandas {
    internal static class SolidWorksConveyorShaftGenerator {
        internal static void Extrude(ModelDoc2 model,string name,double startMm,double lengthMm,Action<SketchManager> draw){
            model.ClearSelection2(true);Feature plane=null;foreach(string n in new[]{"Front Plane","Plano Alzado","Plano frontal","Plano Frontal","Alzado"}){plane=(Feature)((PartDoc)model).FeatureByName(n);if(plane!=null&&plane.Select2(false,0))break;}
            if(plane==null)throw new InvalidOperationException("Flecha: no se encontró Alzado.");
            var sketch=model.SketchManager;sketch.InsertSketch(true);sketch.AddToDB=true;draw(sketch);sketch.AddToDB=false;
            var f=model.FeatureManager.FeatureExtrusion2(true,false,false,0,0,lengthMm/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,startMm==0?0:(int)swStartConditions_e.swStartOffset,Math.Abs(startMm)/1000,startMm<0);
            if(f==null)throw new InvalidOperationException("Flecha: no se creó "+name+".");f.Name=name;model.EditRebuild3();
        }
        public static string Create(SldWorks sw,ConveyorShaftLayout l,string path){return CadReuseSession.Part("Flecha",new{l.Settings,l.SquareLengthMm,l.DiameterMm},path,()=>{CreateUnique(sw,l,path);sw.CloseDoc(Path.GetFileName(path));});}
        static string CreateUnique(SldWorks sw,ConveyorShaftLayout l,string path){
            ConveyorShaftGeometry.Validate(l);string template=sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);var model=(ModelDoc2)sw.NewDocument(template,0,0,0);if(model==null)throw new InvalidOperationException("No se pudo crear la flecha.");
            double half=l.Settings.SquareSideMm/2000,r=l.DiameterMm/2000;
            Extrude(model,"Seccion_Cuadrada_Centrada",0,l.SquareLengthMm,delegate(SketchManager sk){sk.CreateCornerRectangle(-half,-half,0,half,half,0);});
            Extrude(model,"Extremo_Libre_Sin_Cunero",-l.Settings.FreeEndLengthMm,l.Settings.FreeEndLengthMm,delegate(SketchManager sk){sk.CreateCircleByRadius(0,0,0,r);});
            double plain=l.Settings.MotorEndLengthMm-(l.Settings.Keyway?l.Settings.KeyLengthMm:0);
            Extrude(model,"Asiento_Lado_Motor",l.SquareLengthMm,plain,delegate(SketchManager sk){sk.CreateCircleByRadius(0,0,0,r);});
            if(l.Settings.Keyway)Extrude(model,"Extremo_Motor_Con_Cunero",l.SquareLengthMm+plain,l.Settings.KeyLengthMm,delegate(SketchManager sk){
                double a=l.Settings.KeyWidthMm/2000,top=Math.Sqrt(r*r-a*a),bottom=r-l.Settings.KeyDepthMm/1000;
                sk.CreateArc(0,0,0,a,top,0,-a,top,0,-1);sk.CreateLine(-a,top,0,-a,bottom,0);sk.CreateLine(-a,bottom,0,a,bottom,0);sk.CreateLine(a,bottom,0,a,top,0);
            });
            var bodies=(object[])((PartDoc)model).GetBodies2(0,true);if(bodies==null||bodies.Length!=1)throw new InvalidOperationException("Flecha: los extremos no forman un único sólido con el centro cuadrado.");
            double actual=SolidWorksShaftPlateGenerator.Volume(model)*1e9;if(Math.Abs(actual-l.ExpectedVolumeMm3)>Math.Max(.1,l.ExpectedVolumeMm3*.00001))throw new InvalidOperationException("Flecha: el volumen no coincide con la sección cuadrada y el cuñero previstos.");
            var props=model.Extension.get_CustomPropertyManager("");props.Add3("Cuadrado_Largo_mm",30,l.SquareLengthMm.ToString(CultureInfo.InvariantCulture),2);props.Add3("Cuadrado_Lado_mm",30,l.Settings.SquareSideMm.ToString(CultureInfo.InvariantCulture),2);props.Add3("Separacion_Placa_mm",30,"10",2);props.Add3("Lado_Motor",30,l.Settings.MotorOnRight?"RH":"LH",2);
            int error=0,warning=0;if(!model.SaveAs4(path,0,1,ref error,ref warning)||error!=0)throw new InvalidOperationException("No se pudo guardar la flecha (error "+error+").");return path;
        }
    }
}
