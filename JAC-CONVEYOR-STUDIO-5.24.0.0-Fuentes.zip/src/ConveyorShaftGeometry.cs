using System;
using System.Collections.Generic;
using System.Drawing;
namespace PerfilBandas {
    internal sealed class ConveyorShaftSettings {
        public bool Enabled=true,MotorOnRight=true,Keyway=true;
        public double SquareSideMm=38.1,MotorEndLengthMm=101.6,FreeEndLengthMm=101.6;
        public double KeyWidthMm=7.9375,KeyDepthMm=3.97002,KeyLengthMm=50.8;
        public SprocketEntry Sprocket;
        public int SprocketCount=3;
        public string SprocketColor="Amarillo";
        public ConveyorShaftSettings Copy(){var s=(ConveyorShaftSettings)MemberwiseClone();if(Sprocket!=null)s.Sprocket=Sprocket.Copy();return s;}
    }
    internal sealed class ConveyorShaftLayout {
        public const double PlateGapMm=10;
        public double SquareLeftX,SquareRightX,LeftPlateX,RightPlateX,AxisY,AxisZ,DiameterMm;
        public ConveyorShaftSettings Settings;
        public double SquareLengthMm {get{return SquareRightX-SquareLeftX;}}
        public double CenterX {get{return (SquareLeftX+SquareRightX)/2;}}
        public double[] Transform(double longitudinalOffsetMm){bool right=Settings.MotorOnRight;double d=right?1:-1;return new[]{0d,0,-d,0,1,0,d,0,0,(right?SquareLeftX:SquareRightX)/1000,AxisY/1000,(longitudinalOffsetMm+AxisZ)/1000,1,0,0,0};}
        public double ExpectedVolumeMm3 {get{double r=DiameterMm/2,volume=Settings.SquareSideMm*Settings.SquareSideMm*SquareLengthMm+Math.PI*r*r*(Settings.FreeEndLengthMm+Settings.MotorEndLengthMm);if(Settings.Keyway){double a=Settings.KeyWidthMm/2;double removed=a*Math.Sqrt(r*r-a*a)+r*r*Math.Asin(a/r)-Settings.KeyWidthMm*(r-Settings.KeyDepthMm);volume-=removed*Settings.KeyLengthMm;}return volume;}}
    }
    internal static class ConveyorShaftGeometry {
        public static bool Active(BeltSectionSpec section){return ShaftPlateGeometry.Active(section)&&section.ShaftPlates.Shaft!=null&&section.ShaftPlates.Shaft.Enabled;}
        public static ConveyorShaftLayout Calculate(BeltSectionSpec section,ProfileSettings p,SoporteSettings support,ShaftPlateLayout axis,double? leftPlate=null,double? rightPlate=null){
            var s=section.ShaftPlates.Shaft ?? new ConveyorShaftSettings();
            if(s.Sprocket!=null&&!s.Sprocket.MatchesBand(p.BeltModelName))throw new InvalidOperationException("No se pudo ensamblar "+s.Sprocket.Reference+": pertenece a "+(s.Sprocket.BeltModelName??"una banda sin asignar")+" y el tramo utiliza "+p.BeltModelName+". Selecciona un sprocket asociado a esta banda.");
            double left=leftPlate ?? (section.ShaftPlates.Mounting==2?-p.ThicknessMm:0);
            double right=rightPlate ?? (support.LengthMm+(section.ShaftPlates.Mounting==2?p.ThicknessMm:0));
            var l=new ConveyorShaftLayout{LeftPlateX=left,RightPlateX=right,SquareLeftX=left+ConveyorShaftLayout.PlateGapMm,SquareRightX=right-ConveyorShaftLayout.PlateGapMm,AxisY=axis.AxisY,AxisZ=axis.AxisZ,DiameterMm=section.ShaftPlates.ShaftSeatInches*25.4,Settings=s.Copy()};Validate(l);return l;
        }
        public static void Validate(ConveyorShaftLayout l){
            var s=l.Settings;SettingsValidation.Numbers(s,"Flecha");
            if(l.SquareLengthMm<=0||s.SquareSideMm<=0||s.MotorEndLengthMm<=10+ShaftPlateLayout.ThicknessMm||s.FreeEndLengthMm<=10+ShaftPlateLayout.ThicknessMm)throw new InvalidOperationException("Flecha: revisa la sección cuadrada y los largos de ambos extremos; deben atravesar sus placas.");
            if(s.SquareSideMm+1e-8<l.DiameterMm)throw new InvalidOperationException("Flecha: el lado cuadrado debe ser al menos igual al diámetro de los asientos.");
            double r=l.DiameterMm/2,a=s.KeyWidthMm/2;
            if(s.Keyway&&(a<=0||a>=r||s.KeyDepthMm<=r-Math.Sqrt(r*r-a*a)||s.KeyDepthMm>=r||s.KeyLengthMm<=0||s.KeyLengthMm>=s.MotorEndLengthMm))throw new InvalidOperationException("Flecha: revisa ancho, profundidad y longitud del cuñero; debe quedar sólo en el extremo del motor.");
            SprocketGeometry.Centers(l);
        }
        public static PointF[] KeyedProfile(ConveyorShaftLayout l){
            double r=l.DiameterMm/2,a=l.Settings.KeyWidthMm/2,top=Math.Sqrt(r*r-a*a),bottom=r-l.Settings.KeyDepthMm;
            double start=Math.Atan2(top,a),end=Math.PI-start;var points=new List<PointF>();
            for(int i=0;i<=64;i++){double theta=start-(2*Math.PI+start-end)*i/64;points.Add(new PointF((float)(r*Math.Cos(theta)),(float)(r*Math.Sin(theta))));}
            points.Add(new PointF((float)-a,(float)bottom));points.Add(new PointF((float)a,(float)bottom));return points.ToArray();
        }
    }
}

