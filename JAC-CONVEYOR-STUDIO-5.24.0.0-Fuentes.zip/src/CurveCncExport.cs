﻿using System;
using System.IO;
using System.Text;
using System.Globalization;
using System.Collections.Generic;
using System.Web.Script.Serialization;
namespace PerfilBandas {
internal sealed class CncVertex {
 public double X,Y,Bulge;
 public CncVertex(double x,double y,double bulge=0){X=x;Y=y;Bulge=bulge;}
}
internal sealed class CurveCncPart {
 public string Name,Process;
 public double ThicknessMm,WidthMm,HeightMm,InnerRadiusMm,OuterRadiusMm,NeutralRadiusMm,AngleDeg,NetAreaMm2;
 public readonly List<List<CncVertex>> Contours=new List<List<CncVertex>>();
 public int HoleCount {get{return Contours.Count-1;}}
}
// Direct analytic DXF: closed contours only, exact circular arcs encoded as bulges.
// No ExportToDWG2 and no dependency on the CAD application's flat-pattern support.
internal static class CurveCncExport {
 const double Tolerance=1e-7;
 internal static double RadiusAt(CurveFrame frame,double u){return frame.Curve.InnerRadiusMm+frame.Width/2-(frame.Curve.TurnRight?1:-1)*(u-frame.Width/2);}
 static List<CncVertex> Rectangle(double left,double bottom,double width,double height){return new List<CncVertex>{new CncVertex(left,bottom),new CncVertex(left+width,bottom),new CncVertex(left+width,bottom+height),new CncVertex(left,bottom+height)};}
 internal static List<CurveCncPart> Build(CurveSectionSettings curve,ProfileSettings p,SoporteSettings s,CurveFrame frame){
  BeltWidthRules.Validate(p.BeltModelName,p.BandWidthMm);
  SettingsValidation.Numbers(curve,"Curva CNC");SettingsValidation.Numbers(p,"Perfil CNC");
  if(curve.AngleDeg<=0||curve.AngleDeg>180||curve.RollNeutralFactor<=0||curve.RollNeutralFactor>=1||p.ThicknessMm<=0||p.WebHeightMm<=0)throw new InvalidOperationException("CNC de curva: revisa ángulo, espesor, altura y fibra neutra de rolado.");
  double theta=curve.AngleDeg*Math.PI/180,centerRadius=frame.Curve.InnerRadiusMm+frame.Width/2;
  if(centerRadius<=0||Math.Abs(frame.Length-centerRadius*theta)>1e-5||Math.Abs(frame.Width-s.LengthMm)>1e-5)throw new InvalidOperationException("CNC de curva: el marco no coincide con el ángulo o el ancho resuelto.");
  var parts=new List<CurveCncPart>();
  for(int side=0;side<2;side++){
   string label=side==0?"LH":"RH";double u=side==0?0:s.LengthMm,sign=side==0?-1:1;
   double faceA=RadiusAt(frame,u),faceB=RadiusAt(frame,u+sign*p.ThicknessMm),inner=Math.Min(faceA,faceB),outer=Math.Max(faceA,faceB);
   double neutral=inner+curve.RollNeutralFactor*p.ThicknessMm,length=neutral*theta;
   if(inner<=0||p.SupportHoleSizeMm<=0||p.SupportHoleSizeMm/2>=neutral)throw new InvalidOperationException("CNC de curva: radio de alma o barreno no válido.");
   var web=new CurveCncPart{Name=label+"_ALMA",Process="Cortar plano; rolear; soldar cejas",ThicknessMm=p.ThicknessMm,WidthMm=length,HeightMm=p.WebHeightMm,InnerRadiusMm=inner,OuterRadiusMm=outer,NeutralRadiusMm=neutral,AngleDeg=curve.AngleDeg,NetAreaMm2=length*p.WebHeightMm};
   web.Contours.Add(Rectangle(0,0,length,p.WebHeightMm));
   // The CAD radial punch has tangent side planes. Map their intersection with
   // the neutral cylinder (asin), rather than copying route distances verbatim.
   double holeWidth=2*neutral*Math.Asin(p.SupportHoleSizeMm/(2*neutral));
   foreach(double station in SupportHoleLayout.CentersMm(p))foreach(double down in new[]{p.SupportHoleYMm,p.WebHeightMm-p.SupportHoleYMm+p.ResolvedCurveReturnDropMm}){
    double x=station/centerRadius*neutral,y=p.WebHeightMm-down;
    var hole=Rectangle(x-holeWidth/2,y-p.SupportHoleSizeMm/2,holeWidth,p.SupportHoleSizeMm);
    if(hole[0].X<=Tolerance||hole[1].X>=length-Tolerance||hole[0].Y<=Tolerance||hole[2].Y>=p.WebHeightMm-Tolerance)throw new InvalidOperationException("CNC "+web.Name+": un barreno sale del desarrollo del alma; aumenta márgenes o radio.");
    for(int j=1;j<web.Contours.Count;j++){var other=web.Contours[j];if(hole[0].X<other[1].X+Tolerance&&hole[1].X>other[0].X-Tolerance&&hole[0].Y<other[2].Y+Tolerance&&hole[2].Y>other[0].Y-Tolerance)throw new InvalidOperationException("CNC "+web.Name+": barrenos solapados.");}
    web.Contours.Add(hole);web.NetAreaMm2-=holeWidth*p.SupportHoleSizeMm;
   }
   foreach(var slot in CurveWebSlotLayout.Build(frame,p,s,u)){
    double start=slot.StartMm/centerRadius*neutral,width=(slot.EndMm-slot.StartMm)/centerRadius*neutral;
    web.Contours.Add(Rectangle(start,p.WebHeightMm+slot.BottomYMm,width,slot.HeightMm));web.NetAreaMm2-=width*slot.HeightMm;
   }
   parts.Add(web);
   for(int level=0;level<2;level++){
    double flangeWidth=level==0?p.TopFlangeMm:p.BottomFlangeMm;
    double a=RadiusAt(frame,u+sign*p.ThicknessMm),b=RadiusAt(frame,u+sign*flangeWidth),ri=Math.Min(a,b),ro=Math.Max(a,b);
    if(ri<=0||flangeWidth<=p.ThicknessMm)throw new InvalidOperationException("CNC de curva: ceja sin ancho o radio interior positivo.");
    double minX=theta<=Math.PI/2?ri*Math.Cos(theta):ro*Math.Cos(theta),maxY=theta>=Math.PI/2?ro:ro*Math.Sin(theta);
    var flange=new CurveCncPart{Name=label+(level==0?"_CEJA_SUPERIOR":"_CEJA_INFERIOR"),Process="Cortar sector plano; soldar al alma a 90 grados",ThicknessMm=p.ThicknessMm,WidthMm=ro-minX,HeightMm=maxY,InnerRadiusMm=ri,OuterRadiusMm=ro,AngleDeg=curve.AngleDeg,NetAreaMm2=(ro*ro-ri*ri)*theta/2};
    flange.Contours.Add(new List<CncVertex>{new CncVertex(ri-minX,0),new CncVertex(ro-minX,0,Math.Tan(theta/4)),new CncVertex(ro*Math.Cos(theta)-minX,ro*Math.Sin(theta)),new CncVertex(ri*Math.Cos(theta)-minX,ri*Math.Sin(theta),-Math.Tan(theta/4))});
    if(level==1){double radial=CurveLegHoleLayout.RadialCenter(p,u,sign),rho=RadiusAt(frame,radial),half=p.EndHoleSizeMm/2,turn=frame.Curve.TurnRight?1:-1;
     foreach(var placement in CurveLegHoleLayout.Holes(p,frame,radial)){
      double angle=placement.Datum/centerRadius,c=Math.Cos(angle),sin=Math.Sin(angle);var hole=new List<CncVertex>();
      double[] dx={-half,half,half,-half},dz={-half,-half,half,half};
      for(int j=0;j<4;j++){double r=rho-turn*dx[j];hole.Add(new CncVertex(r*c-(dz[j]+placement.Offset)*sin,r*sin+(dz[j]+placement.Offset)*c));}
      ValidateSectorHole(hole,ri,ro,theta,flange.Name);
      foreach(var v in hole)v.X-=minX;
      flange.Contours.Add(hole);flange.NetAreaMm2-=p.EndHoleSizeMm*p.EndHoleSizeMm;
     }
    }
    parts.Add(flange);
   }
  }
  return parts;
 }
 static void ValidateSectorHole(List<CncVertex> hole,double ri,double ro,double theta,string name){
  for(int i=0;i<hole.Count;i++){
   var a=hole[i];var b=hole[(i+1)%hole.Count];double radius=Math.Sqrt(a.X*a.X+a.Y*a.Y),angle=Math.Atan2(a.Y,a.X);
   if(radius<=ri+Tolerance||radius>=ro-Tolerance||angle<=Tolerance||angle>=theta-Tolerance)throw new InvalidOperationException("CNC "+name+": barreno de pata fuera de la ceja; revisa ancho y márgenes.");
   double dx=b.X-a.X,dy=b.Y-a.Y,t=-(a.X*dx+a.Y*dy)/(dx*dx+dy*dy);t=Math.Max(0,Math.Min(1,t));double x=a.X+t*dx,y=a.Y+t*dy;
   if(Math.Sqrt(x*x+y*y)<=ri+Tolerance)throw new InvalidOperationException("CNC "+name+": un borde del barreno atraviesa el radio interior.");
  }
 }
 internal static void Write(string folder,string stem,CurveSectionSettings curve,ProfileSettings p,SoporteSettings s,CurveFrame frame){
  var parts=Build(curve,p,s,frame);string target=Path.Combine(folder,"CNC_CURVAS");Directory.CreateDirectory(target);var manifest=new List<object>();
  foreach(var part in parts){int slots=part.Name.EndsWith("_ALMA")?CurveWebSlotLayout.Build(frame,p,s,part.Name.StartsWith("LH")?0:s.LengthMm).Count:0;string file=stem+"_"+part.Name+".dxf";WriteDxf(Path.Combine(target,file),part);manifest.Add(new{Archivo=file,Pieza=part.Name,Cantidad=1,Proceso=part.Process,EspesorMm=part.ThicknessMm,LargoPlanoMm=part.WidthMm,AltoPlanoMm=part.HeightMm,RadioCaraConcavaMm=part.InnerRadiusMm,RadioCaraConvexaMm=part.OuterRadiusMm,RadioNeutroMm=part.NeutralRadiusMm,AnguloGrados=part.AngleDeg,Barrenos=part.HoleCount-slots,RanurasAlma=slots,AreaNetaMm2=part.NetAreaMm2});}
  double factor;CurveManualRules.TryFactor(p.BandWidthMm,out factor);
  File.WriteAllText(Path.Combine(target,stem+"_CORTE.json"),new JavaScriptSerializer().Serialize(new{Version=2,Unidades="mm",Escala="1:1",FuenteRadios=CurveManualRules.Source,AnchoBandaMm=p.BandWidthMm,FactorRadio=factor,RadioMinimoMm=p.BandWidthMm*factor,RadioElegidoMm=curve.RadiusFor(p.BandWidthMm),Derecha=curve.TurnRight,DescensoRetornoMm=p.ResolvedCurveReturnDropMm,SeparacionLibreSoportesMm=curve.SupportJointGapMm,CentrosSoportesArcoMm=SupportHoleLayout.CentersMm(p),FactorFibraNeutraRolado=curve.RollNeutralFactor,CompensacionCorteMm=0,Piezas=manifest}));
  File.WriteAllText(Path.Combine(target,stem+"_LEEME.txt"),"CORTE CNC DE LATERALES CURVOS - mm, escala 1:1\r\nSeis DXF: alma, ceja superior y ceja inferior por lado LH/RH. Cantidad: una de cada archivo.\r\nCapa CORTE: contornos cerrados; las cejas usan arcos circulares exactos (bulge). No hay cotas ni texto para cortar.\r\nRanuras del alma: dos por espacio entre soportes en el exterior y una en el interior; rectangulares, desarrolladas sobre la fibra neutra. Limite superior 1 mm debajo del soporte completo; inferior 1 mm arriba de la cara superior del nylamid lateral de retorno. Se conservan 2 mm tangenciales junto al soporte y un puente entre ranuras exteriores de hasta 20 mm, ajustado al espacio disponible.\r\nAlma: cortar la tira plana y rolear antes de soldar. Largo = (radio de cara concava + factor de fibra neutra x espesor) x angulo en radianes. El factor configurado se registra en CORTE.json; 0.5 corresponde a media chapa.\r\nBarrenos de soportes: desarrollados sobre la fibra neutra; coordenada longitudinal medida desde la entrada de curva, altura desde el borde inferior. Se proyecta el punzon tangencial del CAD sobre ese cilindro.\r\nCejas: sectores planos independientes, sin plegado; ceja inferior con cuadrados de patas en posiciones y orientaciones del CAD. El ancho de sector excluye el espesor ocupado por el alma.\r\nLos sectores se presentan en coordenadas locales de corte: angulo cero = entrada, angulo final = salida. LH/RH identifican el lado del ensamble; no son necesariamente el interior/exterior.\r\nLos archivos representan la geometria nominal, sin kerf, sobremedidas, compensacion de soldadura ni ajuste de recuperacion elastica del rolado. Aplicar las compensaciones del proceso en CAM.\r\nEl modelo 3D conserva tres cuerpos soldados, sin una operacion nativa Desplegar de SOLIDWORKS. Los DXF se calculan directamente y no usan ExportToDWG2.\r\n");
 }
 static void Pair(StringBuilder text,int code,object value){text.Append(code.ToString(CultureInfo.InvariantCulture)).Append("\r\n").Append(value is double?((double)value).ToString("0.#########",CultureInfo.InvariantCulture):Convert.ToString(value,CultureInfo.InvariantCulture)).Append("\r\n");}
 internal static void WriteDxf(string path,CurveCncPart part){
  var text=new StringBuilder();Pair(text,0,"SECTION");Pair(text,2,"HEADER");Pair(text,9,"$ACADVER");Pair(text,1,"AC1015");Pair(text,9,"$INSUNITS");Pair(text,70,4);Pair(text,9,"$MEASUREMENT");Pair(text,70,1);Pair(text,0,"ENDSEC");
  Pair(text,0,"SECTION");Pair(text,2,"TABLES");Pair(text,0,"TABLE");Pair(text,2,"LTYPE");Pair(text,70,1);Pair(text,0,"LTYPE");Pair(text,2,"CONTINUOUS");Pair(text,70,0);Pair(text,3,"Solid line");Pair(text,72,65);Pair(text,73,0);Pair(text,40,0.0);Pair(text,0,"ENDTAB");
  Pair(text,0,"TABLE");Pair(text,2,"LAYER");Pair(text,70,1);Pair(text,0,"LAYER");Pair(text,2,"CORTE");Pair(text,70,0);Pair(text,62,7);Pair(text,6,"CONTINUOUS");Pair(text,0,"ENDTAB");Pair(text,0,"ENDSEC");
  Pair(text,0,"SECTION");Pair(text,2,"ENTITIES");
  foreach(var contour in part.Contours){Pair(text,0,"LWPOLYLINE");Pair(text,100,"AcDbEntity");Pair(text,8,"CORTE");Pair(text,100,"AcDbPolyline");Pair(text,90,contour.Count);Pair(text,70,1);foreach(var v in contour){Pair(text,10,v.X);Pair(text,20,v.Y);Pair(text,42,v.Bulge);}}
  Pair(text,0,"ENDSEC");Pair(text,0,"EOF");File.WriteAllText(path,text.ToString(),Encoding.ASCII);
 }
}
}


