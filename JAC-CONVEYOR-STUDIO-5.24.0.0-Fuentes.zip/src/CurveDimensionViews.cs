using System;using System.Drawing;using System.Drawing.Drawing2D;
namespace PerfilBandas {
internal sealed partial class DimensionViewsWindow {
 internal static Bitmap BuildRouteSheet(Belt3DGeometry mesh,ProfileSettings p,SoporteSettings s,bool guides,int section){
  var bitmap=new Bitmap(2400,1800);try{using(var g=Graphics.FromImage(bitmap)){
   g.Clear(Color.White);g.SmoothingMode=SmoothingMode.AntiAlias;var frame=mesh.RouteFrames[section];var passage=PassageDimensions.From(p,s,guides);
   using(var title=new Font("Segoe UI",25,FontStyle.Bold))g.DrawString("JAC / TRAZADO CURVO · TRAMO "+(section+1).ToString("00"),title,Brushes.DarkSlateGray,55,25);
   using(var font=new Font("Segoe UI",16))g.DrawString("Unidades: mm · cotas de arco y dimensiones nominales · sin patas en las curvas",font,Brushes.DimGray,55,85);
   RenderView(g,mesh,new Rectangle(45,145,1470,1050),"SUPERIOR / TRAZADO COMPLETO",0,90,-1);
   RenderView(g,mesh,new Rectangle(1510,145,845,1050),"ISOMÉTRICA / TRAMO SELECCIONADO",35,25,section);
   double radius=frame.Curve!=null&&frame.Curve.Enabled?frame.Curve.InnerRadiusMm+(s.LengthMm-p.BandWidthMm)/2:0;
   using(var font=new Font("Segoe UI",20)){string text=radius>0?"Curva "+(frame.Curve.TurnRight?"derecha":"izquierda")+" · ángulo "+frame.Curve.AngleDeg.ToString("0.###")+"°\nRadio interior de banda: "+radius.ToString("0.###")+" mm\nLongitud por centro: "+frame.Length.ToString("0.###")+" mm\nLongitud por borde exterior: "+((radius+p.BandWidthMm)*frame.Curve.AngleDeg*Math.PI/180).ToString("0.###")+" mm":"Tramo recto · longitud "+p.LengthMm.ToString("0.###")+" mm";
    text+="\nLongitud exterior total: "+mesh.Length.ToString("0.###")+" mm\nAncho nominal: "+p.BandWidthMm.ToString("0.###")+" mm · alma: "+p.WebHeightMm.ToString("0.###")+" mm";g.DrawString(text,font,Brushes.DarkSlateGray,80,1245);
    string info="Interior entre perfiles: "+s.LengthMm.ToString("0.###")+" mm\nPaso libre entre labios: "+passage.GuideSpace.ToString("0.###")+" mm\nHolgura total nominal de banda: "+passage.Clearance.ToString("0.###")+" mm\nEspesor de banda: "+p.BeltThicknessMm.ToString("0.###")+" mm\nSoportes superiores: "+p.SupportCount;if(radius>0)info+="\nSoportes inferiores: "+p.SupportCount+"\nPletinas: "+(guides?s.CenterSlotCount+2:0)+" superiores / "+(guides?3:0)+" inferiores";g.DrawString(info,font,Brushes.DarkSlateGray,1240,1245);
   }
  }return bitmap;}catch{bitmap.Dispose();throw;}
 }
}
}