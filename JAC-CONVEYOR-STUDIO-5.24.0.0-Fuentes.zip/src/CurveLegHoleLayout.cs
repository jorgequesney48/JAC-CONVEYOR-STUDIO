﻿using System;
namespace PerfilBandas {
internal sealed class CurvePlateHole {
 internal double Station,Datum,Offset;
 internal BeltPoint3D Point(CurveFrame frame,double radial,double y){var p=frame.Point(radial,y,Datum);double a=frame.HeadingAt(Datum);return new BeltPoint3D(p.X+Offset*Math.Sin(a),y,p.Z+Offset*Math.Cos(a));}
}
internal static class CurveLegHoleLayout {
 internal static CurvePlateHole[] Holes(ProfileSettings p,CurveFrame frame,double radial){var result=new System.Collections.Generic.List<CurvePlateHole>();double scale=CurveCncExport.RadiusAt(frame,radial)/(frame.Curve.InnerRadiusMm+frame.Width/2),delta=p.EndHoleSpacingMm/2/scale;
 foreach(double station in Centers(p,frame,radial)){var hole=new CurvePlateHole{Station=station,Datum=station};if(Math.Abs(Math.Abs(station-frame.Length/2)-delta)<.00001){hole.Datum=frame.Length/2;hole.Offset=station<frame.Length/2?-p.EndHoleSpacingMm/2:p.EndHoleSpacingMm/2;}else if(p.EndHoleTypeLeft=="empalme"&&station<frame.Length/2){hole.Datum=0;hole.Offset=p.EndHoleEdgeMm;}else if(p.EndHoleTypeRight=="empalme"&&station>frame.Length/2){hole.Datum=frame.Length;hole.Offset=-p.EndHoleEdgeMm;}result.Add(hole);}return result.ToArray();}
 internal static double[] LegStations(ProfileSettings p,CurveFrame frame){if(!p.EndHolesBottom)return new double[0];return p.EndHoleTypeRight=="empalme"?new[]{frame.Length/2,frame.Length}:new[]{frame.Length/2};}

 internal static double RadialCenter(ProfileSettings p,double web,double sign){return web+sign*(p.ThicknessMm+p.BottomFlangeMm)/2;}
 internal static double[] Centers(ProfileSettings p,CurveFrame frame,double radial){
  double radius=frame.Curve.InnerRadiusMm+frame.Width/2;
  double scale=(radius-(frame.Curve.TurnRight?1:-1)*(radial-frame.Width/2))/radius;
  var physical=p.Copy();physical.LengthMm=frame.Length*scale;
  if(physical.LengthMm<=p.EndHoleSpacingMm+p.EndHoleSizeMm+2*p.EndHoleEdgeMm)throw new InvalidOperationException("La curva no deja espacio para el par central de agujeros de pata.");
  var holes=VerticalSupportLayout.HoleCenters(physical,false);
  Array.Sort(holes);for(int i=0;i<holes.Length;i++){if(holes[i]<=p.EndHoleSizeMm/2||holes[i]>=physical.LengthMm-p.EndHoleSizeMm/2||(i>0&&holes[i]-holes[i-1]<=p.EndHoleSizeMm))throw new InvalidOperationException("Los agujeros de pata se solapan en la curva; aumenta el ángulo o el radio.");}
  return Array.ConvertAll(holes,z=>z/scale);
 }
}
}
