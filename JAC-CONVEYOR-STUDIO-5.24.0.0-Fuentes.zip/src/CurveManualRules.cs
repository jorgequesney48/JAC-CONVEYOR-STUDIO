using System;
namespace PerfilBandas {
internal static class CurveManualRules {
 public const string Source="E925: tabla completa aportada por el usuario; factores por intervalos confirmados el 2026-10-06";
 internal static readonly double[] WidthBreaks={100,200,300,400,500,600,720,800,1000};
 internal static readonly double[] Factors={1.27,1.60,1.68,1.73,1.82,1.84,1.88,1.88,1.92};
 internal static readonly double[] PrintedRadii={127,320,505,690,910,1106,1350,1500,1918};
 public static bool TryFactor(double width,out double factor){factor=0;if(!BeltWidthRules.IsValidE925(width))return false;for(int i=WidthBreaks.Length-1;i>=0;i--)if(width>=WidthBreaks[i]){factor=Factors[i];return true;}return false;}
 public static bool TryMinimumRadius(double width,out double radius){double factor;bool found=TryFactor(width,out factor);radius=found?width*factor:0;return found;}
 public static int MinimumCenterRails(double width){if(width>=100&&width<=260)return 1;if(width>=280&&width<=660)return 3;if(width>=680&&width<=1060)return 5;if(width>=1080&&width<=1300)return 7;return 0;}
}
}

