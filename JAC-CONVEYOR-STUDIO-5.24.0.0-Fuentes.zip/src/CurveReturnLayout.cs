﻿using System;
using System.Collections.Generic;
namespace PerfilBandas {
internal static class CurveReturnLayout {
 internal static SoporteSettings Support(SoporteSettings upper){var lower=upper.Copy();lower.CenterSlotCount=1;return lower;}
 internal static double SupportY(ProfileSettings p,SoporteSettings s,bool lower){return (lower?-p.WebHeightMm+p.SupportHoleYMm-p.ResolvedCurveReturnDropMm:-p.SupportHoleYMm)-s.EndPlateHoleYMm;}
 internal static double RailBaseY(ProfileSettings p,SoporteSettings s,SlideRailPlacement rail,bool lower){var resolved=lower?Support(s):s;return SupportY(p,resolved,lower)+resolved.ActualFlange1HeightMm-(rail.Position==SlideRailPosition.Center?resolved.CenterSlotDepthMm:resolved.OuterSlotDepthMm);}
 internal static List<SlideRailPlacement> Rails(SoporteSettings upper,double length,bool lower){return SlideRailGeometry.Placements(lower?Support(upper):upper,length);}
}
}
