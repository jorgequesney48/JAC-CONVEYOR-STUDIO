﻿using System;using System.Collections.Generic;
namespace PerfilBandas {
internal sealed class CurveReturnTransition {
 public double BeforeMm,AfterMm,ContactYMm;
 public double GapMm=10,RollerRiseMm=10;
 public double? BeforeRollerYMm,AfterRollerYMm;
 internal double[] Range(SoporteSettings support,CurveFrame frame){var q=SlideRailGeometry.Range(support,1,3,0,frame.Length);double from=BeforeMm>0?0:q[0],to=AfterMm>0?frame.Length:q[0]+q[1];return new[]{from,to-from};}
}
internal static class CurveReturnTransitionLayout {
 internal const double GapMm=10,RollerRiseMm=10;
 internal static double ContactY(ProfileSettings p,SoporteSettings upper){var s=CurveReturnLayout.Support(upper);return CurveReturnLayout.SupportY(p,s,true)+s.ActualFlange1HeightMm-s.CenterSlotDepthMm+SlideRailGeometry.HeightMm;}
 internal static double RollerY(ProfileSettings p,SoporteSettings support,ReturnRollerSettings rollers){return ContactY(p,support)+rollers.CurveRollerRiseMm-rollers.RollerDiameterMm/2;}
 internal static CurveReturnTransition Resolve(IList<BeltSectionSpec> sections,int index,ProfileSettings p,SoporteSettings support,ReturnRollerPlan plan,ReturnRollerSettings rollers){
  var result=new CurveReturnTransition{ContactYMm=ContactY(p,support),RollerRiseMm=rollers==null?10:rollers.CurveRollerRiseMm};if(!sections[index].IncludeSlideRails||rollers==null||!rollers.Enabled||plan==null||plan.Holes.Count==0)return result;
  double radius=rollers.RollerDiameterMm/2;
  if(index>0&&!sections[index-1].IsCurved){var neighbor=sections[index-1];var h=plan.Holes.Find(x=>x.SectionIndex==index-1&&Math.Abs(x.LocalZMm-(neighbor.LengthMm-ReturnRollerLayout.CurveApproachMm))<.00001);if(h==null)throw new InvalidOperationException("Falta el rodillo anterior a la curva para resolver su transición de retorno.");result.BeforeMm=neighbor.LengthMm-h.LocalZMm-radius-GapMm;result.BeforeRollerYMm=h.YMm;}
  if(index+1<sections.Count&&!sections[index+1].IsCurved){var h=plan.Holes.Find(x=>x.SectionIndex==index+1&&Math.Abs(x.LocalZMm-ReturnRollerLayout.CurveApproachMm)<.00001);if(h==null)throw new InvalidOperationException("Falta el rodillo posterior a la curva para resolver su transición de retorno.");result.AfterMm=h.LocalZMm-radius-GapMm;result.AfterRollerYMm=h.YMm;}
  if(result.BeforeMm<0||result.AfterMm<0)throw new InvalidOperationException("El diámetro del rodillo no deja espacio para una prolongación de pletina y su separación de 10 mm.");
  foreach(var y in new[]{result.BeforeRollerYMm,result.AfterRollerYMm})if(y.HasValue&&Math.Abs(y.Value+radius-result.ContactYMm-result.RollerRiseMm)>.00001)throw new InvalidOperationException("La corona del rodillo debe conservar la elevación ajustada sobre el retorno de la curva.");
  return result;
 }
 internal static List<CurveReturnTransition> Build(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,SoporteSettings[] supports,ReturnRollerPlan plan,ReturnRollerSettings rollers){var result=new List<CurveReturnTransition>();for(int i=0;i<sections.Count;i++){result.Add(sections[i].IsCurved?Resolve(sections,i,profiles[i],supports[i],plan,rollers):null);if(i>0&&result[i]!=null&&result[i-1]!=null&&Math.Abs(result[i].ContactYMm-result[i-1].ContactYMm)>.001)throw new InvalidOperationException("Los retornos de curvas consecutivas no pueden quedar a nivel dentro del límite del labio inferior. Revisa las alturas del alma y soportes.");}return result;}
}
}
