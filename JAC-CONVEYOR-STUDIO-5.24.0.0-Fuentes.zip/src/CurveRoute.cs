using System;using System.Collections.Generic;
namespace PerfilBandas {
internal sealed class CurveSectionSettings {
 public bool Enabled,TurnRight=true;
 public bool UseManualMinimum=true;
 public double AngleDeg=90,InnerRadiusMm=1000;
 public double SupportJointGapMm=5; // Free gap at straight/curve and curve/curve support joints.
 public double RollNeutralFactor=.5; // Fraction of thickness from the concave face of the rolled web.
 public CurveSectionSettings Copy(){return (CurveSectionSettings)MemberwiseClone();}
 public double RadiusFor(double width){double radius;return UseManualMinimum&&CurveManualRules.TryMinimumRadius(width,out radius)?radius:InnerRadiusMm;}
 public double CenterLengthMm(double width){return (RadiusFor(width)+width/2)*AngleDeg*Math.PI/180;}
 public double ExteriorLengthMm(double width){return (RadiusFor(width)+width)*AngleDeg*Math.PI/180;}
}
internal sealed class CurveFrame {
 public double X,Z,Heading,Width,Length;public CurveSectionSettings Curve;
 public BeltPoint3D Point(double u,double y,double distance){double x=u,z=distance;if(Curve!=null&&Curve.Enabled){double sign=Curve.TurnRight?1:-1,r=Curve.InnerRadiusMm+Width/2,theta=distance/r;x=Width/2+sign*r-sign*(r-sign*(u-Width/2))*Math.Cos(theta);z=(r-sign*(u-Width/2))*Math.Sin(theta);}return new BeltPoint3D(X+x*Math.Cos(Heading)+z*Math.Sin(Heading),y,Z-x*Math.Sin(Heading)+z*Math.Cos(Heading));}
 public double HeadingAt(double distance){return Heading+(Curve!=null&&Curve.Enabled?(Curve.TurnRight?1:-1)*distance/(Curve.InnerRadiusMm+Width/2):0);}
 public double[] Placement(double distance,bool inverted=false,double lowerWeb=0){double a=HeadingAt(distance),c=Math.Cos(a),s=Math.Sin(a);var origin=Point(0,0,distance);return new[]{c,0,-s,0,inverted?-1.0:1,0,inverted?-s:s,0,inverted?-c:c,origin.X/1000,inverted?-lowerWeb/1000:0,origin.Z/1000,1,0,0,0};}
}
internal static class CurveRoute {
 public static bool HasCurves(IList<BeltSectionSpec> sections){if(sections==null)return false;foreach(var part in sections)if(part!=null&&part.IsCurved)return true;return false;}
 public static void Validate(IList<BeltSectionSpec> sections,ProfileSettings template){if(!HasCurves(sections))return;double width=(sections[0].Profile??template).BandWidthMm;if(!(sections[0].Profile??template).BeltModelName.StartsWith("E925",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Los criterios de curvas conservados corresponden a la familia E925. Falta un manual confirmado para esta otra familia.");
  if(sections[0].IsCurved||sections[sections.Count-1].IsCurved)throw new InvalidOperationException("La entrada y la salida de una banda curva deben ser tramos rectos.");
  if(sections[0].LengthMm<1.5*width||sections[sections.Count-1].LengthMm<1.5*width)throw new InvalidOperationException("Manual de curvas: rectos de entrada y salida de al menos 1.5 veces el ancho nominal.");
  int previous=-1;double between=0;for(int i=0;i<sections.Count;i++){var part=sections[i];if(!part.IsCurved){between+=part.LengthMm;continue;}var curve=part.Curve;SettingsValidation.Numbers(curve,"Curva "+(i+1));if(part.Type!=BeltSectionType.Intermedio)throw new InvalidOperationException("Las curvas deben ser tramos intermedios.");double radius=curve.RadiusFor(width),minimum;if(curve.AngleDeg<=0||curve.AngleDeg>180||radius<=0)throw new InvalidOperationException("Curva: radio positivo y ángulo mayor que 0 y hasta 180 grados (rango de esta versión).");if(curve.RollNeutralFactor<=0||curve.RollNeutralFactor>=1)throw new InvalidOperationException("Curva: el factor de fibra neutra para rolado debe estar entre 0 y 1.");if(radius<=Math.Max((part.Profile??template).TopFlangeMm,(part.Profile??template).BottomFlangeMm)+20)throw new InvalidOperationException("El radio de curva no deja espacio para las cejas soldadas.");if(CurveManualRules.TryMinimumRadius(width,out minimum)&&radius<minimum)throw new InvalidOperationException("El radio interior está por debajo del mínimo calculado con el factor del intervalo E925.");if(previous>=0&&sections[previous].Curve.TurnRight!=curve.TurnRight&&between<2*width)throw new InvalidOperationException("Manual de curvas: giros opuestos necesitan un recto intermedio de al menos 2 veces el ancho nominal.");previous=i;between=0;}
 }
 public static List<CurveFrame> Frames(IList<BeltSectionSpec> sections,SoporteSettings template,ProfileSettings profileTemplate=null){var frames=new List<CurveFrame>();double x=0,z=0,heading=0;foreach(var part in sections){var p=part.Profile??profileTemplate??new ProfileSettings();double width=(part.Support??template).AutoSyncWithBandWidth?SoporteSettings.CalculateLengthFromBand(p.BandWidthMm):(part.Support??template).LengthMm;var frame=new CurveFrame{X=x,Z=z,Heading=heading,Width=width,Curve=part.Curve,Length=part.IsCurved?part.Curve.CenterLengthMm(p.BandWidthMm):part.LengthMm};if(part.IsCurved){ // Radius is measured to the belt inner edge; support spans 20 mm more than the nominal belt.
    frame.Curve=part.Curve.Copy();frame.Curve.InnerRadiusMm=part.Curve.RadiusFor(p.BandWidthMm)-(width-p.BandWidthMm)/2;frame.Curve.UseManualMinimum=false;
   }
   frames.Add(frame);var end=frame.Point(0,0,frame.Length);x=end.X;z=end.Z;heading=frame.HeadingAt(frame.Length);
  }return frames;}
 public static List<BeltSectionSpec> StraightReference(IList<BeltSectionSpec> sections){var result=new List<BeltSectionSpec>();foreach(var part in sections){var copy=part.Copy();if(copy.IsCurved){copy.LengthMm=Math.Max(600,copy.Curve.CenterLengthMm(copy.Profile.BandWidthMm));copy.Curve.Enabled=false;copy.Profile.TopAngleDeg=sections[0].Profile.TopAngleDeg;copy.Profile.BottomAngleDeg=sections[0].Profile.BottomAngleDeg;copy.Profile.BottomFlangeMm=sections[0].Profile.BottomFlangeMm;}result.Add(copy);}return result;}
}
}


