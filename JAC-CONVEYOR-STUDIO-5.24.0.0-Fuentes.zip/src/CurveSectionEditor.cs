﻿using System;using System.Diagnostics;using System.IO;
namespace PerfilBandas {
internal sealed partial class CompleteBeltView {
 internal void AddCurve(){if(generating)return;AddIntermediate();var part=sections[selected];part.Curve=new CurveSectionSettings{Enabled=true};int rails=CurveManualRules.MinimumCenterRails(part.Profile.BandWidthMm);if(rails>0){independentRailCounts=true;part.Support.CenterSlotCount=Math.Max(rails,part.Support.CenterSlotCount);}Changed(-1);OpenDetails(0);WorldPreview.Fit();}
 void CurveEditor(BeltSectionSpec part){
  Note("Tramo curvo · cejas soldadas", "El giro y el radio se aplican sólo a esta curva. Sin dobleces ni rodillos. Travesaños inferiores en el mismo sentido que los superiores; dos pletinas laterales y una central. Dos agujeros de pata en el centro y uno por extremo unido a otra curva.");
  Choice("Sentido del giro","Visto desde arriba, siguiendo la dirección desde conducido hacia motriz.",new[]{"Derecha","Izquierda"},part.Curve.TurnRight?"Derecha":"Izquierda",v=>{part.Curve.TurnRight=v=="Derecha";WorldPreview.Fit();});
  N("Ángulo del giro · °","Rango admitido por esta versión: mayor que 0 y hasta 180°. El PDF no fija este rango.",part.Curve,"AngleDeg",1,180);
  Toggle("Radio mínimo automático · tabla completa","Calcula ancho × factor por intervalos: 100–<200: 1.27; 200–<300: 1.60; 300–<400: 1.68; 400–<500: 1.73; 500–<600: 1.82; 600–<720: 1.84; 720–<800 y 800–<1000: 1.88; desde 1000: 1.92.",part.Curve.UseManualMinimum,v=>{part.Curve.UseManualMinimum=v;BeginInvoke((System.Action)delegate{ShowCategory(category);});});
  if(!part.Curve.UseManualMinimum)N("Radio interior solicitado · mm","Debe respetar el mínimo confirmado para el ancho nominal. Referencia interior interpretada del croquis de página 9.",part.Curve,"InnerRadiusMm",100,10000);
  Note("Radio resuelto: "+F(part.Curve.RadiusFor(part.Profile.BandWidthMm))+" mm","Longitud exterior: "+F(part.Curve.ExteriorLengthMm(part.Profile.BandWidthMm))+" mm · longitud por centro: "+F(part.Curve.CenterLengthMm(part.Profile.BandWidthMm))+" mm. No se usa la cuerda para sumar la longitud.");
  SupportCountEditor(part);
  N("Separación libre entre soportes · mm", "Retira los soportes de los extremos de la curva según radio y ancho del canal, hasta dejar esta holgura con el soporte vecino. Aplica a superiores e inferiores; los barrenos CAD y CNC se actualizan juntos.",part.Curve,"SupportJointGapMm",.5,100);
  N("Fibra neutra del alma roleada · factor", "Desarrollo CNC: radio de la cara cóncava + factor × espesor. 0.5 usa la mitad del espesor; ajustable al proceso de rolado del taller.",part.Curve,"RollNeutralFactor",.01,.99);
  Note("Corte CNC de esta curva", "Al generar CAD se guardan seis DXF 1:1 en CNC_CURVAS: dos almas planas para rolear y cuatro cejas planas para soldar, con sus barrenos. Los laterales 3D siguen como cuerpos soldados.");
  Note("Guías laterales ranuradas en ambos niveles", "Nylamid de 19.05 × 50.8 mm (2 pulgadas de alto): cubierta y pared lateral de 6.35 mm; abertura igual al espesor de banda + 1.5875 mm. El material restante queda debajo. Las pletinas centrales se nivelan con el piso de la ranura. Cara superior de banda: 7.9375 mm bajo el perfil (cubierta de 6.35 mm + holgura de 1.5875 mm); retorno lleva la misma ranura; entrada gradual hacia el rodillo 10 mm más alto.");
  Action("Abrir tabla completa de radios",delegate{OpenCurveReference("E925_tabla_completa_usuario.png");});
  Action("Abrir manual E925 de curvas",OpenCurveManual);
 }
 void OpenCurveManual(){OpenCurveReference("E925_FlushGrid_curvas.pdf");}
 void OpenCurveReference(string name){string root=AppDomain.CurrentDomain.BaseDirectory;foreach(string path in new[]{Path.Combine(root,"assets","manual",name),Path.Combine(root,"..","assets","manual",name)})if(File.Exists(path)){Process.Start(new ProcessStartInfo(Path.GetFullPath(path)){UseShellExecute=true});return;}throw new FileNotFoundException("No se encuentra el manual E925 de curvas guardado.");}
}
}


