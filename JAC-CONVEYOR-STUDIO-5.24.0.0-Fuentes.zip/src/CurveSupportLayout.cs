using System;
using System.Collections.Generic;
namespace PerfilBandas {
// Keep the entire radial cross-support on its side of each joint plane. Its
// inner corner, not its centre-line arc station, controls clearance to a straight.
internal static class CurveSupportLayout {
 internal static double InnerSupportRadius(CurveSectionSettings curve,ProfileSettings p,SoporteSettings s){return curve.RadiusFor(p.BandWidthMm)-(s.LengthMm-p.BandWidthMm)/2;}
 internal static double MinimumEndStation(CurveSectionSettings curve,ProfileSettings p,SoporteSettings s,double gap){
  double inner=InnerSupportRadius(curve,p,s),half=s.WebWidthMm/2,center=curve.RadiusFor(p.BandWidthMm)+p.BandWidthMm/2;
  double amplitude=Math.Sqrt(inner*inner+half*half);
  if(inner<=0||half<=0||gap<0||gap>=amplitude)throw new InvalidOperationException("Curva: dimensiones o separación de soportes no válidas.");
  // inner*sin(theta) - half*cos(theta) = gap, in mm normal to the joint plane.
  return center*(Math.Atan2(half,inner)+Math.Asin(gap/amplitude));
 }
 internal static void Resolve(IList<BeltSectionSpec> sections,int index,ProfileSettings p,SoporteSettings s){
  var section=sections[index];if(!section.IsCurved)return;var curve=section.Curve;
  if(curve.SupportJointGapMm<.5||curve.SupportJointGapMm>100)throw new InvalidOperationException("Curva: la separación libre entre soportes debe estar entre 0.5 y 100 mm.");
  // One curve provides all the gap at a straight joint. Two adjacent curves
  // each provide half, keeping the same total clearance at their common tangent.
  double startGap=index>0&&sections[index-1].IsCurved?Math.Max(curve.SupportJointGapMm,sections[index-1].Curve.SupportJointGapMm)/2:curve.SupportJointGapMm;
  double endGap=index+1<sections.Count&&sections[index+1].IsCurved?Math.Max(curve.SupportJointGapMm,sections[index+1].Curve.SupportJointGapMm)/2:curve.SupportJointGapMm;
  double start=MinimumEndStation(curve,p,s,startGap),end=MinimumEndStation(curve,p,s,endGap);
  var centers=SupportHoleLayout.CentersMm(p);double first=Math.Max(centers[0],start),last=Math.Min(centers[centers.Length-1],p.LengthMm-end);
  // Equal division is retained in automatic mode. Manual interior stations
  // remain unchanged; endpoints move only as much as required for clearance.
  if(section.AutoSupportPitch){for(int i=0;i<centers.Length;i++)centers[i]=first+(last-first)*i/(centers.Length-1);}
  else {centers[0]=first;centers[centers.Length-1]=last;}
  double minimumPitch=Math.Max(70,2*MinimumEndStation(curve,p,s,curve.SupportJointGapMm/2));
  for(int i=0;i<centers.Length;i++){
   if(centers[i]<start-1e-7||centers[i]>p.LengthMm-end+1e-7||i>0&&centers[i]-centers[i-1]<minimumPitch-1e-7)
    throw new InvalidOperationException("Curva: los "+centers.Length+" soportes no caben sin encimarse con la separación libre de "+curve.SupportJointGapMm+" mm. Aumenta el ángulo/radio, reduce la cantidad o activa el reparto automático.");
  }
  p.ResolvedSupportCentersMm=centers;
 }
}
}

