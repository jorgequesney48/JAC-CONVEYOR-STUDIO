﻿using System;using System.Drawing;
namespace PerfilBandas {
internal static class CurveUpperGuideGeometry {
 internal const double HeightMm=50.8; // 2 in: deeper engagement in the curved support.
 internal const double TopMaterialMm=6.35,SideMaterialMm=6.35,ClearanceMm=1.5875;
 // The upper strip is flush with metal: include both cover and groove clearance.
 internal const double BandTopBelowProfileMm=TopMaterialMm+ClearanceMm;
 internal static double EntryRiseMm(double station,double rise=10){return rise*Math.Abs(station)/ReturnRollerLayout.CurveApproachMm;}
 internal static double EntryCapLimit(double rise){return rise<=0?Double.PositiveInfinity:TopMaterialMm*ReturnRollerLayout.CurveApproachMm/rise;}
 internal static double EntryCapLimitMm {get{return EntryCapLimit(10);}}
 internal static double GrooveMm(double thickness){if(Double.IsNaN(thickness)||Double.IsInfinity(thickness)||thickness<=0)throw new InvalidOperationException("El espesor de banda debe ser positivo para la ranura de retención.");return thickness+ClearanceMm;}
 internal static double ContactHeightMm(double thickness){double value=HeightMm-TopMaterialMm-GrooveMm(thickness);if(value<=0)throw new InvalidOperationException("La ranura de banda no deja material debajo en la tira de nylamid de 50.8 mm.");return value;}
 internal static PointF[] SectionMm(double thickness,bool right){float w=(float)SlideRailGeometry.WidthMm,h=(float)HeightMm,wall=(float)SideMaterialMm,lower=(float)ContactHeightMm(thickness),upper=(float)(h-TopMaterialMm);var points=new[]{new PointF(0,0),new PointF(w,0),new PointF(w,lower),new PointF(wall,lower),new PointF(wall,upper),new PointF(w,upper),new PointF(w,h),new PointF(0,h)};if(right)for(int i=0;i<points.Length;i++)points[i].X=w-points[i].X;return points;}
 internal static void Configure(SoporteSettings support,double thickness){support.CurveGuideBandThicknessMm=thickness;support.OuterSlotDepthMm=support.CenterSlotDepthMm+ContactHeightMm(thickness)-SlideRailGeometry.HeightMm;if(support.OuterSlotDepthMm<=0)throw new InvalidOperationException("La ranura de soporte lateral de la curva no tiene profundidad suficiente para este espesor de banda. Aumenta la profundidad central conservando material en el soporte.");}
}
}
