﻿using System;using System.Collections.Generic;
namespace PerfilBandas {
internal sealed class CurveWebSlot {
 public double StartMm,EndMm,TopYMm,BottomYMm;
 public double HeightMm {get{return TopYMm-BottomYMm;}}
}
// Route distances define angular ends. The same sectors are cut in CAD,
// tessellated in the viewer and developed at the neutral radius for CNC.
internal static class CurveWebSlotLayout {
 internal static List<CurveWebSlot> Build(CurveFrame frame,ProfileSettings p,SoporteSettings s,double u){
  var slots=new List<CurveWebSlot>();
  double radius=CurveCncExport.RadiusAt(frame,u),center=frame.Curve.InnerRadiusMm+frame.Width/2;
  bool exterior=radius>center;int count=exterior?2:1;
  double top=CurveReturnLayout.SupportY(p,s,false)+Math.Min(0,s.ActualFlange1HeightMm-s.ActualFlange2HeightMm)-1;
  var lower=CurveReturnLayout.Support(s);
  double bottom=CurveReturnLayout.SupportY(p,lower,true)+lower.ActualFlange1HeightMm-lower.OuterSlotDepthMm+CurveUpperGuideGeometry.HeightMm+1;
  if(top-bottom<1)throw new InvalidOperationException("Las ranuras de curva no caben entre el soporte superior y el nylamid de retorno. Aumenta la altura del alma conservando la nivelación de los tramos.");
  // The support has tangent end planes; bound their intersection at this side.
  double half=s.WebWidthMm/2+2;
  if(half>=radius)throw new InvalidOperationException("El soporte excede el radio de la curva.");
  double inset=center*Math.Asin(half/radius);var stations=SupportHoleLayout.CentersMm(p);
  for(int bay=0;bay<stations.Length-1;bay++){
   double a=stations[bay]+inset,b=stations[bay+1]-inset,available=(b-a)*radius/center;
   double bridge=count==2?Math.Min(20,available/3):0,width=(available-bridge)/count;
   if(width<1)throw new InvalidOperationException("No caben las ranuras entre dos soportes de la curva. Disminuye la cantidad de soportes o aumenta su separación.");
   double step=(width+bridge)*center/radius;
   for(int j=0;j<count;j++)slots.Add(new CurveWebSlot{StartMm=a+j*step,EndMm=a+j*step+width*center/radius,TopYMm=top,BottomYMm=bottom});
  }return slots;
 }
}
}
