using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
namespace PerfilBandas {
internal sealed class CurveCadParts {
 public string Left,Right,UpperSupport,LowerSupport;
 public string[] Legs=new string[2],JointLegs=new string[2];public string Crossbar;
 public readonly List<string> Guides=new List<string>();
 public readonly List<SlideRailPlacement> Placements=new List<SlideRailPlacement>();
 public readonly List<bool> Lower=new List<bool>();
}
internal static partial class SolidWorksEnsambleGenerator {
 // A planar annular sector, extruded through Y. The vertical web and welded lips
 // remain independent bodies, with no sheet-metal bend inserted between them.
 internal static Body2 CurveStrip(SldWorks sw,CurveFrame frame,double fromU,double toU,double top,double height,double start=0,double end=-1){
  if(end<0)end=frame.Length;
  var m=NewLegSketch(sw);string title=m.GetTitle();
  try {
   var sk=m.SketchManager;double sign=frame.Curve.TurnRight?1:-1;
   double center=(frame.Width/2+sign*(frame.Curve.InnerRadiusMm+frame.Width/2))/1000;
   var a=frame.Point(fromU,0,start);var b=frame.Point(fromU,0,end);var c=frame.Point(toU,0,end);var d=frame.Point(toU,0,start);
   if(sk.CreateArc(center,0,0,a.X/1000,a.Z/1000,0,b.X/1000,b.Z/1000,0,(short)-sign)==null||sk.CreateLine(b.X/1000,b.Z/1000,0,c.X/1000,c.Z/1000,0)==null||sk.CreateArc(center,0,0,c.X/1000,c.Z/1000,0,d.X/1000,d.Z/1000,0,(short)sign)==null||sk.CreateLine(d.X/1000,d.Z/1000,0,a.X/1000,a.Z/1000,0)==null)throw new InvalidOperationException("No se pudo dibujar el sector curvo.");
   sk.AddToDB=false;
   var f=m.FeatureManager.FeatureExtrusion2(true,false,false,0,0,height/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
   if(f==null)throw new InvalidOperationException("No se pudo extruir el sector curvo.");
   object[] bodies=(object[])((PartDoc)m).GetBodies2(0,true);if(bodies==null||bodies.Length!=1)throw new InvalidOperationException("El sector no produjo un sólido único.");
   var body=(Body2)((Body2)bodies[0]).Copy();var math=(MathUtility)sw.GetMathUtility();
   if(!body.ApplyTransform((MathTransform)math.CreateTransform(new[]{1.0,0,0,0,0,1,0,-1,0,0,top/1000,0,1,0,0,0})))throw new InvalidOperationException("No se pudo orientar el sector curvo.");
   return body;
  }finally{sw.CloseDoc(title);}
 }
 internal static Body2 CurveGroovedGuideBody(SldWorks sw,CurveFrame frame,double u,double baseY,double thickness,bool right,double start,double end){
  CurveUpperGuideGeometry.ContactHeightMm(thickness);var body=CurveStrip(sw,frame,u,u+SlideRailGeometry.WidthMm,baseY+CurveUpperGuideGeometry.HeightMm,CurveUpperGuideGeometry.HeightMm,start,end);
  double from=right?u-.1:u+CurveUpperGuideGeometry.SideMaterialMm,to=right?u+SlideRailGeometry.WidthMm-CurveUpperGuideGeometry.SideMaterialMm:u+SlideRailGeometry.WidthMm+.1;
  return CurveCut(body,CurveStrip(sw,frame,from,to,baseY+CurveUpperGuideGeometry.HeightMm-CurveUpperGuideGeometry.TopMaterialMm,CurveUpperGuideGeometry.GrooveMm(thickness),start,end));
 }
 internal static Body2 CurveRailEntryTool(SldWorks sw,SlideRailPlacement rail,double baseY,double offset,double length,double thickness,double rise=10){
  var m=NewLegSketch(sw);string title=m.GetTitle();try{
   double bottom=baseY+CurveUpperGuideGeometry.ContactHeightMm(thickness),roof=baseY+CurveUpperGuideGeometry.HeightMm-CurveUpperGuideGeometry.TopMaterialMm;
   double startRoof=roof+CurveUpperGuideGeometry.EntryRiseMm(offset,rise),endRoof=roof+CurveUpperGuideGeometry.EntryRiseMm(offset+length,rise);
   var q=new[]{new[]{offset,bottom},new[]{offset+length,bottom},new[]{offset+length,endRoof},new[]{offset,startRoof}};for(int i=0;i<q.Length;i++){var x=q[i];var y=q[(i+1)%q.Length];m.SketchManager.CreateLine(x[0]/1000,x[1]/1000,0,y[0]/1000,y[1]/1000,0);}m.SketchManager.AddToDB=false;
   double depth=SlideRailGeometry.WidthMm-CurveUpperGuideGeometry.SideMaterialMm+.1;
   if(m.FeatureManager.FeatureExtrusion2(true,false,false,0,0,depth/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false)==null)throw new InvalidOperationException("No se pudo mecanizar la entrada gradual del retorno.");
   var body=(Body2)((Body2)((object[])((PartDoc)m).GetBodies2(0,true))[0]).Copy();double radial=rail.FromLeftMm+(rail.Position==SlideRailPosition.Right?SlideRailGeometry.WidthMm-CurveUpperGuideGeometry.SideMaterialMm:SlideRailGeometry.WidthMm+.1);
   if(!body.ApplyTransform((MathTransform)((MathUtility)sw.GetMathUtility()).CreateTransform(new[]{0d,0,1,0,1,0,-1,0,0,radial/1000,0,0,1,0,0,0})))throw new InvalidOperationException("No se pudo orientar el mecanizado de entrada.");return body;
  }finally{sw.CloseDoc(title);}
 }
 internal static Body2 CurveRailTailBody(SldWorks sw,CurveFrame frame,SlideRailPlacement rail,double baseY,double station,double offset,double length,double bandThickness=0,double rise=10){
  var m=NewLegSketch(sw);string title=m.GetTitle();try{
   bool capture=bandThickness>0&&rail.Position!=SlideRailPosition.Center;
   var contour=capture?new[]{new System.Drawing.PointF(0,0),new System.Drawing.PointF((float)SlideRailGeometry.WidthMm,0),new System.Drawing.PointF((float)SlideRailGeometry.WidthMm,(float)CurveUpperGuideGeometry.HeightMm),new System.Drawing.PointF(0,(float)CurveUpperGuideGeometry.HeightMm)}:rail.Position==SlideRailPosition.Center?SlideRailGeometry.CenterSectionMm():SlideRailGeometry.SideSectionMm(rail.Position==SlideRailPosition.Right);var sk=m.SketchManager;
   for(int i=0;i<contour.Length;i++){var a=contour[i];var b=contour[(i+1)%contour.Length];sk.CreateLine((rail.FromLeftMm+a.X)/1000,(baseY+a.Y)/1000,0,(rail.FromLeftMm+b.X)/1000,(baseY+b.Y)/1000,0);}sk.AddToDB=false;
   if(m.FeatureManager.FeatureExtrusion2(true,false,false,0,0,length/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false)==null)throw new InvalidOperationException("No se pudo extruir la prolongación tangente de retorno.");
   var body=(Body2)((Body2)((object[])((PartDoc)m).GetBodies2(0,true))[0]).Copy();var math=(MathUtility)sw.GetMathUtility();
   if(!body.ApplyTransform((MathTransform)math.CreateTransform(Translation(0,0,offset/1000))))throw new InvalidOperationException("No se pudo situar la prolongación de retorno.");
   if(capture)body=CurveCut(body,CurveRailEntryTool(sw,rail,baseY,offset,length,bandThickness,rise));
   if(!body.ApplyTransform((MathTransform)math.CreateTransform(frame.Placement(station))))throw new InvalidOperationException("No se pudo orientar la prolongación de retorno.");return body;
  }finally{sw.CloseDoc(title);}
 }
 static Body2 CurveHoleTool(SldWorks sw,CurveFrame frame,double u,double y,double station,double size,double depth){
  var m=NewLegSketch(sw);string title=m.GetTitle();try{
   m.SketchManager.CreateCornerRectangle(-size/2000,-size/2000,0,size/2000,size/2000,0);m.SketchManager.AddToDB=false;
   if(m.FeatureManager.FeatureExtrusion2(true,false,false,0,0,depth/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false)==null)throw new InvalidOperationException("No se pudo crear el útil para el barreno de soporte.");
   var body=(Body2)((Body2)((object[])((PartDoc)m).GetBodies2(0,true))[0]).Copy();double a=frame.HeadingAt(station),c=Math.Cos(a),s=Math.Sin(a);var origin=frame.Point(u+depth/2,y,station);
   if(!body.ApplyTransform((MathTransform)((MathUtility)sw.GetMathUtility()).CreateTransform(new[]{s,0,c,0,1,0,-c,0,s,origin.X/1000,origin.Y/1000,origin.Z/1000,1,0,0,0})))throw new InvalidOperationException("No se pudo orientar el barreno de soporte.");return body;
  }finally{sw.CloseDoc(title);}
 }
 static Body2 CurveCut(Body2 body,Body2 tool){int error=0;var result=body.Operations2((int)swBodyOperationType_e.SWBODYCUT,tool,out error) as object[];if(error!=0||result==null||result.Length!=1)throw new InvalidOperationException("No se pudo recortar el alojamiento en la curva ("+error+").");return (Body2)result[0];}
 static Body2 CurveLegHoleTool(SldWorks sw,CurveFrame frame,double radial,CurvePlateHole hole,ProfileSettings p){
  var m=NewLegSketch(sw);string title=m.GetTitle();try{
   double half=p.EndHoleSizeMm/2000,depth=(p.ThicknessMm+4)/1000;m.SketchManager.CreateCornerRectangle(-half,-half,0,half,half,0);m.SketchManager.AddToDB=false;
   if(m.FeatureManager.FeatureExtrusion2(true,false,false,0,0,depth,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false)==null)throw new InvalidOperationException("No se pudo crear el agujero de pata en la curva.");
   var body=(Body2)((Body2)((object[])((PartDoc)m).GetBodies2(0,true))[0]).Copy();double a=frame.HeadingAt(hole.Datum),c=Math.Cos(a),s=Math.Sin(a);var origin=hole.Point(frame,radial,-p.WebHeightMm+p.ThicknessMm+2);
   if(!body.ApplyTransform((MathTransform)((MathUtility)sw.GetMathUtility()).CreateTransform(new[]{c,0,-s,s,0,c,0,-1,0,origin.X/1000,origin.Y/1000,origin.Z/1000,1,0,0,0})))throw new InvalidOperationException("No se pudo orientar el agujero de pata en la curva.");return body;
  }finally{sw.CloseDoc(title);}
 }
 static void SaveCurveBodies(SldWorks sw,string target,List<Body2> bodies,string[] names,CurveSectionSettings curve,double width){
  SolidWorksDocumentSafety.Check(sw,new[]{target});
  var m=(ModelDoc2)sw.NewDocument(sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart),0,0,0);if(m==null)throw new InvalidOperationException("No se pudo crear la pieza curva.");string title=m.GetTitle();try{
   for(int i=0;i<bodies.Count;i++){var f=(Feature)((PartDoc)m).CreateFeatureFromBody3(bodies[i],false,0);if(f==null)throw new InvalidOperationException("No se pudo insertar "+names[i]);f.Name=names[i];}
   var props=m.Extension.get_CustomPropertyManager("");props.Add3("Radio_interior_banda_mm",30,curve.RadiusFor(width).ToString(CultureInfo.InvariantCulture),2);props.Add3("Angulo_curva_grados",30,curve.AngleDeg.ToString(CultureInfo.InvariantCulture),2);props.Add3("Construccion",30,names[0].StartsWith("Alma")?"Alma curva y cejas independientes soldadas a 90 grados; sin dobleces":names[0].Contains("Ranura_C")?"Tira mecanizada de 19.05 x 50.8 mm: pared lateral y cubierta de 6.35 mm; ranura espesor de banda + 1.5875 mm":"Pletina curva; sección de deslizamiento existente",2);
   int e=0,w=0;m.EditRebuild3();if(!m.SaveAs4(target,0,1,ref e,ref w)||e!=0)throw new InvalidOperationException("No se guardó la pieza curva: "+target+" ("+e+").");
  }finally{sw.CloseDoc(m.GetTitle());}
 }
 internal static CurveCadParts CreateCurveParts(SldWorks sw,BeltSectionSpec section,ProfileSettings p,SoporteSettings s,CurveFrame placed,string folder,string stem,CurveReturnTransition transition=null,string only=null){
  var frame=new CurveFrame{Width=placed.Width,Length=placed.Length,Curve=placed.Curve};var result=new CurveCadParts{Left=Path.Combine(folder,stem+"_LH.SLDPRT"),Right=Path.Combine(folder,stem+"_RH.SLDPRT"),UpperSupport=Path.Combine(folder,stem+"_SOPORTE_SUPERIOR.SLDPRT"),LowerSupport=Path.Combine(folder,stem+"_SOPORTE_INFERIOR.SLDPRT")};
  SolidWorksDocumentSafety.Check(sw,only==null?new[]{result.Left,result.Right,result.UpperSupport,result.LowerSupport}:new[]{Path.Combine(folder,stem+"_"+only+".SLDPRT")});
  for(int side=0;side<2;side++){
   if(only!=null&&only!=(side==0?"LH":"RH"))continue;string target=side==0?result.Left:result.Right;
   string shared=CadReuseSession.Part("Perfil_curvo_soldado",new{Perfil=CadReuseSession.ProfileGeometry(p),Soporte=s,frame.Width,frame.Length,frame.Curve,Lado=side},target,()=>{
   double u=side==0?0:s.LengthMm,sign=side==0?-1:1;
   var web=CurveStrip(sw,frame,u,u+sign*p.ThicknessMm,0,p.WebHeightMm);
   foreach(double z in SupportHoleLayout.CentersMm(p))foreach(double y in new[]{-p.SupportHoleYMm,-p.WebHeightMm+p.SupportHoleYMm-p.ResolvedCurveReturnDropMm})web=CurveCut(web,CurveHoleTool(sw,frame,u+sign*p.ThicknessMm/2,y,z,p.SupportHoleSizeMm,4*p.ThicknessMm+4));
   foreach(var slot in CurveWebSlotLayout.Build(frame,p,s,u))web=CurveCut(web,CurveStrip(sw,frame,Math.Min(u,u+sign*p.ThicknessMm)-1,Math.Max(u,u+sign*p.ThicknessMm)+1,slot.TopYMm,slot.HeightMm,slot.StartMm,slot.EndMm));
   var flange=CurveStrip(sw,frame,u+sign*p.ThicknessMm,u+sign*p.BottomFlangeMm,-p.WebHeightMm+p.ThicknessMm,p.ThicknessMm);double radial=CurveLegHoleLayout.RadialCenter(p,u,sign);
   foreach(var hole in CurveLegHoleLayout.Holes(p,frame,radial))flange=CurveCut(flange,CurveLegHoleTool(sw,frame,radial,hole,p));
   var bodies=new List<Body2>{web,CurveStrip(sw,frame,u+sign*p.ThicknessMm,u+sign*p.TopFlangeMm,0,p.ThicknessMm),flange};
   SaveCurveBodies(sw,side==0?result.Left:result.Right,bodies,new[]{"Alma_curva_con_barrenos","Ceja_superior_soldada_90","Ceja_inferior_soldada_90"},section.Curve,p.BandWidthMm);
   });if(side==0)result.Left=shared;else result.Right=shared;
  }
  if(only==null||only=="SOPORTE_SUPERIOR")result.UpperSupport=ReusableSupport(sw,s,result.UpperSupport);sw.CloseDoc(Path.GetFileName(result.UpperSupport));var lower=CurveReturnLayout.Support(s);if(only==null||only=="SOPORTE_INFERIOR")result.LowerSupport=ReusableSupport(sw,lower,result.LowerSupport);sw.CloseDoc(Path.GetFileName(result.LowerSupport));
  if(section.IncludeSlideRails){var range=SlideRailGeometry.Range(s,1,3,0,frame.Length);
   for(int level=0;level<2;level++)foreach(var rail in CurveReturnLayout.Rails(s,p.LengthMm,level==1)){
    bool bottom=level==1;string railSuffix="GUIA_"+(bottom?"INFERIOR_":"SUPERIOR_")+rail.Index.ToString("00");if(only!=null&&only!=railSuffix)continue;var railRange=bottom&&transition!=null?transition.Range(s,frame):range;double h=rail.Position==SlideRailPosition.Center?38.1:31.75,u=rail.FromLeftMm;double railBaseY=CurveReturnLayout.RailBaseY(p,s,rail,bottom);
    string target=Path.Combine(folder,stem+"_GUIA_"+(bottom?"INFERIOR_":"SUPERIOR_")+rail.Index.ToString("00")+".SLDPRT");
    bool capture=rail.Position!=SlideRailPosition.Center;var railSupport=bottom?lower:s;
    string shared=CadReuseSession.Part("Pletina_curva",new{ElevacionEntradaMm=p.ResolvedCurveRollerRiseMm,EspesorRanura=capture?p.BeltThicknessMm:0,frame.Width,frame.Length,frame.Curve,rail.Position,u,railBaseY,Rango=railRange,Relieves=SlideRailGeometry.EndPlateReliefs(p,railSupport,rail.Position,railSupport.ActualFlange1HeightMm),Anterior=bottom&&transition!=null?transition.BeforeMm:0,Posterior=bottom&&transition!=null?transition.AfterMm:0},target,()=>{
    var bodies=new List<Body2>();
    // Lower rails keep the upper cross-section orientation at the return level.

    if(capture)bodies.Add(CurveGroovedGuideBody(sw,frame,u,railBaseY,p.BeltThicknessMm,rail.Position==SlideRailPosition.Right,railRange[0],railRange[0]+railRange[1]));
    else bodies.Add(CurveStrip(sw,frame,u,u+19.05,railBaseY+h,h,railRange[0],railRange[0]+railRange[1]));
    if(rail.Position!=SlideRailPosition.Center){if(!capture){double lipU=u+(rail.Position==SlideRailPosition.Right?12.7:0);bodies.Add(CurveStrip(sw,frame,lipU,lipU+6.35,railBaseY+38.1,6.35,railRange[0],railRange[0]+railRange[1]));}
     foreach(var relief in SlideRailGeometry.EndPlateReliefs(p,railSupport,rail.Position,railSupport.ActualFlange1HeightMm)){double start=Math.Max(railRange[0],relief.StartZ),end=Math.Min(railRange[0]+railRange[1],relief.EndZ);if(end<=start)continue;double top=railBaseY+relief.DepthMm;
      bodies[0]=CurveCut(bodies[0],CurveStrip(sw,frame,u+relief.FromX,u+relief.ToX,top,relief.DepthMm+.1,start,end));}
    }
    var names=new List<string>{capture?"Pletina_lateral_curva_Ranura_C":rail.Position==SlideRailPosition.Center?"Pletina_central_curva":"Pletina_lateral_curva"};if(!capture&&rail.Position!=SlideRailPosition.Center)names.Add("Labio_retencion");
    if(bottom&&transition!=null){if(transition.BeforeMm>0){bodies.Add(CurveRailTailBody(sw,frame,rail,railBaseY,0,-transition.BeforeMm,transition.BeforeMm,p.BeltThicknessMm,p.ResolvedCurveRollerRiseMm));names.Add("Prolongacion_tangente_anterior");}if(transition.AfterMm>0){bodies.Add(CurveRailTailBody(sw,frame,rail,railBaseY,frame.Length,0,transition.AfterMm,p.BeltThicknessMm,p.ResolvedCurveRollerRiseMm));names.Add("Prolongacion_tangente_posterior");}}
    SaveCurveBodies(sw,target,bodies,names.ToArray(),section.Curve,p.BandWidthMm);
    });result.Guides.Add(shared);result.Placements.Add(rail);result.Lower.Add(bottom);
   }
  }if(only==null)CurveCncExport.Write(folder,stem,section.Curve,p,s,frame);return result;
 }
 static int PlaceCurveParts(SldWorks sw,AssemblyDoc assembly,ModelDoc2 model,MathUtility math,CurveCadParts parts,ProfileSettings p,SoporteSettings s,CurveFrame frame){
  int count=0;foreach(string path in new[]{parts.Left,parts.Right}){var c=InsertComponentHelper(sw,assembly,path,0,0,0);FixPlacedComponent(model,assembly,c,math,frame.Placement(0),"perfil curvo soldado");count++;}
  double hcx=s.WebWidthMm/2000;
  foreach(double station in SupportHoleLayout.CentersMm(p))for(int lower=0;lower<2;lower++){
   double sy=CurveReturnLayout.SupportY(p,s,lower==1)/1000;var local=(MathTransform)math.CreateTransform(new[]{0.0,0,-1,0,1,0,1,0,0,0,sy,hcx,1,0,0,0});var move=(MathTransform)math.CreateTransform(frame.Placement(station));var transform=(MathTransform)local.Multiply(move);var path=lower==1?parts.LowerSupport:parts.UpperSupport;var c=InsertComponentHelper(sw,assembly,path,0,0,0);FixPlacedComponent(model,assembly,c,math,(double[])transform.ArrayData,lower==1?"soporte inferior curva":"soporte superior curva");count++;
  }
  foreach(string path in parts.Guides){var c=InsertComponentHelper(sw,assembly,path,0,0,0);FixPlacedComponent(model,assembly,c,math,frame.Placement(0),"pletina de curva");count++;}return count;
 }
 static HashSet<string> ComponentNames(AssemblyDoc assembly){var result=new HashSet<string>();var components=assembly.GetComponents(true) as object[];if(components!=null)foreach(Component2 c in components)result.Add(c.Name2);return result;}
 static void MoveStraightSection(AssemblyDoc assembly,ModelDoc2 model,MathUtility math,HashSet<string> before,CurveFrame frame,double offset){
  var remove=(MathTransform)math.CreateTransform(Translation(0,0,-offset));var move=(MathTransform)math.CreateTransform(frame.Placement(0));foreach(Component2 c in (object[])assembly.GetComponents(true))if(!before.Contains(c.Name2)){
   var original=(MathTransform)c.Transform2;var mapped=(MathTransform)((MathTransform)original.Multiply(remove)).Multiply(move);FixPlacedComponent(model,assembly,c,math,(double[])mapped.ArrayData,"tramo recto sobre trazado curvo");
  }
 }
}
}

