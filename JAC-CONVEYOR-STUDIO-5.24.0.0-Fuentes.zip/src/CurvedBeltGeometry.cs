using System;using System.Collections.Generic;using System.Drawing;using System.Linq;
namespace PerfilBandas {
internal sealed partial class Belt3DGeometry {
 static Belt3DGeometry BuildCurved(IList<BeltSectionSpec> sections,ProfileSettings template,SoporteSettings supportTemplate,ReturnRollerSettings rollers,string color,BearingCatalog bearings,SprocketCatalog sprockets,VerticalSupportSettings legs,BeltDesignPlan supplied,bool showTrajectory){
  var plan=supplied??BeltDesignPlan.Build(sections,template,supportTemplate,rollers,legs,bearings,sprockets);
  if(plan.Issues.Exists(i=>i.Blocking&&!i.Message.StartsWith("Tabla E925:")))plan.RequireValid();
  var reference=CurveRoute.StraightReference(sections);var referencePlan=BeltDesignPlan.Build(reference,template,supportTemplate,new ReturnRollerSettings{Enabled=false},legs,bearings,sprockets);
  for(int i=0;i<sections.Count;i++)if(!sections[i].IsCurved){referencePlan.Profiles[i]=plan.Profiles[i];referencePlan.Supports[i]=plan.Supports[i];}
  // The reference mesh uses the straightened lengths; roller centres remain local to each real section.
  var referenceRollers=new ReturnRollerPlan();double referenceOffset=0;
  for(int i=0;i<sections.Count;i++){foreach(var hole in plan.Rollers.Holes)if(hole.SectionIndex==i){var copy=hole.Copy();copy.GlobalZMm=referenceOffset+copy.LocalZMm;referenceRollers.Holes.Add(copy);}referenceOffset+=referencePlan.Profiles[i].LengthMm;}
  referencePlan.Rollers=referenceRollers;
  var straight=Build(reference,template,supportTemplate,rollers,color,bearings,sprockets,legs,referencePlan,false);
  var frames=CurveRoute.Frames(sections,supportTemplate,template);var mesh=new Belt3DGeometry{Length=BeltLinePlan.TotalLengthMm(sections),Width=frames[0].Width,RouteFrames=frames};double offset=0;
  for(int i=0;i<sections.Count;i++){var p=plan.Profiles[i];var s=plan.Supports[i];var frame=frames[i];mesh.Starts.Add(offset);mesh.Lengths.Add(frame.Length);mesh.Profiles.Add(p);mesh.Patterns.Add(ProfileSlotLayout.PatternFor(p));
   if(!sections[i].IsCurved){foreach(var face in straight.Faces)if(face.Section==i){double start=straight.Starts[i];face.Outer=Array.ConvertAll(face.Outer,q=>frame.Point(q.X,q.Y,q.Z-start));for(int h=0;h<face.Holes.Count;h++)face.Holes[h]=Array.ConvertAll(face.Holes[h],q=>frame.Point(q.X,q.Y,q.Z-start));mesh.Faces.Add(face);}}
   else {mesh.CurveComponents(frame,p,s,sections[i].IncludeSlideRails,i,ViewerMaterials.Nylamid(color),CurveReturnTransitionLayout.Resolve(sections,i,p,s,plan.Rollers,rollers));mesh.CurveLegs(frame,p,s,legs??new VerticalSupportSettings(),i,i+1<sections.Count?plan.Profiles[i+1]:null,i+1<sections.Count?plan.Supports[i+1]:null,i+1<sections.Count?frames[i+1]:null);}offset+=frame.Length;
  }mesh.Trajectory=BeltTrajectory.Build(sections,plan,supportTemplate,rollers);mesh.BeginPart("trajectory");if(showTrajectory)mesh.AddTrajectory(mesh.Trajectory);return mesh;
 }
 void SweepCurve(CurveFrame frame,PointF[] cross,double from,double to,int section,Color color,Action<BeltFace3D> tag){
  int steps=Math.Max(1,(int)Math.Ceiling((to-from)/frame.Length*frame.Curve.AngleDeg/1));
  var first=Array.ConvertAll(cross,q=>frame.Point(q.X,q.Y,from));var last=Array.ConvertAll(cross,q=>frame.Point(q.X,q.Y,to));tag(Face(first,section,color,color==Steel?BeltSurface3D.StainlessSteel:BeltSurface3D.Nylamid));tag(Face(last,section,color,color==Steel?BeltSurface3D.StainlessSteel:BeltSurface3D.Nylamid));
  for(int k=0;k<steps;k++){double a=from+(to-from)*k/steps,b=from+(to-from)*(k+1)/steps;for(int j=0;j<cross.Length;j++){var p=cross[j];var q=cross[(j+1)%cross.Length];var face=Face(new[]{frame.Point(p.X,p.Y,a),frame.Point(q.X,q.Y,a),frame.Point(q.X,q.Y,b),frame.Point(p.X,p.Y,b)},section,color,color==Steel?BeltSurface3D.StainlessSteel:BeltSurface3D.Nylamid);face.ParametricFaceKey=facePart+"/surface/"+j;face.FaceParameter=(k+.5)/steps;face.DrawEdges=j==0||j==cross.Length-1;tag(face);}}
 }
 void CurveComponents(CurveFrame frame,ProfileSettings p,SoporteSettings s,bool rails,int section,Color plastic,CurveReturnTransition transition=null){
  var stations=SupportHoleLayout.CentersMm(p);double sy=-p.SupportHoleYMm-s.EndPlateHoleYMm;
  foreach(double u in new[]{0.0,s.LengthMm}){double outward=u==0?-1:1,thickness=p.ThicknessMm;
   BeginPart("s"+section+"/curve/profile/"+(u==0?0:1)+"/web");CurvedWeb(frame,p,s,u,u+outward*thickness,section);
   BeginPart("s"+section+"/curve/profile/"+(u==0?0:1)+"/top");SweepCurve(frame,Rectangle(Math.Min(u+outward*thickness,u+outward*p.TopFlangeMm),-thickness,p.TopFlangeMm-thickness,thickness),0,frame.Length,section,Steel,f=>f.IsCurveFlange=true);
   BeginPart("s"+section+"/curve/profile/"+(u==0?0:1)+"/bottom");CurvedLegFlange(frame,p,u,outward,section);
  }
  foreach(double station in stations){var upper=new Belt3DGeometry();upper.BeginPart("s"+section+"/curve/support/upper/"+Array.IndexOf(stations,station));upper.CrossSupport(s,sy,0,section);AppendCurveSupport(upper,frame,station,false);var lower=new Belt3DGeometry();lower.BeginPart("s"+section+"/curve/support/lower/"+Array.IndexOf(stations,station));var ls=CurveReturnLayout.Support(s);lower.CrossSupport(ls,CurveReturnLayout.SupportY(p,ls,true),0,section);AppendCurveSupport(lower,frame,station,true);}
  if(!rails)return;var range=SlideRailGeometry.Range(s,1,3,0,frame.Length);
  for(int level=0;level<2;level++)foreach(var rail in CurveReturnLayout.Rails(s,p.LengthMm,level==1)){BeginPart("s"+section+"/curve/rail/"+level+"/"+rail.Index);double y=CurveReturnLayout.RailBaseY(p,s,rail,level==1);
   var contour=rail.Position==SlideRailPosition.Center?SlideRailGeometry.CenterSectionMm():CurveUpperGuideGeometry.SectionMm(p.BeltThicknessMm,rail.Position==SlideRailPosition.Right);
   bool lower=level==1;var cross=Array.ConvertAll(contour,q=>new PointF((float)(rail.FromLeftMm+q.X),(float)(y+q.Y)));var railRange=lower&&transition!=null?transition.Range(s,frame):range;SweepCurve(frame,cross,railRange[0],railRange[0]+railRange[1],section,plastic,f=>{f.IsCurveUpperGuide=!lower;f.IsCurveLowerGuide=lower;});
   if(lower&&transition!=null){CurveRailTail(frame,cross,0,-transition.BeforeMm,transition.BeforeMm,section,plastic,p.BeltThicknessMm,rail.Position,p.ResolvedCurveRollerRiseMm);CurveRailTail(frame,cross,frame.Length,0,transition.AfterMm,section,plastic,p.BeltThicknessMm,rail.Position,p.ResolvedCurveRollerRiseMm);}
  }
 }
 void CurveRailTail(CurveFrame frame,PointF[] cross,double station,double offset,double length,int section,Color color,double thickness=0,SlideRailPosition position=SlideRailPosition.Center,double rise=10){
  if(length<=0)return;double angle=frame.HeadingAt(station),sin=Math.Sin(angle),cos=Math.Cos(angle);var origin=frame.Point(0,0,station);Func<double,double,double,BeltPoint3D> at=(u,y,z)=>new BeltPoint3D(origin.X+u*cos+z*sin,y,origin.Z-u*sin+z*cos);int first=Faces.Count;
  if(thickness<=0||position==SlideRailPosition.Center)Extrude(Array.ConvertAll(cross,q=>at(q.X,q.Y,offset)),new BeltPoint3D(length*sin,0,length*cos),section,color,null,BeltSurface3D.Nylamid);
  else{
   double u=cross.Min(q=>q.X),y=cross.Min(q=>q.Y),floor=CurveUpperGuideGeometry.ContactHeightMm(thickness),wall=CurveUpperGuideGeometry.SideMaterialMm,width=SlideRailGeometry.WidthMm,h=CurveUpperGuideGeometry.HeightMm;
   foreach(var rect in new[]{Rectangle(u,y,width,floor),Rectangle(u+(position==SlideRailPosition.Right?width-wall:0),y+floor,wall,h-floor)})Extrude(Array.ConvertAll(rect,q=>at(q.X,q.Y,offset)),new BeltPoint3D(length*sin,0,length*cos),section,color,null,BeltSurface3D.Nylamid);
   double limit=CurveUpperGuideGeometry.EntryCapLimit(rise),z0=Math.Max(offset,-limit),z1=Math.Min(offset+length,limit);
   if(z1-z0>1e-7){double radial=u+(position==SlideRailPosition.Right?0:wall),roof=y+h-CurveUpperGuideGeometry.TopMaterialMm,top=y+h;var raw=new[]{at(radial,roof+CurveUpperGuideGeometry.EntryRiseMm(z0,rise),z0),at(radial,roof+CurveUpperGuideGeometry.EntryRiseMm(z1,rise),z1),at(radial,top,z1),at(radial,top,z0)};var polygon=new List<BeltPoint3D>();foreach(var q in raw)if(polygon.Count==0||Math.Abs(q.Y-polygon[polygon.Count-1].Y)+Math.Abs(q.X-polygon[polygon.Count-1].X)+Math.Abs(q.Z-polygon[polygon.Count-1].Z)>1e-7)polygon.Add(q);if(polygon.Count>2){var a=polygon[0];var b=polygon[polygon.Count-1];if(Math.Abs(a.Y-b.Y)+Math.Abs(a.X-b.X)+Math.Abs(a.Z-b.Z)<1e-7)polygon.RemoveAt(polygon.Count-1);Extrude(polygon.ToArray(),new BeltPoint3D((width-wall)*cos,0,-(width-wall)*sin),section,color,null,BeltSurface3D.Nylamid);}}
  }
  for(int i=first;i<Faces.Count;i++)Faces[i].IsCurveLowerGuide=true;
 }
 void AppendCurveSupport(Belt3DGeometry source,CurveFrame frame,double station,bool lower){double angle=frame.HeadingAt(station);var origin=frame.Point(0,0,station);Func<BeltPoint3D,BeltPoint3D> move=q=>new BeltPoint3D(origin.X+q.X*Math.Cos(angle)+q.Z*Math.Sin(angle),q.Y,origin.Z-q.X*Math.Sin(angle)+q.Z*Math.Cos(angle));foreach(var face in source.Faces){face.Outer=Array.ConvertAll(face.Outer,q=>move(q));for(int i=0;i<face.Holes.Count;i++)face.Holes[i]=Array.ConvertAll(face.Holes[i],q=>move(q));if(!face.IsVerticalSupport){face.IsCurveUpperSupport=!lower;face.IsCurveLowerSupport=lower;}Faces.Add(face);}}
}
}
