﻿using System;using System.Collections.Generic;
namespace PerfilBandas {
internal sealed partial class Belt3DGeometry {
 void CurvedLegFlange(CurveFrame frame,ProfileSettings p,double web,double sign,int section){
  double inner=web+sign*p.ThicknessMm,outer=web+sign*p.BottomFlangeMm,radial=CurveLegHoleLayout.RadialCenter(p,web,sign),half=p.EndHoleSizeMm/2;
  var placements=CurveLegHoleLayout.Holes(p,frame,radial);var stations=Array.ConvertAll(placements,h=>h.Station);var cuts=new SortedSet<double>{0,frame.Length};
  double radius=frame.Curve.InnerRadiusMm+frame.Width/2,scale=(radius-(frame.Curve.TurnRight?1:-1)*(radial-frame.Width/2))/radius,margin=(half+2)/scale;
  foreach(double z in stations){cuts.Add(z-margin);cuts.Add(z+margin);}
  int steps=Math.Max(1,(int)Math.Ceiling(frame.Curve.AngleDeg/1));for(int k=1;k<steps;k++){double z=frame.Length*k/steps;bool near=false;foreach(double station in stations)if(Math.Abs(z-station)<margin)near=true;if(!near)cuts.Add(z);}
  var list=new List<double>(cuts);for(int k=0;k<list.Count-1;k++){
   double a=list[k],b=list[k+1];var holes=new List<BeltPoint3D[]>();
   foreach(var placement in placements)if(placement.Station>a&&placement.Station<b){var origin=placement.Point(frame,radial,-p.WebHeightMm);double angle=frame.HeadingAt(placement.Datum),c=Math.Cos(angle),s=Math.Sin(angle);var loop=new BeltPoint3D[4];double[] dx={-half,half,half,-half},dz={-half,-half,half,half};for(int j=0;j<4;j++)loop[j]=new BeltPoint3D(origin.X+dx[j]*c+dz[j]*s,origin.Y,origin.Z-dx[j]*s+dz[j]*c);holes.Add(loop);}
   int start=Faces.Count;Extrude(new[]{frame.Point(inner,-p.WebHeightMm,a),frame.Point(outer,-p.WebHeightMm,a),frame.Point(outer,-p.WebHeightMm,b),frame.Point(inner,-p.WebHeightMm,b)},new BeltPoint3D(0,p.ThicknessMm,0),section,Steel,holes);
   for(int j=start;j<Faces.Count;j++){Faces[j].IsCurveFlange=true;Faces[j].DrawEdges=false;}
  }
 }
}
}
