﻿using System;using System.Collections.Generic;using System.Drawing;
namespace PerfilBandas {
internal sealed partial class Belt3DGeometry {
 // Break the web mesh around support holes so each opening is contained in one
 // surface patch. Project the hole onto the same chord as the visible face.
 void CurvedWeb(CurveFrame frame,ProfileSettings p,SoporteSettings s,double u,double outer,int section){
  var slots=CurveWebSlotLayout.Build(frame,p,s,u);
  double half=p.SupportHoleSizeMm/2;var cuts=new SortedSet<double>{0,frame.Length};var stations=SupportHoleLayout.CentersMm(p);int steps=Math.Max(1,(int)Math.Ceiling(frame.Curve.AngleDeg/1));
  for(int k=1;k<steps;k++){double z=frame.Length*k/steps;bool near=false;foreach(double station in stations)if(Math.Abs(z-station)<half+2)near=true;if(!near)cuts.Add(z);}
  foreach(double station in stations){cuts.Add(station-half-1);cuts.Add(station+half+1);}
  foreach(var slot in slots){cuts.Add(slot.StartMm);cuts.Add(slot.EndMm);}
  var list=new List<double>(cuts);Func<double,double,double,double,double,BeltPoint3D> chord=(radial,y,z,a,b)=>{var first=frame.Point(radial,y,a);var last=frame.Point(radial,y,b);double t=(z-a)/(b-a);return new BeltPoint3D(first.X+(last.X-first.X)*t,y,first.Z+(last.Z-first.Z)*t);};
  for(int k=0;k<list.Count-1;k++){double a=list[k],b=list[k+1];foreach(double radial in new[]{u,outer}){
   var opening=slots.Find(slot=>(a+b)/2>slot.StartMm&&(a+b)/2<slot.EndMm);
   if(opening!=null){foreach(var band in new[]{new[]{0.0,opening.TopYMm},new[]{opening.BottomYMm,-p.WebHeightMm}}){var patch=Face(new[]{frame.Point(radial,band[0],a),frame.Point(radial,band[1],a),frame.Point(radial,band[1],b),frame.Point(radial,band[0],b)},section,Steel,BeltSurface3D.StainlessSteel);patch.IsCurveWeb=true;patch.DrawEdges=false;}continue;}
   var face=Face(new[]{frame.Point(radial,0,a),frame.Point(radial,-p.WebHeightMm,a),frame.Point(radial,-p.WebHeightMm,b),frame.Point(radial,0,b)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;face.DrawEdges=false;
   foreach(double station in stations)if(station-half>a&&station+half<b)foreach(double y in new[]{-p.SupportHoleYMm,-p.WebHeightMm+p.SupportHoleYMm-p.ResolvedCurveReturnDropMm})face.Holes.Add(new[]{chord(radial,y-half,station-half,a,b),chord(radial,y+half,station-half,a,b),chord(radial,y+half,station+half,a,b),chord(radial,y-half,station+half,a,b)});
  }
  foreach(double y in new[]{0.0,-p.WebHeightMm}){var face=Face(new[]{frame.Point(u,y,a),frame.Point(outer,y,a),frame.Point(outer,y,b),frame.Point(u,y,b)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;face.DrawEdges=false;}
  }
  foreach(double station in stations)foreach(double y in new[]{-p.SupportHoleYMm,-p.WebHeightMm+p.SupportHoleYMm-p.ResolvedCurveReturnDropMm}){int patch=list.FindIndex(z=>z>station);double a=list[patch-1],b=list[patch];var loop=new[]{new PointF((float)(station-half),(float)(y-half)),new PointF((float)(station-half),(float)(y+half)),new PointF((float)(station+half),(float)(y+half)),new PointF((float)(station+half),(float)(y-half))};for(int j=0;j<4;j++){var first=loop[j];var last=loop[(j+1)%4];var face=Face(new[]{chord(u,first.Y,first.X,a,b),chord(outer,first.Y,first.X,a,b),chord(outer,last.Y,last.X,a,b),chord(u,last.Y,last.X,a,b)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;}}
  foreach(var slot in slots){
   var segments=new List<double>{slot.StartMm};foreach(var z in list)if(z>slot.StartMm&&z<slot.EndMm)segments.Add(z);segments.Add(slot.EndMm);
   for(int k=0;k<segments.Count-1;k++)foreach(var y in new[]{slot.TopYMm,slot.BottomYMm}){double a=segments[k],b=segments[k+1];var face=Face(new[]{frame.Point(u,y,a),frame.Point(outer,y,a),frame.Point(outer,y,b),frame.Point(u,y,b)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;face.DrawEdges=false;}
   foreach(var z in new[]{slot.StartMm,slot.EndMm}){var face=Face(new[]{frame.Point(u,slot.TopYMm,z),frame.Point(outer,slot.TopYMm,z),frame.Point(outer,slot.BottomYMm,z),frame.Point(u,slot.BottomYMm,z)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;}
  }
  foreach(double end in new[]{0.0,frame.Length}){var face=Face(new[]{frame.Point(u,0,end),frame.Point(outer,0,end),frame.Point(outer,-p.WebHeightMm,end),frame.Point(u,-p.WebHeightMm,end)},section,Steel,BeltSurface3D.StainlessSteel);face.IsCurveWeb=true;}
 }
}
}
