﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal static class DesignUi
    {
        public static readonly Color Canvas = Color.FromArgb(234, 240, 243);
        public static readonly Color Surface = Color.White;
        public static readonly Color Ink = Color.FromArgb(33, 56, 68);
        public static readonly Color Muted = Color.FromArgb(82, 103, 115);
        public static readonly Color Primary = Color.FromArgb(8, 112, 125);
        public static readonly Color Accent = Color.FromArgb(8, 127, 140);
        public static readonly Color Petronas = Color.FromArgb(8, 127, 140);
        public static readonly Color Danger = Color.FromArgb(208, 38, 46);
        public static readonly Color Success = Color.FromArgb(22, 128, 94);
        public static readonly Color Violet = Color.FromArgb(73, 89, 94);
        public static readonly Color Selection = Color.FromArgb(219, 238, 240);
        public static readonly Color Border = Color.FromArgb(203, 214, 222);
        public static readonly Font NavigationRegular = new Font("Bahnschrift", 10f, FontStyle.Regular);
        public static readonly Font NavigationBold = new Font("Bahnschrift", 10f, FontStyle.Bold);

        public static TableLayoutPanel Page()
        {
            var page = new TableLayoutPanel {
                Dock = DockStyle.Fill, AutoScroll = true, ColumnCount = 2,
                Padding = new Padding(22, 20, 22, 28), BackColor = Surface
            };
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 53));
            page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47));
            return page;
        }

        public static void StyleInputs(Control root)
        {
            foreach (Control child in root.Controls)
            {
                if (child is ComboBox || child is NumericUpDown || child is TextBox)
                {
                    child.Font = new Font("Segoe UI", 10f);
                    child.ForeColor = Ink;
                    child.MinimumSize = new Size(0, 30);
                    child.Margin = new Padding(4, 5, 0, 5);
                }
                else if (child is Button)
                {
                    var button = (Button)child;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderSize = 0;
                    button.Cursor = Cursors.Hand;
                    button.Font = new Font("Bahnschrift", 10f, FontStyle.Bold);
                    button.MinimumSize = new Size(0, 38);
                }
                else if (child is Label && child.ForeColor == Color.DimGray)
                    child.ForeColor = Muted;
                StyleInputs(child);
            }
        }
    }

    internal sealed class CategoryWorkspace : UserControl
    {
        private readonly FlowLayoutPanel navigation;
        private readonly Panel content;
        private readonly List<Button> buttons = new List<Button>();
        private readonly List<Control> pages = new List<Control>();
        public event Action<int> PageChanged;

        public CategoryWorkspace()
        {
            Dock = DockStyle.Left;
            Width = 640;
            BackColor = DesignUi.Canvas;
            navigation = new FlowLayoutPanel {
                Dock = DockStyle.Left, Width = 166, FlowDirection = FlowDirection.TopDown,
                WrapContents = false, AutoScroll = true, Padding = new Padding(9, 16, 9, 12),
                BackColor = DesignUi.Canvas
            };
            content = new Panel { Dock = DockStyle.Fill, BackColor = DesignUi.Surface };
            Controls.Add(content);
            Controls.Add(navigation);
        }

        public TableLayoutPanel AddPage(string title, string description)
        {
            int index = pages.Count;
            var page = DesignUi.Page();
            var heading = new Label {
                Text = title, AutoSize = true, Font = new Font("Segoe UI Semibold", 16f, FontStyle.Bold),
                ForeColor = DesignUi.Ink, Margin = new Padding(0, 0, 0, 4)
            };
            page.Controls.Add(heading, 0, page.RowCount);
            page.SetColumnSpan(heading, 2);
            page.RowCount++;
            var subtitle = new Label {
                Text = description, AutoSize = true, MaximumSize = new Size(400, 0),
                Font = new Font("Segoe UI", 9f), ForeColor = DesignUi.Muted,
                Margin = new Padding(0, 0, 0, 18)
            };
            page.Controls.Add(subtitle, 0, page.RowCount);
            page.SetColumnSpan(subtitle, 2);
            page.RowCount++;
            page.Visible = false;
            content.Controls.Add(page);
            pages.Add(page);

            var button = new Button {
                Text = title, TextAlign = ContentAlignment.MiddleLeft,
                Width = 142, Height = 48, Margin = new Padding(0, 0, 0, 6),
                Padding = new Padding(12, 0, 4, 0),
                FlatStyle = FlatStyle.Flat, FlatAppearance = { BorderSize = 0 },
                ForeColor = DesignUi.Ink, BackColor = navigation.BackColor,
                Font = DesignUi.NavigationRegular, Cursor = Cursors.Hand,
                TabStop = true
            };
            button.Click += delegate { ShowPage(index); };
            navigation.Controls.Add(button);
            buttons.Add(button);
            if (index == 0) ShowPage(0);
            return page;
        }

        public void ShowPage(int index)
        {
            if (index < 0 || index >= pages.Count) return;
            for (int i = 0; i < pages.Count; i++)
            {
                pages[i].Visible = i == index;
                buttons[i].ForeColor = i == index ? DesignUi.Primary : DesignUi.Ink;
                buttons[i].Font = i == index ? DesignUi.NavigationBold : DesignUi.NavigationRegular;
                buttons[i].BackColor = i == index ? DesignUi.Selection : navigation.BackColor;
            }
            pages[index].BringToFront();
            if (PageChanged != null) PageChanged(index);
        }
    }
}
