﻿using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    // ═════════════════════════════════════════════════════════════════════════════
    // PARÁMETROS DEL ENSAMBLE AUTOMATIZADO DE TRANSPORTADOR
    // ═════════════════════════════════════════════════════════════════════════════
    internal sealed class EnsambleSettings
    {
        public string AssemblyName = "ENSAMBLE_BANDA.SLDASM";
        public int SupportCount = 6;
        public double SupportHoleEdgeMm = 50.0;
        public double SupportHoleSpacingMm = 420.0;
        public double SupportHoleSizeMm = 11.0;
        public double SupportHoleYMm = 60.0; // Altura exacta desde el borde superior (mm)
        public double BandWidthMm = 500.0;
        public double SupportLengthMm = 520.0;
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // GENERADOR DE ENSAMBLAJES SOLIDWORKS
    // ═════════════════════════════════════════════════════════════════════════════
    internal static partial class SolidWorksEnsambleGenerator
    {
        private static Component2 InsertComponentHelper(SldWorks sw, AssemblyDoc assy, string partPath, double x, double y, double z)
        {
            ModelDoc2 assyDoc = (ModelDoc2)assy;
            string assyTitle = assyDoc.GetTitle();
            int err = 0, warn = 0;
            ModelDoc2 partDoc=sw.GetOpenDocumentByName(partPath) as ModelDoc2;bool opened=partDoc==null;
            if(opened)partDoc = sw.OpenDoc6(partPath, Path.GetExtension(partPath).Equals(".SLDASM",StringComparison.OrdinalIgnoreCase)?(int)swDocumentTypes_e.swDocASSEMBLY:(int)swDocumentTypes_e.swDocPART, (int)swOpenDocOptions_e.swOpenDocOptions_Silent, "", ref err, ref warn);
            if(partDoc==null || !String.Equals(Path.GetFullPath(partDoc.GetPathName()),Path.GetFullPath(partPath),StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("No se pudo abrir la pieza correcta para insertar: "+partPath+" (error "+err+").");
            sw.ActivateDoc3(assyTitle, true, 0, ref err);
            Component2 comp = assy.AddComponent5(partPath, 0, "", false, "", x, y, z);
            if(opened)try { sw.CloseDoc(Path.GetFileName(partPath)); } catch { }
            return comp;
        }

        private static void PlaceComponent(Component2 comp, MathUtility mathUtil, double[] transform, string name)
        {
            MathTransform target = (MathTransform)mathUtil.CreateTransform(transform);
            if (target == null || !comp.SetTransformAndSolve2(target))
                throw new InvalidOperationException("No se pudo colocar " + name + ".");
            double[] actual = (double[])comp.Transform2.ArrayData;
            for (int i = 0; i < 12; i++)
                if (Math.Abs(actual[i] - transform[i]) > 0.000001)
                    throw new InvalidOperationException("SOLIDWORKS cambió la posición de " + name + ".");
        }

        private static double[] HoleCenter(MathUtility mathUtil, Component2 comp, double x, double y, double z)
        {
            MathPoint point = (MathPoint)mathUtil.CreatePoint(new double[] { x, y, z });
            return (double[])((MathPoint)point.MultiplyTransform(comp.Transform2)).ArrayData;
        }

        private static void AssertHoleAlignment(MathUtility mathUtil, Component2 profile, Component2 support,
            double profileX, double profileY, double profileZ, double supportX, double supportY, double supportZ,
            double expectedXOffset, string name)
        {
            double[] a = HoleCenter(mathUtil, profile, profileX, profileY, profileZ);
            double[] b = HoleCenter(mathUtil, support, supportX, supportY, supportZ);
            // Los centros quedan en caras opuestas del alma; deben compartir Y y Z.
            if (Math.Abs((a[0] - b[0]) - expectedXOffset) > 0.00001 ||
                Math.Abs(a[1] - b[1]) > 0.00001 || Math.Abs(a[2] - b[2]) > 0.00001)
                throw new InvalidOperationException("Los barrenos de " + name + " no están alineados.");
        }

        private static void AssertBendsOutward(Component2 left, Component2 right, double thickness)
        {
            PartDoc leftPart = left.GetModelDoc2() as PartDoc;
            PartDoc rightPart = right.GetModelDoc2() as PartDoc;
            if (leftPart == null || rightPart == null)
                throw new InvalidOperationException("No se pudo inspeccionar la geometría de los perfiles.");
            double[] leftBox = (double[])leftPart.GetPartBox(true);
            double[] rightBox = (double[])rightPart.GetPartBox(true);
            double leftX = ((double[])left.Transform2.ArrayData)[9];
            double rightX = ((double[])right.Transform2.ArrayData)[9];
            if (rightX <= leftX || leftBox[0] >= -thickness - 0.001 || rightBox[3] <= 0.001)
                throw new InvalidOperationException("Los dobleces de los perfiles no apuntan hacia afuera de la banda.");
        }

        public static string GenerateAssembly(string customFolder = null, ProfileSettings profSettings = null, SoporteSettings sopSettings = null)
        {
            ProfileSettings requestedProfile = profSettings ?? new ProfileSettings();
            SupportHoleLayout.CentersMm(requestedProfile);
            string stage = "iniciando SOLIDWORKS";
            try
            {
                Type swType = Type.GetTypeFromProgID("SldWorks.Application");
                if (swType == null) throw new InvalidOperationException("SOLIDWORKS no está instalado o no registró su interfaz COM.");
                SldWorks sw = null;
                try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
                catch { sw = (SldWorks)Activator.CreateInstance(swType); }
                if (sw == null) throw new InvalidOperationException("No fue posible obtener la instancia de SOLIDWORKS.");
                sw.Visible = true;

                string folder = !string.IsNullOrWhiteSpace(customFolder) ? customFolder : ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);

                string pathLH = Path.Combine(folder, "PERFIL_LATERAL_LH.SLDPRT");
                string pathRH = Path.Combine(folder, "PERFIL_LATERAL_RH.SLDPRT");
                string pathC  = Path.Combine(folder, "SOPORTE_C.SLDPRT");

                // Liberar primero el ensamble que referencia las piezas anteriores.
                // De otro modo SOLIDWORKS puede reutilizar un perfil con el paso viejo.
                try { sw.CloseDoc("ENSAMBLE_BANDA.SLDASM"); } catch { }
                try { sw.CloseDoc(Path.GetFileName(pathLH)); } catch { }
                try { sw.CloseDoc(Path.GetFileName(pathRH)); } catch { }
                try { sw.CloseDoc(Path.GetFileName(pathC)); } catch { }

                // Generar piezas actualizadas y sincronizadas
                stage = "generando perfiles laterales LH y RH sincronizados";
                SoporteSettings ss = sopSettings ?? new SoporteSettings();
                ProfileSettings ps = requestedProfile.Copy();
                SupportHoleLayout.SetElevation(ps,ss);
                SolidWorksProfileGenerator.Create(ps, "LH", folder, null, sw);
                SolidWorksProfileGenerator.Create(ps, "RH", folder, null, sw);

                stage = "generando soporte C sincronizado";
                if (!ps.IncludeSupportHoles || !ss.IncludeEndPlates)
                    throw new InvalidOperationException("El ensamble requiere los barrenos en los perfiles y las plaquitas en el soporte C.");
                if (Math.Abs(ps.SupportHoleSizeMm - ss.EndPlateHoleSizeMm) > 0.001)
                    throw new InvalidOperationException("Los barrenos del perfil y las plaquitas deben tener el mismo tamaño.");
                SolidWorksSoporteGenerator.Create(ss, folder, null, sw);

                stage = "creando nuevo documento de ensamblaje";
                string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplateAssembly);
                if (string.IsNullOrEmpty(template) || !File.Exists(template))
                    throw new InvalidOperationException("No se encontró la plantilla de ensamblaje predeterminada en SOLIDWORKS.");

                AssemblyDoc assy = (AssemblyDoc)sw.NewDocument(template, 0, 0, 0);
                if (assy == null) throw new InvalidOperationException("No se pudo crear el documento de ensamblaje.");
                ModelDoc2 model = (ModelDoc2)assy;

                MathUtility mathUtil = (MathUtility)sw.GetMathUtility();

                stage = "insertando perfil lateral izquierdo (LH)";
                Component2 compLH = InsertComponentHelper(sw, assy, pathLH, 0, 0, 0);
                if (compLH == null) throw new InvalidOperationException("No se pudo insertar PERFIL_LATERAL_LH en el ensamblaje.");

                // SOLIDWORKS centra automáticamente el primer componente al insertarlo.
                // Quitar esa fijación y colocar explícitamente el origen de la pieza.
                model.ClearSelection2(true);
                if (!compLH.Select4(false, null, false))
                    throw new InvalidOperationException("No se pudo seleccionar el perfil LH.");
                assy.UnfixComponent();
                model.ClearSelection2(true);
                PlaceComponent(compLH, mathUtil, new double[] {
                    1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0
                }, "perfil LH");
                compLH.Select4(false, null, false);
                assy.FixComponent();
                model.ClearSelection2(true);

                // Parámetros dimensionales exactos
                double t_LH = ps.ThicknessMm / 1000.0;
                double supportLengthM = ss.LengthMm / 1000.0;
                double webWidthM = ss.WebWidthMm / 1000.0;
                double hcx = webWidthM / 2.0;
                double hcy = ss.EndPlateHoleYMm / 1000.0;
                double holeYProfM = ps.SupportHoleYMm / 1000.0;
                double[] centersMm = SupportHoleLayout.CentersMm(ps);

                stage = "insertando perfil lateral derecho (RH)";
                // LH se monta a la izquierda: sus dobleces apuntan hacia -X.
                // RH se monta a la derecha: sus dobleces apuntan hacia +X.
                // Las caras interiores de ambos perfiles están en X=0 local.
                double txRH = supportLengthM;
                Component2 compRH = InsertComponentHelper(sw, assy, pathRH, txRH, 0, 0);
                if (compRH == null) throw new InvalidOperationException("No se pudo insertar PERFIL_LATERAL_RH en el ensamblaje.");

                double[] rhXform = new double[16] {
                    1, 0, 0,
                    0, 1, 0,
                    0, 0, 1,
                    txRH, 0, 0,
                    1.0, 0, 0, 0
                };
                PlaceComponent(compRH, mathUtil, rhXform, "perfil RH");
                model.ClearSelection2(true);
                if (!compRH.Select4(false, null, false))
                    throw new InvalidOperationException("No se pudo seleccionar el perfil RH.");
                assy.FixComponent();
                model.ClearSelection2(true);
                AssertBendsOutward(compLH, compRH, t_LH);

                stage = "calculando posiciones longitudinales de los 6 orificios";
                double[] zHoles = Array.ConvertAll(centersMm, center => center / 1000.0);

                stage = "insertando y alineando los 6 soportes C transversales";
                // Altura vertical: el barreno del perfil está a Y = -holeYProfM
                // En el soporte C, el barreno está a Y = +hcy
                // Por tanto: Ty = -holeYProfM - hcy
                double tySop = -holeYProfM - hcy;
                // La plaquita en Z_part=0 toca la cara interior de LH (X=0).
                double txSop = 0;
                Component2[] supports = new Component2[zHoles.Length];

                for (int i = 0; i < zHoles.Length; i++)
                {
                    double zHole = zHoles[i];
                    // En SOPORTE_C, el barreno está centrado en X_part = hcx (25.4 mm).
                    // X_part se mapea a -Z_assy; el centro de la plaquita va a zHole.
                    double tzSop = zHole + hcx;

                    Component2 compC = InsertComponentHelper(sw, assy, pathC, 0, 0, 0);
                    if (compC == null)
                        throw new InvalidOperationException("No se pudo insertar soporte C " + (i + 1) + ".");
                    {
                        // Matriz ortogonal rígida:
                        // X_assy = Z_part (longitud del soporte C de LH hacia RH)
                        // Y_assy = Y_part  (lomo hacia arriba)
                        // Z_assy = -X_part (ancho transversal)
                        double[] cXform = new double[16] {
                            0, 0, -1,
                            0, 1, 0,
                            1, 0, 0,
                            txSop, tySop, tzSop,
                            1.0, 0, 0, 0
                        };
                        PlaceComponent(compC, mathUtil, cXform, "soporte C " + (i + 1));
                        AssertHoleAlignment(mathUtil, compLH, compC,
                            0, -holeYProfM, zHole, hcx, hcy, 0, 0,
                            "perfil LH y soporte " + (i + 1));
                        AssertHoleAlignment(mathUtil, compRH, compC,
                            0, -holeYProfM, zHole, hcx, hcy, supportLengthM, 0,
                            "perfil RH y soporte " + (i + 1));
                        model.ClearSelection2(true);
                        if (!compC.Select4(false, null, false))
                            throw new InvalidOperationException("No se pudo seleccionar soporte C " + (i + 1) + ".");
                        assy.FixComponent();
                        model.ClearSelection2(true);
                        supports[i] = compC;
                    }
                }

                stage = "reconstruyendo y guardando el ensamblaje";
                model.ViewZoomtofit2();
                model.EditRebuild3();
                AssertBendsOutward(compLH, compRH, t_LH);

                // Comprobar de nuevo después de resolver y reconstruir el ensamble.
                for (int i = 0; i < supports.Length; i++)
                {
                    AssertHoleAlignment(mathUtil, compLH, supports[i], 0, -holeYProfM, zHoles[i],
                        hcx, hcy, 0, 0, "perfil LH y soporte " + (i + 1));
                    AssertHoleAlignment(mathUtil, compRH, supports[i], 0, -holeYProfM, zHoles[i],
                        hcx, hcy, supportLengthM, 0, "perfil RH y soporte " + (i + 1));
                }
                object[] allComponents = (object[])assy.GetComponents(false);
                if (allComponents == null || allComponents.Length != 8)
                    throw new InvalidOperationException("El ensamble no contiene los dos perfiles y los seis soportes esperados.");

                string outputPath = Path.Combine(folder, "ENSAMBLE_BANDA.SLDASM");
                int errSave = 0, warnSave = 0;
                if (!model.SaveAs4(outputPath, (int)swSaveAsVersion_e.swSaveAsCurrentVersion,
                    (int)swSaveAsOptions_e.swSaveAsOptions_Silent, ref errSave, ref warnSave) || errSave != 0)
                    throw new InvalidOperationException("No se pudo guardar el ensamble (error " + errSave + ").");

                return outputPath;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Fallo durante " + stage + ": " + ex.Message, ex);
            }
        }
    }
}
