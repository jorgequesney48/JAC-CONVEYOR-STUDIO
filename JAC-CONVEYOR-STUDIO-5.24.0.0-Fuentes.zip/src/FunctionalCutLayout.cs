﻿using System;
using System.Collections.Generic;
namespace PerfilBandas {
internal static partial class ProfileSlotLayout {
    internal static void InterruptForRollers(ProfileSettings p,ProfilePattern original){
        if(original.LogoVisible)foreach(var h in p.ResolvedRollerHoles){var covers=new List<double[]>{new[]{h.YMm,h.DiameterMm/2}};if(h.Keyhole){covers.Add(new[]{h.YMm+15.35,9.0});covers.Add(new[]{h.YMm+(ReturnRollerSeatGeometry.UpperJoin+ReturnRollerSeatGeometry.LowerJoin)/2,Math.Sqrt(25+Math.Pow((ReturnRollerSeatGeometry.UpperJoin-ReturnRollerSeatGeometry.LowerJoin)/2,2))});}foreach(var circle in covers){double dx=Math.Max(0,Math.Abs(h.LocalZMm-original.LogoCenterMm)-original.LogoWidthMm/2),dy=Math.Max(0,Math.Abs(circle[0]-original.CenterYMm)-original.LogoHeightMm/2);if(Math.Sqrt(dx*dx+dy*dy)<circle[1]+ClearanceMm-1e-6)throw new InvalidOperationException("Logo: no se permite interrumpirlo ni ocultarlo para un rodillo.");}}
        var cuts=new List<ProfileSlotSpec>();int changed=0;
        foreach(var slot in original.Slots){double left=slot.CenterMm-slot.LengthMm/2,right=slot.CenterMm+slot.LengthMm/2;var ranges=new List<double[]>{new[]{left,right}};
            foreach(var h in p.ResolvedRollerHoles){if(!RollerSlotInterruption.Allows(original,slot,h))continue;double width=h.Keyhole?9:h.DiameterMm/2,bottom=h.YMm-(h.Keyhole?6.35:width),top=h.YMm+(h.Keyhole?24.35:width),clearance=h.SlotClearanceMm;
                if(slot.CenterYMm+slot.RadiusMm+clearance<bottom||slot.CenterYMm-slot.RadiusMm-clearance>top)continue;
                double a=h.LocalZMm-width-clearance,b=h.LocalZMm+width+clearance;var next=new List<double[]>();foreach(var range in ranges){if(b<=range[0]||a>=range[1])next.Add(range);else{if(a>range[0])next.Add(new[]{range[0],a});if(b<range[1])next.Add(new[]{b,range[1]});}}ranges=next;
            }
            foreach(var range in ranges)if(range[1]-range[0]>=2*slot.RadiusMm+MinimumStraightMm){var c=slot.Copy();c.CenterMm=(range[0]+range[1])/2;c.LengthMm=range[1]-range[0];cuts.Add(c);}
            if(ranges.Count!=1||ranges[0][0]!=left||ranges[0][1]!=right)changed++;
        }
        original.Slots=cuts.ToArray();original.Description+=" · "+changed+" primeras ranuras de extremos interrumpidas; otras conservadas";
        original.LeftMarginMm=cuts.Count==0?p.LengthMm/2:cuts[0].CenterMm-cuts[0].LengthMm/2;original.RightMarginMm=cuts.Count==0?p.LengthMm/2:p.LengthMm-cuts[cuts.Count-1].CenterMm-cuts[cuts.Count-1].LengthMm/2;
        ValidateObstacles(p,original,original.ProtectedLeftMm,original.ProtectedRightMm);p.ResolvedPattern=original;p.ResolvedSlots=original.Slots;
    }
    // The same protected pattern is used by CAD and preview. Functional centres never move.
    static void ProtectFunctionalGeometry(ProfileSettings p,ProfilePattern pattern,double left,double right) {
        if(p.CenteredCuts&&String.IsNullOrEmpty(p.SlotCombination)) {
            int n=pattern.Slots.Length;if(pattern.LogoVisible&&n%2!=0)n--;
            double width=pattern.LogoVisible?pattern.LogoWidthMm:0;
            double length=n==0?0:(p.LengthMm-(n+(pattern.LogoVisible?1:0))*p.SlotGapMm-width)/n;
            var centered=new List<ProfileSlotSpec>();double x=p.SlotGapMm/2;
            for(int j=0;j<n;j++){if(pattern.LogoVisible&&j==n/2)x+=width+p.SlotGapMm;centered.Add(new ProfileSlotSpec{CenterMm=x+length/2,LengthMm=length,RadiusMm=p.SlotHeightMm/2,CenterYMm=pattern.CenterYMm});x+=length+p.SlotGapMm;}
            pattern.Slots=centered.ToArray();pattern.LogoCenterMm=p.LengthMm/2;
        }
        var reserved=new List<double[]>();
        if(p.IncludeSupportHoles)foreach(double z in SupportHoleLayout.CentersMm(p))reserved.Add(new[]{z,-p.SupportHoleYMm,p.SupportHoleSizeMm/2,p.SupportHoleSizeMm/2,-1.0});
        if(p.ResolvedRollerHoles!=null)foreach(var h in p.ResolvedRollerHoles)if(!h.PreserveCuts)reserved.Add(new[]{h.LocalZMm,h.YMm+(h.Keyhole?9:0),h.Keyhole?9:h.DiameterMm/2,h.Keyhole?15.35:h.DiameterMm/2,h.SlotClearanceMm,(double)RollerSlotInterruption.Side(h)});
        var cuts=new List<ProfileSlotSpec>();int removed=0;
        foreach(var slot in pattern.Slots) {
            var ranges=new List<double[]>{new[]{Math.Max(left+ClearanceMm,slot.CenterMm-slot.LengthMm/2),Math.Min(p.LengthMm-right-ClearanceMm,slot.CenterMm+slot.LengthMm/2)}};
            foreach(var o in reserved)if((o.Length<6||(o[5]<0&&Object.ReferenceEquals(slot,pattern.Slots[0]))||(o[5]>0&&Object.ReferenceEquals(slot,pattern.Slots[pattern.Slots.Length-1]))))if(Math.Abs(slot.CenterYMm-o[1])<slot.RadiusMm+o[3]+(o[4]>=0?o[4]:ClearanceMm)) {
                var next=new List<double[]>();double gap=o[4]>=0?o[4]:Math.Max(ClearanceMm,(p.SlotGapMm-2*o[2])/2),a=o[0]-o[2]-gap,b=o[0]+o[2]+gap;
                foreach(var range in ranges){if(b<=range[0]||a>=range[1])next.Add(range);else{if(a>range[0])next.Add(new[]{range[0],a});if(b<range[1])next.Add(new[]{b,range[1]});}}ranges=next;
            }
            foreach(var range in ranges)if(range[1]-range[0]>=2*slot.RadiusMm+MinimumStraightMm-1e-6){var c=slot.Copy();c.CenterMm=(range[0]+range[1])/2;c.LengthMm=range[1]-range[0];cuts.Add(c);}
            if(ranges.Count!=1||ranges[0][0]!=slot.CenterMm-slot.LengthMm/2||ranges[0][1]!=slot.CenterMm+slot.LengthMm/2)removed++;
        }
        if(p.CenteredCuts && (p.ResolvedRollerHoles==null || !Array.Exists(p.ResolvedRollerHoles,h=>!h.PreserveCuts))) {
            // Keep only mirrored intervals that remain clear on BOTH sides of the centre.
            var mirrored=new List<ProfileSlotSpec>();
            foreach(var a in cuts)foreach(var b in cuts){double lo=Math.Max(a.CenterMm-a.LengthMm/2,p.LengthMm-b.CenterMm-b.LengthMm/2),hi=Math.Min(a.CenterMm+a.LengthMm/2,p.LengthMm-b.CenterMm+b.LengthMm/2);if(hi-lo>=2*a.RadiusMm+MinimumStraightMm-1e-6){var c=a.Copy();c.CenterMm=(lo+hi)/2;c.LengthMm=hi-lo;if(!mirrored.Exists(s=>Math.Abs(s.CenterMm-c.CenterMm)<1e-5&&Math.Abs(s.LengthMm-c.LengthMm)<1e-5))mirrored.Add(c);}}
            cuts=mirrored;
        }
        bool omitted=false;
        if(pattern.LogoVisible){double a=pattern.LogoCenterMm-pattern.LogoWidthMm/2,b=pattern.LogoCenterMm+pattern.LogoWidthMm/2;
            if(a<left+ClearanceMm||b>p.LengthMm-right-ClearanceMm)omitted=true;
            foreach(var o in reserved){double dx=Math.Max(0,Math.Abs(o[0]-pattern.LogoCenterMm)-pattern.LogoWidthMm/2-o[2]),dy=Math.Max(0,Math.Abs(o[1]-pattern.CenterYMm)-pattern.LogoHeightMm/2-o[3]);if(Math.Sqrt(dx*dx+dy*dy)<ClearanceMm){if(o[4]>=0)throw new InvalidOperationException("Logo: no se permite interrumpirlo ni ocultarlo para un rodillo.");omitted=true;}}
            if(omitted)pattern.LogoVisible=false;
        }
        cuts.Sort((a,b)=>a.CenterMm.CompareTo(b.CenterMm));pattern.Slots=cuts.ToArray();
        pattern.LeftMarginMm=cuts.Count==0?p.LengthMm/2:cuts[0].CenterMm-cuts[0].LengthMm/2;
        pattern.RightMarginMm=cuts.Count==0?p.LengthMm/2:p.LengthMm-cuts[cuts.Count-1].CenterMm-cuts[cuts.Count-1].LengthMm/2;
        if(removed>0||omitted)pattern.Description+=" · adaptado a fijaciones/retorno"+(omitted?" · logo omitido para conservar material":"");
    }
}
}

