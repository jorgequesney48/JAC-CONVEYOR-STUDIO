using System;using System.Runtime.InteropServices;
namespace PerfilBandas {
internal sealed partial class HardwareViewport {
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate int UniformLocation(uint program,[MarshalAs(UnmanagedType.LPStr)]string name);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void UniformFloat(int location,float value);
 uint beltProgram;UniformFloat uniformFloat;int patternLocation,travelLocation,loopLocation;
 BeltFace3D currentTextureFace;BeltPoint3D uvOrigin,uvS,uvT;double uvS0,uvT0;
 void TextureFace(BeltFace3D face){
  currentTextureFace=null;if(face.BeltCoordinates==null)return;var points=face.Outer;var a=points[0];
  for(int i=1;i<points.Length-1;i++){
   var b=MeasurementGeometry.Sub(points[i],a);var c=MeasurementGeometry.Sub(points[i+1],a);
   double bb=MeasurementGeometry.Dot(b,b),cc=MeasurementGeometry.Dot(c,c),bc=MeasurementGeometry.Dot(b,c),den=bb*cc-bc*bc;if(Math.Abs(den)<1e-9)continue;
   var uv=face.BeltCoordinates;double s1=uv[i].X-uv[0].X,s2=uv[i+1].X-uv[0].X,t1=uv[i].Y-uv[0].Y,t2=uv[i+1].Y-uv[0].Y;
   uvS=MeasurementGeometry.Add(MeasurementGeometry.Mul(b,(s1*cc-s2*bc)/den),MeasurementGeometry.Mul(c,(s2*bb-s1*bc)/den));
   uvT=MeasurementGeometry.Add(MeasurementGeometry.Mul(b,(t1*cc-t2*bc)/den),MeasurementGeometry.Mul(c,(t2*bb-t1*bc)/den));
   uvOrigin=a;uvS0=uv[0].X;uvT0=uv[0].Y;currentTextureFace=face;return;
  }
 }
 void TextureVertex(double x,double y,double z){
  if(currentTextureFace==null){glTexCoord4d(0,0,0,0);return;}
  for(int i=0;i<currentTextureFace.Outer.Length;i++){var v=currentTextureFace.Outer[i];if(Math.Abs(v.X-x)+Math.Abs(v.Y-y)+Math.Abs(v.Z-z)<1e-7){var uv=currentTextureFace.BeltCoordinates[i];glTexCoord4d(uv.X,uv.Y,1,currentTextureFace.BeltWidthMm);return;}}
  var p=MeasurementGeometry.Sub(new BeltPoint3D(x,y,z),uvOrigin);
  glTexCoord4d(uvS0+MeasurementGeometry.Dot(p,uvS),uvT0+MeasurementGeometry.Dot(p,uvT),1,currentTextureFace.BeltWidthMm);
 }
 void CreateBeltProgram(){
  var create=Extension<CreateShader>("glCreateShader");var source=Extension<ShaderSource>("glShaderSource");var compile=Extension<ShaderAction>("glCompileShader");var status=Extension<ShaderStatus>("glGetShaderiv");var destroy=Extension<ShaderAction>("glDeleteShader");var program=Extension<CreateProgram>("glCreateProgram");var attach=Extension<AttachShader>("glAttachShader");var link=Extension<ShaderAction>("glLinkProgram");var linked=Extension<ShaderStatus>("glGetProgramiv");var location=Extension<UniformLocation>("glGetUniformLocation");uniformFloat=Extension<UniformFloat>("glUniform1f");
  if(location==null||uniformFloat==null)throw new InvalidOperationException("El controlador no ofrece parámetros de simulación GPU.");
  string vertex=@"#version 120
varying vec4 beltUV;
void main(){gl_Position=gl_ModelViewProjectionMatrix*gl_Vertex;gl_FrontColor=gl_Color;beltUV=gl_MultiTexCoord0;}";
  string fragment=@"#version 120
varying vec4 beltUV;
uniform float patternEnabled,travel,loopLength;
void main(){
 if(patternEnabled<0.5||beltUV.z<0.5){gl_FragColor=gl_Color;return;}
 float q=beltUV.x-travel;
 float z=mod(q,25.0)-12.5;
 float u=mod(beltUV.y+(mod(floor(q/25.0),2.0)>0.5?10.0:0.0),20.0)-10.0;
 if(beltUV.y>4.0&&beltUV.y<beltUV.w-4.0&&z*z/90.25+u*u/49.0<1.0)discard;
 vec3 color=mod(q,25.0)<1.1?vec3(28.0,63.0,116.0):vec3(48.0,88.0,158.0);
 if(loopLength>0.0&&mod(beltUV.x-travel,loopLength)<25.0)color=vec3(248.0,180.0,58.0);
 gl_FragColor=vec4(color/255.0,1.0);
}";
  uint vs=0,fs=0;try{vs=create(0x8B31);fs=create(0x8B30);source(vs,1,new[]{vertex},IntPtr.Zero);source(fs,1,new[]{fragment},IntPtr.Zero);int ok;compile(vs);status(vs,0x8B81,out ok);if(ok==0)throw new InvalidOperationException("Shader de coordenadas de banda rechazado.");compile(fs);status(fs,0x8B81,out ok);if(ok==0)throw new InvalidOperationException("Shader del patrón de banda rechazado.");beltProgram=program();attach(beltProgram,vs);attach(beltProgram,fs);link(beltProgram);linked(beltProgram,0x8B82,out ok);if(ok==0)throw new InvalidOperationException("No se pudo enlazar el patrón de banda.");patternLocation=location(beltProgram,"patternEnabled");travelLocation=location(beltProgram,"travel");loopLocation=location(beltProgram,"loopLength");}finally{if(vs!=0)destroy(vs);if(fs!=0)destroy(fs);}
 }
 void BeltUniforms(bool enabled,double travel,double loop){useProgram(beltProgram);uniformFloat(patternLocation,enabled?1:0);uniformFloat(travelLocation,(float)travel);uniformFloat(loopLocation,(float)loop);}
}
}
