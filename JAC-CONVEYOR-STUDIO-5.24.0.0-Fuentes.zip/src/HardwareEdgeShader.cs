using System;using System.Runtime.InteropServices;
namespace PerfilBandas {
internal sealed partial class HardwareViewport {
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate uint CreateShader(uint type);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void ShaderSource(uint shader,int count,[MarshalAs(UnmanagedType.LPArray,ArraySubType=UnmanagedType.LPStr)]string[] source,IntPtr lengths);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void ShaderAction(uint shader);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void ShaderStatus(uint shader,uint name,out int value);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate uint CreateProgram();
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void AttachShader(uint program,uint shader);
 uint edgeProgram;ShaderAction useProgram,deleteProgram;
 void CreateEdgeProgram(){
  var create=Extension<CreateShader>("glCreateShader");var source=Extension<ShaderSource>("glShaderSource");var compile=Extension<ShaderAction>("glCompileShader");var status=Extension<ShaderStatus>("glGetShaderiv");var destroy=Extension<ShaderAction>("glDeleteShader");var program=Extension<CreateProgram>("glCreateProgram");var attach=Extension<AttachShader>("glAttachShader");var link=Extension<ShaderAction>("glLinkProgram");var linked=Extension<ShaderStatus>("glGetProgramiv");useProgram=Extension<ShaderAction>("glUseProgram");deleteProgram=Extension<ShaderAction>("glDeleteProgram");
  if(create==null||source==null||compile==null||status==null||destroy==null||program==null||attach==null||link==null||linked==null||useProgram==null||deleteProgram==null)throw new InvalidOperationException("El controlador no ofrece shaders OpenGL 2.0; se utilizará CPU.");
  string vertex=@"#version 120
void main(){
 vec4 p=gl_ModelViewMatrix*gl_Vertex;
 vec4 q=gl_ModelViewMatrix*vec4(gl_MultiTexCoord0.xyz,1.0);
 vec3 n=gl_NormalMatrix*gl_Normal;
 vec2 d=q.xy-p.xy;
 float length2=dot(d,d);
 vec2 offset=length2>0.000001?vec2(-d.y,d.x)*inversesqrt(length2)*0.5*gl_MultiTexCoord0.w:vec2(0.0);
 if(abs(n.z)>0.000001){p.xy+=offset;p.z-=dot(n.xy,offset)/n.z;}
 gl_Position=gl_ProjectionMatrix*p;
 gl_FrontColor=gl_Color;
}";
  string fragment="#version 120\nvoid main(){gl_FragColor=gl_Color;}";
  uint vs=0,fs=0;try{vs=create(0x8B31);fs=create(0x8B30);source(vs,1,new[]{vertex},IntPtr.Zero);source(fs,1,new[]{fragment},IntPtr.Zero);int ok;compile(vs);status(vs,0x8B81,out ok);if(ok==0)throw new InvalidOperationException("El controlador rechazó el shader de contornos.");compile(fs);status(fs,0x8B81,out ok);if(ok==0)throw new InvalidOperationException("El controlador rechazó el shader de color.");edgeProgram=program();attach(edgeProgram,vs);attach(edgeProgram,fs);link(edgeProgram);linked(edgeProgram,0x8B82,out ok);if(ok==0)throw new InvalidOperationException("No se pudo enlazar el programa GPU.");}finally{if(vs!=0)destroy(vs);if(fs!=0)destroy(fs);}
 }
 void CompileEdgeFace(BeltFace3D face){
  if(face.Outer.Length<3)return;var a=face.Outer[0];double nx=0,ny=0,nz=0,norm=0;
  for(int k=1;k<face.Outer.Length-1&&norm<1e-12;k++){var b=face.Outer[k];var c=face.Outer[k+1];nx=(b.Y-a.Y)*(c.Z-a.Z)-(b.Z-a.Z)*(c.Y-a.Y);ny=(b.Z-a.Z)*(c.X-a.X)-(b.X-a.X)*(c.Z-a.Z);nz=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);norm=Math.Sqrt(nx*nx+ny*ny+nz*nz);}if(norm<1e-12)return;
  glNormal3d(nx/norm,ny/norm,nz/norm);var contours=new System.Collections.Generic.List<BeltPoint3D[]>{face.Outer};contours.AddRange(face.Holes);
  glBegin(0x0007);foreach(var loop in contours)for(int i=0;i<loop.Length;i++){var p=loop[i];var q=loop[(i+1)%loop.Length];EdgeVertex(p,q,1);EdgeVertex(q,p,-1);EdgeVertex(q,p,1);EdgeVertex(p,q,-1);}glEnd();
 }
 static void EdgeVertex(BeltPoint3D p,BeltPoint3D other,double sign){glTexCoord4d(other.X,other.Y,other.Z,sign);glVertex3d(p.X,p.Y,p.Z);}
 [DllImport("opengl32.dll")]static extern void glNormal3d(double x,double y,double z);
 [DllImport("opengl32.dll")]static extern void glTexCoord4d(double x,double y,double z,double w);
}
}
