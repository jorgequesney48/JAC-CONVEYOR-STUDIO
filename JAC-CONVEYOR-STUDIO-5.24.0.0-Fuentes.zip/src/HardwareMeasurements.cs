using System;using System.Runtime.InteropServices;
namespace PerfilBandas {
internal sealed partial class HardwareViewport {
    void DrawMeasurement(Belt3DGeometry geometry,double[] camera,MeasurementSelection measure){
        if(measure==null||measure.First<0)return;
        glLoadMatrixd(camera);glEnable(0x0BE2);glBlendFunc(0x0302,0x0303);glDepthMask(false);
        try{
            int[] indexes={measure.First,measure.Second};for(int i=0;i<indexes.Length;i++)if(indexes[i]>=0&&indexes[i]<geometry.Faces.Count){if(i==0)glColor4d(1,.52,0,.45);else glColor4d(0,.65,1,.45);CompileFace(geometry.Faces[indexes[i]]);}
            glDisable(0x0B71);glPointSize(9);var a=measure.Result==null?measure.FirstHit:measure.Result.FirstPoint;glColor4d(1,.45,0,1);glBegin(0x0000);glVertex3d(a.X,a.Y,a.Z);glEnd();
            if(measure.Result!=null){var b=measure.Result.SecondPoint;glColor4d(.85,.2,.08,1);glLineWidth(2);glBegin(0x0001);glVertex3d(a.X,a.Y,a.Z);glVertex3d(b.X,b.Y,b.Z);glEnd();glColor4d(0,.65,1,1);glBegin(0x0000);glVertex3d(b.X,b.Y,b.Z);glEnd();}
        }finally{glDepthMask(true);glEnable(0x0B71);glDisable(0x0BE2);glPointSize(1);glLineWidth(1);}
    }
    [DllImport("opengl32.dll")]static extern void glColor4d(double red,double green,double blue,double alpha);
    [DllImport("opengl32.dll")]static extern void glBlendFunc(uint source,uint destination);
    [DllImport("opengl32.dll")]static extern void glDepthMask([MarshalAs(UnmanagedType.I1)]bool enabled);
    [DllImport("opengl32.dll")]static extern void glPointSize(float size);
}
}