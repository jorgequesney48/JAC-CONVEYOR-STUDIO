using System;using System.Drawing;using System.Drawing.Imaging;using System.Drawing.Text;using System.Runtime.InteropServices;using System.Windows.Forms;
namespace PerfilBandas {
internal sealed partial class HardwareViewport {
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate bool ChooseFormat(IntPtr hdc,int[] integers,float[] floats,uint maximum,int[] formats,out uint count);
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate bool SwapInterval(int interval);
 static T Extension<T>(string name) where T:class {IntPtr p=wglGetProcAddress(name);long n=p.ToInt64();return n==0||n==1||n==2||n==3||n==-1?null:Marshal.GetDelegateForFunctionPointer(p,typeof(T)) as T;}
 int ChooseQualityFormat(ref PixelFormat format){
  // A temporary invisible surface loads this monitor's driver before choosing the real surface's format.
  var bootstrap=new NativeWindow();IntPtr bootstrapDC=IntPtr.Zero,bootstrapContext=IntPtr.Zero;
  try{var screen=Screen.FromHandle(window);bootstrap.CreateHandle(new CreateParams{Caption="JAC GPU bootstrap",X=screen.Bounds.Left,Y=screen.Bounds.Top,Width=1,Height=1,Style=unchecked((int)0x80000000),ClassStyle=0x20});bootstrapDC=GetDC(bootstrap.Handle);
   int basic=ChoosePixelFormat(bootstrapDC,ref format);if(basic==0||!SetPixelFormat(bootstrapDC,basic,ref format))return ChoosePixelFormat(dc,ref format);
   bootstrapContext=wglCreateContext(bootstrapDC);if(bootstrapContext==IntPtr.Zero||!wglMakeCurrent(bootstrapDC,bootstrapContext))return ChoosePixelFormat(dc,ref format);
   var choose=Extension<ChooseFormat>("wglChoosePixelFormatARB");if(choose!=null)foreach(int samples in new[]{4,2}){var attributes=new[]{0x2001,1,0x2010,1,0x2011,1,0x2013,0x202B,0x2014,32,0x201B,8,0x2022,24,0x2023,8,0x2041,1,0x2042,samples,0};var formats=new int[1];uint found;
    if(choose(dc,attributes,null,1,formats,out found)&&found>0){DescribePixelFormat(dc,formats[0],(uint)Marshal.SizeOf(typeof(PixelFormat)),ref format);return formats[0];}}
   return ChoosePixelFormat(dc,ref format);
  }finally{wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);if(bootstrapContext!=IntPtr.Zero)wglDeleteContext(bootstrapContext);if(bootstrapDC!=IntPtr.Zero)ReleaseDC(bootstrap.Handle,bootstrapDC);bootstrap.DestroyHandle();}
 }
 void ConfigurePresentation(){int samples;glGetIntegerv(0x80A9,out samples);Samples=Math.Max(0,samples);if(Samples>0)glEnable(0x809D);var interval=Extension<SwapInterval>("wglSwapIntervalEXT");Synchronized=interval!=null&&interval(1);}
 uint overlayTexture;string overlayText;int overlayWidth;const int OverlayHeight=88;
 void DrawOverlay(int width,string text){
  if(String.IsNullOrEmpty(text))return;int size=Math.Min(1024,Math.Max(1,width-36));
  if(overlayTexture==0||overlayText!=text||overlayWidth!=size){ReleaseOverlay();var ids=new uint[1];glGenTextures(1,ids);overlayTexture=ids[0];overlayText=text;overlayWidth=size;glBindTexture(0x0DE1,overlayTexture);
   using(var bitmap=new Bitmap(size,OverlayHeight,System.Drawing.Imaging.PixelFormat.Format32bppPArgb)){using(var g=Graphics.FromImage(bitmap))using(var font=new Font("Segoe UI",9)){g.Clear(Color.Transparent);g.TextRenderingHint=TextRenderingHint.AntiAliasGridFit;using(var brush=new SolidBrush(DesignUi.Ink))g.DrawString(text,font,brush,new RectangleF(0,0,size,OverlayHeight));}
    var data=bitmap.LockBits(new Rectangle(0,0,size,OverlayHeight),ImageLockMode.ReadOnly,bitmap.PixelFormat);try{glTexImage2D(0x0DE1,0,0x1908,size,OverlayHeight,0,0x80E1,0x1401,data.Scan0);}finally{bitmap.UnlockBits(data);}}
   glTexParameteri(0x0DE1,0x2801,0x2601);glTexParameteri(0x0DE1,0x2800,0x2601);
  }
  glLoadIdentity();glDisable(0x0B71);glEnable(0x0DE1);glBindTexture(0x0DE1,overlayTexture);glEnable(0x0BE2);glBlendFunc(1,0x0303);glColor4d(1,1,1,1);
  glBegin(0x0007);glTexCoord2f(0,0);glVertex3d(18,16,0);glTexCoord2f(1,0);glVertex3d(18+size,16,0);glTexCoord2f(1,1);glVertex3d(18+size,16+OverlayHeight,0);glTexCoord2f(0,1);glVertex3d(18,16+OverlayHeight,0);glEnd();
  glDisable(0x0DE1);glDisable(0x0BE2);glEnable(0x0B71);
 }
 void ReleaseOverlay(){if(overlayTexture!=0){glDeleteTextures(1,new[]{overlayTexture});overlayTexture=0;}overlayText=null;}
 [DllImport("opengl32.dll",CharSet=CharSet.Ansi)]static extern IntPtr wglGetProcAddress(string name);
 [DllImport("gdi32.dll")]static extern int DescribePixelFormat(IntPtr hdc,int index,uint size,ref PixelFormat format);
 [DllImport("opengl32.dll")]static extern void glGetIntegerv(uint name,out int value);
 [DllImport("opengl32.dll")]static extern void glGenTextures(int count,uint[] textures);
 [DllImport("opengl32.dll")]static extern void glDeleteTextures(int count,uint[] textures);
 [DllImport("opengl32.dll")]static extern void glBindTexture(uint target,uint texture);
 [DllImport("opengl32.dll")]static extern void glTexParameteri(uint target,uint name,int value);
 [DllImport("opengl32.dll")]static extern void glTexImage2D(uint target,int level,int format,int width,int height,int border,uint pixelFormat,uint type,IntPtr data);
 [DllImport("opengl32.dll")]static extern void glTexCoord2f(float s,float t);
}
}
