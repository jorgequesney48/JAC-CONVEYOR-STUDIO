using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
namespace PerfilBandas {
// Uses the installed Windows OpenGL ICD. No third-party runtime or driver installation.
// GLU tessellates each planar face with ALL its hole contours; camera movement uses GPU lists.
internal sealed partial class HardwareViewport:IDisposable {
    IntPtr window,dc,context,tess;uint lists;int count;Belt3DGeometry mesh;
    public string Renderer;public double LastMilliseconds;public long BuildMilliseconds;
    double boundsMinX,boundsMinY,boundsMinZ,boundsMaxX,boundsMaxY,boundsMaxZ;
    public int Samples {get;private set;} public bool Synchronized {get;private set;}
    public int GeometryBuilds {get;private set;} public int PresentedFrames {get;private set;}
    readonly List<IntPtr> allocations=new List<IntPtr>();uint tessError;
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void BeginCallback(uint mode);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void EndCallback();
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void VertexCallback(IntPtr point);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void ErrorCallback(uint error);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate void CombineCallback(IntPtr xyz,IntPtr data,IntPtr weights,out IntPtr result);
    BeginCallback begin;EndCallback end;VertexCallback vertex;ErrorCallback error;CombineCallback combine;
    [StructLayout(LayoutKind.Sequential)]struct PixelFormat {public ushort Size,Version;public uint Flags;public byte Type,ColorBits,RedBits,RedShift,GreenBits,GreenShift,BlueBits,BlueShift,AlphaBits,AlphaShift,AccumBits,AccumRedBits,AccumGreenBits,AccumBlueBits,AccumAlphaBits,DepthBits,StencilBits,AuxBuffers,LayerType,Reserved;public uint LayerMask,VisibleMask,DamageMask;}
    public HardwareViewport(IntPtr handle){
        window=handle;dc=GetDC(window);
        try{var format=new PixelFormat{Size=(ushort)Marshal.SizeOf(typeof(PixelFormat)),Version=1,Flags=0x25,ColorBits=32,AlphaBits=8,DepthBits=24,StencilBits=8};int index=GetPixelFormat(dc);if(index==0){index=ChooseQualityFormat(ref format);if(index==0||!SetPixelFormat(dc,index,ref format))throw new InvalidOperationException("No se obtuvo formato OpenGL.");}context=wglCreateContext(dc);if(context==IntPtr.Zero||!wglMakeCurrent(dc,context))throw new InvalidOperationException("No se creó contexto OpenGL.");Renderer=Marshal.PtrToStringAnsi(glGetString(0x1F01));if(String.IsNullOrEmpty(Renderer)||Renderer.IndexOf("GDI Generic",StringComparison.OrdinalIgnoreCase)>=0)throw new InvalidOperationException("El adaptador sólo ofrece OpenGL por software.");
            ConfigurePresentation();
            CreateEdgeProgram();CreateBeltProgram();
            tess=gluNewTess();if(tess==IntPtr.Zero)throw new InvalidOperationException("No se pudo crear teselador GLU.");
            begin=mode=>glBegin(mode);end=()=>glEnd();vertex=point=>{var xyz=new double[3];Marshal.Copy(point,xyz,0,3);TextureVertex(xyz[0],xyz[1],xyz[2]);glVertex3d(xyz[0],xyz[1],xyz[2]);};error=code=>tessError=code;combine=Combine;
            gluTessCallback(tess,100100,Marshal.GetFunctionPointerForDelegate(begin));gluTessCallback(tess,100101,Marshal.GetFunctionPointerForDelegate(vertex));gluTessCallback(tess,100102,Marshal.GetFunctionPointerForDelegate(end));gluTessCallback(tess,100103,Marshal.GetFunctionPointerForDelegate(error));gluTessCallback(tess,100105,Marshal.GetFunctionPointerForDelegate(combine));
            glEnable(0x0B71);glDepthFunc(0x0203);glDisable(0x0B44);wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);
        }catch{Dispose();throw;}
    }
    void Combine(IntPtr xyz,IntPtr data,IntPtr weights,out IntPtr result){var values=new double[3];Marshal.Copy(xyz,values,0,3);result=Allocate(values);}
    IntPtr Allocate(double[] values){IntPtr pointer=Marshal.AllocHGlobal(24);Marshal.Copy(values,0,pointer,3);allocations.Add(pointer);return pointer;}
    void CompileFace(BeltFace3D face){
        TextureFace(face);tessError=0;gluTessBeginPolygon(tess,IntPtr.Zero);
        var contours=new List<BeltPoint3D[]>{face.Outer};contours.AddRange(face.Holes);
        try{foreach(var contour in contours){gluTessBeginContour(tess);foreach(var point in contour){var xyz=new[]{point.X,point.Y,point.Z};IntPtr pointer=Allocate(xyz);gluTessVertex(tess,pointer,pointer);}gluTessEndContour(tess);}gluTessEndPolygon(tess);if(tessError!=0)throw new InvalidOperationException("GLU no pudo conservar el contorno con barrenos: "+tessError);}
        finally{foreach(var pointer in allocations)Marshal.FreeHGlobal(pointer);allocations.Clear();}
    }
    void Compile(Belt3DGeometry geometry){
        if(Object.ReferenceEquals(mesh,geometry))return;var watch=System.Diagnostics.Stopwatch.StartNew();if(lists!=0)glDeleteLists(lists,count*2);lists=0;mesh=null;count=geometry.Starts.Count;CacheBounds(geometry);lists=glGenLists(count*2);if(lists==0)throw new InvalidOperationException("No hay memoria para la geometría GPU.");
        for(int section=0;section<count;section++){
            glNewList(lists+(uint)(section*2),0x1300);
            try{foreach(var face in geometry.Faces)if(face.Section==section){double shade=.9;if(face.Outer.Length>2){var a=face.Outer[0];var b=face.Outer[1];var c=face.Outer[2];double nx=(b.Y-a.Y)*(c.Z-a.Z)-(b.Z-a.Z)*(c.Y-a.Y),ny=(b.Z-a.Z)*(c.X-a.X)-(b.X-a.X)*(c.Z-a.Z),nz=(b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X),norm=Math.Sqrt(nx*nx+ny*ny+nz*nz);if(norm>1e-9)shade=.64+.32*Math.Abs((nx*.4+ny*.8+nz*.45)/norm);}glColor3d(face.Color.R/255d*shade,face.Color.G/255d*shade,face.Color.B/255d*shade);CompileFace(face);}}
            finally{glEndList();}
            glNewList(lists+(uint)(section*2+1),0x1300);
            try{foreach(var face in geometry.Faces)if(face.Section==section&&face.DrawEdges)CompileEdgeFace(face);}finally{glEndList();}
        }
        mesh=geometry;BuildMilliseconds=watch.ElapsedMilliseconds;GeometryBuilds++;
    }
    void CacheBounds(Belt3DGeometry geometry){
        boundsMinX=boundsMinY=boundsMinZ=Double.PositiveInfinity;
        boundsMaxX=boundsMaxY=boundsMaxZ=Double.NegativeInfinity;
        foreach(var face in geometry.Faces)foreach(var p in face.Outer){
            boundsMinX=Math.Min(boundsMinX,p.X);boundsMaxX=Math.Max(boundsMaxX,p.X);
            boundsMinY=Math.Min(boundsMinY,p.Y);boundsMaxY=Math.Max(boundsMaxY,p.Y);
            boundsMinZ=Math.Min(boundsMinZ,p.Z);boundsMaxZ=Math.Max(boundsMaxZ,p.Z);
        }
    }
    void DepthRange(double[] camera,out double near,out double far){
        double low=Double.PositiveInfinity,high=Double.NegativeInfinity;
        for(int corner=0;corner<8;corner++){
            double x=(corner&1)==0?boundsMinX:boundsMaxX,y=(corner&2)==0?boundsMinY:boundsMaxY,z=(corner&4)==0?boundsMinZ:boundsMaxZ;
            double depth=x*camera[2]+y*camera[6]+z*camera[10]+camera[14];
            low=Math.Min(low,depth);high=Math.Max(high,depth);
        }
        if(Double.IsInfinity(low)||Double.IsInfinity(high)){near=-1;far=1;return;}
        double margin=Math.Max(1,(high-low)*.01);near=-high-margin;far=-low+margin;
    }
    public void Draw(Belt3DGeometry geometry,int width,int height,double[] camera,int selected,int focus,Color background,bool moving,MeasurementSelection measurement=null,string overlay=null,bool beltPattern=false,double beltTravel=0,double beltLoop=0){
        if(!wglMakeCurrent(dc,context))throw new InvalidOperationException("Se perdió el contexto GPU.");
        try{
            Compile(geometry);var watch=System.Diagnostics.Stopwatch.StartNew();glViewport(0,0,width,height);
            glMatrixMode(0x1701);glLoadIdentity();double near,far;DepthRange(camera,out near,out far);glOrtho(0,width,height,0,near,far);
            glMatrixMode(0x1700);glLoadMatrixd(camera);glEnable(0x0B71);
            glClearColor(background.R/255f,background.G/255f,background.B/255f,1);glClear(0x4100);
            BeltUniforms(beltPattern,beltTravel,beltLoop);
            try{for(int i=0;i<count;i++)if(focus<0||focus==i)glCallList(lists+(uint)(i*2));}finally{useProgram(0);}
            // Keep full geometry and contours in GPU memory, at full resolution even during navigation.
            // A tiny constant depth bias avoids coplanar noise without a slope-dependent offset through thin plates.
            glDepthRange(0,Math.Max(0,1-.001/Math.Max(1,far-near)));glDepthMask(false);useProgram(edgeProgram);
            try{for(int i=0;i<count;i++)if(focus<0||focus==i){if(i==selected)glColor3d(.18,.42,.45);else glColor3d(.38,.42,.46);glCallList(lists+(uint)(i*2+1));}}
            finally{useProgram(0);glDepthRange(0,1);glDepthMask(true);}
            DrawMeasurement(geometry,camera,measurement);DrawOverlay(width,overlay);glFlush();if(!SwapBuffers(dc))throw new InvalidOperationException("No se pudo presentar cuadro GPU.");PresentedFrames++;LastMilliseconds=watch.Elapsed.TotalMilliseconds;
        }finally{wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);}
    }
    public Bitmap Capture(int width,int height){if(!wglMakeCurrent(dc,context))throw new InvalidOperationException("No hay contexto GPU.");try{var bytes=new byte[width*height*4];glReadBuffer(0x0404);glReadPixels(0,0,width,height,0x80E1,0x1401,bytes);var bitmap=new Bitmap(width,height,System.Drawing.Imaging.PixelFormat.Format32bppArgb);var data=bitmap.LockBits(new Rectangle(0,0,width,height),System.Drawing.Imaging.ImageLockMode.WriteOnly,bitmap.PixelFormat);try{Marshal.Copy(bytes,0,data.Scan0,bytes.Length);}finally{bitmap.UnlockBits(data);}bitmap.RotateFlip(RotateFlipType.RotateNoneFlipY);return bitmap;}finally{wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);}}
    public void Dispose(){if(context!=IntPtr.Zero){wglMakeCurrent(dc,context);if(lists!=0)glDeleteLists(lists,count*2);if(edgeProgram!=0&&deleteProgram!=null)deleteProgram(edgeProgram);edgeProgram=0;if(beltProgram!=0&&deleteProgram!=null)deleteProgram(beltProgram);beltProgram=0;ReleaseOverlay();if(tess!=IntPtr.Zero)gluDeleteTess(tess);wglMakeCurrent(IntPtr.Zero,IntPtr.Zero);wglDeleteContext(context);}if(dc!=IntPtr.Zero)ReleaseDC(window,dc);dc=context=tess=IntPtr.Zero;}
    [DllImport("opengl32.dll")]static extern void glDepthRange(double near,double far);
    [DllImport("user32.dll")]static extern IntPtr GetDC(IntPtr window);[DllImport("user32.dll")]static extern int ReleaseDC(IntPtr window,IntPtr dc);
    [DllImport("gdi32.dll")]static extern int ChoosePixelFormat(IntPtr dc,ref PixelFormat format);[DllImport("gdi32.dll")]static extern bool SetPixelFormat(IntPtr dc,int index,ref PixelFormat format);[DllImport("gdi32.dll")]static extern bool SwapBuffers(IntPtr dc);
    [DllImport("gdi32.dll")]static extern int GetPixelFormat(IntPtr dc);
    [DllImport("opengl32.dll")]static extern IntPtr wglCreateContext(IntPtr dc);[DllImport("opengl32.dll")]static extern bool wglMakeCurrent(IntPtr dc,IntPtr context);[DllImport("opengl32.dll")]static extern bool wglDeleteContext(IntPtr context);
    [DllImport("opengl32.dll")]static extern IntPtr glGetString(uint name);[DllImport("opengl32.dll")]static extern void glBegin(uint mode);[DllImport("opengl32.dll")]static extern void glEnd();[DllImport("opengl32.dll")]static extern void glVertex3d(double x,double y,double z);[DllImport("opengl32.dll")]static extern void glColor3d(double r,double g,double b);[DllImport("opengl32.dll")]static extern void glEnable(uint flag);[DllImport("opengl32.dll")]static extern void glDisable(uint flag);[DllImport("opengl32.dll")]static extern void glDepthFunc(uint function);[DllImport("opengl32.dll")]static extern uint glGenLists(int count);[DllImport("opengl32.dll")]static extern void glDeleteLists(uint lists,int count);[DllImport("opengl32.dll")]static extern void glNewList(uint list,uint mode);[DllImport("opengl32.dll")]static extern void glEndList();[DllImport("opengl32.dll")]static extern void glCallList(uint list);[DllImport("opengl32.dll")]static extern void glClearColor(float r,float g,float b,float a);[DllImport("opengl32.dll")]static extern void glClear(uint mask);[DllImport("opengl32.dll")]static extern void glViewport(int x,int y,int width,int height);[DllImport("opengl32.dll")]static extern void glMatrixMode(uint mode);[DllImport("opengl32.dll")]static extern void glLoadIdentity();[DllImport("opengl32.dll")]static extern void glLoadMatrixd(double[] matrix);[DllImport("opengl32.dll")]static extern void glOrtho(double left,double right,double bottom,double top,double near,double far);[DllImport("opengl32.dll")]static extern void glPolygonOffset(float factor,float units);[DllImport("opengl32.dll")]static extern void glLineWidth(float width);[DllImport("opengl32.dll")]static extern void glFlush();
    [DllImport("opengl32.dll")]static extern void glReadBuffer(uint mode);[DllImport("opengl32.dll")]static extern void glReadPixels(int x,int y,int width,int height,uint format,uint type,byte[] data);
    [DllImport("glu32.dll")]static extern IntPtr gluNewTess();[DllImport("glu32.dll")]static extern void gluDeleteTess(IntPtr tess);[DllImport("glu32.dll")]static extern void gluTessCallback(IntPtr tess,uint type,IntPtr callback);[DllImport("glu32.dll")]static extern void gluTessBeginPolygon(IntPtr tess,IntPtr data);[DllImport("glu32.dll")]static extern void gluTessBeginContour(IntPtr tess);[DllImport("glu32.dll")]static extern void gluTessVertex(IntPtr tess,IntPtr coords,IntPtr data);[DllImport("glu32.dll")]static extern void gluTessEndContour(IntPtr tess);[DllImport("glu32.dll")]static extern void gluTessEndPolygon(IntPtr tess);
}
}
