using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using SolidWorks.Interop.sldworks;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
 internal static string GenerateIndividualPart(IList<BeltSectionSpec> sections,ProfileSettings profile,SoporteSettings support,ReturnRollerSettings rollers,VerticalSupportSettings legs,AssemblyPartItem item,string root,Action<string> progress,CancellationToken cancellation){
  var plan=BeltDesignPlan.Build(sections,profile,support,rollers,legs);plan.RequireValid();
  if(!AssemblyParts.Build(sections,plan,rollers,legs).Exists(p=>p.Key==item.Key))throw new InvalidOperationException("La pieza seleccionada ya no está en este ensamble.");
  cancellation.ThrowIfCancellationRequested();if(progress!=null)progress("Generando "+item.Name);
  string stem="PIEZA_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+"_"+Guid.NewGuid().ToString("N").Substring(0,6);
  string folder=Path.Combine(Path.GetFullPath(root),"PIEZAS_INDIVIDUALES",stem);Directory.CreateDirectory(folder);
  string target=Path.Combine(folder,(item.Section<0?"BANDA":"TRAMO_"+(item.Section+1).ToString("00"))+"_"+item.Suffix+".SLDPRT");
  string refs=Path.Combine(Path.GetTempPath(),"JAC_Pieza_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(refs);
  SldWorks sw;try{sw=(SldWorks)Marshal.GetActiveObject("SldWorks.Application");}catch{var type=Type.GetTypeFromProgID("SldWorks.Application");if(type==null)throw new InvalidOperationException("SOLIDWORKS no está instalado.");sw=(SldWorks)Activator.CreateInstance(type);}sw.Visible=true;
  try{using(var reuse=new CadReuseSession()){
   if(item.Kind==AssemblyPartKind.Trajectory)return GenerateBeltTrajectory(sw,BeltTrajectory.Build(sections,plan,support,rollers),target);
   int i=item.Section;var section=sections[i];var p=plan.Profiles[i];var s=plan.Supports[i];var settings=section.IsCurved?CurveLegLayout.Settings(legs):legs;
   var frames=section.IsCurved?CurveRoute.Frames(sections,support,profile):null;var frame=frames==null?null:frames[i];
   Func<bool,GeneratedProfile> reference=right=>GenerateReusableProfile(sw,section,p,s,s.ActualFlange1HeightMm,right,Path.Combine(refs,stem+(right?"_REFERENCIA_RH.SLDPRT":"_REFERENCIA_LH.SLDPRT")),refs);
   Func<double[]> mount=()=>{if(section.IsCurved)return new[]{0.0,-p.WebHeightMm};var referencePart=reference(false);int e=0,w=0;var doc=sw.OpenDoc6(referencePart.Path,1,1,"",ref e,ref w);if(doc==null)throw new InvalidOperationException("No se pudo medir la referencia de montaje.");try{var point=VerticalSupportLayout.MountOrigin(doc,p);return new[]{point[0]*1000,point[1]*1000};}finally{sw.CloseDoc(doc.GetTitle());}};
   switch(item.Kind){
    case AssemblyPartKind.Profile:return GenerateReusableProfile(sw,section,p,s,s.ActualFlange1HeightMm,item.Side==1,target,folder).Path;
    case AssemblyPartKind.Support:return ReusableSupport(sw,s,target);
    case AssemblyPartKind.CurvePart:{string prefix=stem+"_CURVA_TRAMO_"+(i+1).ToString("00");CreateCurveParts(sw,section,p,s,frame,folder,prefix,CurveReturnTransitionLayout.Resolve(sections,i,p,s,plan.Rollers,rollers),item.Suffix);return Path.Combine(folder,prefix+"_"+item.Suffix+".SLDPRT");}
    case AssemblyPartKind.Rail:{var plate=ShaftPlateGeometry.Active(section)?reference(false).Plate:null;double start=plate==null?0:plate.RailStartZ,length=plate==null?p.LengthMm:plate.RailLengthMm;var range=SlideRailGeometry.Range(s,i,sections.Count,start,length);if(item.Side==1)return SolidWorksSlideRailGenerator.CreateCenter(range[1],folder,Path.GetFileNameWithoutExtension(target),sw);var side=item.Side==0?SlideRailPosition.Left:SlideRailPosition.Right;return SolidWorksSlideRailGenerator.Create(range[1],folder,Path.GetFileNameWithoutExtension(target),side,sw,SlideRailGeometry.EndPlateReliefs(p,s,side,s.ActualFlange1HeightMm,range[0]));}
    case AssemblyPartKind.ShaftPlate:return SolidWorksShaftPlateGenerator.Create(sw,section,reference(item.Side==1).Plate,item.Side==1,folder,Path.GetFileNameWithoutExtension(target));
    case AssemblyPartKind.Shaft:{var left=reference(false);var right=reference(true);double lx=section.ShaftPlates.Mounting==2?left.Datums.OuterX:left.Datums.InnerX,rx=s.LengthMm+(section.ShaftPlates.Mounting==2?right.Datums.OuterX:right.Datums.InnerX);return SolidWorksConveyorShaftGenerator.Create(sw,ConveyorShaftGeometry.Calculate(section,p,s,left.Plate,lx,rx),target);}
    case AssemblyPartKind.Bearing:File.Copy(BearingCatalog.Default().ModelPath(section.ShaftPlates.Bearing),target);return target;
    case AssemblyPartKind.Sprocket:File.Copy(SprocketCatalog.Default().ModelPath(section.ShaftPlates.Shaft.Sprocket),target);return target;
    case AssemblyPartKind.ReturnRoller:return CreateReturnCylinder(sw,target,rollers.RollerDiameterMm,rollers.ShaftDiameterMm,s.LengthMm-2*rollers.SideClearanceMm,"Rodillo_Retorno_Simplificado");
    case AssemblyPartKind.ReturnAxle:return rollers.KeyholeSeats?CreateReturnAxle(sw,target,rollers,p,s):CreateReturnCylinder(sw,target,rollers.ShaftDiameterMm,0,s.LengthMm+2*(rollers.ShaftProjectionMm+p.ThicknessMm),"Eje_Retorno_Sin_Retencion");
    case AssemblyPartKind.LegTube:case AssemblyPartKind.LegPlate:case AssemblyPartKind.LegCap:case AssemblyPartKind.LegBase:{int which=item.Kind==AssemblyPartKind.LegTube?1:item.Kind==AssemblyPartKind.LegPlate?2:item.Kind==AssemblyPartKind.LegCap?3:4;double y=which==1?mount()[1]:section.IsCurved?-p.WebHeightMm:VerticalSupportLayout.NominalMountMm(p)[1];return GenerateVerticalSupportUnique(sw,settings,y,folder,"PATA",null,which);}
    case AssemblyPartKind.Crossbar:{var origin=mount();var cross=section.IsCurved?CurveLegLayout.Crossbar(legs,p,s):LegCrossbarLayout.Build(legs,origin[0],s.LengthMm-origin[0],origin[1],origin[1],0);return GenerateLegCrossbar(sw,settings,cross.LengthMm,target);}
    case AssemblyPartKind.CurveLegPlate:{int side=item.Side%2;double radius=CurveLegLayout.Radius(p,s,frame,side),nextRadius=0;if(item.Side>=2){var next=plan.Profiles[i+1];var nextSupport=plan.Supports[i+1];CurveLegLayout.ValidateJoint(p,s,frame,next,nextSupport,frames[i+1]);nextRadius=CurveLegLayout.Radius(next,nextSupport,frames[i+1],side);if(side==1){double temp=radius;radius=nextRadius;nextRadius=temp;}}return GenerateCurveLegPlate(sw,target,radius,CurveLegLayout.Edge(p),CurveLegLayout.Concave(frame,side),nextRadius);}
    default:throw new InvalidOperationException("Tipo de pieza desconocido.");
   }
  }}finally{foreach(string path in Directory.GetFiles(refs,"*.SLDPRT"))sw.CloseDoc(Path.GetFileName(path));try{Directory.Delete(refs,true);}catch(IOException){} }
 }
}
}
