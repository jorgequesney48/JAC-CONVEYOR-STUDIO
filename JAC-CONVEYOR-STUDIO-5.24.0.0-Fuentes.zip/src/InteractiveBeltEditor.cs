﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas {
    internal sealed partial class CompleteBeltView {
        internal readonly Belt3DPreview WorldPreview=new Belt3DPreview { Name="Belt3DCanvas" };
        readonly InspectorPages inspectorTabs=new InspectorPages();
        readonly List<Button> inspectorSegments=new List<Button>();
        Panel inspectorHost;
        Button parameterToggle;
        internal bool InspectorVisible {get{return inspectorHost!=null&&inspectorHost.Visible;}}
        readonly Panel quickPanel=new Panel();
        readonly Label quickResult=new Label(),quickFeedback=new Label();
        readonly Dictionary<string,Control> quickInputs=new Dictionary<string,Control>();
        readonly Dictionary<string,string> pendingQuickErrors=new Dictionary<string,string>();
        bool synchronizingQuick;
        Panel modelEditor;
        internal int SelectedSection {get{return selected;}}
        sealed class EditSpec {public string Title,Hint;public decimal Min,Max;public int Decimals=2;}
        static EditSpec Spec(string key) {
            switch(key) {
                case "Length":return new EditSpec{Title="Largo del tramo · mm",Hint="Sólo modifica el tramo seleccionado.",Min=600,Max=6000};
                case "SlotHeight":return new EditSpec{Title="Altura de ranura · mm",Hint="Los radios y largos se recalculan automáticamente.",Min=2,Max=150};
                case "SlotGap":return new EditSpec{Title="Separación libre (todos) · mm",Hint="Esta separación es común a todos los tramos.",Min=20,Max=450};
                case "SlotOffset":return new EditSpec{Title="Ranura sobre doblez · mm",Hint="Desde la tangencia del doblez hasta el borde inferior.",Min=10,Max=200};
                case "Width":return new EditSpec{Title="Ancho de banda (todos) · mm",Hint="E925: múltiplos de 20 mm. Aplica a todos los tramos para conservar la continuidad.",Min=100,Max=1320,Decimals=0};
                case "Thickness":return new EditSpec{Title="Espesor del perfil · mm",Hint="Modifica el calibre real del perfil; respeta la opción Aplicar a todos.",Min=.5m,Max=6};
                case "LogoScale":return new EditSpec{Title="Escala del logo · %",Hint="100% equivale a 140 mm de ancho para JAC.",Min=10,Max=300};
                default:throw new ArgumentException("Parámetro no disponible.");
            }
        }
        Control Create3DWorkspace() {
            var host=new Panel {Dock=DockStyle.Fill,Padding=Padding.Empty};
            var tools=new FlowLayoutPanel {Name="View3DToolbar",Dock=DockStyle.Top,Height=48,WrapContents=true,AutoScroll=false,BackColor=DesignUi.Canvas,Padding=new Padding(0,4,0,5)};
            MinimalLayout.FitToolbar(tools);
            tools.Controls.Add(CreateTrajectoryButton());
            parameterToggle=ViewButton("Abrir ajustes",delegate{SetInspectorVisible(!InspectorVisible);},112);parameterToggle.Name="ToggleTramoParameters";tools.Controls.Add(parameterToggle);
            var orientation=new ComboBox{Name="ViewOrientation",DropDownStyle=ComboBoxStyle.DropDownList,Width=116,Font=DesignUi.NavigationRegular,FlatStyle=FlatStyle.Flat,AccessibleName="Orientación del modelo",Margin=new Padding(0,3,6,0)};orientation.Items.AddRange(new[]{"Isométrica","Lateral","Superior","Frontal"});orientation.SelectedIndex=0;orientation.SelectedIndexChanged+=delegate{WorldPreview.SetView(orientation.Text);};tools.Controls.Add(orientation);
            tools.Controls.Add(ViewButton("−",delegate{WorldPreview.ChangeZoom(1/1.15);},32));tools.Controls.Add(ViewButton("+",delegate{WorldPreview.ChangeZoom(1.15);},32));
            tools.Controls.Add(ViewButton("Ajustar",delegate{WorldPreview.Fit();},72));
            WorldPreview.Dock=DockStyle.Fill;WorldPreview.SectionSelected+=SelectSection;
            WorldPreview.ParameterEditRequested+=OpenModelEditor;
            host.Controls.Add(WorldPreview);host.Controls.Add(new MeasurementBar(WorldPreview,ShowDimensionViews));host.Controls.Add(tools);return host;
        }
        static Button ViewButton(string name,Action action,int width) {
            var b=new RoundedButton {Text=name,Width=width,Height=34,BackColor=Color.White,ForeColor=DesignUi.Ink,Margin=new Padding(0,0,6,5),Font=DesignUi.NavigationRegular,Cursor=Cursors.Hand};
            if(name=="Ver tramo"){b.BackColor=DesignUi.Accent;b.ForeColor=Color.White;}
            else if(name=="Ajustar"||name=="Ver banda"){b.BackColor=DesignUi.Selection;b.ForeColor=DesignUi.Primary;}
            b.Click+=delegate{action();};return b;
        }
        Control CreateInspector() {
            var host=new Panel {Name="TramoParameterSheet",Dock=DockStyle.Right,Width=390,BackColor=DesignUi.Canvas,Padding=new Padding(12,0,0,0),Visible=false};inspectorHost=host;
            var sheet=new Panel {Dock=DockStyle.Fill,BackColor=Color.White,Padding=new Padding(12)};
            var titleBar=new Panel {Dock=DockStyle.Top,Height=46,BackColor=Color.White};
            selectionTitle.Dock=DockStyle.Fill;selectionTitle.TextAlign=ContentAlignment.MiddleLeft;selectionTitle.ForeColor=DesignUi.Ink;selectionTitle.Font=new Font("Bahnschrift",12,FontStyle.Bold);
            var close=ViewButton("×",delegate{SetInspectorVisible(false);},34);close.Name="CloseTramoParameters";close.Dock=DockStyle.Right;close.AccessibleName="Cerrar parámetros del tramo";close.Font=new Font("Segoe UI",16);
            titleBar.Controls.Add(selectionTitle);titleBar.Controls.Add(close);
            inspectorTabs.Name="TramoInspector";inspectorTabs.Dock=DockStyle.Fill;inspectorTabs.Font=new Font("Segoe UI",10);
            host.ParentChanged+=delegate{if(host.Parent==null)return;Action fit=delegate{host.Width=Math.Max(330,Math.Min(430,(int)(host.Parent.ClientSize.Width*.36)));};host.Parent.ClientSizeChanged+=delegate{fit();};fit();};
            var quick=new Panel {Name="Principal",BackColor=Color.White};var advanced=new Panel {Name="Detalles",BackColor=Color.White};var reference=new Panel {Name="Referencia",BackColor=Color.White};
            quickPanel.Dock=DockStyle.Fill;quickPanel.AutoScroll=true;quickPanel.Padding=new Padding(4,12,4,0);quick.Controls.Add(quickPanel);
            advanced.Controls.Add(fields);advanced.Controls.Add(CreateCategoryNavigation());reference.Controls.Add(detailHost);
            inspectorTabs.TabPages.AddRange(new[]{quick,advanced,reference});
            var scope=new Panel{Dock=DockStyle.Top,Height=46,BackColor=DesignUi.Selection};
            applyGroupButton=new CheckBox{Name="ApplyAllChangesSwitch",Appearance=Appearance.Button,Dock=DockStyle.Right,Width=174,TextAlign=ContentAlignment.MiddleCenter,FlatStyle=FlatStyle.Flat,Font=DesignUi.NavigationRegular,ForeColor=DesignUi.Primary,BackColor=Color.White,Checked=applyToAllChanges,AccessibleName="Aplicar automáticamente los cambios de este apartado a todos los tramos"};applyGroupButton.FlatAppearance.BorderColor=DesignUi.Border;applyGroupButton.FlatAppearance.CheckedBackColor=DesignUi.Selection;tips.SetToolTip(applyGroupButton,"Activado: los cambios se copian a los demás tramos. Desactívalo para ajustar sólo este tramo.");SyncApplyAllSwitch();applyGroupButton.CheckedChanged+=delegate{if(synchronizingApplyAll)return;applyToAllChanges=applyGroupButton.Checked;Changed(applyToAllChanges?category:-1);SyncCategoryNavigation(category);};
            scopeLabel=new Label{Dock=DockStyle.Fill,Text="Ajustes del tramo",TextAlign=ContentAlignment.MiddleLeft,ForeColor=DesignUi.Primary};scope.Controls.Add(scopeLabel);scope.Controls.Add(applyGroupButton);
            var segments=new TableLayoutPanel {Dock=DockStyle.Top,Height=40,ColumnCount=3,RowCount=1,BackColor=DesignUi.Canvas,Padding=new Padding(3),Margin=Padding.Empty};
            for(int i=0;i<3;i++){int index=i;segments.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100f/3));var b=ViewButton(new[]{"Resumen","Ajustes","Referencia"}[i],delegate{inspectorTabs.SelectedIndex=index;},95);b.Dock=DockStyle.Fill;b.Margin=new Padding(1);inspectorSegments.Add(b);segments.Controls.Add(b,i,0);}
            inspectorTabs.SelectedIndexChanged+=delegate{RefreshInspectorSegments();if(sections.Count>0&&inspectorTabs.SelectedIndex==1)ShowCategory(category);};RefreshInspectorSegments();
            sheet.Controls.Add(inspectorTabs);sheet.Controls.Add(segments);sheet.Controls.Add(scope);sheet.Controls.Add(titleBar);host.Controls.Add(sheet);return host;
        }
        void RefreshInspectorSegments(){for(int i=0;i<inspectorSegments.Count;i++){inspectorSegments[i].BackColor=i==inspectorTabs.SelectedIndex?Color.White:DesignUi.Canvas;inspectorSegments[i].ForeColor=i==inspectorTabs.SelectedIndex?DesignUi.Ink:DesignUi.Muted;}}
        internal void SetInspectorVisible(bool visible){
            if(inspectorHost==null)return;
            if(!visible){CloseModelEditor();pendingQuickErrors.Clear();quickFeedback.Text="";quickFeedback.Visible=false;}
            inspectorHost.Visible=visible;WorldPreview.EditableAnnotations=false;WorldPreview.Invalidate();
            parameterToggle.Text=visible?"Cerrar ajustes":"Abrir ajustes";parameterToggle.BackColor=visible?DesignUi.Selection:DesignUi.Accent;parameterToggle.ForeColor=visible?DesignUi.Primary:Color.White;
            if(visible&&sections.Count>0){RefreshState();quickPanel.Focus();}
            else if(sections.Count>0){RefreshState();WorldPreview.Focus();}
        }
        protected override bool ProcessCmdKey(ref Message msg,Keys keyData){if(keyData==(Keys.Control|Keys.F)){SearchParameters();return true;}if(keyData==(Keys.Control|Keys.Z)){UndoDesign();return true;}if(keyData==(Keys.Control|Keys.Y)){UndoDesign(true);return true;}if(keyData==Keys.Escape&&modelEditor==null&&InspectorVisible){SetInspectorVisible(false);return true;}return base.ProcessCmdKey(ref msg,keyData);}
        internal void OpenDetails(int index){SetInspectorVisible(true);ShowCategory(index);inspectorTabs.SelectedIndex=1;}
        static Label QuickLabel(string text){return new Label{Text=text,AutoSize=true,ForeColor=DesignUi.Ink,Font=DesignUi.NavigationRegular,Margin=new Padding(0,7,0,5),Dock=DockStyle.Top};}
        void QuickRow(TableLayoutPanel table,Control control){int row=table.RowCount++;table.RowStyles.Add(new RowStyle(SizeType.AutoSize));table.Controls.Add(control,0,row);}
        void QuickField(TableLayoutPanel table,string title,Control input){
            var group=new RoundedPanel {BackColor=DesignUi.Canvas,Dock=DockStyle.Top,Height=72,Padding=new Padding(10,7,10,8),Margin=new Padding(0,0,0,8)};
            var label=QuickLabel(title);label.AutoSize=false;label.Height=24;label.Margin=Padding.Empty;label.ForeColor=DesignUi.Muted;
            input.Dock=DockStyle.Top;input.BackColor=DesignUi.Canvas;input.ForeColor=DesignUi.Ink;
            var number=input as NumericUpDown;if(number!=null)number.BorderStyle=BorderStyle.None;
            var combo=input as ComboBox;if(combo!=null)combo.FlatStyle=FlatStyle.Flat;
            group.Controls.Add(input);group.Controls.Add(label);QuickRow(table,group);
        }
        void BuildQuickEditor() {
            synchronizingQuick=true;pendingQuickErrors.Clear();quickInputs.Clear();
            quickPanel.SuspendLayout();
            // Shared labels remain owned by the inspector when their old table is disposed.
            if(quickResult.Parent!=null)quickResult.Parent.Controls.Remove(quickResult);if(quickFeedback.Parent!=null)quickFeedback.Parent.Controls.Remove(quickFeedback);
            while(quickPanel.Controls.Count>0)quickPanel.Controls[0].Dispose();
            var table=new TableLayoutPanel {Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Margin=Padding.Empty};table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));quickPanel.Controls.Add(table);
            quickResult.Name="SelectedTramoSummary";quickResult.Dock=DockStyle.Top;quickResult.AutoSize=true;quickResult.MaximumSize=new Size(285,0);quickResult.ForeColor=DesignUi.Muted;quickResult.Font=DesignUi.NavigationRegular;quickResult.Margin=new Padding(0,0,0,14);QuickRow(table,quickResult);
            quickFeedback.Dock=DockStyle.Top;quickFeedback.AutoSize=true;quickFeedback.ForeColor=Color.Firebrick;quickFeedback.MaximumSize=new Size(300,0);quickFeedback.Margin=new Padding(0,0,0,6);QuickRow(table,quickFeedback);
            var plasticColor=new ComboBox {Name="Quick_NylamidColor",DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Top};plasticColor.Items.AddRange(ViewerMaterials.NylamidNames);quickInputs.Add("NylamidColor",plasticColor);QuickField(table,"Color Nylamid (todos)",plasticColor);
            plasticColor.SelectedIndexChanged+=delegate{if(!synchronizingQuick&&plasticColor.SelectedIndex>=0)QuickEdit("NylamidColor",(string)plasticColor.SelectedItem,plasticColor);};tips.SetToolTip(plasticColor,"Acabado visual de todas las tiras. El color se guarda con el proyecto.");
            if(sections[selected].Type!=BeltSectionType.Intermedio){var bearing=BearingButton();bearing.Dock=DockStyle.Top;QuickRow(table,bearing);
                var sprocket=SprocketButton();sprocket.Dock=DockStyle.Top;QuickRow(table,sprocket);
                QuickRow(table,new Label{Text="Cantidad de sprockets · distribución uniforme",AutoSize=true});
                var shaft=sections[selected].ShaftPlates.Shaft;var quantity=new NumericUpDown{Minimum=1,Maximum=50,Value=Math.Max(1,Math.Min(50,shaft.SprocketCount)),Dock=DockStyle.Top};
                quantity.Name="Quick_SprocketCount";quantity.ValueChanged+=delegate{if(!synchronizingQuick){SetSprocketCount((int)quantity.Value);Changed(-1);}};QuickRow(table,quantity);
                var separate=new CheckBox{Name="IndependentSprocketCounts",Text="Permitir cantidades diferentes por eje",Checked=independentSprocketCounts,AutoSize=true};separate.CheckedChanged+=delegate{SetIndependentSprocketCounts(separate.Checked);Changed(-1);};QuickRow(table,separate);
                var sprocketColor=new ComboBox{Name="Quick_SprocketColor",DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Top};sprocketColor.Items.AddRange(ViewerMaterials.NylamidNames);sprocketColor.SelectedItem=shaft.SprocketColor??"Amarillo";sprocketColor.SelectedIndexChanged+=delegate{if(!synchronizingQuick){shaft.SprocketColor=sprocketColor.Text;Changed(-1);}};QuickField(table,"Color de sprockets de este eje",sprocketColor);
            }
            if(!sections[selected].IsCurved)AddQuickNumber(table,"Length");
            else QuickRow(table,ViewButton("Editar giro y radio de la curva",delegate{OpenDetails(0);},280));
            if(!sections[selected].IsCurved){
            var combination=new ComboBox {Name="Quick_Combination",DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Top,DropDownWidth=620};
            foreach(string code in ProfileSlotLayout.Combinations())combination.Items.Add(ProfileSlotLayout.CombinationLabel(code));
            quickInputs.Add("Combination",combination);QuickField(table,"Composición de este tramo",combination);
            combination.SelectedIndexChanged+=delegate{if(!synchronizingQuick&&combination.SelectedIndex>=0)QuickEdit("Combination",ProfileSlotLayout.Combinations()[combination.SelectedIndex],combination);};
            AddQuickNumber(table,"SlotHeight");AddQuickNumber(table,"SlotGap");AddQuickNumber(table,"SlotOffset");}
            var supportCount=new ComboBox {Name="Quick_SupportCount",DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Top};supportCount.Items.Add("Automático");for(int count=2;count<=SupportHoleLayout.MaximumCount;count++)supportCount.Items.Add(count+" soportes");quickInputs.Add("SupportCount",supportCount);QuickField(table,"Soportes de este tramo",supportCount);
            supportCount.SelectedIndexChanged+=delegate{if(!synchronizingQuick&&supportCount.SelectedIndex>=0)QuickEdit("SupportCount",supportCount.SelectedIndex==0?0:supportCount.SelectedIndex+1,supportCount);};
            var removeSupport=ViewButton("Quitar un soporte interior",delegate{string error;if(TryRemoveInteriorSupport(out error)){pendingQuickErrors.Remove("SupportCount");Changed(-1);}else{quickFeedback.Text=error;quickFeedback.Visible=true;}},280);removeSupport.Name="Quick_RemoveInteriorSupport";removeSupport.Dock=DockStyle.Top;QuickRow(table,removeSupport);
            var rails=new CheckBox {Name="Quick_Rails",Text="Incluir pletinas de Nylamid",AutoSize=true,Dock=DockStyle.Top,Margin=new Padding(0,12,0,5)};quickInputs.Add("Rails",rails);QuickRow(table,rails);rails.CheckedChanged+=delegate{if(!synchronizingQuick)QuickEdit("Rails",rails.Checked,rails);};
            AddQuickNumber(table,"Thickness");AddQuickNumber(table,"Width");if(!sections[selected].IsCurved)AddQuickNumber(table,"LogoScale");
            var details=ViewButton("Más ajustes de este tramo",delegate{OpenDetails(0);},280);details.Dock=DockStyle.Top;details.Margin=new Padding(0,16,0,12);QuickRow(table,details);
            synchronizingQuick=false;quickPanel.ResumeLayout();
        }
        void AddQuickNumber(TableLayoutPanel table,string key) {
            var spec=Spec(key);var n=new NumericUpDown {Name="Quick_"+key,Minimum=spec.Min,Maximum=spec.Max,DecimalPlaces=spec.Decimals,Increment=key=="Width"&&BeltWidthRules.IsE925(sections[selected].Profile.BeltModelName)?20:1,Dock=DockStyle.Top,Font=DesignUi.NavigationRegular,AccessibleName=spec.Title};
            quickInputs.Add(key,n);tips.SetToolTip(n,spec.Hint);QuickField(table,spec.Title,n);
            n.ValueChanged+=delegate{if(!synchronizingQuick)QuickEdit(key,(double)n.Value,n);};
        }
        double InteractiveValue(string key) {
            var s=sections[selected];var p=s.Profile;
            switch(key){case "Length":return s.LengthMm;case "SlotHeight":return p.SlotHeightMm;case "SlotGap":return p.SlotGapMm;case "SlotOffset":return p.SlotBottomOffsetMm;case "Width":return p.BandWidthMm;case "Thickness":return p.ThicknessMm;case "LogoScale":return p.MarkScale;default:throw new ArgumentException("Parámetro no disponible.");}
        }
        void RefreshQuickValues(ProfileSettings p,SoporteSettings support) {
            RefreshBearingButtons();RefreshSprocketButtons();
            synchronizingQuick=true;foreach(Control c in quickPanel.Controls.Find("Quick_SprocketCount",true))((NumericUpDown)c).Value=Math.Max(1,Math.Min(50,sections[selected].ShaftPlates.Shaft.SprocketCount));
            synchronizingQuick=true;
            try {
                foreach(var entry in quickInputs) {
                    if(pendingQuickErrors.ContainsKey(entry.Key))continue;var n=entry.Value as NumericUpDown;
                    if(n!=null){decimal value=(decimal)InteractiveValue(entry.Key);n.Value=Math.Max(n.Minimum,Math.Min(n.Maximum,value));n.BackColor=value<n.Minimum||value>n.Maximum?Color.MistyRose:DesignUi.Canvas;}
                    else if(entry.Key=="Combination")((ComboBox)entry.Value).SelectedIndex=Array.IndexOf(ProfileSlotLayout.Combinations(),sections[selected].Profile.SlotCombination??"");
                    else if(entry.Key=="SupportCount")((ComboBox)entry.Value).SelectedIndex=sections[selected].SupportCount==0?0:sections[selected].SupportCount-1;
                    else if(entry.Key=="Rails")((CheckBox)entry.Value).Checked=sections[selected].IncludeSlideRails;
                    else if(entry.Key=="NylamidColor")((ComboBox)entry.Value).SelectedItem=nylamidColor;
                }
                if(sections[selected].IsCurved)quickResult.Text="Curva "+(sections[selected].Curve.TurnRight?"derecha":"izquierda")+" · "+F(sections[selected].Curve.AngleDeg)+"°\nRadio interior "+F(sections[selected].Curve.RadiusFor(p.BandWidthMm))+" mm\n"+p.SupportCount+" soportes arriba / "+p.SupportCount+" abajo\n"+(support.CenterSlotCount+2)+" pletinas superiores / 3 inferiores";
                else try{var pattern=ProfileSlotLayout.PatternFor(p);quickResult.Text=p.BeltModelName+"  ·  banda "+F(p.BandWidthMm)+" mm  ·  "+p.SupportCount+" soportes\nAlma "+F(p.WebHeightMm)+" mm  ·  lámina "+F(p.ThicknessMm)+" mm\n"+ProfileSlotLayout.CombinationLabel(pattern.Combination)+"\n"+ProfileSlotLayout.DimensionsText(pattern);}
                catch(Exception ex){quickResult.Text=ex.Message;}
                foreach(Control button in quickPanel.Controls.Find("Quick_RemoveInteriorSupport",true))button.Enabled=p.SupportCount>2;
            } finally {synchronizingQuick=false;}
        }
        void QuickEdit(string key,object value,Control input) {
            string error;if(TryApplyInteractiveEdit(key,value,out error)){pendingQuickErrors.Remove(key);input.BackColor=DesignUi.Canvas;Changed(-1);}
            else{pendingQuickErrors[key]=error;input.BackColor=Color.MistyRose;ShowPendingQuickErrors();}
        }
        void ShowPendingQuickErrors() {
            quickFeedback.Text="";quickFeedback.Visible=pendingQuickErrors.Count>0;if(pendingQuickErrors.Count==0)return;
            foreach(var error in pendingQuickErrors.Values){quickFeedback.Text="Cambio pendiente, sin aplicar:\n"+error;break;}
            status.Text=quickFeedback.Text;status.ForeColor=Color.Firebrick;generate.Enabled=false;
        }
        void ChangeInteractiveValue(IList<BeltSectionSpec> list,string key,object value) {
            var section=list[selected];var p=section.Profile;
            if(key=="Combination"){p.SlotCombination=(string)value;return;}if(key=="Rails"){section.IncludeSlideRails=(bool)value;return;}
            double v=Convert.ToDouble(value);
            switch(key){
                case "Length":section.LengthMm=v;break;
                case "SlotHeight":p.SlotHeightMm=v;break;
                case "SlotGap":foreach(var s in list)s.Profile.SlotGapMm=v;break;
                case "SlotOffset":p.SlotBottomOffsetMm=v;break;
                case "Width":foreach(var s in list)BeltWidthRules.Validate(s.Profile.BeltModelName,v);foreach(var s in list)s.Profile.BandWidthMm=v;break;
                case "Thickness":p.ThicknessMm=v;break;
                case "LogoScale":p.MarkScale=v;break;
                case "SupportCount":section.SupportCount=(int)v;break;
                case "RedistributeSupportCount":section.SupportCount=(int)v;section.AutoSupportPitch=true;break;
                default:throw new ArgumentException("Parámetro no disponible.");
            }
        }
        void CopyInteractiveToAll(IList<BeltSectionSpec> list,string key){
            if(!applyToAllChanges)return;var origin=list[selected];foreach(var other in list){if(other==origin)continue;switch(key){
                case "Combination":other.Profile.SlotCombination=origin.Profile.SlotCombination;break;
                case "Rails":other.IncludeSlideRails=origin.IncludeSlideRails;break;
                case "SlotHeight":other.Profile.SlotHeightMm=origin.Profile.SlotHeightMm;break;
                case "SlotOffset":other.Profile.SlotBottomOffsetMm=origin.Profile.SlotBottomOffsetMm;break;
                case "Thickness":other.Profile.ThicknessMm=origin.Profile.ThicknessMm;break;
                case "LogoScale":other.Profile.MarkScale=origin.Profile.MarkScale;break;
                case "SupportCount":case "RedistributeSupportCount":other.SupportCount=origin.SupportCount;other.AutoSupportPitch=origin.AutoSupportPitch;break;
            }}
        }
        internal bool TryApplyInteractiveEdit(string key,object value,out string error) {
            error=null;
            try {
                if(generating)throw new InvalidOperationException("Espera a que termine la generación.");
                if(key=="NylamidColor"){ViewerMaterials.Nylamid((string)value);nylamidColor=(string)value;return true;}
                if(key!="Combination"&&key!="Rails"&&key!="SupportCount"&&key!="RedistributeSupportCount"){var spec=Spec(key);double v=Convert.ToDouble(value);if(Double.IsNaN(v)||Double.IsInfinity(v)||v<(double)spec.Min||v>(double)spec.Max)throw new InvalidOperationException("La medida está fuera del rango permitido.");}
                var candidate=new List<BeltSectionSpec>();foreach(var s in sections)candidate.Add(s.Copy());ChangeInteractiveValue(candidate,key,value);CopyInteractiveToAll(candidate,key);
                BeltLinePlan.Validate(candidate,profile);BeltLinePlan.ValidateSupports(candidate,profile,supportTemplate);ReturnRollerLayout.Build(candidate,profile,supportTemplate,rollers.Copy());
                ChangeInteractiveValue(sections,key,value);CopyInteractiveToAll(sections,key);if(key=="SlotGap")profile.SlotGapMm=Convert.ToDouble(value);
                return true;
            }catch(Exception ex){error=ex.Message;return false;}
        }
        internal bool TryRemoveInteriorSupport(out string error){
            error=null;
            try{
                int count=BeltLinePlan.ProfileFor(sections,selected,profile).SupportCount;
                if(count<=2){error="Se conservan los dos soportes de los extremos; no quedan soportes interiores para quitar.";return false;}
                return TryApplyInteractiveEdit("RedistributeSupportCount",count-1,out error);
            }catch(Exception ex){error=ex.Message;return false;}
        }
        void CloseModelEditor(){if(modelEditor!=null){modelEditor.Dispose();modelEditor=null;}}
        internal void OpenModelEditor(string key,Rectangle anchor){OpenModelEditor(WorldPreview,key,anchor);}
        void OpenModelEditor(Belt3DPreview source,string key,Rectangle anchor) {
            if(generating)return;CloseModelEditor();
            modelEditor=new RoundedPanel {Name="ModelParameterEditor",Size=new Size(300,212),BackColor=Color.White,Padding=new Padding(16)};
            var table=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=4};table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            table.RowStyles.Add(new RowStyle(SizeType.Absolute,34));table.RowStyles.Add(new RowStyle(SizeType.Absolute,36));table.RowStyles.Add(new RowStyle(SizeType.Percent,100));table.RowStyles.Add(new RowStyle(SizeType.Absolute,40));
            Control input;Func<object> read;string title;
            if(key=="Combination") {
                title="Composición / tramo "+(selected+1).ToString("00");var c=new ComboBox {Name="ModelValue",DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Top,DropDownWidth=620};var codes=ProfileSlotLayout.Combinations();foreach(string code in codes)c.Items.Add(ProfileSlotLayout.CombinationLabel(code));c.SelectedIndex=Array.IndexOf(codes,sections[selected].Profile.SlotCombination??"");input=c;read=delegate{return codes[c.SelectedIndex];};
            }else{var spec=Spec(key);title=spec.Title;var n=new NumericUpDown {Name="ModelValue",Minimum=spec.Min,Maximum=spec.Max,DecimalPlaces=spec.Decimals,Value=Math.Max(spec.Min,Math.Min(spec.Max,(decimal)InteractiveValue(key))),Dock=DockStyle.Top,Font=new Font("Segoe UI",11)};input=n;read=delegate{return (double)n.Value;};}
            var heading=QuickLabel(title);heading.Font=new Font("Segoe UI Semibold",10,FontStyle.Bold);table.Controls.Add(heading,0,0);table.Controls.Add(input,0,1);
            var message=new Label {Dock=DockStyle.Fill,ForeColor=DesignUi.Muted,Font=new Font("Segoe UI",9),Text=key=="Combination"?"Elige el orden; los largos se calculan automáticamente.":Spec(key).Hint};table.Controls.Add(message,0,2);
            string hint=message.Text;Action resetMessage=delegate{message.Text=hint;message.ForeColor=DesignUi.Muted;};
            if(input is NumericUpDown)((NumericUpDown)input).ValueChanged+=delegate{resetMessage();};else((ComboBox)input).SelectedIndexChanged+=delegate{resetMessage();};
            var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};
            Action apply=delegate{string error;if(TryApplyInteractiveEdit(key,read(),out error)){pendingQuickErrors.Remove(key);CloseModelEditor();Changed(-1);}else{message.Text=error;message.ForeColor=Color.Firebrick;}};
            var ok=ViewButton("Aplicar",apply,108);ok.Name="ApplyModelValue";ok.BackColor=DesignUi.Accent;ok.ForeColor=Color.White;actions.Controls.Add(ok);var cancel=ViewButton("Cancelar",CloseModelEditor,108);cancel.Name="CancelModelValue";cancel.BackColor=DesignUi.Canvas;actions.Controls.Add(cancel);table.Controls.Add(actions,0,3);modelEditor.Controls.Add(table);
            input.KeyDown+=delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Enter){e.Handled=true;e.SuppressKeyPress=true;apply();}else if(e.KeyCode==Keys.Escape){e.Handled=true;e.SuppressKeyPress=true;CloseModelEditor();}};
            source.Controls.Add(modelEditor);modelEditor.Location=new Point(Math.Max(8,Math.Min(source.Width-modelEditor.Width-8,anchor.Left)),Math.Max(42,Math.Min(source.Height-modelEditor.Height-40,anchor.Top-modelEditor.Height-10)));modelEditor.BringToFront();input.Focus();
        }
    }
}



