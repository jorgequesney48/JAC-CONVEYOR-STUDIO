﻿using System;
using System.Globalization;
using SolidWorks.Interop.sldworks;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
    internal static string GenerateLegCrossbar(SldWorks sw,VerticalSupportSettings settings,double lengthMm,string target){
        return CadReuseSession.Part("PTR_union_H",new{settings.TubeSideMm,lengthMm,settings.CrossbarHeightMm},target,()=>{
        settings.Validate();if(lengthMm<=0)throw new InvalidOperationException("El largo del travesaño H debe ser positivo.");SolidWorksDocumentSafety.Check(sw,new[]{target});sw.CloseDoc(System.IO.Path.GetFileName(target));
        var model=NewLegSketch(sw);double half=settings.TubeSideMm/2000,wall=LegCrossbarLayout.WallMm/1000;var sketch=model.SketchManager;
        sketch.CreateCornerRectangle(-half,-half,0,half,half,0);sketch.CreateCornerRectangle(-half+wall,-half+wall,0,half-wall,half-wall,0);sketch.AddToDB=false;
        var feature=model.FeatureManager.FeatureExtrusion2(true,false,false,0,0,lengthMm/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
        if(feature==null)throw new InvalidOperationException("No se pudo extruir el PTR de unión en H.");feature.Name="PTR_Union_H";
        var props=model.Extension.get_CustomPropertyManager("");props.Add3("PTR_pulgadas",30,settings.TubeSideInches.ToString(CultureInfo.InvariantCulture),2);props.Add3("Largo_PTR_mm",30,lengthMm.ToString(CultureInfo.InvariantCulture),2);props.Add3("Altura_eje_desde_base_mm",30,settings.CrossbarHeightMm.ToString(CultureInfo.InvariantCulture),2);props.Add3("Espesor_PTR_mm",30,LegCrossbarLayout.WallMm.ToString(CultureInfo.InvariantCulture),2);
        int errors=0,warnings=0;if(!model.SaveAs4(target,0,1,ref errors,ref warnings)||errors!=0)throw new InvalidOperationException("No se pudo guardar el travesaño H.");sw.CloseDoc(model.GetTitle());
        });
    }
}
}
