﻿using System;
namespace PerfilBandas {
internal sealed class LegCrossbarLayout {
    public double StartX,EndX,CenterY,SideMm,StationZ;
    public double LengthMm {get{return EndX-StartX;}}
    public const double WallMm=3;
    public static LegCrossbarLayout Build(VerticalSupportSettings settings,double leftMountX,double rightMountX,double leftMountY,double rightMountY,double stationZ){
        settings.Validate();double half=settings.TubeSideMm/2;
        var result=new LegCrossbarLayout{StartX=leftMountX+settings.EffectiveTubeCenterX+half,EndX=rightMountX-settings.EffectiveTubeCenterX-half,CenterY=-settings.BeltHeightMm+settings.CrossbarHeightMm,SideMm=settings.TubeSideMm,StationZ=stationZ};
        if(result.LengthMm<=0)throw new InvalidOperationException("No hay espacio entre las patas para colocar el travesaño H.");
        double lowestTop=Math.Min(leftMountY,rightMountY)+settings.EffectiveTubeCenterX-half+settings.BevelIntercept;
        if(result.CenterY-half<=-settings.BeltHeightMm+VerticalSupportSettings.FootBelowTubeMm||result.CenterY+half>=lowestTop)throw new InvalidOperationException("El travesaño H debe quedar dentro del PTR vertical, por encima de la tapa inferior y por debajo del montaje superior. Revisa su altura.");
        return result;
    }
    public static LegCrossbarLayout Nominal(VerticalSupportSettings settings,ProfileSettings profile,SoporteSettings support,double stationZ){
        var mount=VerticalSupportLayout.NominalMountMm(profile);double left=mount[0],right=support.LengthMm-mount[0],y=mount[1];
        return Build(settings,left,right,y,y,stationZ);
    }
    public double[] Transform(){return new[]{0.0,1,0,0,0,1,1,0,0,StartX/1000,CenterY/1000,StationZ/1000,1,0,0,0};}
}
}
