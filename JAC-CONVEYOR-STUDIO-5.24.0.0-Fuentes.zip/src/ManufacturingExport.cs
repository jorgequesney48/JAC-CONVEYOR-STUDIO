using System;
using System.IO;
using System.Collections.Generic;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
    // ExportToDWG2 blocked in the installed SOLIDWORKS build. Curves use analytic DXF.
    internal static void ExportFlatPatterns(SolidWorks.Interop.sldworks.SldWorks sw,IEnumerable<string> paths,string folder){
        var cnc=Directory.Exists(Path.Combine(folder,"CNC_CURVAS"))?Directory.GetFiles(Path.Combine(folder,"CNC_CURVAS"),"*.dxf"):new string[0];
        var report=new List<object>();
        foreach(string path in paths)if(path.EndsWith(".SLDPRT",StringComparison.OrdinalIgnoreCase)){
            string prefix=Path.GetFileNameWithoutExtension(path)+"_";var matching=Array.FindAll(cnc,f=>Path.GetFileName(f).StartsWith(prefix,StringComparison.OrdinalIgnoreCase));
            report.Add(new{Pieza=Path.GetFileName(path),Estado=matching.Length==3?"Tres DXF disponibles: alma y cejas superior/inferior":"Pendiente de revisión y exportación manual en SOLIDWORKS",Dxf=matching});
        }
        File.WriteAllText(Path.Combine(folder,"DESPLEGADOS.json"),new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(new{Estado=cnc.Length>0?"DXF analíticos de curvas generados; otras piezas requieren exportación manual":"Exportación automática de otras chapas deshabilitada: llamada CAD bloqueante",DxfCurvas=cnc,Piezas=report}));
        File.WriteAllText(Path.Combine(folder,"DESPLEGADOS_LEEME.txt"),(cnc.Length>0?"Los DXF de laterales curvos están en CNC_CURVAS (dos almas y cuatro cejas por curva).\r\n":"")+"Los DXF de las demás piezas NO se generaron automáticamente.\r\nAbrir las piezas restantes de chapa en SOLIDWORKS, comprobar su desplegado y exportar a DXF con geometría y líneas de doblez, escala 1:1.\r\nEl soporte C contiene placas soldadas: separar los cuerpos y sus desarrollos.\r\nConfirmar espesor, material, factor K y compensación del taller antes de cortar.\r\n");
    }
}
}
