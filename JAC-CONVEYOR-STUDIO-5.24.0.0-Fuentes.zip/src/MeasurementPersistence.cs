using System;
using System.Collections.Generic;
using System.Linq;
namespace PerfilBandas {
internal static class MeasurementPersistence {
 internal static void Identify(Belt3DGeometry mesh){
  if(mesh==null)return;var counts=new Dictionary<string,int>();
  foreach(var f in mesh.Faces){if(f.PartKey!=null)continue;
   string role=f.IsTransportBelt?"belt":f.IsLegCrossbar?"crossbar":f.IsVerticalSupport?"leg":f.IsCurveWeb?"web":f.IsCurveFlange?"flange":f.IsCurveUpperSupport?"upperSupport":f.IsCurveLowerSupport?"lowerSupport":f.IsCurveUpperGuide?"upperGuide":f.IsCurveLowerGuide?"lowerGuide":f.IsBearing?"bearing":f.IsShaft?"shaft":f.IsSprocket?"sprocket":f.Surface.ToString();
   string key="s"+f.Section+"/curve/"+role;int index;counts.TryGetValue(key,out index);counts[key]=index+1;f.PartKey=key;f.FaceKey=key+"/"+index;
  }
 }
 internal static BeltPoint3D Center(BeltFace3D face){return new BeltPoint3D(face.Outer.Average(p=>p.X),face.Outer.Average(p=>p.Y),face.Outer.Average(p=>p.Z));}
 static double[] Bounds(List<BeltFace3D> part){var points=part.SelectMany(f=>f.Outer).ToArray();return new[]{points.Min(p=>p.X),points.Min(p=>p.Y),points.Min(p=>p.Z),points.Max(p=>p.X),points.Max(p=>p.Y),points.Max(p=>p.Z)};}
 static BeltPoint3D Relative(BeltFace3D face,double[] b){var c=Center(face);return new BeltPoint3D((c.X-b[0])/Math.Max(1,b[3]-b[0]),(c.Y-b[1])/Math.Max(1,b[4]-b[1]),(c.Z-b[2])/Math.Max(1,b[5]-b[2]));}
 internal static int Find(Belt3DGeometry oldMesh,int index,Belt3DGeometry mesh){
  if(oldMesh==null||mesh==null||index<0||index>=oldMesh.Faces.Count)return -1;
  Identify(oldMesh);Identify(mesh);var prior=oldMesh.Faces[index];var oldPart=oldMesh.Faces.Where(f=>f.PartKey==prior.PartKey).ToList();var part=mesh.Faces.Where(f=>f.PartKey==prior.PartKey).ToList();if(part.Count==0)return -1;
  var exact=part.FirstOrDefault(f=>f.FaceKey==prior.FaceKey);
  if(prior.ParametricFaceKey!=null){var samples=part.Where(f=>f.ParametricFaceKey==prior.ParametricFaceKey).OrderBy(f=>Math.Abs(f.FaceParameter-prior.FaceParameter)).ToList();return samples.Count==0?-1:mesh.Faces.IndexOf(samples[0]);}
  if(exact!=null&&oldPart.Count==part.Count&&exact.Outer.Length==prior.Outer.Length)return mesh.Faces.IndexOf(exact);
  BeltPoint3D normal;if(!MeasurementGeometry.Normal(prior,out normal))return -1;var at=Relative(prior,Bounds(oldPart));var bounds=Bounds(part);double best=.025;BeltFace3D match=null;
  foreach(var candidate in part){BeltPoint3D n;if(!MeasurementGeometry.Normal(candidate,out n)||MeasurementGeometry.Dot(normal,n)<.95)continue;var c=Relative(candidate,bounds);double score=Math.Pow(at.X-c.X,2)+Math.Pow(at.Y-c.Y,2)+Math.Pow(at.Z-c.Z,2);if(score<best){best=score;match=candidate;}}
  return match==null?-1:mesh.Faces.IndexOf(match);
 }
}
internal sealed partial class Belt3DPreview {
 void RestoreMeasurement(Belt3DGeometry oldMesh,Belt3DGeometry mesh){
  bool had=Measurement.First>=0;int first=MeasurementPersistence.Find(oldMesh,Measurement.First,mesh),second=MeasurementPersistence.Find(oldMesh,Measurement.Second,mesh);
  if(first<0&&second>=0){first=second;second=-1;}if(first==second)second=-1;
  Measurement.First=first;Measurement.Second=second;Measurement.Result=null;
  if(first>=0){Measurement.FirstHit=MeasurementPersistence.Center(mesh.Faces[first]);if(second>=0){Measurement.SecondHit=MeasurementPersistence.Center(mesh.Faces[second]);Measurement.Result=MeasurementGeometry.Measure(mesh,first,second);measurementHint=Measurement.Result.Description;}else measurementHint="Cara 1 conservada · selecciona la segunda cara.";}
  else measurementHint=had?"La cara seleccionada ya no existe en el modelo actualizado.":null;
  NotifyMeasurement();
 }
}
}
