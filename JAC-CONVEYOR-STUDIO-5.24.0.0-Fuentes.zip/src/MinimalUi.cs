﻿using System;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PerfilBandas {
    internal static class MinimalLayout {
        internal static void FitToolbar(FlowLayoutPanel tools){
            bool updating=false;
            Action fit=delegate{if(updating)return;updating=true;try{int available=Math.Max(1,tools.ClientSize.Width-tools.Padding.Horizontal),used=0,row=0,total=tools.Padding.Vertical;foreach(Control c in tools.Controls){int w=c.Width+c.Margin.Horizontal,h=c.Height+c.Margin.Vertical;if(used>0&&used+w>available){total+=row;row=0;used=0;}used+=w;row=Math.Max(row,h);}total+=row;if(tools.Height!=total)tools.Height=total;}finally{updating=false;}};
            tools.Layout+=delegate{fit();};tools.SizeChanged+=delegate{fit();};
        }
    }
    internal static class MinimalShape {
        internal static GraphicsPath Round(Rectangle bounds,int radius) {
            var path=new GraphicsPath();int d=Math.Max(1,Math.Min(radius*2,Math.Min(bounds.Width,bounds.Height)));
            path.AddArc(bounds.Left,bounds.Top,d,d,180,90);path.AddArc(bounds.Right-d,bounds.Top,d,d,270,90);
            path.AddArc(bounds.Right-d,bounds.Bottom-d,d,d,0,90);path.AddArc(bounds.Left,bounds.Bottom-d,d,d,90,90);path.CloseFigure();return path;
        }
    }
    // Keep native Button keyboard, accessibility and click behavior, painting only its surface.
    internal sealed class RoundedButton : Button {
        internal int Radius=5;
        internal bool Outlined {get;set;}
        bool hover,pressed;
        internal RoundedButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;UseVisualStyleBackColor=false;}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=false;pressed=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnMouseDown(MouseEventArgs e){pressed=true;Invalidate();base.OnMouseDown(e);}
        protected override void OnMouseUp(MouseEventArgs e){pressed=false;Invalidate();base.OnMouseUp(e);}
        protected override void OnPaint(PaintEventArgs e){
            var g=e.Graphics;g.Clear(Parent==null?DesignUi.Canvas:Parent.BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;
            bool destructive=BackColor==DesignUi.Danger;Color fill=BackColor;if(!Enabled)fill=destructive?Color.FromArgb(250,222,224):DesignUi.Canvas;else if(pressed)fill=ControlPaint.Dark(fill,.08f);else if(hover)fill=ControlPaint.Dark(fill,.025f);
            using(var path=MinimalShape.Round(new Rectangle(1,1,Math.Max(1,Width-3),Math.Max(1,Height-3)),Radius)){
                using(var brush=new SolidBrush(fill))g.FillPath(brush,path);
                if(Outlined||Focused)using(var pen=new Pen(Focused?DesignUi.Accent:DesignUi.Border,Focused?2:1))g.DrawPath(pen,path);
            }
            var flags=TextFormatFlags.VerticalCenter|TextFormatFlags.WordBreak|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding;
            flags|=TextAlign==ContentAlignment.MiddleLeft?TextFormatFlags.Left:TextFormatFlags.HorizontalCenter;
            if(!ShowKeyboardCues)flags|=TextFormatFlags.HidePrefix;
            int inset=Width<=42?2:9;
            TextRenderer.DrawText(g,Text,Font,new Rectangle(Padding.Left+inset,Padding.Top,Math.Max(1,Width-Padding.Horizontal-inset*2),Math.Max(1,Height-Padding.Vertical)),Enabled?ForeColor:destructive?Color.FromArgb(154,71,76):DesignUi.Muted,flags);
        }
    }
    internal sealed class RoundedPanel : Panel {
        internal RoundedPanel(){DoubleBuffered=true;ResizeRedraw=true;}
        protected override void OnPaintBackground(PaintEventArgs e){
            e.Graphics.Clear(Parent==null?DesignUi.Canvas:Parent.BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            using(var path=MinimalShape.Round(new Rectangle(0,0,Math.Max(1,Width-1),Math.Max(1,Height-1)),16))using(var brush=new SolidBrush(BackColor))e.Graphics.FillPath(brush,path);
        }
    }
    // Borderless pages navigated by separate segmented buttons.
    internal sealed class InspectorPages : Panel {
        internal sealed class PageCollection : Collection<Panel> {
            readonly InspectorPages owner;internal PageCollection(InspectorPages value){owner=value;}
            protected override void InsertItem(int index,Panel item){base.InsertItem(index,item);item.Dock=DockStyle.Fill;owner.Controls.Add(item);owner.UpdatePages();}
            internal void AddRange(Panel[] pages){foreach(var p in pages)Add(p);}
        }
        internal readonly PageCollection TabPages;
        int selectedIndex;
        internal event EventHandler SelectedIndexChanged;
        internal InspectorPages(){TabPages=new PageCollection(this);}
        internal int SelectedIndex {get{return selectedIndex;}set{if(value<0||value>=TabPages.Count||value==selectedIndex)return;selectedIndex=value;UpdatePages();if(SelectedIndexChanged!=null)SelectedIndexChanged(this,EventArgs.Empty);}}
        void UpdatePages(){for(int i=0;i<TabPages.Count;i++){TabPages[i].Visible=i==selectedIndex;if(i==selectedIndex)TabPages[i].BringToFront();}}
    }
    internal sealed class MinimalToolStripRenderer : ToolStripProfessionalRenderer {
        internal MinimalToolStripRenderer(){RoundedEdges=false;}
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e){}
        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e){
            var b=e.Item as ToolStripButton;if(b==null||(!b.Checked&&!b.Selected))return;
            using(var path=MinimalShape.Round(new Rectangle(0,0,Math.Max(1,b.Width-1),Math.Max(1,b.Height-1)),9))using(var fill=new SolidBrush(b.Checked?DesignUi.Selection:DesignUi.Canvas))e.Graphics.FillPath(fill,path);
        }
    }
}
