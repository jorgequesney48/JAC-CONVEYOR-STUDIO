using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool showSupports = args != null && args.Length > 0 && args[0].ToLower().Contains("soporte");
            Application.Run(new MainForm(showSupports));
        }
    }


    internal sealed class ProfileSettings
    {
        public bool CurvedWeldedProfile;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double ResolvedCurveReturnDropMm;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double ResolvedCurveRollerRiseMm=10;
        public ProfileSettings Copy() {
            var copy=(ProfileSettings)MemberwiseClone();
            if(ResolvedSlots!=null) copy.ResolvedSlots=Array.ConvertAll(ResolvedSlots,delegate(ProfileSlotSpec slot){return slot.Copy();});
            if(ResolvedRollerHoles!=null) copy.ResolvedRollerHoles=Array.ConvertAll(ResolvedRollerHoles,delegate(ReturnRollerHole hole){return hole.Copy();});
            if(ResolvedPattern!=null) copy.ResolvedPattern=ResolvedPattern.Copy();
            if(ResolvedSupportCentersMm!=null)copy.ResolvedSupportCentersMm=(double[])ResolvedSupportCentersMm.Clone();
            return copy;
        }
        [System.Web.Script.Serialization.ScriptIgnore]
        public ProfilePattern ResolvedPattern;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double[] ResolvedSupportCentersMm;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double? ResolvedUpperSupportBottomYMm;
        public double SlotGapMm=200, SlotHeightMm=60, SlotBottomOffsetMm=80, SlotReferenceLengthMm=2400;
        public bool SlotTrimFromRight=false;
        public bool AdaptFunctionalCuts=true;
        public bool CenteredCuts=false;
        public string SlotCombination=""; // Empty = automatic; R = slot, L = logo, in longitudinal order.
        public double LengthMm = 2400;
        public double WebHeightMm = 225.50;
        public string Gauge = "14";
        public double ThicknessMm = 1.90;
        public double BendRadiusMm = 1.50;
        public double KFactor = 0.45;
        public double TopFlangeMm = 31.75;
        public double TopAngleDeg = 90;
        public double BottomFlangeMm = VerticalSupportSettings.DefaultBottomFlangeMm;
        public double BottomAngleDeg = 135;
        public bool MarkA = true;
        public bool MarkB = false;
        public double MarkScale = 170;
        public int SlotCount = 4;
        public double SlotOverallLengthMm = 300;
        public double SlotEndRadiusMm = 30;
        public double SlotSpacingMm = 500;
        [System.Web.Script.Serialization.ScriptIgnore]
        public ProfileSlotSpec[] ResolvedSlots;
        [System.Web.Script.Serialization.ScriptIgnore]
        public ReturnRollerHole[] ResolvedRollerHoles;

        // Orificios en extremos — medidas estándar (imperial) según macro PERFORACIONES SOPORTES.swp
        public string EndHoleTypeLeft  = "ninguno";   // "ninguno", "empalme", "final"
        public string EndHoleTypeRight = "ninguno";
        // Cuadrado 11×11 mm; 31.75 mm (1¼") del borde; 63.5 mm (2½") entre orificios.
        public double EndHoleSizeMm    = 11.0;
        public double EndHoleEdgeMm    = 31.75;
        public double EndHoleSpacingMm = 63.5;
        public bool EndHolesBottom     = true; // Pestaña inferior 45° (soporte PTR)
        public bool EndHolesTop        = true; // Pestaña superior 90° (aditamentos)

        // Orificios en el alma para sujeción de los 6 soportes C transversales
        public bool IncludeSupportHoles    = true;      // 6 orificios para atornillar los soportes transversales
        public int SupportCount            = 6;         // 2 a 32 soportes; cada tramo de banda puede elegirlo
        public double SupportHoleSizeMm    = 11.0;      // Cuadrado 11×11 mm (tornillo de coche 3/8")
        public double SupportHoleYMm       = 60.0;      // Cota vertical desde borde superior del alma (mm)
        public double SupportHoleEdgeMm    = 50.0;      // Medida inicial desde el extremo al borde del 1er orificio (mm)
        public double SupportHoleSpacingMm = 420.0;     // Paso entre orificios (420 mm estándar según macro)

        // Modelo de banda seleccionado del catálogo band_catalog.json
        public string BeltModelName    = "E925";
        public double BeltThicknessMm = 12.0;
        public bool AutoSupportHeight = true;
        public double BandWidthMm      = 520;   // Ancho inicial de la correa (mm).

        // Lado del perfil: "LH" (izquierdo), "RH" (derecho) o "par" (ambos)
        public string Side             = "LH";

        // Standard US stainless sheet nominal thicknesses. Editable in the UI.
        public static double GaugeThickness(string gauge)
        {
            switch (gauge)
            {
                case "10": return 3.42;
                case "12": return 2.66;
                case "14": return 1.90;
                case "16": return 1.51;
                case "18": return 1.21;
                default: return 1.90;
            }
        }
    }

    // ── Catálogo de modelos de banda ─────────────────────────────────────────────
    internal sealed class BeltModel
    {
        public string Name;
        public int MinWidthMm;
        public int MaxWidthMm;
        public int StepMm;

        public string[] ValidWidths()
        {
            var list = new System.Collections.Generic.List<string>();
            for (int w = MinWidthMm; w <= MaxWidthMm; w += StepMm)
                list.Add(w.ToString());
            return list.ToArray();
        }

        public override string ToString() { return Name; }
    }

    internal static class BeltCatalog
    {
        private static readonly BeltModel[] _defaults = new BeltModel[]
        {
            new BeltModel { Name = "E925", MinWidthMm = 100, MaxWidthMm = 1320, StepMm = 20 }
        };

        /// <summary>Carga el catálogo desde band_catalog.json junto al .exe.
        /// Si el archivo no existe, lo crea con el modelo E925 por defecto.</summary>
        public static BeltModel[] Load(string folder)
        {
            string path = Path.Combine(folder, "band_catalog.json");
            if (!File.Exists(path))
            {
                TryWriteDefault(path);
                return _defaults;
            }
            try
            {
                string json = File.ReadAllText(path, System.Text.Encoding.UTF8);
                BeltModel[] parsed = Parse(json);
                return (parsed != null && parsed.Length > 0) ? parsed : _defaults;
            }
            catch
            {
                return _defaults;
            }
        }

        private static void TryWriteDefault(string path)
        {
            try
            {
                const string json =
                    "{\r\n" +
                    "  \"modelos\": [\r\n" +
                    "    {\r\n" +
                    "      \"nombre\": \"E925\",\r\n" +
                    "      \"ancho_min_mm\": 100,\r\n" +
                    "      \"ancho_max_mm\": 1320,\r\n" +
                    "      \"incremento_mm\": 20\r\n" +
                    "    }\r\n" +
                    "  ]\r\n" +
                    "}\r\n";
                File.WriteAllText(path, json, System.Text.Encoding.UTF8);
            }
            catch { }
        }

        private static BeltModel[] Parse(string json)
        {
            var models = new System.Collections.Generic.List<BeltModel>();
            int start = 0;
            while (true)
            {
                int ob = json.IndexOf('{', start);
                if (ob < 0) break;
                int cb = json.IndexOf('}', ob + 1);
                if (cb < 0) break;
                string block = json.Substring(ob, cb - ob + 1);
                start = cb + 1;
                if (block.Contains("modelos")) continue; // bloque raíz, lo saltamos
                string name = ExtractString(block, "nombre");
                int    min  = ExtractInt(block, "ancho_min_mm");
                int    max  = ExtractInt(block, "ancho_max_mm");
                int    step = ExtractInt(block, "incremento_mm");
                if (name == null || min <= 0 || max <= min || step <= 0 || step > (max - min)) continue;
                if(BeltWidthRules.IsE925(name)){step=20;min=Math.Max(100,((min+19)/20)*20);max=(max/20)*20;}
                models.Add(new BeltModel { Name = name, MinWidthMm = min, MaxWidthMm = max, StepMm = step });
            }
            return models.ToArray();
        }

        private static string ExtractString(string block, string key)
        {
            string pat = "\"" + key + "\"";
            int ki = block.IndexOf(pat);
            if (ki < 0) return null;
            int colon = block.IndexOf(':', ki + pat.Length);
            if (colon < 0) return null;
            int q1 = block.IndexOf('"', colon + 1);
            if (q1 < 0) return null;
            int q2 = block.IndexOf('"', q1 + 1);
            if (q2 < 0) return null;
            return block.Substring(q1 + 1, q2 - q1 - 1);
        }

        private static int ExtractInt(string block, string key)
        {
            string pat = "\"" + key + "\"";
            int ki = block.IndexOf(pat);
            if (ki < 0) return 0;
            int colon = block.IndexOf(':', ki + pat.Length);
            if (colon < 0) return 0;
            int p = colon + 1;
            while (p < block.Length && (block[p] == ' ' || block[p] == '\t' || block[p] == '\r' || block[p] == '\n')) p++;
            int end = p;
            while (end < block.Length && char.IsDigit(block[end])) end++;
            int result;
            return int.TryParse(block.Substring(p, end - p), out result) ? result : 0;
        }
    }

    internal sealed class MainForm : Form
    {
        private readonly ProfileSettings values = new ProfileSettings();
        private readonly ProfilePreview preview = new ProfilePreview();
        private readonly FrontProfilePreview frontPreview = new FrontProfilePreview();
        private readonly AssemblyPreview assemblyPreview = new AssemblyPreview();
        private readonly Panel workspaceHost = new Panel { Dock = DockStyle.Fill };
        private readonly Panel profileWorkspace = new Panel { Dock = DockStyle.Fill };
        private TabControl previewTabs;
        private ToolStripButton profileNav;
        private ToolStripButton supportNav;
        private ToolStripButton completeNav;
        private readonly NumericUpDown length = Number(2400, 100, 12000, 1);
        private readonly NumericUpDown height = Number(225.50m, 20, 1000, .01m);
        private readonly ComboBox gauge = new ComboBox();
        private readonly NumericUpDown thickness = Number(1.90m, .5m, 6, .01m);
        private readonly NumericUpDown radius = Number(1.50m, .1m, 25, .01m);
        private readonly NumericUpDown profileK = Number(.45m, .01m, .99m, .01m);
        private readonly NumericUpDown topFlange = Number(31.75m, 5, 250, .01m);
        private readonly NumericUpDown topAngle = Number(90, 1, 179, .1m);
        private readonly NumericUpDown bottomFlange = Number((decimal)VerticalSupportSettings.DefaultBottomFlangeMm, 5, 250, .01m);
        private readonly NumericUpDown bottomAngle = Number(135, 1, 179, .1m);
        private readonly RadioButton markA = new RadioButton { Text = "Logo A — emblema vectorizado (ancho base 140 mm)", Checked = true, AutoSize = true };
        private readonly RadioButton markB = new RadioButton { Text = "Marca B — hexágono Ø 70 mm", AutoSize = true };
        private readonly NumericUpDown markScale = Number(170, 10, 300, 1);
        private readonly NumericUpDown slotHeight=Number(60,2,150,1),slotGap=Number(200,20,450,1),slotOffset=Number(80,10,200,1);
        private readonly Label slotLayoutNote=new Label {AutoSize=true,MaximumSize=new Size(290,0)};
        private readonly ComboBox holeLeft  = new ComboBox();
        private readonly ComboBox holeRight = new ComboBox();
        private readonly CheckBox holeBottom = new CheckBox { Text = "Perforaciones inferiores (soporte a 45°)", Checked = true, AutoSize = true };
        private readonly CheckBox holeTop    = new CheckBox { Text = "Perforaciones superiores (aditamentos)", Checked = true, AutoSize = true };

        // Orificios en el alma para sujeción de soportes C
        private readonly CheckBox includeSupportHoles = new CheckBox { Text = "Generar 6 barrenos para soportes C en alma", Checked = true, AutoSize = true, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = Color.FromArgb(0, 102, 170) };
        private readonly NumericUpDown supportHoleEdge = Number(50.0m, 10, 300, 1);
        private readonly NumericUpDown supportHoleY    = Number(60.0m, 10, 200, 1);
        private readonly NumericUpDown supportHoleStep = Number(420.0m, 50, 2000, 1);
        private readonly NumericUpDown supportHoleSize = Number(11.0m, 6, 30, .5m);
        private readonly Label supportLayoutNote = new Label { AutoSize = true, MaximumSize = new Size(420, 0), Font = new Font("Segoe UI", 8.5f), Margin = new Padding(0, 4, 0, 12) };

        private readonly TextBox targetFolderBox = new TextBox { Text = ProjectPaths.GetDefaultPiecesFolder(), Dock = DockStyle.Fill };
        private readonly Label status = new Label { AutoSize = true, ForeColor = Color.DimGray, MaximumSize = new Size(520, 0) };

        // Catálogo de modelos de banda — cargado desde band_catalog.json junto al .exe
        private BeltModel[] catalog;
        private readonly ComboBox beltModelBox   = new ComboBox();
        private readonly ComboBox bandWidthBox   = new ComboBox();
        private readonly Label    bandRangeLabel = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(0, 0, 0, 8) };

        // Selector de lado
        private readonly ComboBox sideBox = new ComboBox();
        private SoporteForm _soporteFormInstance;
        private CompleteBeltView _completeBeltView;

        public MainForm(bool showSupports = false)
        {
            Text = "JAC · Bandas · v" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(3);
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(1120, 720);
            Size = new Size(1440, 860);
            BackColor = DesignUi.Canvas;
            Font = new Font("Segoe UI", 10f);

            var topNav = new ToolStrip
            {
                GripStyle = ToolStripGripStyle.Hidden,
                BackColor = DesignUi.Surface,
                Padding = new Padding(16, 9, 16, 9),
                Renderer = new MinimalToolStripRenderer(),
                Dock = DockStyle.Top
            };
            var brand = new ToolStripLabel("JAC   Bandas")
            {
                Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold),
                ForeColor = DesignUi.Ink,
                Margin = new Padding(0, 0, 28, 0)
            };
            profileNav = new ToolStripButton("Perfiles laterales")
            {
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = DesignUi.Primary,
                Checked = true
            };
            supportNav = new ToolStripButton("Soportes C")
            {
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = DesignUi.Primary
            };
            completeNav = new ToolStripButton("Banda completa")
            {
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = DesignUi.Primary
            };
            profileNav.Click += delegate { ShowProfileWorkspace(); };
            supportNav.Click += delegate { OpenSoporteWindow(); };
            completeNav.Click += delegate { OpenCompleteBelt(); };
            topNav.Items.Add(brand);
            topNav.Items.Add(completeNav);
            var individualParts = new ToolStripDropDownButton("Piezas individuales");
            individualParts.DropDownItems.Add(profileNav);
            individualParts.DropDownItems.Add(supportNav);
            topNav.Items.Add(individualParts);

            gauge.DropDownStyle = ComboBoxStyle.DropDownList;
            gauge.Items.AddRange(new object[] { "10", "12", "14", "16", "18" });
            gauge.SelectedItem = "14";
            gauge.SelectedIndexChanged += delegate { thickness.Value = (decimal)ProfileSettings.GaugeThickness(gauge.Text); Sync(); };


            string[] holeTypes = new string[] { "Ninguno", "Empalme (1 orificio)", "Final de banda (2 orificios)" };
            holeLeft.DropDownStyle  = ComboBoxStyle.DropDownList;
            holeLeft.Items.AddRange(holeTypes);  holeLeft.SelectedIndex  = 0;
            holeRight.DropDownStyle = ComboBoxStyle.DropDownList;
            holeRight.Items.AddRange(holeTypes); holeRight.SelectedIndex = 0;

            // ── Catálogo de modelos de banda ──────────────────────────────────────
            catalog = BeltCatalog.Load(AppDomain.CurrentDomain.BaseDirectory);
            beltModelBox.DropDownStyle = ComboBoxStyle.DropDownList;
            foreach (BeltModel m in catalog) beltModelBox.Items.Add(m);
            if (beltModelBox.Items.Count > 0) beltModelBox.SelectedIndex = 0;
            bandWidthBox.DropDownStyle = ComboBoxStyle.DropDownList;
            RebuildWidths();
            beltModelBox.SelectedIndexChanged += delegate { RebuildWidths(); Sync(); };
            bandWidthBox.SelectedIndexChanged  += delegate { Sync(); };

            // Selector de lado LH / RH / Par
            sideBox.DropDownStyle = ComboBoxStyle.DropDownList;
            sideBox.Items.AddRange(new object[] { "Izquierdo (LH)", "Derecho (RH)", "Par (LH + RH)" });
            sideBox.SelectedIndex = 0;
            sideBox.SelectedIndexChanged += delegate { Sync(); };

            var categories = new CategoryWorkspace();
            var left = categories.AddPage("Banda", "Selecciona el modelo, ancho y lado del perfil.");
            Section(left, "Modelo de banda");
            Row(left, "Modelo", beltModelBox);
            Row(left, "Ancho de banda (mm)", bandWidthBox);
            left.Controls.Add(bandRangeLabel, 0, left.RowCount); left.SetColumnSpan(bandRangeLabel, 2); left.RowCount++;
            Section(left, "Lado del perfil");
            Row(left, "Lado a generar", sideBox);
            var sideNote = new Label { Text = "LH = izquierdo  ·  RH = derecho  ·  Par genera ambos archivos .SLDPRT", AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(0, 0, 0, 8) };
            left.Controls.Add(sideNote, 0, left.RowCount); left.SetColumnSpan(sideNote, 2); left.RowCount++;
            left = categories.AddPage("Geometría", "Dimensiones de la lámina y dobleces del perfil.");
            Section(left, "Dimensiones generales");
            Row(left, "Longitud total (mm)", length);
            Row(left, "Altura del cuerpo vertical (mm)", height);
            Row(left, "Calibre de lámina inoxidable", gauge);
            Row(left, "Espesor asociado al calibre (mm)", thickness);
            Row(left, "Radio interior de doblez (mm)", radius);
            Row(left, "Factor K del perfil", profileK);
            Section(left, "Doblez superior");
            Row(left, "Pestaña (mm)", topFlange);
            Row(left, "Ángulo (°)", topAngle);
            Section(left, "Doblez inferior");
            Row(left, "Pestaña (mm)", bottomFlange);
            Row(left, "Ángulo interno (°)", bottomAngle);
            left = categories.AddPage("Marca y ranuras", "Distribución automática con separación libre constante.");
            Section(left, "Marca y estado automático de recorte");
            left.Controls.Add(markA, 0, left.RowCount); left.SetColumnSpan(markA, 2); left.RowCount++;
            left.Controls.Add(markB, 0, left.RowCount); left.SetColumnSpan(markB, 2); left.RowCount++;
            Row(left, "Escala de logo (%)", markScale);
            Section(left, "Ranuras horizontales");
            Row(left,"Altura de ranura (mm)",slotHeight);
            Row(left,"Separación libre (mm)",slotGap);
            Row(left,"Borde inferior sobre doblez (mm)",slotOffset);
            left.Controls.Add(slotLayoutNote,0,left.RowCount);left.SetColumnSpan(slotLayoutNote,2);left.RowCount++;
            left = categories.AddPage("Barrenos", "Fijaciones del soporte C y perforaciones de los extremos.");
            Section(left, "Orificios para soportes C (alma)");
            left.Controls.Add(includeSupportHoles, 0, left.RowCount); left.SetColumnSpan(includeSupportHoles, 2); left.RowCount++;
            Row(left, "Distancia al 1er orificio (mm)", supportHoleEdge);
            Row(left, "Altura vertical Y (mm)", supportHoleY);
            Row(left, "Paso entre orificios (mm)", supportHoleStep);
            Row(left, "Tamaño barreno cuadrado (mm)", supportHoleSize);
            left.Controls.Add(supportLayoutNote, 0, left.RowCount); left.SetColumnSpan(supportLayoutNote, 2); left.RowCount++;
            Section(left, "Orificios en extremos (soportes y aditamentos)");
            Row(left, "Extremo izquierdo", holeLeft);
            Row(left, "Extremo derecho", holeRight);
            left.Controls.Add(holeBottom, 0, left.RowCount); left.SetColumnSpan(holeBottom, 2); left.RowCount++;
            left.Controls.Add(holeTop, 0, left.RowCount); left.SetColumnSpan(holeTop, 2); left.RowCount++;
            var holeNote = new Label { Text = "Medidas estándar: cuadrado 11×11 mm · 31.75 mm (1¼\") del borde · 63.5 mm (2½\") entre orificios", AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(0, 2, 0, 8) };
            left.Controls.Add(holeNote, 0, left.RowCount); left.SetColumnSpan(holeNote, 2); left.RowCount++;

            left = categories.AddPage("Generación", "Revisa la carpeta y genera piezas o el ensamble en SOLIDWORKS.");
            Section(left, "Carpeta de Destino para Ensamble");
            var folderPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoSize = true, Margin = new Padding(0, 0, 0, 4) };
            folderPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            folderPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            var openFolderBtn = new Button { Text = "Abrir carpeta", Dock = DockStyle.Fill, Height = 34 };
            openFolderBtn.Click += delegate { ProjectPaths.OpenFolder(targetFolderBox.Text); };
            var browseFolderBtn = new Button { Text = "Examinar...", Dock = DockStyle.Fill, Height = 34 };
            browseFolderBtn.Click += delegate
            {
                using (var fbd = new FolderBrowserDialog())
                {
                    fbd.SelectedPath = targetFolderBox.Text;
                    if (fbd.ShowDialog() == DialogResult.OK)
                        targetFolderBox.Text = fbd.SelectedPath;
                }
            };
            folderPanel.Controls.Add(targetFolderBox, 0, 0); folderPanel.SetColumnSpan(targetFolderBox, 2);
            folderPanel.Controls.Add(browseFolderBtn, 0, 1);
            folderPanel.Controls.Add(openFolderBtn, 1, 1);
            left.Controls.Add(folderPanel, 0, left.RowCount); left.SetColumnSpan(folderPanel, 2); left.RowCount++;

            var generateAllBtn = new Button
            {
                Text = "Generar piezas LH, RH y soporte C",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Height = 44,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(0, 120, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 6, 0, 4)
            };
            generateAllBtn.Click += GenerateAllForAssembly;
            left.Controls.Add(generateAllBtn, 0, left.RowCount); left.SetColumnSpan(generateAllBtn, 2); left.RowCount++;

            var assembleAllBtn = new Button
            {
                Text = "Armar ensamble completo",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Height = 48,
                Dock = DockStyle.Fill,
                BackColor = DesignUi.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 4, 0, 6)
            };
            assembleAllBtn.Click += AssembleAllConveyor;
            left.Controls.Add(assembleAllBtn, 0, left.RowCount); left.SetColumnSpan(assembleAllBtn, 2); left.RowCount++;

            var generate = new Button { Text = "Crear solo perfil lateral en SOLIDWORKS", AutoSize = true, Height = 34, Dock = DockStyle.Fill, BackColor = Color.FromArgb(0, 102, 170), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Margin = new Padding(0, 2, 0, 6) };
            generate.Click += Generate;
            left.Controls.Add(generate, 0, left.RowCount); left.SetColumnSpan(generate, 2); left.RowCount++;
            left.Controls.Add(status, 0, left.RowCount); left.SetColumnSpan(status, 2); left.RowCount++;


            Section(left, "Continuar con soporte C");
            var openSupportBtn = new Button
            {
                Text = "Configurar soporte C",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                AutoSize = true,
                Height = 40,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(0, 120, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 4, 0, 10)
            };
            openSupportBtn.Click += delegate { OpenSoporteWindow(); };
            left.Controls.Add(openSupportBtn, 0, left.RowCount); left.SetColumnSpan(openSupportBtn, 2); left.RowCount++;

            var right = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18), BackColor = DesignUi.Canvas };
            var previewTitle = new Label {
                Text = "Vista previa interactiva", Dock = DockStyle.Top, Height = 42,
                Font = new Font("Segoe UI Semibold", 14f, FontStyle.Bold),
                ForeColor = DesignUi.Ink, TextAlign = ContentAlignment.MiddleLeft
            };
            previewTabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10f), Padding = new Point(16, 7) };
            var assemblyTab = new TabPage("Ensamble") { BackColor = Color.White };
            var sectionTab = new TabPage("Sección transversal") { BackColor = Color.White };
            var frontTab = new TabPage("Vista frontal") { BackColor = Color.White };
            assemblyPreview.Dock = DockStyle.Fill;
            preview.Dock = DockStyle.Fill;
            frontPreview.Dock = DockStyle.Fill;
            assemblyTab.Controls.Add(assemblyPreview);
            sectionTab.Controls.Add(preview);
            frontTab.Controls.Add(frontPreview);
            previewTabs.TabPages.AddRange(new TabPage[] { assemblyTab, sectionTab, frontTab });
            categories.PageChanged += delegate(int page) {
                assemblyPreview.HighlightCategory = page;
                assemblyPreview.Invalidate();
                previewTabs.SelectedIndex = page == 1 ? 1 : page == 2 || page == 3 ? 2 : 0;
            };
            right.Controls.Add(previewTabs);
            right.Controls.Add(previewTitle);
            profileWorkspace.Controls.Add(right);
            profileWorkspace.Controls.Add(categories);
            workspaceHost.Controls.Add(profileWorkspace);
            Controls.Add(workspaceHost);
            Controls.Add(topNav);
            DesignUi.StyleInputs(categories);

            foreach (Control c in new Control[] { length, height, thickness, radius, profileK, topFlange, topAngle, bottomFlange, bottomAngle, markScale, markA, markB, slotHeight, slotGap, slotOffset, holeLeft, holeRight, holeBottom, holeTop, includeSupportHoles, supportHoleEdge, supportHoleY, supportHoleStep, supportHoleSize })
            {
                if (c is NumericUpDown) ((NumericUpDown)c).ValueChanged += delegate { Sync(); };
                if (c is RadioButton) ((RadioButton)c).CheckedChanged += delegate { Sync(); };
                if (c is CheckBox) ((CheckBox)c).CheckedChanged += delegate { Sync(); };
                if (c is ComboBox) ((ComboBox)c).SelectedIndexChanged += delegate { Sync(); };
            }
            Sync();
            if (showSupports) Shown += delegate { OpenSoporteWindow(); };
            else Shown += delegate { OpenCompleteBelt(); };
        }

        private static NumericUpDown Number(decimal value, decimal min, decimal max, decimal increment)
        {
            return new NumericUpDown { DecimalPlaces = increment < 1 ? 2 : 0, Increment = increment, Minimum = min, Maximum = max, Value = value, Dock = DockStyle.Fill, ThousandsSeparator = false };
        }

        private static Label Title(string text) { return new Label { Text = text, Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = DesignUi.Primary, AutoSize = true, Margin = new Padding(0, 14, 0, 7) }; }
        private static void Section(TableLayoutPanel panel, string text)
        {
            var title = Title(text);
            panel.Controls.Add(title, 0, panel.RowCount);
            panel.SetColumnSpan(title, 2);
            panel.RowCount++;
        }
        private static void Row(TableLayoutPanel panel, string label, Control input)
        {
            panel.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 9.5f), ForeColor = DesignUi.Ink, Margin = new Padding(0, 6, 8, 6) }, 0, panel.RowCount);
            panel.Controls.Add(input, 1, panel.RowCount); panel.RowCount++;
        }

        private void RebuildWidths()
        {
            BeltModel m = beltModelBox.SelectedItem as BeltModel;
            if (m == null) return;
            string prev = String.IsNullOrWhiteSpace(bandWidthBox.Text)?values.BandWidthMm.ToString(System.Globalization.CultureInfo.InvariantCulture):bandWidthBox.Text;
            bandWidthBox.Items.Clear();
            foreach (string w in m.ValidWidths()) bandWidthBox.Items.Add(w);
            bandRangeLabel.Text = "Rango: " + m.MinWidthMm + " – " + m.MaxWidthMm + " mm  ·  Incremento: " + m.StepMm + " mm";
            int prevVal;
            if (int.TryParse(prev, out prevVal))
            {
                // Ajusta al múltiplo válido más cercano dentro del rango del nuevo modelo
                int snapped = m.MinWidthMm + (int)Math.Round((double)(prevVal - m.MinWidthMm) / m.StepMm) * m.StepMm;
                snapped = Math.Max(m.MinWidthMm, Math.Min(m.MaxWidthMm, snapped));
                int idx = bandWidthBox.Items.IndexOf(snapped.ToString());
                bandWidthBox.SelectedIndex = idx >= 0 ? idx : 0;
            }
            else { bandWidthBox.SelectedIndex = 0; }
        }

        private void Sync()
        {
            // Leer modelo y ancho de banda del catálogo
            BeltModel selModel = beltModelBox.SelectedItem as BeltModel;
            if (selModel != null) values.BeltModelName = selModel.Name;
            int bw;
            if (bandWidthBox.SelectedItem != null && int.TryParse(bandWidthBox.Text, out bw)) values.BandWidthMm = bw;

            // Leer lado
            if (sideBox.SelectedIndex == 1)      values.Side = "RH";
            else if (sideBox.SelectedIndex == 2)  values.Side = "par";
            else                                  values.Side = "LH";
            values.LengthMm = (double)length.Value; values.WebHeightMm = (double)height.Value; values.Gauge = gauge.Text;
            values.ThicknessMm = (double)thickness.Value; values.BendRadiusMm = (double)radius.Value; values.KFactor = (double)profileK.Value;
            values.TopFlangeMm = (double)topFlange.Value; values.TopAngleDeg = (double)topAngle.Value;
            values.BottomFlangeMm = (double)bottomFlange.Value; values.BottomAngleDeg = (double)bottomAngle.Value;
            values.MarkA = markA.Checked; values.MarkB = markB.Checked; values.MarkScale = (double)markScale.Value;
            values.SlotHeightMm=(double)slotHeight.Value;values.SlotGapMm=(double)slotGap.Value;values.SlotBottomOffsetMm=(double)slotOffset.Value;
            values.ResolvedSlots=null;values.ResolvedPattern=null;
            values.EndHoleTypeLeft  = HoleTypeCode(holeLeft.Text);
            values.EndHoleTypeRight = HoleTypeCode(holeRight.Text);
            values.EndHolesBottom   = holeBottom.Checked;
            values.EndHolesTop      = holeTop.Checked;
            values.IncludeSupportHoles = includeSupportHoles.Checked;
            values.SupportHoleEdgeMm   = (double)supportHoleEdge.Value;
            values.SupportHoleYMm      = (double)supportHoleY.Value;
            values.SupportHoleSpacingMm = (double)supportHoleStep.Value;
            values.SupportHoleSizeMm   = (double)supportHoleSize.Value;
            if (values.IncludeSupportHoles)
            {
                try
                {
                    double[] centers = SupportHoleLayout.CentersMm(values);
                    supportLayoutNote.ForeColor = Color.FromArgb(0, 120, 60);
                    supportLayoutNote.Text = "Centros desde el extremo: " +
                        string.Join(" · ", Array.ConvertAll(centers, x => x.ToString("0.##", CultureInfo.InvariantCulture))) +
                        " mm. Para actualizar un ensamble existente, vuelve a armarlo.";
                }
                catch (InvalidOperationException ex)
                {
                    supportLayoutNote.ForeColor = Color.Firebrick;
                    supportLayoutNote.Text = ex.Message;
                }
            }
            else
            {
                supportLayoutNote.ForeColor = DesignUi.Muted;
                supportLayoutNote.Text = "Barrenos para soportes C desactivados.";
            }
            try {var pattern=ProfileSlotLayout.PatternFor(values);slotLayoutNote.ForeColor=DesignUi.Muted;slotLayoutNote.Text=pattern.Description+"\n"+ProfileSlotLayout.DimensionsText(pattern);}
            catch(Exception ex){slotLayoutNote.ForeColor=Color.Firebrick;slotLayoutNote.Text=ex.Message;}
            preview.Settings = values; preview.Invalidate();
            frontPreview.Settings = values; frontPreview.Invalidate();
            assemblyPreview.Settings = values; assemblyPreview.Invalidate();
            status.Text = "";
        }

        private static string HoleTypeCode(string displayText)
        {
            if (displayText.StartsWith("Empalme")) return "empalme";
            if (displayText.StartsWith("Final"))   return "final";
            return "ninguno";
        }

        private void Generate(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(0, 102, 170);
                status.Text = "Generando perfil lateral...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();

                if (values.Side == "par")
                {
                    // Genera LH y RH en secuencia en la misma instancia de SOLIDWORKS
                    string fileLH = SolidWorksProfileGenerator.Create(values, "LH", folder);
                    string fileRH = SolidWorksProfileGenerator.Create(values, "RH", folder);
                    status.ForeColor = Color.FromArgb(0, 100, 55);
                    status.Text = "Par generado en:\r\n" + folder + "\r\n• PERFIL_LATERAL_LH.SLDPRT\r\n• PERFIL_LATERAL_RH.SLDPRT";
                }
                else
                {
                    string file = SolidWorksProfileGenerator.Create(values, values.Side, folder);
                    status.ForeColor = Color.FromArgb(0, 100, 55);
                    status.Text = "Pieza creada (" + values.Side.ToUpper() + "): " + file;
                }
                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                string report = BuildDiagnosticReport(ex);
                status.Text = report;
                TrySaveDiagnosticLog(report);
            }
        }

        private void GenerateAllForAssembly(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(0, 102, 170);
                status.Text = "Conectando con SOLIDWORKS...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);

                status.Text = "1/3: Creando PERFIL_LATERAL_LH.SLDPRT...";
                Application.DoEvents();
                string fileLH = SolidWorksProfileGenerator.Create(values, "LH", folder);

                status.Text = "2/3: Creando PERFIL_LATERAL_RH.SLDPRT...";
                Application.DoEvents();
                string fileRH = SolidWorksProfileGenerator.Create(values, "RH", folder);

                status.Text = "3/3: Creando SOPORTE_C.SLDPRT (con plaquitas soldadas)...";
                Application.DoEvents();
                var sValues = new SoporteSettings
                {
                    BeltModelName = values.BeltModelName,
                    BandWidthMm = values.BandWidthMm,
                    LengthMm = SoporteSettings.CalculateLengthFromBand(values.BandWidthMm),
                    IncludeNylamidSlots = true,
                    CenterSlotCount = SoporteSettings.SuggestCenterSlots(values.BandWidthMm),
                    IncludeEndPlates = true
                };
                string fileSoporte = SolidWorksSoporteGenerator.Create(sValues, folder);

                status.ForeColor = Color.FromArgb(0, 120, 60);
                status.Text = "¡Conjunto de piezas generado con éxito!\r\nCarpeta: " + folder +
                    "\r\n✓ " + Path.GetFileName(fileLH) +
                    "\r\n✓ " + Path.GetFileName(fileRH) +
                    "\r\n✓ " + Path.GetFileName(fileSoporte) +
                    "\r\n\r\nListas para insertar y grabar el macro de ensamble.";

                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                string report = BuildDiagnosticReport(ex);
                status.Text = "ERROR AL GENERAR CONJUNTO:\r\n" + ex.Message;
                TrySaveDiagnosticLog(report);
            }
        }

        private void AssembleAllConveyor(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(130, 40, 160);
                status.Text = "Armando ensamblaje con 6 soportes C en SOLIDWORKS...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);

                var sValues = new SoporteSettings
                {
                    BeltModelName = values.BeltModelName,
                    BandWidthMm = values.BandWidthMm,
                    LengthMm = SoporteSettings.CalculateLengthFromBand(values.BandWidthMm),
                    IncludeNylamidSlots = true,
                    CenterSlotCount = SoporteSettings.SuggestCenterSlots(values.BandWidthMm),
                    IncludeEndPlates = true
                };

                string assyPath = SolidWorksEnsambleGenerator.GenerateAssembly(folder, values, sValues);

                status.ForeColor = Color.FromArgb(0, 120, 60);
                status.Text = "¡Ensamblaje completado con éxito!\r\nArchivo: " + assyPath +
                    "\r\n✓ Perfiles laterales LH y RH alineados" +
                    "\r\n✓ 6 soportes C colocados con paso de " + values.SupportHoleSpacingMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm" +
                    "\r\n✓ Centros de barrenos alineados con los soportes.";

                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                string report = BuildDiagnosticReport(ex);
                status.Text = "ERROR AL ARMAR ENSAMBLAJE:\r\n" + ex.Message;
                TrySaveDiagnosticLog(report);
            }
        }

        private void OpenSoporteWindow()
        {
            Sync();
            if (_soporteFormInstance == null || _soporteFormInstance.IsDisposed)
            {
                _soporteFormInstance = new SoporteForm(values.BeltModelName, values.BandWidthMm, values);
                _soporteFormInstance.TopLevel = false;
                _soporteFormInstance.FormBorderStyle = FormBorderStyle.None;
                _soporteFormInstance.MinimumSize = Size.Empty;
                _soporteFormInstance.Dock = DockStyle.Fill;
                workspaceHost.Controls.Add(_soporteFormInstance);
            }
            profileWorkspace.Hide();
            if (_completeBeltView != null) _completeBeltView.Hide();
            _soporteFormInstance.Show();
            _soporteFormInstance.BringToFront();
            profileNav.Checked = false;
            supportNav.Checked = true;
            completeNav.Checked = false;
        }

        private void OpenCompleteBelt()
        {
            Sync();
            if (_completeBeltView == null)
            {
                _completeBeltView = new CompleteBeltView(values, delegate {
                    return _soporteFormInstance != null && !_soporteFormInstance.IsDisposed
                        ? _soporteFormInstance.CurrentSettings() : null;
                });
                workspaceHost.Controls.Add(_completeBeltView);
            }
            _completeBeltView.RefreshProfile();
            profileWorkspace.Hide();
            if (_soporteFormInstance != null && !_soporteFormInstance.IsDisposed) _soporteFormInstance.Hide();
            _completeBeltView.Show();
            _completeBeltView.BringToFront();
            profileNav.Checked = false;
            supportNav.Checked = false;
            completeNav.Checked = true;
        }

        private void ShowProfileWorkspace()
        {
            if (_soporteFormInstance != null && !_soporteFormInstance.IsDisposed)
                _soporteFormInstance.Hide();
            if (_completeBeltView != null) _completeBeltView.Hide();
            profileWorkspace.Show();
            profileWorkspace.BringToFront();
            profileNav.Checked = true;
            supportNav.Checked = false;
            completeNav.Checked = false;
        }

        private string BuildDiagnosticReport(Exception ex)
        {
            Exception deepest = ex;
            while (deepest.InnerException != null) deepest = deepest.InnerException;
            int hresult = deepest.HResult;
            string hresultText;
            switch ((uint)hresult)
            {
                case 0x8002000B:
                    hresultText = "DISP_E_BADINDEX: SolidWorks recibió un índice o elemento de colección no válido.";
                    break;
                case 0x8002802B:
                    hresultText = "TYPE_E_ELEMENTNOTFOUND: SolidWorks no encontró el objeto solicitado.";
                    break;
                case 0x800401E3:
                    hresultText = "MK_E_UNAVAILABLE: no se encontró una instancia COM disponible de SolidWorks.";
                    break;
                case 0x80131509:
                    hresultText = "INVALID_OPERATION: la aplicación detuvo el proceso porque SolidWorks no devolvió la operación esperada; no es un error de conexión COM.";
                    break;
                default:
                    hresultText = "Código COM no clasificado por la aplicación.";
                    break;
            }

            return "ERROR AL GENERAR LA PIEZA\r\n" +
                ex.Message + "\r\n" +
                "HRESULT: 0x" + hresult.ToString("X8") + " — " + hresultText + "\r\n" +
                "Parámetros: L=" + values.LengthMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm; H=" + values.WebHeightMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm; espesor=" + values.ThicknessMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm; R=" + values.BendRadiusMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm; superior=" + values.TopFlangeMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm @ " + values.TopAngleDeg.ToString("0.##", CultureInfo.InvariantCulture) +
                "°; inferior=" + values.BottomFlangeMm.ToString("0.##", CultureInfo.InvariantCulture) +
                " mm @ " + values.BottomAngleDeg.ToString("0.##", CultureInfo.InvariantCulture) + "°.\r\n" +
                "Se guardó el detalle en PerfilBandas_errores.log.";
        }

        private static void TrySaveDiagnosticLog(string report)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PerfilBandas_errores.log");
                File.AppendAllText(logPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + System.Environment.NewLine + report + System.Environment.NewLine + new string('-', 80) + System.Environment.NewLine);
            }
            catch
            {
                // The on-screen diagnostic remains available if the folder is read-only.
            }
        }
    }

    internal sealed class ProfilePreview : Control
    {
        public ProfileSettings Settings { get; set; }
        public ProfilePreview() { DoubleBuffered = true; BackColor = Color.FromArgb(248, 250, 252); }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e); if (Settings == null) return;
            var g = e.Graphics; g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var outer=ProfileBendGeometry.Boundary(Settings,Settings.BendRadiusMm+Settings.ThicknessMm);
            var inner=ProfileBendGeometry.Boundary(Settings,Settings.BendRadiusMm);
            var contour=new System.Collections.Generic.List<PointF>(outer);Array.Reverse(inner);contour.AddRange(inner);
            float minX=Single.MaxValue,maxX=Single.MinValue,minY=Single.MaxValue,maxY=Single.MinValue;
            foreach(var q in contour){minX=Math.Min(minX,q.X);maxX=Math.Max(maxX,q.X);minY=Math.Min(minY,q.Y);maxY=Math.Max(maxY,q.Y);}
            float scale=Math.Max(.01f,Math.Min((Width-80f)/Math.Max(1,maxX-minX),(Height-100f)/Math.Max(1,maxY-minY)));
            Func<PointF,PointF> project=q=>new PointF(Width/2f+(q.X-(minX+maxX)/2)*scale,(Height-65)/2f-(q.Y-(minY+maxY)/2)*scale);
            using(var fill=new SolidBrush(Color.FromArgb(140,157,171)))using(var pen=new Pen(Color.FromArgb(25,90,140),1)){
                var polygon=Array.ConvertAll(contour.ToArray(),q=>project(q));g.FillPolygon(fill,polygon);g.DrawPolygon(pen,polygon);
            }
            using(var neutralPen=new Pen(Color.FromArgb(210,105,30),1)){
                neutralPen.DashStyle=DashStyle.Dash;
                g.DrawLines(neutralPen,Array.ConvertAll(ProfileBendGeometry.Boundary(Settings,Settings.BendRadiusMm+Settings.KFactor*Settings.ThicknessMm),q=>project(q)));
            }
            TextRenderer.DrawText(g,"Naranja: fibra neutra",Font,new Point(16,12),Color.FromArgb(170,80,20));
            var text=String.Format(CultureInfo.InvariantCulture,"R={0:0.##} mm · K={1:0.##} · Desarrollo={2:0.##} mm",Settings.BendRadiusMm,Settings.KFactor,ProfileBendGeometry.DevelopedWidth(Settings));
            TextRenderer.DrawText(g, text, Font, new Point(16, Height - 32), Color.DimGray);
        }
    }

    internal static class LogoAGeometry
    {
        // Contornos trazados de la imagen entregada. Las coordenadas conservan su proporción original.
        private static readonly double[][][] Contours = new double[][][]
        {
            new double[][] { new double[] { 35,299 }, new double[] { 172,297 }, new double[] { 153,256 }, new double[] { 66,255 } },
            new double[][] { new double[] { 333,72 }, new double[] { 286,72 }, new double[] { 172,246 }, new double[] { 191,288 } },
            new double[][] { new double[] { 391,72 }, new double[] { 386,73 }, new double[] { 252,278 }, new double[] { 329,234 }, new double[] { 391,140 } },
            new double[][] { new double[] { 259,299 }, new double[] { 544,299 }, new double[] { 470,256 }, new double[] { 449,255 }, new double[] { 334,256 } },
            new double[][] { new double[] { 413,72 }, new double[] { 413,140 }, new double[] { 474,233 }, new double[] { 553,279 }, new double[] { 418,73 } },
            new double[][] { new double[] { 470,72 }, new double[] { 613,288 }, new double[] { 632,244 }, new double[] { 519,72 } },
            new double[][] { new double[] { 544,72 }, new double[] { 574,116 }, new double[] { 647,115 }, new double[] { 619,72 } },
            new double[][] { new double[] { 632,297 }, new double[] { 769,299 }, new double[] { 738,255 }, new double[] { 651,256 } }
        };
        private const double MinX = 35, MaxX = 769, MinY = 72, MaxY = 299;
        public const double BaseWidthMm = 140.0;
        public const double BaseHeightMm=140.0*(299-72)/(769-35);
        internal static PointF[][] ContoursMm(double widthMm) {
            double factor=widthMm/(MaxX-MinX),mx=(MinX+MaxX)/2,my=(MinY+MaxY)/2;
            var result=new PointF[Contours.Length][];
            for(int i=0;i<Contours.Length;i++) {
                result[i]=new PointF[Contours[i].Length];
                for(int j=0;j<result[i].Length;j++)result[i][j]=new PointF((float)((Contours[i][j][0]-mx)*factor),(float)((my-Contours[i][j][1])*factor));
            }
            return result;
        }
        public static double AreaMm2(double widthMm) {
            double area=0;
            foreach(var contour in Contours) {
                double sum=0;
                for(int i=0;i<contour.Length;i++){var a=contour[i];var b=contour[(i+1)%contour.Length];sum+=a[0]*b[1]-b[0]*a[1];}
                area+=Math.Abs(sum)/2;
            }
            return area*Math.Pow(widthMm/(MaxX-MinX),2);
        }
        public static void AddToModelSketch(SketchManager sketch,Sketch active,MathUtility math,double z,double y,double width,bool right) {
            double factor=width/(MaxX-MinX),mx=(MinX+MaxX)/2,my=(MinY+MaxY)/2,sign=right?-1:1;
            Func<double[],double[]> point=delegate(double[] a){return (double[])((MathPoint)((MathPoint)math.CreatePoint(new[]{0.0,y+(my-a[1])*factor,z+sign*(a[0]-mx)*factor})).MultiplyTransform(active.ModelToSketchTransform)).ArrayData;};
            foreach(var contour in Contours)for(int i=0;i<contour.Length;i++){var a=point(contour[i]);var b=point(contour[(i+1)%contour.Length]);sketch.CreateLine(a[0],a[1],0,b[0],b[1],0);}
        }
        public static int SegmentCount { get { int total = 0; foreach (double[][] contour in Contours) total += contour.Length; return total; } }

        public static void AddToSketch(SketchManager sketch, double centerX, double centerY, double widthMeters, bool mirrorX = false)
        {
            double factor = widthMeters / (MaxX - MinX);
            double midX = (MinX + MaxX) / 2.0, midY = (MinY + MaxY) / 2.0;
            // LH: la cara exterior refleja el croquis en X → se niega el delta-X para compensar.
            // RH: la cara ya está orientada correctamente → NO negamos, el logo queda legible.
            double xSign = mirrorX ? 1.0 : -1.0;
            foreach (double[][] contour in Contours)
            {
                for (int i = 0; i < contour.Length; i++)
                {
                    double[] a = contour[i], b = contour[(i + 1) % contour.Length];
                    sketch.CreateLine(centerX + xSign * (a[0] - midX) * factor, centerY + (midY - a[1]) * factor, 0,
                                      centerX + xSign * (b[0] - midX) * factor, centerY + (midY - b[1]) * factor, 0);
                }
            }
        }

        public static void Draw(Graphics g, Brush fill, Pen pen, float centerX, float centerY, float widthPixels)
        {
            float factor = widthPixels / (float)(MaxX - MinX);
            double midX = (MinX + MaxX) / 2.0, midY = (MinY + MaxY) / 2.0;
            foreach (double[][] contour in Contours)
            {
                PointF[] points = new PointF[contour.Length];
                for (int i = 0; i < contour.Length; i++)
                    points[i] = new PointF(centerX + (float)((contour[i][0] - midX) * factor), centerY + (float)((contour[i][1] - midY) * factor));
                g.FillPolygon(fill, points); g.DrawPolygon(pen, points);
            }
        }
    }

    internal sealed class FrontProfilePreview : Control
    {
        public ProfileSettings Settings { get; set; }
        public FrontProfilePreview() { DoubleBuffered = true; BackColor = Color.FromArgb(248, 250, 252); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Settings == null || Width < 40 || Height < 50) return;
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            TextRenderer.DrawText(g, "VISTA FRONTAL · LARGO "+Settings.LengthMm.ToString("0.##")+" mm", Font,
                new Point(24, 20), Color.FromArgb(41, 55, 72));

            float left = 24, right = Width - 24, availableWidth = right - left;
            float availableHeight=Math.Max(30,Height-(Height>280?190:90));
            float scale=Math.Min(availableWidth/(float)Settings.LengthMm,availableHeight/(float)Settings.WebHeightMm);
            // Una sola escala conserva la relación física exacta entre largo, altura, logo y ranuras.
            float bodyHeight = (float)Settings.WebHeightMm * scale;
            availableWidth=(float)Settings.LengthMm*scale;left=(Width-availableWidth)/2;right=left+availableWidth;
            float top=45+(availableHeight-bodyHeight)/2;
            var body = new RectangleF(left, top, availableWidth, bodyHeight);
            using (var fill = new SolidBrush(Color.FromArgb(246, 248, 250))) g.FillRectangle(fill, body);
            using (var pen = new Pen(Color.FromArgb(45, 60, 75), 1.6f)) g.DrawRectangle(pen, body.X, body.Y, body.Width, body.Height);
            using (var bendPen = new Pen(Color.FromArgb(210, 105, 30), 1.2f))
            {
                bendPen.DashStyle = DashStyle.Dash;
                g.DrawLine(bendPen, body.Left + 2, body.Top, body.Right - 2, body.Top);
                g.DrawLine(bendPen, body.Left + 2, body.Bottom, body.Right - 2, body.Bottom);
            }

            float centerY = body.Top + body.Height / 2f;
            ProfilePattern pattern;
            try {pattern=ProfileSlotLayout.PatternFor(Settings);} catch(Exception ex){TextRenderer.DrawText(g,ex.Message,Font,new Rectangle(24,45,Width-48,100),Color.Firebrick);return;}
            float markSize = (float)((Settings.MarkA ? LogoAGeometry.BaseWidthMm : 70.0) * Settings.MarkScale / 100.0) * scale;
            float markX=left+(float)pattern.LogoCenterMm*scale;
            centerY=body.Top-(float)pattern.CenterYMm*scale;
            using (var markPen = new Pen(Color.FromArgb(0, 102, 170), 1.8f))
            {
                if (pattern.LogoVisible && Settings.MarkA)
                {
                    using (var markFill = new SolidBrush(Color.White))
                        LogoAGeometry.Draw(g, markFill, markPen, markX, centerY, markSize);
                }
                else if (pattern.LogoVisible && Settings.MarkB)
                {
                    PointF[] hexagon = new PointF[6];
                    float radius = markSize / 2f;
                    for (int i = 0; i < 6; i++)
                    {
                        double a = Math.PI / 6.0 + i * Math.PI / 3.0;
                        hexagon[i] = new PointF(markX + radius * (float)Math.Cos(a), centerY + radius * (float)Math.Sin(a));
                    }
                    g.DrawPolygon(markPen, hexagon);
                }
            }

            using (var slotFill = new SolidBrush(Color.White))
            using (var slotPen = new Pen(Color.FromArgb(0, 102, 170), 1.5f))
            {
                ProfileSlotSpec[] slots;
                try {slots=ProfileSlotLayout.For(Settings);} catch {slots=new ProfileSlotSpec[0];}
                foreach(var slot in slots)
                    DrawSlot(g,slotFill,slotPen,left+(float)slot.CenterMm*scale,body.Top-(float)slot.CenterYMm*scale,(float)slot.LengthMm*scale,(float)slot.RadiusMm*scale);
            }
            // Orificios en extremos — cuadrados estándar 11×11 mm
            if (Settings.EndHoleTypeLeft != "ninguno" || Settings.EndHoleTypeRight != "ninguno")
            {
                float holeSz   = Math.Max(4f, (float)Settings.EndHoleSizeMm   * scale);
                float holeEdge = (float)Settings.EndHoleEdgeMm               * scale;
                float holeStep = (float)Settings.EndHoleSpacingMm            * scale;
                using (var holeFill = new SolidBrush(Color.FromArgb(220, 53, 69)))
                using (var holePen  = new Pen(Color.FromArgb(140, 20, 30), 1.2f))
                {
                    // Orificios superiores (pestaña superior / borde superior)
                    if (Settings.EndHolesTop)
                    {
                        float yTop = body.Top + 4f;
                        if (Settings.EndHoleTypeLeft == "empalme" || Settings.EndHoleTypeLeft == "final")
                        {
                            float x1 = left + holeEdge, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x1 - h, yTop - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x1 - h, yTop - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeLeft == "final")
                        {
                            float x2 = left + holeEdge + holeStep, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x2 - h, yTop - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x2 - h, yTop - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeRight == "empalme" || Settings.EndHoleTypeRight == "final")
                        {
                            float x1 = right - holeEdge, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x1 - h, yTop - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x1 - h, yTop - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeRight == "final")
                        {
                            float x2 = right - holeEdge - holeStep, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x2 - h, yTop - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x2 - h, yTop - h, holeSz, holeSz);
                        }
                    }

                    // Orificios inferiores (pestaña inferior 45° / borde inferior)
                    if (Settings.EndHolesBottom)
                    {
                        float yBottom = body.Bottom - 4f;
                        if (Settings.EndHoleTypeLeft == "empalme" || Settings.EndHoleTypeLeft == "final")
                        {
                            float x1 = left + holeEdge, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x1 - h, yBottom - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x1 - h, yBottom - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeLeft == "final")
                        {
                            float x2 = left + holeEdge + holeStep, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x2 - h, yBottom - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x2 - h, yBottom - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeRight == "empalme" || Settings.EndHoleTypeRight == "final")
                        {
                            float x1 = right - holeEdge, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x1 - h, yBottom - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x1 - h, yBottom - h, holeSz, holeSz);
                        }
                        if (Settings.EndHoleTypeRight == "final")
                        {
                            float x2 = right - holeEdge - holeStep, h = holeSz / 2f;
                            g.FillRectangle(holeFill, x2 - h, yBottom - h, holeSz, holeSz);
                            g.DrawRectangle(holePen,  x2 - h, yBottom - h, holeSz, holeSz);
                        }
                    }
                }
            }
            if(VerticalSupportLayout.HasCenter(Settings)) {
                float size=Math.Max(4f,(float)Settings.EndHoleSizeMm*scale);
                using(var fill=new SolidBrush(Color.FromArgb(220,53,69)))
                using(var pen=new Pen(Color.FromArgb(140,20,30),1.2f))
                foreach(double z in new[]{Settings.LengthMm/2-Settings.EndHoleSpacingMm/2,Settings.LengthMm/2+Settings.EndHoleSpacingMm/2}) {
                    float x=left+(float)z*scale,y=body.Bottom-4f;
                    g.FillRectangle(fill,x-size/2,y-size/2,size,size);g.DrawRectangle(pen,x-size/2,y-size/2,size,size);
                }
            }
            // Orificios para sujeción de los 6 soportes C (alma del perfil)
            if (Settings.IncludeSupportHoles)
            {
                float holeSz = Math.Max(4f, (float)Settings.SupportHoleSizeMm * scale);
                float h = holeSz / 2f;
                float yHole = body.Top + (float)Settings.SupportHoleYMm * scale;
                double[] centersMm;
                try { centersMm = SupportHoleLayout.CentersMm(Settings); }
                catch (InvalidOperationException) { centersMm = new double[0]; }

                using (var supFill = new SolidBrush(Color.FromArgb(40, 167, 69))) // Verde esmeralda
                using (var supPen = new Pen(Color.FromArgb(20, 100, 40), 1.2f))
                {
                    foreach (double centerMm in centersMm)
                    {
                        float xH = left + (float)centerMm * scale;
                        g.FillRectangle(supFill, xH - h, yHole - h, holeSz, holeSz);
                        g.DrawRectangle(supPen, xH - h, yHole - h, holeSz, holeSz);
                    }
                }
            }
            if(Settings.ResolvedRollerHoles!=null) using(var rollerPen=new Pen(Color.FromArgb(184,109,29),1.4f))
                foreach(var roller in Settings.ResolvedRollerHoles) {
                    var contour=Array.ConvertAll(ReturnRollerSeatGeometry.Contour(roller),q=>new PointF(left+(float)(roller.LocalZMm+q.X)*scale,body.Top-(float)(roller.YMm+q.Y)*scale));
                    g.FillPolygon(Brushes.White,contour);g.DrawPolygon(rollerPen,contour);
                }
            if (Height > 280)
            {
                var intervals=new System.Collections.Generic.List<double[]>();
                foreach(var slot in pattern.Slots)intervals.Add(new[]{slot.CenterMm-slot.LengthMm/2,slot.CenterMm+slot.LengthMm/2});
                if(pattern.LogoVisible)intervals.Add(new[]{pattern.LogoCenterMm-pattern.LogoWidthMm/2,pattern.LogoCenterMm+pattern.LogoWidthMm/2});
                intervals.Sort(delegate(double[] a,double[] b){return a[0].CompareTo(b[0]);});
                using(var dim=new Pen(Color.FromArgb(100,130,145),1)) {
                    double last=0;
                    for(int i=0;i<=intervals.Count;i++) {
                        double end=i<intervals.Count?intervals[i][0]:Settings.LengthMm;
                        float x1=left+(float)last*scale,x2=left+(float)end*scale,dy=body.Bottom+8;
                        g.DrawLine(dim,x1,dy,x2,dy);g.DrawLine(dim,x1,dy-3,x1,dy+3);g.DrawLine(dim,x2,dy-3,x2,dy+3);
                        if(x2-x1>20)TextRenderer.DrawText(g,(end-last).ToString("0.#"),Font,new Rectangle((int)x1,(int)dy+3,(int)(x2-x1),18),Color.DimGray,TextFormatFlags.HorizontalCenter);
                        if(i<intervals.Count)last=intervals[i][1];
                    }
                    float tangentY=body.Top-(float)pattern.LowerTangentYMm*scale;
                    float slotBottomY=body.Top-(float)(pattern.CenterYMm-(pattern.Slots.Length==0?0:Settings.SlotHeightMm/2))*scale;
                    float dimX=body.Left-12;
                    g.DrawLine(dim,dimX,slotBottomY,dimX,tangentY);
                    g.DrawLine(dim,dimX-3,slotBottomY,dimX+3,slotBottomY);
                    g.DrawLine(dim,dimX-3,tangentY,dimX+3,tangentY);
                    g.DrawLine(dim,dimX,slotBottomY,body.Left+4,slotBottomY);
                    g.DrawLine(dim,dimX,tangentY,body.Left+4,tangentY);
                    string verticalLabel=pattern.Slots.Length==0?"Centro del logo sobre doblez: "+(Settings.SlotBottomOffsetMm+Settings.SlotHeightMm/2).ToString("0.##"):"Borde inferior efectivo sobre doblez: "+(pattern.Slots[0].CenterYMm-pattern.Slots[0].RadiusMm-pattern.LowerTangentYMm).ToString("0.##");
                    TextRenderer.DrawText(g,verticalLabel+" mm",Font,new Point((int)body.Left,(int)body.Bottom+34),Color.DimGray);
                }
                int infoY = Height - 105;
                using (var rule = new Pen(Color.FromArgb(220, 227, 234)))
                    g.DrawLine(rule, 24, infoY - 15, Width - 24, infoY - 15);
                string supportInfo = Settings.IncludeSupportHoles
                    ? Settings.SupportCount + " barrenos de soporte · " + Settings.SupportHoleSizeMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm"
                    : "Barrenos de soporte desactivados";
                TextRenderer.DrawText(g, "LARGO  " + Settings.LengthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm",
                    Font, new Point(24, infoY), Color.FromArgb(41, 55, 72));
                TextRenderer.DrawText(g, "ALMA  " + Settings.WebHeightMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm",
                    Font, new Point(24, infoY + 26), Color.FromArgb(41, 55, 72));
                TextRenderer.DrawText(g, supportInfo, Font,
                    new Point(24, infoY + 52), Color.FromArgb(30, 110, 60));
            }
            string note = "Blanco: corte pasante  ·  Verde: soportes C  ·  Rojo: extremos";
            TextRenderer.DrawText(g, note, Font, new Point(24, Height - 26), Color.DimGray);
        }

        private static void DrawSlot(Graphics g, Brush fill, Pen pen, float centerX, float centerY, float totalLength, float radius)
        {
            radius = Math.Max(2, radius);
            totalLength = Math.Max(radius * 2f, totalLength);
            float straight = totalLength - radius * 2f;
            var path = new GraphicsPath();
            path.AddArc(centerX - straight / 2f - radius, centerY - radius, radius * 2f, radius * 2f, 90, 180);
            path.AddLine(centerX - straight / 2f, centerY - radius, centerX + straight / 2f, centerY - radius);
            path.AddArc(centerX + straight / 2f - radius, centerY - radius, radius * 2f, radius * 2f, 270, 180);
            path.AddLine(centerX + straight / 2f, centerY + radius, centerX - straight / 2f, centerY + radius);
            path.CloseFigure();
            g.FillPath(fill, path); g.DrawPath(pen, path); path.Dispose();
        }
    }

    internal static class SolidWorksProfileGenerator
    {
        // All lengths passed to the SOLIDWORKS API use metres.
        public static string Create(ProfileSettings s, string sideCode = "LH", string customFolder = null, string fileStem = null, SldWorks instance = null)
        {
            BeltWidthRules.Validate(s.BeltModelName,s.BandWidthMm);
            SettingsValidation.Numbers(s,"Perfil");
            if(s.TopFlangeMm<=s.ThicknessMm||s.BottomFlangeMm<=s.ThicknessMm)throw new InvalidOperationException("Perfil: las pestañas deben ser mayores que el espesor.");
            if (s.IncludeSupportHoles) SupportHoleLayout.CentersMm(s);
            var cutPattern=ProfileSlotLayout.PatternFor(s);
            bool isRH = (sideCode == "RH");
            string stage = "conectar con SOLIDWORKS";
            try
            {
                Type type = Type.GetTypeFromProgID("SldWorks.Application");
                if (type == null) throw new InvalidOperationException("SOLIDWORKS no está instalado o no registró su API.");
                SldWorks sw = instance;
                if (sw == null)
                {
                    try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
                    catch { sw = (SldWorks)Activator.CreateInstance(type); }
                }
                if (sw == null) throw new InvalidOperationException("No fue posible iniciar SOLIDWORKS.");
                sw.Visible = true;
                stage = "localizar la plantilla de pieza";
                string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
                if (String.IsNullOrWhiteSpace(template) || !File.Exists(template)) throw new InvalidOperationException("Configura la plantilla predeterminada de pieza en SOLIDWORKS antes de generar.");
                stage = "crear el documento de pieza";
                ModelDoc2 model = (ModelDoc2)sw.NewDocument(template, 0, 0, 0);
                if (model == null) throw new InvalidOperationException("SOLIDWORKS no pudo crear la pieza nueva.");

                double l = s.LengthMm / 1000.0, h = s.WebHeightMm / 1000.0, thick = s.ThicknessMm / 1000.0, r = s.BendRadiusMm / 1000.0;
                stage = "seleccionar el plano de referencia";
                SelectPrimaryReferencePlane(model);
                stage = "dibujar la sección completa del perfil";
                SketchManager baseSketch = model.SketchManager;
                baseSketch.InsertSketch(true);
                baseSketch.AddToDB = true;
                AddProfileSection(baseSketch, s, isRH);
                baseSketch.AddToDB = false;
                stage = "crear el perfil completo con Brida base/Pestaña";
                ProfileBendGeometry.Validate(s);
                Feature feature = CreateProfileBaseFlange(model, l, thick, r, s.KFactor, isRH);
                if (feature == null) throw new InvalidOperationException("SolidWorks devolvió una operación Brida base/Pestaña vacía.");
                model.ClearSelection2(true);
                model.EditRebuild3();
                stage = "crear orificios de sujeción para soportes C";
                AddSupportHoles(model, sw, s);
                model.EditRebuild3();
                stage = "crear la marca de prueba";
                AddTestMark(model, s, sw, isRH);
                model.EditRebuild3();
                stage = "crear orificios en extremos";
                AddEndHoles(model, sw, s);
                model.EditRebuild3();

            // Properties keep the generated part traceable and preserve all dimensions for a later flange-operation pass.
                stage = "registrar las propiedades de la pieza";
                dynamic cp = ((dynamic)model.Extension).CustomPropertyManager("");
                cp.Add3("PerfilTipo", 30, "Lateral banda", 2);
                cp.Add3("Lado", 30, sideCode.ToUpper(), 2);
            cp.Add3("Largo_mm", 30, s.LengthMm.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("Alma_mm", 30, s.WebHeightMm.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("Calibre", 30, s.Gauge, 2);
            cp.Add3("RadioInterior_mm",30,s.BendRadiusMm.ToString(CultureInfo.InvariantCulture),2);
            cp.Add3("FactorK",30,s.KFactor.ToString(CultureInfo.InvariantCulture),2);
            cp.Add3("AnchoDesarrollado_mm",30,ProfileBendGeometry.DevelopedWidth(s).ToString(CultureInfo.InvariantCulture),2);
            cp.Add3("PestanaSuperior_mm", 30, s.TopFlangeMm.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("AnguloSuperior_deg", 30, s.TopAngleDeg.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("PestanaInferior_mm", 30, s.BottomFlangeMm.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("AnguloInferior_deg", 30, s.BottomAngleDeg.ToString(CultureInfo.InvariantCulture), 2);
              cp.Add3("MarcaA", 30, s.MarkA ? "Cuadrado 70x70 mm" : "No", 2);
                cp.Add3("MarcaB", 30, s.MarkB ? "Hexagono diametro 70 mm" : "No", 2);
                cp.Add3("Ranuras", 30, ProfileSlotLayout.For(s).Length.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("PatronLogoRanuras",30,new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(cutPattern),2);
                cp.Add3("RanurasResueltas",30,new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(ProfileSlotLayout.For(s)),2);
                cp.Add3("RanuraLongitud_mm", 30, (cutPattern.Slots.Length==0?0:cutPattern.Slots[0].LengthMm).ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanuraRadio_mm", 30, (s.SlotHeightMm/2).ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanuraSeparacion_mm", 30, s.SlotGapMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioExtIzq", 30, s.EndHoleTypeLeft, 2);
                cp.Add3("OrificioExtDer", 30, s.EndHoleTypeRight, 2);
                cp.Add3("OrificioTamano_mm", 30, s.EndHoleSizeMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioBorde_mm", 30, s.EndHoleEdgeMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioPaso_mm", 30, s.EndHoleSpacingMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificiosSoporteInf", 30, s.EndHolesBottom ? "Si" : "No", 2);
                cp.Add3("OrificiosSoporteCentral",30,VerticalSupportLayout.HasCenter(s)?"2 cuadrados iguales a extremos":"No (longitud <= 2000 mm o inferiores desactivados)",2);
                cp.Add3("OrificiosAditSup", 30, s.EndHolesTop ? "Si" : "No", 2);
                cp.Add3("OrificiosSoportesC", 30, s.IncludeSupportHoles ? s.SupportCount + " orificios alma" : "No", 2);
                cp.Add3("OrificioSoporteTamano_mm", 30, s.SupportHoleSizeMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioSoporteY_mm", 30, s.SupportHoleYMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioSoporteBorde_mm", 30, s.SupportHoleEdgeMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("OrificioSoportePaso_mm", 30, s.SupportHoleSpacingMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("ModeloBanda",       30, s.BeltModelName, 2);
                cp.Add3("AnchoBanda_mm",     30, s.BandWidthMm.ToString(CultureInfo.InvariantCulture), 2);
                stage = "guardar la pieza";
                string folder = !String.IsNullOrWhiteSpace(customFolder) ? customFolder : ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);
                string output = Path.Combine(folder, (fileStem ?? "PERFIL_LATERAL_" + sideCode.ToUpper()) + ".SLDPRT");
                int saveError = model.SaveAs3(output, 0, 2);
                if (saveError != 0 || !File.Exists(output))
                    throw new InvalidOperationException("SOLIDWORKS no guardó el perfil actualizado (código " + saveError + "): " + output);
                return output;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error durante: " + stage + ". " + ex.Message, ex);
            }
        }

        private static void SelectPrimaryReferencePlane(ModelDoc2 model)
        {
            model.ClearSelection2(true);
            PartDoc part = (PartDoc)model;
            string[] planeNames = new string[] { "Plano Alzado", "Front Plane", "Plano frontal", "Plano Frontal", "Alzado" };
            foreach (string planeName in planeNames)
            {
                try
                {
                    Feature plane = (Feature)part.FeatureByName(planeName);
                    if (plane != null && plane.Select2(false, 0)) return;
                }
                catch (COMException)
                {
                    // Try the next language-specific name.
                }
            }
            throw new InvalidOperationException("No se pudo seleccionar el plano Alzado de la plantilla de pieza.");
        }

        private static void AddRectangle(SketchManager sketch, double left, double top, double right, double bottom)
        {
            sketch.CreateLine(left, top, 0, right, top, 0);
            sketch.CreateLine(right, top, 0, right, bottom, 0);
            sketch.CreateLine(right, bottom, 0, left, bottom, 0);
            sketch.CreateLine(left, bottom, 0, left, top, 0);
        }

        private static void AddProfileSection(SketchManager sketch, ProfileSettings s, bool mirrorX = false)
        {
            double topLength = s.TopFlangeMm / 1000.0;
            double height = s.WebHeightMm / 1000.0;
            double bottomLength = s.BottomFlangeMm / 1000.0;
            double topDirection = (90.0 + s.TopAngleDeg) * Math.PI / 180.0;
            double bottomDirection = (90.0 + s.BottomAngleDeg) * Math.PI / 180.0;
            // Para RH se niega la componente X de los extremos libres de las pestañas,
            // produciendo un espejo horizontal de la sección (pestañas hacia la derecha).
            double mx = mirrorX ? -1.0 : 1.0;

            double jointX = 0.0, jointY = 0.0;
            double bottomX = 0.0, bottomY = -height;
            double topFreeX = jointX + mx * topLength * Math.Cos(topDirection);
            double topFreeY = jointY + topLength * Math.Sin(topDirection);
            double bottomFreeX = bottomX + mx * bottomLength * Math.Cos(bottomDirection);
            double bottomFreeY = bottomY + bottomLength * Math.Sin(bottomDirection);

            sketch.CreateLine(topFreeX, topFreeY, 0, jointX, jointY, 0);
            sketch.CreateLine(jointX, jointY, 0, bottomX, bottomY, 0);
            sketch.CreateLine(bottomX, bottomY, 0, bottomFreeX, bottomFreeY, 0);
        }

        private static Feature CreateProfileBaseFlange(ModelDoc2 model, double length, double thickness, double bendRadius, double kFactor, bool isRH)
        {
            FeatureManager manager = model.FeatureManager;
            CustomBendAllowance allowance = manager.CreateCustomBendAllowance();
            allowance.KFactor = kFactor;
            dynamic data = manager.CreateDefinition((int)swFeatureNameID_e.swFmBaseFlange);
            if (data == null) throw new InvalidOperationException("CreateDefinition(swFmBaseFlange) devolvió vacío.");
            data.Initialize(false, true, allowance, true, 1, true, 0.5, 0.0001, 0.0001);
            data.BendRadius = bendRadius;
            data.D1EndConditionDistance = length;
            data.D1EndConditionType = 1;
            data.D1ReverseOffset = false;
            data.D2EndConditionDistance = 0.01;
            data.D2EndConditionType = 1;
            data.D2ReverseOffset = false;
            data.OffsetDirections = 1;
            data.ReverseDirection = false;
            data.ReverseThickness = isRH;
            data.Thickness = thickness;
            return manager.CreateFeature(data);
        }

        private static void AddEdgeFlange(ModelDoc2 model, double length, double height, double flangeLength, double angle, double radius, bool top, bool outward)
        {
            string side = top ? "superior" : "inferior";
            string substep = "buscar el borde longitudinal de la brida base";
            string apiMethod = "IBody2.GetEdges";
            try
            {
                Edge edge = FindLongHorizontalEdge(model, length, height, top);
                if (edge == null) throw new InvalidOperationException("No se encontró un borde horizontal con la longitud y posición esperadas.");

                substep = "crear el croquis auxiliar sobre el borde";
                apiMethod = "IModelDoc2.InsertSketchForEdgeFlange";
                Feature sketchFeature = (Feature)model.InsertSketchForEdgeFlange(edge, angle, top ? false : true);
                if (sketchFeature == null) throw new InvalidOperationException("SolidWorks devolvió un croquis auxiliar vacío.");

                substep = "leer los dos vértices del borde seleccionado";
                apiMethod = "IEdge.GetStartVertex/GetEndVertex";
                Vertex v1 = (Vertex)edge.GetStartVertex(); Vertex v2 = (Vertex)edge.GetEndVertex();
                if (v1 == null || v2 == null) throw new InvalidOperationException("El borde seleccionado no devolvió ambos vértices.");
                double[] p1 = (double[])v1.GetPoint(); double[] p2 = (double[])v2.GetPoint();

                substep = "dibujar el perfil auxiliar de la pestaña";
                apiMethod = "IModelDoc2.CreateLine2";
                double direction = top ? 1.0 : -1.0;
                model.SetAddToDB(true);
                model.CreateLine2(p1[0], p1[1], p1[2], p1[0], p1[1] + direction * flangeLength, p1[2]);
                model.CreateLine2(p1[0], p1[1] + direction * flangeLength, p1[2], p2[0], p2[1] + direction * flangeLength, p2[2]);
                model.CreateLine2(p2[0], p2[1] + direction * flangeLength, p2[2], p2[0], p2[1], p2[2]);
                model.SetAddToDB(false);
                model.InsertSketch2(true);

                substep = "insertar la operación Brida de arista";
                apiMethod = "IFeatureManager.InsertSheetMetalEdgeFlange2";
                object[] edges = new object[] { edge };
                object[] sketches = new object[] { sketchFeature };
                // 128 = default relief; 1 = material inside; 4 = no relief;
                // 2 = inner virtual sharp.
                Feature flange = model.FeatureManager.InsertSheetMetalEdgeFlange2(edges, sketches, 128, angle, radius, 1, flangeLength, 4, 0, 0, 0, 2, null);
                if (flange == null) throw new InvalidOperationException("SolidWorks devolvió una operación de brida de arista vacía.");
                model.EditRebuild3();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Doblez " + side + ": falló el subpaso '" + substep + "'. " +
                    "Llamada API: " + apiMethod + ". " +
                    "Pestaña=" + (flangeLength * 1000.0).ToString("0.###", CultureInfo.InvariantCulture) +
                    " mm; ángulo API=" + (angle * 180.0 / Math.PI).ToString("0.###", CultureInfo.InvariantCulture) +
                    "°; radio=" + (radius * 1000.0).ToString("0.###", CultureInfo.InvariantCulture) + " mm. " +
                    "Detalle original: " + ex.Message, ex);
            }
        }

        private static Edge FindLongHorizontalEdge(ModelDoc2 model, double length, double height, bool top)
        {
            PartDoc part = (PartDoc)model;
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            if (bodies == null) return null;
            double targetY = top ? height / 2.0 : -height / 2.0;
            Edge best = null; double bestScore = Double.MaxValue;
            foreach (object bodyObject in bodies)
            {
                Body2 body = (Body2)bodyObject;
                object[] edges = (object[])body.GetEdges();
                if (edges == null) continue;
                foreach (object edgeObject in edges)
                {
                    Edge edge = (Edge)edgeObject;
                    Vertex a = (Vertex)edge.GetStartVertex(); Vertex b = (Vertex)edge.GetEndVertex();
                    if (a == null || b == null) continue;
                    double[] p1 = (double[])a.GetPoint(); double[] p2 = (double[])b.GetPoint();
                    double dx = Math.Abs(p2[0] - p1[0]), dy = Math.Abs(p2[1] - p1[1]);
                    if (dx < length * 0.99 || dy > 0.00001) continue;
                    double score = Math.Abs(((p1[1] + p2[1]) / 2.0) - targetY) + Math.Abs(p1[2]) * 0.01;
                    if (score < bestScore) { best = edge; bestScore = score; }
                }
            }
            return best;
        }

        private static void AddTestMark(ModelDoc2 model, ProfileSettings s, SldWorks sw, bool isRH = false)
        {
            var pattern=ProfileSlotLayout.PatternFor(s);
            if (!pattern.LogoVisible && pattern.Slots.Length==0) return;
            double before=SolidWorksShaftPlateGenerator.Volume(model);
            double size = ((s.MarkA ? LogoAGeometry.BaseWidthMm : 70.0) / 1000.0) * s.MarkScale / 100.0;
            string substep = "seleccionar la cara plana del alma";
            try
            {
                SelectLargestPlanarFace(model);
                SketchManager sketch = model.SketchManager;

                substep = "abrir un croquis sobre la cara del alma";
                sketch.InsertSketch(true);
                Sketch activeSketch = (Sketch)model.GetActiveSketch2();
                if (activeSketch == null)
                    throw new InvalidOperationException("SolidWorks no dejó un croquis activo después de seleccionar la cara.");

                substep = "dibujar el contorno cerrado de la marca";
                sketch.AddToDB = true;
                // La Brida base/Pestaña se extruye en la dirección X negativa
                // (igual que el croquis grabado por el usuario: centro X=-1.2 m para L=2.4 m).
                var math=(MathUtility)sw.GetMathUtility();
                var center=(double[])((MathPoint)((MathPoint)math.CreatePoint(new[]{0.0,pattern.CenterYMm/1000,pattern.LogoCenterMm/1000})).MultiplyTransform(activeSketch.ModelToSketchTransform)).ArrayData;
                double centerX=center[0],centerY=center[1];
                if (pattern.LogoVisible && s.MarkA)
                {
                    // isRH=true: el logo NO se niega en X porque la cara ya está orientada
                    // en espejo respecto a LH — así el texto queda legible desde el exterior.
                    LogoAGeometry.AddToModelSketch(sketch,activeSketch,math,pattern.LogoCenterMm/1000,pattern.CenterYMm/1000,size,isRH);
                }
                else if(pattern.LogoVisible && s.MarkB)
                {
                    double radius = size / 2.0;
                    for (int i = 0; i < 6; i++)
                    {
                        double a1 = Math.PI / 6.0 + i * Math.PI / 3.0, a2 = Math.PI / 6.0 + (i + 1) * Math.PI / 3.0;
                        sketch.CreateLine(centerX + radius * Math.Cos(a1), centerY + radius * Math.Sin(a1), 0, centerX + radius * Math.Cos(a2), centerY + radius * Math.Sin(a2), 0);
                    }
                }
                if (pattern.Slots.Length > 0) AddConfigurableSlots(sketch, s, activeSketch, (MathUtility)sw.GetMathUtility());
                sketch.AddToDB = false;

                object[] segments = (object[])activeSketch.GetSketchSegments();
                // Each resolved capsule has two straight edges and two explicit semicircular arcs.
                int expectedSegments = !pattern.LogoVisible?0:s.MarkA?LogoAGeometry.SegmentCount:6;
                foreach(var slot in ProfileSlotLayout.For(s)) expectedSegments+=4;
                int actualSegments = segments == null ? 0 : segments.Length;
                if (actualSegments != expectedSegments)
                    throw new InvalidOperationException("El croquis de la marca contiene " + actualSegments + " segmentos; se esperaban " + expectedSegments + ".");

                // La operación debe consumir el croquis mientras continúa activo. Cerrarlo antes
                // de FeatureCut puede dejar el croquis sin seleccionar en algunas versiones/localizaciones.
                substep = "crear el corte extruido A través de todo";
                Feature cut = model.FeatureManager.FeatureCut4(
                    true, false, false,
                    (int)swEndConditions_e.swEndCondThroughAll, (int)swEndConditions_e.swEndCondBlind,
                    0.01, 0.01,
                    false, false, false, false,
                    Math.PI / 180.0, Math.PI / 180.0,
                    false, false, false, false,
                    true,
                    true, true,
                    true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false,
                    true);
                if (cut == null)
                    throw new InvalidOperationException("FeatureCut4 devolvió vacío aun cuando el croquis estaba activo y contenía " + actualSegments + " segmentos cerrados.");
                cut.Name="Logo_Ranuras_Patron300";model.EditRebuild3();
                double area=pattern.LogoVisible?(s.MarkA?LogoAGeometry.AreaMm2(pattern.LogoWidthMm):3*Math.Sqrt(3)/2*Math.Pow(35*s.MarkScale/100,2)):0;
                foreach(var slot in pattern.Slots)area+=2*slot.RadiusMm*(slot.LengthMm-2*slot.RadiusMm)+Math.PI*slot.RadiusMm*slot.RadiusMm;
                double expected=area*s.ThicknessMm/1e9,removed=before-SolidWorksShaftPlateGenerator.Volume(model);
                if(Math.Abs(removed-expected)>Math.Max(expected*.002,1e-12))throw new InvalidOperationException("El volumen de los cortes de logo/ranuras no coincide con el patrón. Esperado="+(expected*1e9).ToString("0.###")+" mm3; retirado="+(removed*1e9).ToString("0.###")+" mm3.");
            }
            catch (Exception ex)
            {
                try { model.SketchManager.AddToDB = false; } catch { }
                throw new InvalidOperationException(
                    "Marca de prueba: falló el subpaso '" + substep + "'. " +
                    "Tipo=" + (s.MarkA ? "cuadrado" : "hexágono") +
                    "; tamaño=" + (size * 1000.0).ToString("0.###", CultureInfo.InvariantCulture) +
                    " mm; centro X=" + (-s.LengthMm / 2.0).ToString("0.###", CultureInfo.InvariantCulture) +
                    " mm; centro Y=" + (-s.WebHeightMm / 2.0).ToString("0.###", CultureInfo.InvariantCulture) +
                    " mm. Detalle: " + ex.Message, ex);
            }
        }

        private static void AddSupportHoles(ModelDoc2 model, SldWorks sw, ProfileSettings s)
        {
            if (!s.IncludeSupportHoles) return;

            string substep = "seleccionar la cara del alma";
            try
            {
                Face2 webFace = FindWebFace(model, s);
                if (webFace == null)
                    throw new InvalidOperationException("No se encontró la cara del alma para los barrenos de soporte.");

                model.ClearSelection2(true);
                Entity entity = (Entity)webFace;
                if (!entity.Select(false))
                    throw new InvalidOperationException("SolidWorks no permitió seleccionar la cara del alma.");

                SketchManager sketchMgr = model.SketchManager;
                substep = "abrir croquis para barrenos de soportes";
                sketchMgr.InsertSketch(true);
                Sketch activeSketch = (Sketch)model.GetActiveSketch2();
                if (activeSketch == null)
                    throw new InvalidOperationException("SolidWorks no dejó un croquis activo en el alma.");

                MathTransform xform = activeSketch.ModelToSketchTransform;
                MathUtility mathUtil = (MathUtility)sw.GetMathUtility();

                Func<double, double, double, double[]> toSk = (x, y, z) =>
                {
                    MathPoint pt = (MathPoint)mathUtil.CreatePoint(new double[] { x, y, z });
                    MathPoint ptSk = (MathPoint)pt.MultiplyTransform(xform);
                    return (double[])ptSk.ArrayData;
                };

                double[] faceBox = (double[])webFace.GetBox();
                double webX = (faceBox[0] + faceBox[3]) / 2.0;

                double holeSz = s.SupportHoleSizeMm / 1000.0;
                double hhalf = holeSz / 2.0;
                double yCenter = -s.SupportHoleYMm / 1000.0;
                double[] centersMm = SupportHoleLayout.CentersMm(s);

                sketchMgr.AddToDB = true;
                substep = "dibujar los 6 barrenos cuadrados mediante proyección 3D";

                for (int i = 0; i < centersMm.Length; i++)
                {
                    double zCenter = centersMm[i] / 1000.0;
                    double[] p1 = toSk(webX, yCenter - hhalf, zCenter - hhalf);
                    double[] p2 = toSk(webX, yCenter - hhalf, zCenter + hhalf);
                    double[] p3 = toSk(webX, yCenter + hhalf, zCenter + hhalf);
                    double[] p4 = toSk(webX, yCenter + hhalf, zCenter - hhalf);

                    sketchMgr.CreateLine(p1[0], p1[1], 0, p2[0], p2[1], 0);
                    sketchMgr.CreateLine(p2[0], p2[1], 0, p3[0], p3[1], 0);
                    sketchMgr.CreateLine(p3[0], p3[1], 0, p4[0], p4[1], 0);
                    sketchMgr.CreateLine(p4[0], p4[1], 0, p1[0], p1[1], 0);
                }

                sketchMgr.AddToDB = false;

                substep = "crear corte pasante de los barrenos para soportes C";
                Feature cut = model.FeatureManager.FeatureCut4(
                    true, false, false,
                    (int)swEndConditions_e.swEndCondThroughAll, 0,
                    0.01, 0.01,
                    false, false, false, false,
                    0, 0, false, false, false, false,
                    true, true, true, true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false, true);

                if (cut == null)
                    throw new InvalidOperationException("SOLIDWORKS no creó el corte de los seis barrenos.");
                try { cut.Name = "Barrenos_Soportes_C"; } catch { }

                model.ClearSelection2(true);
            }
            catch (Exception ex)
            {
                try { model.SketchManager.AddToDB = false; } catch { }
                throw new InvalidOperationException("Fallo al crear barrenos para soportes C ('" + substep + "'): " + ex.Message, ex);
            }
        }

        private static Face2 FindWebFace(ModelDoc2 model, ProfileSettings s)
        {
            PartDoc part = (PartDoc)model;
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            if (bodies == null) return null;

            double expectedArea = (s.WebHeightMm / 1000.0) * (s.LengthMm / 1000.0);
            double minLength = (s.LengthMm / 1000.0) * 0.85;

            Face2 bestFace = null;
            double bestScore = double.MaxValue;

            foreach (object bodyObj in bodies)
            {
                Body2 body = (Body2)bodyObj;
                object[] faces = (object[])body.GetFaces();
                if (faces == null) continue;
                foreach (object faceObj in faces)
                {
                    Face2 face = (Face2)faceObj;
                    Surface surf = (Surface)face.GetSurface();
                    if (surf == null || !surf.IsPlane()) continue;

                    double[] box = (double[])face.GetBox();
                    if (box == null) continue;
                    double faceLen = Math.Abs(box[5] - box[2]);
                    if (faceLen < minLength) continue;

                    double faceHeight = Math.Abs(box[4] - box[1]);
                    if (faceHeight < (s.WebHeightMm / 1000.0) * 0.70) continue;

                    double area = face.GetArea();
                    double score = Math.Abs(area - expectedArea);
                    if (score < bestScore)
                    {
                        bestScore = score;
                        bestFace = face;
                    }
                }
            }
            return bestFace ?? FindLargestPlanarFaceDirect(bodies);
        }

        private static Face2 FindLargestPlanarFaceDirect(object[] bodies)
        {
            if (bodies == null) return null;
            Face2 bestFace = null;
            double bestArea = 0.0;
            foreach (object bodyObj in bodies)
            {
                Body2 body = (Body2)bodyObj;
                object[] faces = (object[])body.GetFaces();
                if (faces == null) continue;
                foreach (object faceObj in faces)
                {
                    Face2 face = (Face2)faceObj;
                    Surface surf = (Surface)face.GetSurface();
                    if (surf != null && surf.IsPlane())
                    {
                        double area = face.GetArea();
                        if (area > bestArea) { bestFace = face; bestArea = area; }
                    }
                }
            }
            return bestFace;
        }

        private static void AddEndHoles(ModelDoc2 model, SldWorks sw, ProfileSettings s)
        {
            if (s.EndHoleTypeLeft == "ninguno" && s.EndHoleTypeRight == "ninguno" && !VerticalSupportLayout.HasCenter(s)) return;

            // 1. Orificios inferiores en la pestaña a 45° (soporte PTR)
            if (s.EndHolesBottom)
            {
                CutEndHolesOnFlange(model, sw, s, false);
                model.EditRebuild3();
            }

            // 2. Orificios superiores en la pestaña superior a 90° (aditamentos)
            if (s.EndHolesTop && (s.EndHoleTypeLeft != "ninguno" || s.EndHoleTypeRight != "ninguno"))
            {
                CutEndHolesOnFlange(model, sw, s, true);
                model.EditRebuild3();
            }
        }

        private static void CutEndHolesOnFlange(ModelDoc2 model, SldWorks sw, ProfileSettings s, bool isTopFlange)
        {
            string flangeName = isTopFlange ? "pestaña superior (aditamentos)" : "pestaña inferior 45° (soporte)";
            string substep = "seleccionar la cara de la " + flangeName;
            try
            {
                Face2 face = FindFlangeFace(model, s, isTopFlange);
                if (face == null)
                    throw new InvalidOperationException("No se encontró la cara de la " + flangeName + ".");

                model.ClearSelection2(true);
                Entity entity = (Entity)face;
                if (!entity.Select(false))
                    throw new InvalidOperationException("SolidWorks no permitió seleccionar la cara de la " + flangeName + ".");

                SketchManager sketchMgr = model.SketchManager;
                substep = "abrir croquis en " + flangeName;
                sketchMgr.InsertSketch(true);
                Sketch activeSketch = (Sketch)model.GetActiveSketch2();
                if (activeSketch == null)
                    throw new InvalidOperationException("SolidWorks no dejó un croquis activo en " + flangeName + ".");

                MathTransform xform = activeSketch.ModelToSketchTransform;
                MathUtility mathUtil = (MathUtility)sw.GetMathUtility();

                // Dimensiones estándar del macro PERFORACIONES SOPORTES:
                // Cuadrado 11×11 mm · borde 31.75 mm (1¼") · paso 63.5 mm (2½")
                double half = (s.EndHoleSizeMm / 2.0) / 1000.0;

                // Datum transversal: borde libre inferior; centro de cara superior.
                // Obtener la caja de la cara real para localizar el borde libre y su inclinación.
                // Esto evita el error de posicionamiento causado por usar fórmulas angulares
                // que asumen una cara sin radio de doblez ni espesor.
                double[] faceBox = (double[])face.GetBox();
                // faceBox = { minX, minY, minZ, maxX, maxY, maxZ }
                double[] holeOrigin = VerticalSupportLayout.FaceHoleOrigin(faceBox,s,isTopFlange);
                double fcx = holeOrigin[0];
                double fcy = holeOrigin[1];
                double fMinZ = faceBox[2];                     // inicio del perfil en Z
                double fMaxZ = faceBox[5];                     // fin del perfil en Z

                // Transformar dos puntos de referencia conocidos (datum de barrenos en Z=mín y Z=máx)
                // al sistema de coordenadas del croquis, para derivar empíricamente el mapeo de ejes.
                // Esto evita asumir qué eje del croquis corresponde a la dirección de longitud del perfil.
                MathPoint ptRef0 = (MathPoint)mathUtil.CreatePoint(new double[] { fcx, fcy, fMinZ });
                MathPoint ptRefL = (MathPoint)mathUtil.CreatePoint(new double[] { fcx, fcy, fMaxZ });
                double[] sk0 = (double[])((MathPoint)ptRef0.MultiplyTransform(xform)).ArrayData;
                double[] skL = (double[])((MathPoint)ptRefL.MultiplyTransform(xform)).ArrayData;

                // Tasa de cambio de coordenadas de croquis por unidad de longitud en Z del modelo.
                double dZ = fMaxZ - fMinZ;
                double rX  = (skL[0] - sk0[0]) / dZ; // d(croquis_X) / d(modelo_Z)
                double rY  = (skL[1] - sk0[1]) / dZ; // d(croquis_Y) / d(modelo_Z)

                sketchMgr.AddToDB = true;
                substep = "dibujar orificios cuadrados 11×11 mm en " + flangeName;

                Action<double> drawHoleAtZ = delegate(double z3d)
                {
                    // Interpolación lineal: centro del orificio en coordenadas de croquis.
                    // sk0 = posición del datum transversal en Z=fMinZ (en croquis).
                    // rX, rY = desplazamiento en croquis por metro avanzado en Z del modelo.
                    double skX = sk0[0] + (z3d - fMinZ) * rX;
                    double skY = sk0[1] + (z3d - fMinZ) * rY;
                    // Cuadrado exacto de 11.00 × 11.00 mm (half = 5.5 mm) con líneas directas AddToDB=true.
                    // El datum inferior conserva la distancia al borde libre al variar el doblez.
                    sketchMgr.CreateLine(skX - half, skY - half, 0, skX + half, skY - half, 0);
                    sketchMgr.CreateLine(skX + half, skY - half, 0, skX + half, skY + half, 0);
                    sketchMgr.CreateLine(skX + half, skY + half, 0, skX - half, skY + half, 0);
                    sketchMgr.CreateLine(skX - half, skY + half, 0, skX - half, skY - half, 0);
                };

                foreach(double center in VerticalSupportLayout.HoleCenters(s,isTopFlange)) drawHoleAtZ(center/1000.0);

                sketchMgr.AddToDB = false;
                substep = "crear corte extruido limitado al espesor en " + flangeName;

                // Limitar la profundidad a 2× el espesor para cortar limpiamente la pestaña
                // sin traspasar ("Por todo") hacia el alma inclinada de 5 grados ni otras caras.
                double cutDepth = (s.ThicknessMm / 1000.0) * 2.0;

                Feature cut = model.FeatureManager.FeatureCut4(
                    true, false, false,
                    (int)swEndConditions_e.swEndCondBlind, (int)swEndConditions_e.swEndCondBlind,
                    cutDepth, 0.01,
                    false, false, false, false,
                    Math.PI / 180.0, Math.PI / 180.0,
                    false, false, false, false,
                    true,
                    true, true,
                    true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false,
                    true);

                if (cut == null)
                {
                    try { model.SketchManager.AddToDB = false; } catch { }
                    throw new InvalidOperationException("FeatureCut4 devolvió vacío para " + flangeName + ".");
                }
            }
            catch (Exception ex)
            {
                try { model.SketchManager.AddToDB = false; } catch { }
                throw new InvalidOperationException(
                    "Orificios en extremos (" + flangeName + "): falló '" + substep + "'. " + ex.Message, ex);
            }
        }

        internal static Face2 FindFlangeFace(ModelDoc2 model, ProfileSettings s, bool isTopFlange)
        {
            PartDoc part = (PartDoc)model;
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            if (bodies == null) return null;

            double expectedWidth = (isTopFlange ? s.TopFlangeMm : s.BottomFlangeMm) / 1000.0;
            double expectedArea  = expectedWidth * (s.LengthMm / 1000.0);
            double minLength     = (s.LengthMm / 1000.0) * 0.85;

            Face2 bestFace = null;
            double bestScore = double.MaxValue;

            foreach (object bodyObj in bodies)
            {
                Body2 body = (Body2)bodyObj;
                object[] faces = (object[])body.GetFaces();
                if (faces == null) continue;
                foreach (object faceObj in faces)
                {
                    Face2 face = (Face2)faceObj;
                    Surface surf = (Surface)face.GetSurface();
                    if (surf == null || !surf.IsPlane()) continue;

                    double[] box = (double[])face.GetBox();
                    if (box == null) continue;
                    double faceLength = Math.Abs(box[5] - box[2]);
                    if (faceLength < minLength) continue; // Sólo caras longitudinales

                    double area = face.GetArea();
                    if (area < expectedArea * 0.3) continue;

                    if (isTopFlange)
                    {
                        // Pestaña superior: situada en la parte alta (Y cerca de 0)
                        if (box[1] < -0.08) continue;
                        double score = Math.Abs(area - expectedArea);
                        if (score < bestScore) { bestScore = score; bestFace = face; }
                    }
                    else
                    {
                        // Pestaña inferior: situada en la parte baja (Y cerca de -WebHeight)
                        double bottomThreshold = -(s.WebHeightMm / 1000.0) * 0.65;
                        if (box[4] > bottomThreshold) continue;
                        double score = Math.Abs(area - expectedArea);
                        if (score < bestScore) { bestScore = score; bestFace = face; }
                    }
                }
            }

            return bestFace;
        }

        private static void AddConfigurableSlots(SketchManager sketch, ProfileSettings s, Sketch active, MathUtility math)
        {
            Func<double,double,double[]> point=delegate(double z,double y) {
                return (double[])((MathPoint)((MathPoint)math.CreatePoint(new[]{0.0,y,z})).MultiplyTransform(active.ModelToSketchTransform)).ArrayData;
            };
            foreach(var slot in ProfileSlotLayout.For(s)) {
                double r=slot.RadiusMm/1000,half=(slot.LengthMm-2*slot.RadiusMm)/2000;
                double za=slot.CenterMm/1000-half,zb=slot.CenterMm/1000+half,yy=slot.CenterYMm/1000;
                var tl=point(za,yy+r);var tr=point(zb,yy+r);var bl=point(za,yy-r);var br=point(zb,yy-r);
                var left=point(za-r,yy);var right=point(zb+r,yy);
                sketch.CreateLine(tl[0],tl[1],0,tr[0],tr[1],0);
                sketch.Create3PointArc(tr[0],tr[1],0,br[0],br[1],0,right[0],right[1],0);
                sketch.CreateLine(br[0],br[1],0,bl[0],bl[1],0);
                sketch.Create3PointArc(bl[0],bl[1],0,tl[0],tl[1],0,left[0],left[1],0);
            }
        }

        private static void SelectLargestPlanarFace(ModelDoc2 model)
        {
            model.ClearSelection2(true);
            PartDoc part = (PartDoc)model;
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            Face2 bestFace = null;
            double bestArea = 0.0;
            if (bodies != null)
            {
                foreach (object bodyObject in bodies)
                {
                    Body2 body = (Body2)bodyObject;
                    object[] faces = (object[])body.GetFaces();
                    if (faces == null) continue;
                    foreach (object faceObject in faces)
                    {
                        Face2 face = (Face2)faceObject;
                        Surface surface = (Surface)face.GetSurface();
                        if (surface == null || !surface.IsPlane()) continue;
                        double area = face.GetArea();
                        if (area > bestArea) { bestFace = face; bestArea = area; }
                    }
                }
            }
            if (bestFace == null) throw new InvalidOperationException("No se encontró la cara plana principal para colocar la marca.");
            Entity entity = (Entity)bestFace;
            if (!entity.Select(false)) throw new InvalidOperationException("SolidWorks no permitió seleccionar la cara plana principal.");
        }
    }
}
