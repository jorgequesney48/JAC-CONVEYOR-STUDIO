﻿using System;
using System.IO;
using SolidWorks.Interop.sldworks;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
    static string CreateReturnCylinder(SldWorks sw,string path,double outer,double inner,double length,string name){
        return CadReuseSession.Part("Cilindro_retorno",new{outer,inner,length},path,()=>{
        if(outer<=inner||inner<0||length<=0)throw new InvalidOperationException("Rodillo: revisa diámetros y separación lateral.");
        var model=NewLegSketch(sw);model.SketchManager.CreateCircleByRadius(0,0,0,outer/2000);if(inner>0)model.SketchManager.CreateCircleByRadius(0,0,0,inner/2000);model.SketchManager.AddToDB=false;
        var feature=model.FeatureManager.FeatureExtrusion2(true,false,false,0,0,length/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
        if(feature==null)throw new InvalidOperationException("No se creó "+name);feature.Name=name;model.EditRebuild3();
        double expected=Math.PI*(outer*outer-inner*inner)*length/4/1e9;
        if(Math.Abs(SolidWorksShaftPlateGenerator.Volume(model)-expected)>expected*.001)throw new InvalidOperationException("Volumen incorrecto de "+name);
        int e=0,w=0;if(!model.SaveAs4(path,0,1,ref e,ref w)||e!=0)throw new InvalidOperationException("No se guardó "+name+" ("+e+")");sw.CloseDoc(model.GetTitle());
        });
    }
    static string CreateReturnAxle(SldWorks sw,string path,ReturnRollerSettings settings,ProfileSettings profile,SoporteSettings support){
        return CadReuseSession.Part("Eje_tableado",new{Longitud=support.LengthMm+2*(settings.ShaftProjectionMm+profile.ThicknessMm),Plano=ReturnRollerSeatGeometry.FlatLength(settings,profile)},path,()=>{
        double length=support.LengthMm+2*(settings.ShaftProjectionMm+profile.ThicknessMm),flat=ReturnRollerSeatGeometry.FlatLength(settings,profile),r=ReturnRollerSeatGeometry.SeatRadius/1000,a=ReturnRollerSeatGeometry.HalfFlat/1000,v=Math.Sqrt(r*r-a*a);
        if(length<=2*flat)throw new InvalidOperationException("Eje: no hay espacio para el tramo redondo entre caras planas.");
        string template=sw.GetUserPreferenceStringValue((int)SolidWorks.Interop.swconst.swUserPreferenceStringValue_e.swDefaultTemplatePart);var model=(ModelDoc2)sw.NewDocument(template,0,0,0);if(model==null)throw new InvalidOperationException("No se creó el eje de retorno.");
        Action<SketchManager> flats=sk=>{sk.CreateLine(v,a,0,-v,a,0);sk.Create3PointArc(-v,a,0,-v,-a,0,-r,0,0);sk.CreateLine(-v,-a,0,v,-a,0);sk.Create3PointArc(v,-a,0,v,a,0,r,0,0);};
        SolidWorksConveyorShaftGenerator.Extrude(model,"Tramo_Redondo_Eje_Retorno",flat,length-2*flat,sk=>sk.CreateCircleByRadius(0,0,0,r));
        SolidWorksConveyorShaftGenerator.Extrude(model,"Extremo_Tableado_Izquierdo",0,flat,flats);SolidWorksConveyorShaftGenerator.Extrude(model,"Extremo_Tableado_Derecho",length-flat,flat,flats);
        double expected=(Math.PI*ReturnRollerSeatGeometry.SeatRadius*ReturnRollerSeatGeometry.SeatRadius*(length-2*flat)+2*flat*ReturnRollerSeatGeometry.FlatArea)/1e9;
        if(Math.Abs(SolidWorksShaftPlateGenerator.Volume(model)-expected)>expected*.001)throw new InvalidOperationException("Volumen incorrecto del eje tableado.");
        int e=0,w=0;if(!model.SaveAs4(path,0,1,ref e,ref w)||e!=0)throw new InvalidOperationException("No se guardó eje tableado ("+e+")");sw.CloseDoc(model.GetTitle());
        });
    }
    static double[] ReturnCylinderTransform(double x,double y,double z){return new[]{0d,1,0,0,0,1,1,0,0,x/1000,y/1000,z/1000,1,0,0,0};}
}
}
