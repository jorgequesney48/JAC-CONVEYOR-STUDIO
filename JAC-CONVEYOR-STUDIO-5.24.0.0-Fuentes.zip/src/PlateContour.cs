using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace PerfilBandas
{
    // Canonical coordinates: X from the free plate end toward the conveyor, Y upward.
    internal sealed class ContourEdge
    {
        public double X1,Y1,X2,Y2,CX,CY,Radius,Start,Sweep;
    }
    internal sealed class PlateContour
    {
        public readonly List<ContourEdge> Edges=new List<ContourEdge>();
        public double ReliefRadiusMm, CornerRadiusMm;
        private void Line(double x1,double y1,double x2,double y2)
        { if(Math.Abs(x1-x2)+Math.Abs(y1-y2)>1e-9) Edges.Add(new ContourEdge{X1=x1,Y1=y1,X2=x2,Y2=y2}); }
        private void Arc(double cx,double cy,double r,double start,double sweep)
        {
            double a=start*Math.PI/180,b=(start+sweep)*Math.PI/180;
            Edges.Add(new ContourEdge{CX=cx,CY=cy,Radius=r,Start=start,Sweep=sweep,
                X1=cx+r*Math.Cos(a),Y1=cy+r*Math.Sin(a),X2=cx+r*Math.Cos(b),Y2=cy+r*Math.Sin(b)});
        }
        public double AreaMm2 {
            get {
                double area=0;
                foreach(var e in Edges) {
                    if(e.Radius==0) area+=e.X1*e.Y2-e.X2*e.Y1;
                    else area+=e.CX*(e.Y2-e.Y1)-e.CY*(e.X2-e.X1)+e.Radius*e.Radius*e.Sweep*Math.PI/180;
                }
                return Math.Abs(area)/2;
            }
        }
        public GraphicsPath Drawing(float x,float top,float scale,double topY)
        {
            var path=new GraphicsPath();
            foreach(var e in Edges) {
                if(e.Radius==0) path.AddLine(x+(float)e.X1*scale,top+(float)(topY-e.Y1)*scale,x+(float)e.X2*scale,top+(float)(topY-e.Y2)*scale);
                else path.AddArc(x+(float)(e.CX-e.Radius)*scale,top+(float)(topY-e.CY-e.Radius)*scale,(float)(2*e.Radius)*scale,(float)(2*e.Radius)*scale,(float)-e.Start,(float)-e.Sweep);
            }
            path.CloseFigure();return path;
        }
        public static PlateContour Build(ShaftPlateSettings s,ShaftPlateLayout l)
        {
            var c=new PlateContour();
            double top=l.TopY,bottom=top-l.HeightMm,join=l.PlateLengthMm-l.OverlapMm,length=l.PlateLengthMm;
            double lapTop=s.Mounting==2?Math.Min(top,l.WebTopY)-.25:top;
            double lapBottom=s.Mounting==2?Math.Max(bottom,l.WebBottomY)+.25:bottom;
            double r=Math.Min(s.SculptedContour?s.ContourRadiusMm:20,Math.Min(l.HeightMm/4,join/4)),relief=0;
            if(s.SculptedContour) {
                if(s.ContourRadiusMm<=0 || s.ReliefRadiusMm<=0 || s.ContourMarginMm<2)
                    throw new InvalidOperationException("Placas: radios positivos y material de contorno de al menos 2 mm.");
                double envelope=Math.Max(s.BearingEnvelopeMm/2,Math.Max(s.OpeningDiameterMm/2,s.BoltPitchMm/2+s.BoltDiameterMm/2));
                double protectedRadius=Math.Max(envelope+s.ContourMarginMm,l.Sprocket.PitchDiameterMm/2+l.EffectiveCoverMarginMm);
                relief=Math.Max(0,Math.Min(s.ReliefRadiusMm,Math.Min(l.AxisY-protectedRadius-bottom,join-l.AxisFromEndMm-protectedRadius)));
                r=Math.Min(r,Math.Max(.5,l.AxisFromEndMm-envelope));
            }
            c.ReliefRadiusMm=relief;c.CornerRadiusMm=r;
            double raised=bottom+relief;
            c.Line(r,top,join,top);
            if(s.Mounting==2) {
                c.Line(join,top,join,lapTop);c.Line(join,lapTop,length,lapTop);
                c.Line(length,lapTop,length,lapBottom);c.Line(length,lapBottom,join,lapBottom);c.Line(join,lapBottom,join,bottom);
            } else c.Line(join,top,join,bottom);
            if(relief>1e-6) c.Arc(join-relief,bottom,relief,0,90);
            c.Line(join-relief,raised,r,raised);
            c.Arc(r,raised+r,r,-90,-90);
            c.Line(0,raised+r,0,top-r);c.Arc(r,top-r,r,180,-90);
            return c;
        }
    }
}
