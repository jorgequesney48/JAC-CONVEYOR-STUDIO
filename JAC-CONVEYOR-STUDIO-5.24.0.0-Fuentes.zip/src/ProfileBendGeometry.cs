using System;
using System.Collections.Generic;
using System.Drawing;

namespace PerfilBandas {
    // Dimensions of the sketch are measured to the virtual intersection of
    // the outer faces, as in the SolidWorks base flange.
    internal static class ProfileBendGeometry {
        internal static double Sweep(ProfileSettings p,bool top) {
            return (top?p.TopAngleDeg:180-p.BottomAngleDeg)*Math.PI/180;
        }
        internal static double Tangent(ProfileSettings p,bool top) {
            return (p.BendRadiusMm+p.ThicknessMm)*Math.Tan(Sweep(p,top)/2);
        }
        internal static double Allowance(ProfileSettings p,bool top) {
            return Sweep(p,top)*(p.BendRadiusMm+p.KFactor*p.ThicknessMm);
        }
        internal static double DevelopedWidth(ProfileSettings p) {
            return p.WebHeightMm+p.TopFlangeMm+p.BottomFlangeMm
                -2*(Tangent(p,true)+Tangent(p,false))+Allowance(p,true)+Allowance(p,false);
        }
        internal static PointF[] Boundary(ProfileSettings p,double radius) {
            double outer=p.BendRadiusMm+p.ThicknessMm,inset=outer-radius;
            var points=new List<PointF>();
            Action<double,double> add=(x,y)=>points.Add(new PointF((float)x,(float)y));
            double a=(90+p.TopAngleDeg)*Math.PI/180;
            add(p.TopFlangeMm*Math.Cos(a)-inset*Math.Sin(a),p.TopFlangeMm*Math.Sin(a)+inset*Math.Cos(a));
            double sweep=Sweep(p,true),cy=-Tangent(p,true);
            int steps=Math.Max(2,(int)Math.Ceiling(sweep*180/Math.PI/3));
            for(int j=steps;j>=0;j--){a=sweep*j/steps;add(-outer+radius*Math.Cos(a),cy+radius*Math.Sin(a));}
            sweep=-Sweep(p,false);cy=-p.WebHeightMm+Tangent(p,false);
            steps=Math.Max(2,(int)Math.Ceiling(-sweep*180/Math.PI/3));
            for(int j=0;j<=steps;j++){a=sweep*j/steps;add(-outer+radius*Math.Cos(a),cy+radius*Math.Sin(a));}
            a=(90+p.BottomAngleDeg)*Math.PI/180;
            add(p.BottomFlangeMm*Math.Cos(a)+inset*Math.Sin(a),-p.WebHeightMm+p.BottomFlangeMm*Math.Sin(a)-inset*Math.Cos(a));
            return points.ToArray();
        }
        internal static void Validate(ProfileSettings p) {
            double upper=Tangent(p,true),lower=Tangent(p,false);
            if(p.KFactor<=0||p.KFactor>=1||Double.IsNaN(p.KFactor)||Double.IsInfinity(p.KFactor))
                throw new InvalidOperationException("El factor K del perfil debe estar entre 0 y 1.");
            if(upper>=p.TopFlangeMm||lower>=p.BottomFlangeMm||upper+lower>=p.WebHeightMm)
                throw new InvalidOperationException("El radio y los ángulos de doblez no caben en las pestañas o el alma del perfil.");
        }
    }
}
