using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace PerfilBandas
{
    internal static partial class ProfileSlotLayout
    {
        static string Signature(ProfileSettings p) { return new JavaScriptSerializer().Serialize(new{Perfil=p,SoporteInferiorResuelto=p.ResolvedUpperSupportBottomYMm}); }
        public static string CombinationLabel(string value)
        {
            if (String.IsNullOrEmpty(value)) return "Automático por recorte";
            var words = new List<string>();
            foreach (string token in value.Split(',')) words.Add(token == "R" ? "Ranura" : "Logo");
            return String.Join(" → ", words.ToArray());
        }
        public static string[] Combinations()
        {
            var values = new List<string> { "", "L" };
            for (int n = 1; n <= 4; n++)
            {
                var tokens = new List<string>(); for (int i = 0; i < n; i++) tokens.Add("R");
                values.Add(String.Join(",", tokens.ToArray()));
                for (int i = 0; i <= n; i++) { var withLogo = new List<string>(tokens); withLogo.Insert(i, "L"); values.Add(String.Join(",", withLogo.ToArray())); }
            }
            return values.ToArray();
        }
        public static string DimensionsText(ProfilePattern pattern)
        {
            return (pattern.Slots.Length == 0 ? "Sólo logo · sin ranuras" : "Largo: " + pattern.Slots[0].LengthMm.ToString("0.##") + " · radio: " + pattern.Slots[0].RadiusMm.ToString("0.##") + " mm")
                + "\nSeparación libre: " + pattern.GapMm.ToString("0.##") + " mm"
                + "\nMárgenes: " + pattern.LeftMarginMm.ToString("0.##") + " / " + pattern.RightMarginMm.ToString("0.##") + " mm";
        }
        public static ProfilePattern Calculate(ProfileSettings p)
        {
            SettingsValidation.Numbers(p, "Perfil");
            Positive(p.LengthMm, "largo de perfil"); Positive(p.WebHeightMm, "altura del alma");
            Positive(p.ThicknessMm, "espesor"); Positive(p.BendRadiusMm, "radio de doblez");
            Positive(p.SlotGapMm, "separación libre"); Positive(p.SlotHeightMm, "altura de ranura");
            Positive(p.SlotReferenceLengthMm, "largo de referencia"); Positive(p.MarkScale, "escala de marca");
            if (p.TopAngleDeg <= 0 || p.TopAngleDeg >= 180 || p.BottomAngleDeg <= 0 || p.BottomAngleDeg >= 180)
                throw new InvalidOperationException("Perfil: los ángulos de doblez deben estar entre 0° y 180°.");
            if (p.MarkA && p.MarkB) throw new InvalidOperationException("Marca: selecciona una sola marca.");
            if (p.SlotBottomOffsetMm < ClearanceMm) throw new InvalidOperationException("Ranuras: conserva al menos 10 mm sobre la tangencia del doblez inferior.");
            ProfilePattern pattern;
            if (!String.IsNullOrEmpty(p.SlotCombination))
            {
                pattern = ChosenPattern(p, p.SlotCombination); pattern.Manual = true;
            }
            else
            {
                pattern = CalculateAutomatic(p);
                if ((p.MarkA || p.MarkB) && pattern.State == 4)
                {
                    pattern = ChosenPattern(p, "L"); pattern.State = 4;
                }
            }
            pattern.UpperSupportBottomYMm=UpperSupportBottomY(p);pattern.UpperSlotLimitYMm=pattern.UpperSupportBottomYMm-ClearanceMm;
            pattern.CutMm = Math.Max(0, p.SlotReferenceLengthMm - p.LengthMm);
            if (pattern.Combination == null)
            {
                var elements = new List<KeyValuePair<double,string>>();
                foreach (var slot in pattern.Slots) elements.Add(new KeyValuePair<double,string>(slot.CenterMm,"R"));
                if (pattern.LogoVisible) elements.Add(new KeyValuePair<double,string>(pattern.LogoCenterMm,"L"));
                elements.Sort(delegate(KeyValuePair<double,string> a,KeyValuePair<double,string> b){return a.Key.CompareTo(b.Key);});
                var tokens = new List<string>(); foreach(var element in elements) tokens.Add(element.Value);
                pattern.Combination = String.Join(",",tokens.ToArray());
            }
            if (pattern.Slots.Length > 0) pattern.LeftMarginMm = pattern.RightMarginMm = pattern.EndMarginMm;
            string detail = pattern.Description != null && pattern.Description.Contains("eliminación adicional") ? " · eliminación adicional para conservar separaciones y largos" : "";
            pattern.Description = (pattern.Manual ? "Elegido: " : "Automático: ") + CombinationLabel(pattern.Combination) + detail;
            if (pattern.Slots.Length == 0) pattern.Description += " · centrado, márgenes mínimos " + pattern.EndMarginMm.ToString("0.##") + " mm";
            if(pattern.Slots.Length>0&&pattern.CenterYMm<pattern.LowerTangentYMm+p.SlotBottomOffsetMm+p.SlotHeightMm/2-1e-7)pattern.Description+=" · altura limitada debajo del soporte";
            pattern.InputSignature = Signature(p);
            return pattern;
        }
        static ProfilePattern ChosenPattern(ProfileSettings p, string combination)
        {
            if (Array.IndexOf(Combinations(),combination) < 0) throw new InvalidOperationException("Distribución: combinación no admitida.");
            var tokens = combination.Split(','); int count = 0; bool logo = false;
            foreach (string token in tokens) { if (token == "R") count++; else logo = true; }
            if (logo && !p.MarkA && !p.MarkB) throw new InvalidOperationException("Distribución: selecciona una marca para usar Logo en la combinación.");
            double g=p.SlotGapMm,e=g/2,h=p.SlotHeightMm,r=h/2,w=LogoWidth(p),mh=LogoHeight(p);
            double length=count==0?0:(p.LengthMm-(count+(logo?1:0))*g-(logo?w:0))/count;
            if (count>0 && length<h+MinimumStraightMm-1e-8) throw new InvalidOperationException("Distribución: la combinación no cabe con esta altura y separación. Elige menos elementos; tu selección se conserva.");
            if (count==0 && p.LengthMm<g+w-1e-8) throw new InvalidOperationException("Logo: no cabe con su tamaño y los márgenes mínimos. Reduce la escala o cambia la combinación.");
            double lower=-p.WebHeightMm+(p.BendRadiusMm+p.ThicknessMm)*Math.Tan((180-p.BottomAngleDeg)*Math.PI/360);
            double upper=-ProfileBendGeometry.Tangent(p,true);
            double cy=count>0?LimitSlotCenter(p,lower,lower+p.SlotBottomOffsetMm+r,r):lower+p.SlotBottomOffsetMm+r;
            if (count>0 && cy+r>upper-ClearanceMm) throw new InvalidOperationException("Ranuras: altura/elevación invade el doblez superior.");
            if (logo && (cy+mh/2>upper-ClearanceMm || cy-mh/2<lower+ClearanceMm)) throw new InvalidOperationException("Logo: no cabe en la franja con 10 mm hacia los dobleces.");
            double margin=count==0?(p.LengthMm-w)/2:e,x=margin;
            var result=new ProfilePattern{LogoVisible=logo,Combination=combination,LogoWidthMm=w,LogoHeightMm=mh,CenterYMm=cy,
                GapMm=g,EndMarginMm=e,LengthMm=p.LengthMm,LowerTangentYMm=lower,LeftMarginMm=margin,RightMarginMm=margin};
            var slots=new List<ProfileSlotSpec>();
            for(int i=0;i<tokens.Length;i++) {
                if(tokens[i]=="R"){slots.Add(new ProfileSlotSpec{CenterMm=x+length/2,LengthMm=length,RadiusMm=r,CenterYMm=cy});x+=length;}
                else{result.LogoCenterMm=x+w/2;x+=w;}
                if(i<tokens.Length-1)x+=g;
            }
            if(Math.Abs(x-(p.LengthMm-margin))>1e-6)throw new InvalidOperationException("Distribución: error interno de cierre del patrón.");
            result.Slots=slots.ToArray(); return result;
        }
    }
}
