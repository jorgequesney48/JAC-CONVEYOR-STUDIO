using System;
using System.Collections.Generic;
namespace PerfilBandas {
    internal sealed class ProfileSlotSpec {
        public double CenterMm,LengthMm,RadiusMm,CenterYMm;
        public bool Functional=true;
        public ProfileSlotSpec Copy(){return (ProfileSlotSpec)MemberwiseClone();}
    }
    internal sealed class ProfilePattern {
        public ProfileSlotSpec[] Slots;
        public bool LogoVisible;
        public bool Manual;
        public string Combination;
        public double LeftMarginMm,RightMarginMm,CutMm,ProtectedLeftMm,ProtectedRightMm;
        [System.Web.Script.Serialization.ScriptIgnore] public string InputSignature;
        public double LogoCenterMm,CenterYMm,LogoWidthMm,LogoHeightMm,GapMm,EndMarginMm,LengthMm,LowerTangentYMm;
        public double UpperSupportBottomYMm,UpperSlotLimitYMm;
        public int State;
        public string Description;
        public ProfilePattern Copy(){var c=(ProfilePattern)MemberwiseClone();c.Slots=Array.ConvertAll(Slots,delegate(ProfileSlotSpec s){return s.Copy();});return c;}
    }
    internal static partial class ProfileSlotLayout {
        public const double ClearanceMm=10,MinimumStraightMm=2;
        static void Positive(double v,string name){if(Double.IsNaN(v)||Double.IsInfinity(v)||v<=0||v>100000)throw new InvalidOperationException("Ranuras: valor inválido en "+name+".");}
        internal static double UpperSupportBottomY(ProfileSettings p) {
            if(p.ResolvedUpperSupportBottomYMm.HasValue)return p.ResolvedUpperSupportBottomYMm.Value;
            var s=new SoporteSettings();return -p.SupportHoleYMm-s.EndPlateHoleYMm+Math.Min(0,s.ActualFlange1HeightMm-s.ActualFlange2HeightMm);
        }
        static double LimitSlotCenter(ProfileSettings p,double lower,double requested,double radius) {
            double ceiling=UpperSupportBottomY(p)-ClearanceMm;
            double resolved=Math.Min(requested,ceiling-radius);
            if(resolved-radius<lower+ClearanceMm-1e-7)throw new InvalidOperationException("Ranuras: no cabe esta altura debajo del soporte C y encima del doblez inferior con 10 mm de margen. Reduce la altura de ranura, aumenta el alma o revisa la altura del soporte.");
            return resolved;
        }
        internal static void ValidateBelowSupport(ProfileSettings p,ProfilePattern pattern) {
            double ceiling=UpperSupportBottomY(p)-ClearanceMm;
            foreach(var slot in pattern.Slots)if(slot.CenterYMm+slot.RadiusMm>ceiling+1e-7)throw new InvalidOperationException("Ranuras: el borde superior debe quedar al menos 10 mm debajo de la parte inferior del soporte C.");
        }
        public static double LogoWidth(ProfileSettings p){return (p.MarkA?LogoAGeometry.BaseWidthMm:70*Math.Cos(Math.PI/6))*p.MarkScale/100;}
        public static double LogoHeight(ProfileSettings p){return (p.MarkA?LogoAGeometry.BaseHeightMm:70)*p.MarkScale/100;}
        public static ProfileSlotSpec[] Resolve(ProfileSettings p,bool adapt,double leftOverlap,double rightOverlap) {
            var pattern=Calculate(p);
            if(p.AdaptFunctionalCuts) ProtectFunctionalGeometry(p,pattern,leftOverlap,rightOverlap);
            ValidateObstacles(p,pattern,leftOverlap,rightOverlap);
            pattern.ProtectedLeftMm=leftOverlap;pattern.ProtectedRightMm=rightOverlap;
            p.ResolvedPattern=pattern;p.ResolvedSlots=pattern.Slots;return pattern.Slots;
        }
        static ProfilePattern CalculateAutomatic(ProfileSettings p) {
            Positive(p.LengthMm,"largo de perfil");Positive(p.SlotGapMm,"separación libre");Positive(p.SlotHeightMm,"altura de ranura");
            Positive(p.SlotReferenceLengthMm,"largo de referencia");Positive(p.MarkScale,"escala de marca");
            if(Double.IsNaN(p.SlotBottomOffsetMm)||Double.IsInfinity(p.SlotBottomOffsetMm)||p.SlotBottomOffsetMm<ClearanceMm||p.SlotBottomOffsetMm>100000)
                throw new InvalidOperationException("Ranuras: el borde inferior debe conservar al menos 10 mm sobre la tangencia del doblez inferior.");
            double g=p.SlotGapMm,e=g/2,h=p.SlotHeightMm,r=h/2,w=LogoWidth(p);
            bool requested=p.MarkA||p.MarkB;
            double baseLength=(p.SlotReferenceLengthMm-(requested?5:4)*g-(requested?w:0))/4;
            if(baseLength<h+MinimumStraightMm)throw new InvalidOperationException("Ranuras: el patrón de referencia no admite cuatro ranuras. Reduce separación, altura o tamaño de logo.");
            double cut=Math.Max(0,p.SlotReferenceLengthMm-p.LengthMm);
            double a1=e,a2=e+baseLength+g,logoStart=e+2*baseLength+2*g;
            double a3=requested?logoStart+w+g:logoStart;
            int state=0;
            if(cut>=a1-1e-8)state=1;
            if(cut>=a2-1e-8)state=2;
            if(requested&&cut>=logoStart-1e-8)state=3;
            if(cut>=a3-1e-8)state=requested?4:3;
            int[] counts=requested?new[]{4,3,2,2,1}:new[]{4,3,2,1};
            int max=counts.Length-1,initial=state,n=0;double length=0;bool logo=false;
            for(;state<=max;state++) {
                if(requested&&state==4){var lone=ChosenPattern(p,"L");lone.State=4;return lone;}
                n=counts[state];logo=requested&&state<3;
                length=(p.LengthMm-(n+(logo?1:0))*g-(logo?w:0))/n;
                double minimum=n==1?h+MinimumStraightMm:Math.Max(h+MinimumStraightMm,baseLength);
                if(length>=minimum-1e-8)break;
            }
            if(state>max)throw new InvalidOperationException("Ranuras: el perfil necesita al menos "+(g+h+MinimumStraightMm).ToString("0.##")+" mm para conservar los márgenes y una ranura válida.");
            double lower=-p.WebHeightMm+(p.BendRadiusMm+p.ThicknessMm)*Math.Tan((180-p.BottomAngleDeg)*Math.PI/360);
            double cy=LimitSlotCenter(p,lower,lower+p.SlotBottomOffsetMm+r,r);
            double upper=-ProfileBendGeometry.Tangent(p,true);
            if(cy+r>upper-ClearanceMm)throw new InvalidOperationException("Ranuras: altura/elevación invade el doblez superior. Reduce altura o elevación.");
            double mh=LogoHeight(p);
            if(logo&&(cy+mh/2>upper-ClearanceMm||cy-mh/2<lower+ClearanceMm))throw new InvalidOperationException("Logo: no cabe en la franja con 10 mm hacia los dobleces. Ajusta escala o elevación.");
            var result=new ProfilePattern{LogoVisible=logo,LogoWidthMm=w,LogoHeightMm=mh,CenterYMm=cy,GapMm=g,EndMarginMm=e,LengthMm=p.LengthMm,LowerTangentYMm=lower,State=state};
            var slots=new List<ProfileSlotSpec>();double x=e;int logoAfter=n==4?2:1;
            for(int i=0;i<n;i++) {
                slots.Add(new ProfileSlotSpec{CenterMm=x+length/2,LengthMm=length,RadiusMm=r,CenterYMm=cy});x+=length;
                if(logo&&i+1==logoAfter){x+=g;result.LogoCenterMm=x+w/2;x+=w;}
                if(i<n-1)x+=g;
            }
            if(Math.Abs(x-(p.LengthMm-e))>1e-6)throw new InvalidOperationException("Ranuras: error interno de cierre del patrón.");
            if(p.SlotTrimFromRight){foreach(var slot in slots)slot.CenterMm=p.LengthMm-slot.CenterMm;result.LogoCenterMm=p.LengthMm-result.LogoCenterMm;slots.Sort(delegate(ProfileSlotSpec a,ProfileSlotSpec b){return a.CenterMm.CompareTo(b.CenterMm);});}
            result.Slots=slots.ToArray();
            result.Description=n+" ranuras"+(logo?" + logo":requested?" · logo omitido por recorte":" · sin marca")+(state>initial?" · eliminación adicional para conservar separaciones y largo de referencia":"");
            return result;
        }
        public static double DistanceToSlot(ProfileSlotSpec s,double x,double y) {
            double a=s.CenterMm-s.LengthMm/2+s.RadiusMm,b=s.CenterMm+s.LengthMm/2-s.RadiusMm;
            double dx=Math.Max(a-x,Math.Max(0,x-b));return Math.Max(0,Math.Sqrt(dx*dx+(y-s.CenterYMm)*(y-s.CenterYMm))-s.RadiusMm);
        }
        static double SlotRectangleDistance(ProfileSlotSpec s,double x,double y,double half) {
            double a=s.CenterMm-s.LengthMm/2+s.RadiusMm,b=s.CenterMm+s.LengthMm/2-s.RadiusMm;
            double dx=Math.Max(x-half-b,Math.Max(0,a-(x+half))),dy=Math.Max(0,Math.Abs(s.CenterYMm-y)-half);
            return Math.Max(0,Math.Sqrt(dx*dx+dy*dy)-s.RadiusMm);
        }
        public static void ValidateObstacles(ProfileSettings p,ProfilePattern pattern,double left,double right) {
            ValidateBelowSupport(p,pattern);
            foreach(var slot in pattern.Slots) {
                if(slot.CenterMm-slot.LengthMm/2<left+ClearanceMm||slot.CenterMm+slot.LengthMm/2>p.LengthMm-right-ClearanceMm)throw new InvalidOperationException("Ranuras: el margen de "+pattern.EndMarginMm.ToString("0.##")+" mm no protege el solape. Revisa placa o separación libre.");
                if(p.IncludeSupportHoles)foreach(double z in SupportHoleLayout.CentersMm(p))if(SlotRectangleDistance(slot,z,-p.SupportHoleYMm,p.SupportHoleSizeMm/2)<ClearanceMm-1e-6)throw new InvalidOperationException("Ranuras: un soporte C invade la abertura en Z="+z.ToString("0.##")+" mm. Revisa elevación o soportes.");
            }
            if(p.ResolvedRollerHoles!=null)foreach(var slot in pattern.Slots)foreach(var h in p.ResolvedRollerHoles)
                if(DistanceToSlot(slot,h.LocalZMm,h.YMm)<h.DiameterMm/2+h.SlotClearanceMm-1e-6)
                    throw new InvalidOperationException("Ranuras: falta separación junto al barreno de retorno en Z="+h.LocalZMm.ToString("0.##")+" mm. Activa adaptar recortes o revisa la altura del rodillo.");
            if(pattern.LogoVisible&&(pattern.LogoCenterMm-pattern.LogoWidthMm/2<left+ClearanceMm||pattern.LogoCenterMm+pattern.LogoWidthMm/2>p.LengthMm-right-ClearanceMm))throw new InvalidOperationException("Logo: invade el solape de una placa. Revisa placa o separación libre.");
            if(pattern.LogoVisible&&p.IncludeSupportHoles)foreach(double z in SupportHoleLayout.CentersMm(p)) {
                double half=p.SupportHoleSizeMm/2;
                double dx=Math.Max(0,Math.Abs(z-pattern.LogoCenterMm)-pattern.LogoWidthMm/2-half),dy=Math.Max(0,Math.Abs(-p.SupportHoleYMm-pattern.CenterYMm)-pattern.LogoHeightMm/2-half);
                if(Math.Sqrt(dx*dx+dy*dy)<ClearanceMm)throw new InvalidOperationException("Logo: invade el cuadrado de soporte en Z="+z.ToString("0.##")+" mm.");
            }
        }
        public static ProfilePattern PatternFor(ProfileSettings p){
            if(p==null)throw new ArgumentNullException("p");
            if(p.CurvedWeldedProfile){p.ResolvedPattern=new ProfilePattern{Slots=new ProfileSlotSpec[0],LogoVisible=false,LengthMm=p.LengthMm,Description="Alma curva con barrenos de soportes; cejas soldadas independientes"};p.ResolvedSlots=p.ResolvedPattern.Slots;return p.ResolvedPattern;}
            SettingsValidation.Numbers(p,"Perfil");
            if(p.ResolvedPattern==null||p.ResolvedPattern.InputSignature!=Signature(p)){
                double left=p.ResolvedPattern==null?0:p.ResolvedPattern.ProtectedLeftMm,right=p.ResolvedPattern==null?0:p.ResolvedPattern.ProtectedRightMm;
                Resolve(p,true,left,right);
            }
            ValidateBelowSupport(p,p.ResolvedPattern);return p.ResolvedPattern;
        }
        public static ProfileSlotSpec[] For(ProfileSettings p){return PatternFor(p).Slots;}
    }
}
