using System;
using System.Diagnostics;
using System.IO;

namespace PerfilBandas
{
    internal static class ProjectPaths
    {
        public static string GetDefaultPiecesFolder()
        {
            try
            {
                string sourceRoot = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ".."));
                if (File.Exists(Path.Combine(sourceRoot, "build.ps1")))
                {
                    string pieces = Path.Combine(sourceRoot, "piezas_ensamble");
                    Directory.CreateDirectory(pieces);
                    return pieces;
                }
            }
            catch { }

            try
            {
                string baseFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "piezas_ensamble");
                Directory.CreateDirectory(baseFolder);
                return baseFolder;
            }
            catch { }

            string docFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "PerfilBandas", "piezas_ensamble");
            Directory.CreateDirectory(docFolder);
            return docFolder;
        }

        public static void OpenFolder(string path)
        {
            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                Process.Start("explorer.exe", path);
            }
            catch { }
        }
    }
}
