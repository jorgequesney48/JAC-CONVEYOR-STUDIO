using System;
using System.Windows.Forms;
namespace PerfilBandas {
    internal sealed partial class CompleteBeltView {
        internal void SetRendererPreference(bool enabled) {
            WorldPreview.SetHardwarePreference(enabled);
            if(preview3D!=null&&!preview3D.IsDisposed)preview3D.Preview.SetHardwarePreference(enabled);
        }
        internal void ChangeRenderer(bool enabled) {
            SetRendererPreference(enabled);
            Changed();
            WorldPreview.Update();
            if(preview3D!=null&&!preview3D.IsDisposed)preview3D.Preview.Update();
            status.Text="Visor principal: "+WorldPreview.RendererDescription;
            if(preview3D!=null&&!preview3D.IsDisposed)status.Text+=" · Ampliado: "+preview3D.Preview.RendererDescription;
            status.ForeColor=DesignUi.Ink;
        }
    }
}