﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections.Generic;
using System.Windows.Forms;
namespace PerfilBandas {
internal sealed class ReturnOverviewDiagram:Control {
    internal ReturnOverviewGeometry Model;internal int View;internal int SelectedSupport;internal string Issue;internal event Action SelectionChanged;
    double zMin,zMax;RectangleF sideRect;
    public ReturnOverviewDiagram(){DoubleBuffered=true;BackColor=Color.FromArgb(242,246,246);ResizeRedraw=true;}
    protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(Model==null||!sideRect.Contains(e.Location)||Model.Supports.Count==0)return;double z=zMin+(e.X-sideRect.Left)/sideRect.Width*(zMax-zMin),best=Double.MaxValue;for(int i=0;i<Model.Supports.Count;i++){double d=Math.Abs(Model.Supports[i].Z-z);if(d<best){best=d;SelectedSupport=i;}}Invalidate();if(SelectionChanged!=null)SelectionChanged();}
    protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var font=new Font("Segoe UI",9))using(var bold=new Font("Segoe UI",10,FontStyle.Bold)){
        if(Model==null){g.DrawString(Issue??"Configura los soportes y las flechas.",font,Brushes.Firebrick,new RectangleF(16,16,Width-32,Height-32));return;}
        try{DrawSide(g,font,bold);DrawCross(g,font,bold);if(Issue!=null)g.DrawString("Diseño pendiente: consulta el panel de incidencias.",font,Brushes.Firebrick,16,Height-25);}catch(Exception ex){g.DrawString(ex.Message,font,Brushes.Firebrick,16,16);}
    }}
    void DrawSide(Graphics g,Font font,Font bold){
        var m=Model;double left=m.Driven.AxisZ-ReturnRollerLayout.BeltEnvelopeRadius(m.Driven)-30,right=m.MotorZ+ReturnRollerLayout.BeltEnvelopeRadius(m.Motor)+30;
        if(View==1)left=Math.Max(left,m.MotorZ-700);else if(View==2)right=Math.Min(right,m.Driven.AxisZ+700);
        zMin=left;zMax=right;double high=0,low=-100;foreach(var s in m.Supports){high=Math.Max(high,s.TopY+s.Profile.BeltThicknessMm+SlideRailGeometry.HeightMm);low=Math.Min(low,Math.Min(s.BaseY,s.TopY-s.Support.ActualFlange2HeightMm));}
        if(m.Plan!=null)foreach(var r in m.Plan.Holes)low=Math.Min(low,r.YMm-m.Settings.RollerDiameterMm/2);low=Math.Min(low,Math.Min(m.Driven.AxisY-ReturnRollerLayout.BeltEnvelopeRadius(m.Driven),m.Motor.AxisY-ReturnRollerLayout.BeltEnvelopeRadius(m.Motor)));
        high+=12;low-=Math.Max(30,(right-left)*.035);sideRect=new RectangleF(35,70,Math.Max(10,Width-70),Math.Max(80,Height*.43f-75));
        double scale=Math.Min(sideRect.Width/(right-left),sideRect.Height/(high-low));
        sideRect=new RectangleF(sideRect.Left+(float)((sideRect.Width-(right-left)*scale)/2),sideRect.Top+(float)((sideRect.Height-(high-low)*scale)/2),(float)((right-left)*scale),(float)((high-low)*scale));
        double sx=scale,sy=scale;Func<double,double,PointF> p=(z,y)=>new PointF(sideRect.Left+(float)((z-left)*sx),sideRect.Top+(float)((high-y)*sy));
        g.DrawString("LATERAL · "+m.Supports.Count+" soportes · "+(m.Plan==null?0:m.Plan.Holes.Count)+" rodillos previstos",bold,Brushes.Black,16,14);
        g.DrawString("Escala proporcional · clic en soporte para ver ranuras · Motriz / Conducido para acercar",font,Brushes.DimGray,16,39);
        var old=g.Save();g.SetClip(sideRect);
        for(int i=0;i<m.Supports.Count;i++){var station=m.Supports[i];using(var fill=new SolidBrush(station.Collision?Color.FromArgb(120,225,40,40):i==SelectedSupport?Color.FromArgb(150,0,130,155):Color.FromArgb(80,100,115,125)))using(var pen=new Pen(station.Collision?Color.Firebrick:Color.SlateGray,1))foreach(var box in station.Material){var a=p(box.Z0,box.Y1);var b=p(box.Z1,box.Y0);g.FillRectangle(fill,a.X,a.Y,Math.Max(1,b.X-a.X),Math.Max(1,b.Y-a.Y));g.DrawRectangle(pen,a.X,a.Y,Math.Max(1,b.X-a.X),Math.Max(1,b.Y-a.Y));}}
        foreach(var strip in m.AllBands){using(var fill=new SolidBrush(strip.IsUpper?Color.FromArgb(130,0,155,120):Color.FromArgb(115,25,120,215)))using(var pen=new Pen(strip.IsUpper?Color.SeaGreen:Color.RoyalBlue,1.5f)){var polygon=Array.ConvertAll(strip.Polygon,q=>p(q.X,q.Y));g.FillPolygon(fill,polygon);if(m.Curves.Contains(strip)){g.DrawLine(pen,polygon[0],polygon[1]);g.DrawLine(pen,polygon[2],polygon[3]);}else g.DrawPolygon(pen,polygon);}}
        if(m.Plan!=null){int n=0;foreach(var r in m.Plan.Holes){double radius=m.Settings.RollerDiameterMm/2;var a=p(r.GlobalZMm-radius,r.YMm+radius);using(var pen=new Pen(Color.FromArgb(135,95,30),2)){g.DrawEllipse(pen,a.X,a.Y,(float)(2*radius*sx),(float)(2*radius*sy));}g.DrawString((++n).ToString(),font,Brushes.SaddleBrown,p(r.GlobalZMm,r.YMm-radius-7));}}
        foreach(bool motor in new[]{false,true}){var shaft=motor?m.Motor:m.Driven;double z=motor?m.MotorZ:m.Driven.AxisZ,radius=ReturnRollerLayout.BeltEnvelopeRadius(shaft);var a=p(z-radius,shaft.AxisY+radius);using(var pen=new Pen(Color.DarkSlateGray,1.5f))g.DrawEllipse(pen,a.X,a.Y,(float)(2*radius*sx),(float)(2*radius*sy));}
        g.Restore(old);g.DrawString("Verde: banda superior · azul: retorno y abrazo completos, sin flecha · rojo: interferencia",font,Brushes.DimGray,16,sideRect.Bottom+10);
    }
    void DrawCross(Graphics g,Font font,Font bold){
        var m=Model;if(m.Supports.Count==0)return;SelectedSupport=Math.Max(0,Math.Min(SelectedSupport,m.Supports.Count-1));var station=m.Supports[SelectedSupport];var s=station.Support;
        float top=Height*.52f;g.DrawString("CORTE FRONTAL · soporte "+(SelectedSupport+1)+" · tramo "+(station.Section+1)+" · Z "+station.Z.ToString("0.##")+" mm",bold,station.Collision?Brushes.Firebrick:Brushes.Black,16,top);
        double high=station.TopY+SlideRailGeometry.HeightMm+station.Profile.BeltThicknessMm,low=Math.Min(station.BaseY,station.TopY-s.ActualFlange2HeightMm)-15;
        var strips=new List<ReturnBandStrip>();foreach(var strip in m.AllBands){var bounds=strip.HeightAt(station.Z);if(bounds!=null){strips.Add(strip);low=Math.Min(low,bounds[0]-15);high=Math.Max(high,bounds[1]+10);}}
        double scale=Math.Min((Width-80)/s.LengthMm,(Height-top-135)/(high-low));Func<double,double,PointF> p=(x,y)=>new PointF(40+(float)(x*scale),top+35+(float)((high-y)*scale));
        var cuts=UpperSupportGeometry.Cuts(s);double back=station.TopY-s.ActualFlange2HeightMm;
        foreach(double bottom in new[]{back,station.BaseY}){var contour=new List<PointF>{p(0,bottom),p(s.LengthMm,bottom),p(s.LengthMm,station.TopY)};for(int i=cuts.Count-1;i>=0;i--){var c=cuts[i];contour.Add(p(c[1],station.TopY));contour.Add(p(c[1],station.TopY-c[2]));contour.Add(p(c[0],station.TopY-c[2]));contour.Add(p(c[0],station.TopY));}contour.Add(p(0,station.TopY));using(var fill=new SolidBrush(Color.FromArgb(bottom==back?60:110,110,120,130)))using(var pen=new Pen(station.Collision?Color.Firebrick:Color.SlateGray,1.5f)){g.FillPolygon(fill,contour.ToArray());g.DrawPolygon(pen,contour.ToArray());}}
        if(station.HasGuides)foreach(var rail in SlideRailGeometry.Placements(s,station.Profile.LengthMm)){
            double depth=rail.Position==SlideRailPosition.Center?s.CenterSlotDepthMm:s.OuterSlotDepthMm;
            var contour=rail.Position==SlideRailPosition.Center?SlideRailGeometry.CenterSectionMm():SlideRailGeometry.SideSectionMm(rail.Position==SlideRailPosition.Right);
            var points=Array.ConvertAll(contour,q=>p(rail.FromLeftMm+q.X,station.TopY-depth+q.Y));
            using(var fill=new SolidBrush(Color.FromArgb(180,230,190,100)))using(var pen=new Pen(Color.SaddleBrown,1)){g.FillPolygon(fill,points);g.DrawPolygon(pen,points);}
        }
        foreach(var strip in strips){var bounds=strip.HeightAt(station.Z);var a=p(strip.X0,bounds[1]);var b=p(strip.X1,bounds[0]);using(var fill=new SolidBrush(strip.IsUpper?Color.FromArgb(160,0,155,120):Color.FromArgb(140,25,120,215)))g.FillRectangle(fill,a.X,a.Y,Math.Max(1,b.X-a.X),Math.Max(2,b.Y-a.Y));}
        if(m.Plan!=null)foreach(var roller in m.Plan.Holes){double d=Math.Abs(roller.GlobalZMm-station.Z),r=m.Settings.RollerDiameterMm/2;if(d<r){double h=Math.Sqrt(r*r-d*d);var a=p(m.Settings.SideClearanceMm,roller.YMm+h);var b=p(s.LengthMm-m.Settings.SideClearanceMm,roller.YMm-h);using(var pen=new Pen(Color.SaddleBrown,2))g.DrawRectangle(pen,a.X,a.Y,b.X-a.X,b.Y-a.Y);}}
        DrawDimension(g,font,p,m.VerticalDimension(station,true));DrawDimension(g,font,p,m.VerticalDimension(station,false));
        g.DrawString("Banda superior → metal: "+ReturnOverviewGeometry.DistanceText(station.UpperGap),font,station.UpperGap<-.01?Brushes.Firebrick:Brushes.SeaGreen,16,Height-94);
        g.DrawString("Retorno → metal: "+ReturnOverviewGeometry.DistanceText(station.ReturnGap)+" · distancias mínimas 3D",font,station.ReturnGap<-.01?Brushes.Firebrick:Brushes.RoyalBlue,16,Height-72);
        g.DrawString("Ranuras: "+cuts.Count+" · ancho "+s.SlotWidthMm.ToString("0.##")+" · profundidad lateral/central "+s.OuterSlotDepthMm.ToString("0.##")+" / "+s.CenterSlotDepthMm.ToString("0.##")+" mm",font,Brushes.DimGray,16,Height-42);
    }
    static void DrawDimension(Graphics g,Font font,Func<double,double,PointF> point,SupportBandDimension dimension){
        if(dimension==null)return;var a=point(dimension.X,dimension.SupportY);var b=point(dimension.X,dimension.BandY);Color color=dimension.Gap<-.01?Color.Firebrick:dimension.Upper?Color.SeaGreen:Color.RoyalBlue;
        using(var pen=new Pen(color,1.5f))using(var brush=new SolidBrush(color)){
            g.DrawLine(pen,a,b);foreach(var q in new[]{a,b}){g.DrawLine(pen,q.X-6,q.Y,q.X+6,q.Y);g.DrawLine(pen,q.X-3,q.Y+3,q.X+3,q.Y-3);}
            string label="Vertical "+ReturnOverviewGeometry.DistanceText(dimension.Gap);var size=g.MeasureString(label,font);float x=Math.Min(a.X+9,g.VisibleClipBounds.Right-size.Width-10),y=(a.Y+b.Y)/2-size.Height/2;
            g.FillRectangle(Brushes.White,x-2,y-1,size.Width+4,size.Height+2);g.DrawString(label,font,brush,x,y);
        }
    }
    internal static double Minimum(ReturnSupportStation s){return Math.Min(s.RollerGap,Math.Min(s.ReturnGap,s.UpperGap));}
}
}
