﻿using System;
using System.Collections.Generic;
namespace PerfilBandas {
internal static partial class ReturnRollerLayout {
    // Continuous interval reachability: no sampling grid for intermediate centres.
    static List<double[]> Merge(List<double[]> values) {
        values.Sort((a,b)=>a[0].CompareTo(b[0]));var result=new List<double[]>();
        foreach(var v in values){if(v[1]<v[0])continue;if(result.Count==0||v[0]>result[result.Count-1][1]+1e-8)result.Add(new[]{v[0],v[1]});else result[result.Count-1][1]=Math.Max(result[result.Count-1][1],v[1]);}return result;
    }
    static List<double[]> Intersect(List<double[]> a,List<double[]> b) {
        var result=new List<double[]>();int i=0,j=0;
        while(i<a.Count&&j<b.Count){double lo=Math.Max(a[i][0],b[j][0]),hi=Math.Min(a[i][1],b[j][1]);if(lo<=hi+1e-9)result.Add(new[]{lo,Math.Max(lo,hi)});if(a[i][1]<b[j][1])i++;else j++;}return Merge(result);
    }
    static double[] LineBox(double left,double bottom,double right,double top,double slope,double intercept) {
        double lo=left,hi=right;
        if(Math.Abs(slope)<1e-12){if(intercept<bottom||intercept>top)return null;}
        else {double a=(bottom-intercept)/slope,b=(top-intercept)/slope;lo=Math.Max(lo,Math.Min(a,b));hi=Math.Min(hi,Math.Max(a,b));}
        return lo<=hi?new[]{lo,hi}:null;
    }
    static void Box(List<double[]> intervals,double left,double bottom,double right,double top,double slope,double intercept) {var v=LineBox(left,bottom,right,top,slope,intercept);if(v!=null)intervals.Add(v);}
    static void Disk(List<double[]> intervals,double x,double y,double radius,double slope,double intercept) {
        double a=1+slope*slope,b=2*(slope*(intercept-y)-x),c=x*x+(intercept-y)*(intercept-y)-radius*radius,d=b*b-4*a*c;
        if(d>=0){double r=Math.Sqrt(d);intervals.Add(new[]{(-b-r)/(2*a),(-b+r)/(2*a)});}
    }
    static void RoundedBox(List<double[]> intervals,double left,double bottom,double right,double top,double radius,double slope,double intercept) {
        Box(intervals,left-radius,bottom,right+radius,top,slope,intercept);Box(intervals,left,bottom-radius,right,top+radius,slope,intercept);
        Disk(intervals,left,bottom,radius,slope,intercept);Disk(intervals,left,top,radius,slope,intercept);Disk(intervals,right,bottom,radius,slope,intercept);Disk(intervals,right,top,radius,slope,intercept);
    }
    static List<double[]> FreeCentres(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,double start,double end,double yStart,double yEnd,ReturnRollerSettings settings,bool ignoreSlots=false) {
        if(settings.KeyholeSeats){var round=settings.Copy();round.KeyholeSeats=false;var lower=FreeCentres(sections,profiles,offsets,start,end,yStart,yEnd,round,ignoreSlots);round.ShaftDiameterMm=18;var entry=FreeCentres(sections,profiles,offsets,start,end,yStart+ReturnRollerSeatGeometry.CenterDistance,yEnd+ReturnRollerSeatGeometry.CenterDistance,round,ignoreSlots);double centre=(ReturnRollerSeatGeometry.UpperJoin+ReturnRollerSeatGeometry.LowerJoin)/2;round.ShaftDiameterMm=2*Math.Sqrt(25+Math.Pow((ReturnRollerSeatGeometry.UpperJoin-ReturnRollerSeatGeometry.LowerJoin)/2,2));var neck=FreeCentres(sections,profiles,offsets,start,end,yStart+centre,yEnd+centre,round,ignoreSlots);return Intersect(Intersect(lower,entry),neck);}
        double slope=(yEnd-yStart)/(end-start),intercept=yStart-slope*start,margin=settings.HoleDiameterMm/2+settings.EdgeClearanceMm;
        var baseRanges=new List<double[]>();var blocked=new List<double[]>();
        for(int i=0;i<profiles.Length;i++) {
            if(sections[i].IsCurved)continue;
            var p=profiles[i];double o=offsets[i],top=-(p.BendRadiusMm+p.ThicknessMm)*Math.Tan((180-p.TopAngleDeg)*Math.PI/360),bottom=-p.WebHeightMm+(p.BendRadiusMm+p.ThicknessMm)*Math.Tan((180-p.BottomAngleDeg)*Math.PI/360);
            double joint=settings.HoleDiameterMm/2+Math.Max(100,settings.EdgeClearanceMm);double lo=o+joint,hi=o+p.LengthMm-joint;
            if(ShaftPlateGeometry.Active(sections[i])){double overlap=ShaftPlateGeometry.EffectiveOverlap(sections[i],p);if(sections[i].Type==BeltSectionType.Conducido)lo=Math.Max(lo,o+overlap+margin);if(sections[i].Type==BeltSectionType.Motriz)hi=Math.Min(hi,o+p.LengthMm-overlap-margin);}
            var valid=LineBox(Math.Max(start,lo),bottom+margin,Math.Min(end,hi),top-margin,slope,intercept);if(valid!=null)baseRanges.Add(valid);
            if(p.IncludeSupportHoles)foreach(double z in SupportHoleLayout.CentersMm(p)){double r=p.SupportHoleSizeMm/2;RoundedBox(blocked,o+z-r,-p.SupportHoleYMm-r,o+z+r,-p.SupportHoleYMm+r,margin,slope,intercept);RoundedBox(blocked,o+z-r,-p.WebHeightMm+p.SupportHoleYMm-r,o+z+r,-p.WebHeightMm+p.SupportHoleYMm+r,margin,slope,intercept);}
            var pattern=ProfileSlotLayout.PatternFor(p);
            foreach(var s in pattern.Slots){if(ignoreSlots&&pattern.Slots.Length>0&&(Object.ReferenceEquals(s,pattern.Slots[0])||Object.ReferenceEquals(s,pattern.Slots[pattern.Slots.Length-1])))continue;double a=o+s.CenterMm-s.LengthMm/2+s.RadiusMm,b=o+s.CenterMm+s.LengthMm/2-s.RadiusMm,r=s.RadiusMm+settings.HoleDiameterMm/2+settings.SlotClearanceMm;Box(blocked,a,s.CenterYMm-r,b,s.CenterYMm+r,slope,intercept);Disk(blocked,a,s.CenterYMm,r,slope,intercept);Disk(blocked,b,s.CenterYMm,r,slope,intercept);}
            if(pattern.LogoVisible)RoundedBox(blocked,o+pattern.LogoCenterMm-pattern.LogoWidthMm/2,pattern.CenterYMm-pattern.LogoHeightMm/2,o+pattern.LogoCenterMm+pattern.LogoWidthMm/2,pattern.CenterYMm+pattern.LogoHeightMm/2,settings.HoleDiameterMm/2+Math.Max(settings.EdgeClearanceMm,ProfileSlotLayout.ClearanceMm),slope,intercept);
        }
        var free=Merge(baseRanges);
        foreach(var forbidden in Merge(blocked)){var next=new List<double[]>();foreach(var f in free){if(forbidden[1]<f[0]||forbidden[0]>f[1])next.Add(f);else{if(forbidden[0]>f[0])next.Add(new[]{f[0],forbidden[0]-1e-5});if(forbidden[1]<f[1])next.Add(new[]{forbidden[1]+1e-5,f[1]});}}free=next;}
        return free;
    }
    internal static List<double> PlaceInFreeIntervals(List<double[]> free,double start,double end,double minimum,double maximum,double preferredPitch=0) {
        free=Merge(free);if(Intersect(free,new List<double[]>{new[]{start,start}}).Count==0||Intersect(free,new List<double[]>{new[]{end,end}}).Count==0)return null;
        var layers=new List<List<double[]>>{new List<double[]>{new[]{start,start}}};
        int limit=Math.Min(1000,(int)Math.Floor((end-start)/minimum));
        var counts=new List<int>();for(int i=1;i<=limit;i++)counts.Add(i);
        if(preferredPitch>0)counts.Sort((a,b)=>Math.Abs((end-start)/a-preferredPitch).CompareTo(Math.Abs((end-start)/b-preferredPitch)));
        foreach(int n in counts) {
            if(preferredPitch>0){layers=PitchLayers(free,start,end,n,minimum,maximum);if(layers==null)continue;}
            else {
            var expanded=new List<double[]>();foreach(var r in layers[n-1])expanded.Add(new[]{r[0]+minimum,Math.Min(end,r[1]+maximum)});
            var reachable=Intersect(Merge(expanded),free);if(reachable.Count==0)return null;layers.Add(reachable);
            if(Intersect(reachable,new List<double[]>{new[]{end,end}}).Count==0)continue;
            }
            // Choose a feasible roller count, then minimise the largest
            // pitch deviation from its ideal equal spacing. Feasibility covers
            // every free interval, so slot avoidance cannot bias one end.
            double idealPitch=(end-start)/n,low=0,high=Math.Max(idealPitch-minimum,maximum-idealPitch);
            var balanced=layers;
            for(int iteration=0;iteration<35&&high-low>1e-6;iteration++){
                double deviation=(low+high)/2;
                var trial=PitchLayers(free,start,end,n,Math.Max(minimum,idealPitch-deviation),Math.Min(maximum,idealPitch+deviation));
                if(trial==null)low=deviation;else{high=deviation;balanced=trial;}
            }
            minimum=Math.Max(minimum,idealPitch-high);maximum=Math.Min(maximum,idealPitch+high);layers=balanced;
            var positions=new List<double>{end};double current=end;
            for(int k=n-1;k>=0;k--){var previous=Intersect(layers[k],new List<double[]>{new[]{current-maximum,current-minimum}});double ideal=start+(end-start)*k/n,best=0,error=Double.MaxValue;foreach(var r in previous){double value=Math.Max(r[0],Math.Min(r[1],ideal)),distance=Math.Abs(value-ideal);if(distance<error){error=distance;best=value;}}if(previous.Count==0)return null;positions.Add(best);current=best;}
            positions.Reverse();return positions;
        }
        return null;
    }
    static List<List<double[]>> PitchLayers(List<double[]> free,double start,double end,int count,double minimum,double maximum){
        var layers=new List<List<double[]>>{new List<double[]>{new[]{start,start}}};
        for(int k=1;k<=count;k++){
            var expanded=new List<double[]>();foreach(var r in layers[k-1])expanded.Add(new[]{r[0]+minimum,Math.Min(end,r[1]+maximum)});
            var reachable=Intersect(Merge(expanded),free);if(reachable.Count==0)return null;layers.Add(reachable);
        }
        return Intersect(layers[count],new List<double[]>{new[]{end,end}}).Count==0?null:layers;
    }
    static List<double> EndDistances(double preferred,double low,double high) {
        var values=new List<double>{preferred};for(double d=low;d<=high;d+=1)if(Math.Abs(d-preferred)>1e-8)values.Add(d);
        values.Sort((a,b)=>Math.Abs(a-preferred).CompareTo(Math.Abs(b-preferred)));return values;
    }
    static List<double> FeasibleEndDistances(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout shaft,double axisZ,ReturnRollerSettings settings,bool motor,bool interrupt){
        double low=motor?ReturnRollerRules.MotorMinMm:ReturnRollerRules.DrivenMinMm,high=motor?ReturnRollerRules.MotorMaxMm:ReturnRollerRules.DrivenMaxMm,preferred=motor?settings.FirstMotorFromShaftMm:settings.FirstFromShaftMm;
        double start=motor?axisZ-high:axisZ+low,end=motor?axisZ-low:axisZ+high,y0=CenterY(settings,shaft,motor?high:low),y1=CenterY(settings,shaft,motor?low:high);
        var free=FreeCentres(sections,profiles,offsets,start,end,y0,y1,settings,interrupt);var values=EndDistances(preferred,low,high);
        foreach(var zone in free){double a=motor?axisZ-zone[1]:zone[0]-axisZ,b=motor?axisZ-zone[0]:zone[1]-axisZ;values.Add(a);values.Add(b);values.Add((a+b)/2);values.Add(Math.Max(a,Math.Min(b,preferred)));}
        values.Sort((a,b)=>Math.Abs(a-preferred).CompareTo(Math.Abs(b-preferred)));return values;
    }
    static ReturnRollerHole AutoHole(double z,double y,IList<BeltSectionSpec> sections,double[] offsets,ReturnRollerSettings settings,string role,bool interrupt=false) {
        int i=0;while(i<sections.Count-1&&z>=offsets[i+1])i++;
        return new ReturnRollerHole{SectionIndex=i,GlobalZMm=z,LocalZMm=z-offsets[i],Keyhole=settings.KeyholeSeats,YMm=y,DiameterMm=settings.HoleDiameterMm,JointMarginMm=100,SlotClearanceMm=settings.SlotClearanceMm,PreserveCuts=!interrupt||(role!="Primero conducido"&&role!="Primero motriz"&&role!="Salida de curva"&&role!="Antes de curva · 150 mm"),Role=role};
    }
    static ReturnRollerPlan BuildAutomatic(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout first,ShaftPlateLayout last,ReturnRollerSettings settings) {
        var original=BuildAutomaticPass(sections,profiles,offsets,first,last,settings,false);if(original!=null)return original;
        var split=settings.AllowSlotInterruption?BuildAutomaticPass(sections,profiles,offsets,first,last,settings,true):null;if(split!=null)return split;
        throw new InvalidOperationException("Rodillos: no se encontró reparto válido con 100 mm libres en extremos y el margen elegido junto a ranuras. Para admitir cortes, activa Interrumpir solo la primera ranura. El logo se conserva; revisa largo, sprocket, abrazo o paso del manual.");
    }
    static ReturnRollerPlan BuildAutomaticPass(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout first,ShaftPlateLayout last,ReturnRollerSettings settings,bool interrupt) {
        if(BeltLinePlan.TotalLengthMm(sections)<=ReturnRollerRules.MinimumConveyorMm)throw new InvalidOperationException("Rodillos: esta referencia del manual aplica a transportadores superiores a 2 metros.");
        if(settings.HeightMode!=1)throw new InvalidOperationException("Rodillos: selecciona Abrazo y recorrido de banda para verificar el criterio de 180–210° del manual.");
        double minimum=settings.RollerDiameterMm+2*settings.EdgeClearanceMm,maximum=settings.AutoCatenary?settings.TargetPitchMm:Math.Min(settings.TargetPitchMm,settings.CatenarySpanMm-ReturnRollerRules.CatenaryExtraMm);
        if(maximum<minimum||settings.CatenarySpanMm<minimum)throw new InvalidOperationException("Rodillos: la catenaria debe ser mayor que los intervalos normales y permitir separar los cuerpos.");
        var driven=new List<ReturnRollerHole>();var motor=new List<ReturnRollerHole>();
        foreach(double d in FeasibleEndDistances(sections,profiles,offsets,first,first.AxisZ,settings,false,interrupt)){var h=AutoHole(first.AxisZ+d,CenterY(settings,first,d),sections,offsets,settings,"Primero conducido",interrupt);if(Conflict(sections[h.SectionIndex],profiles[h.SectionIndex],h,settings.EdgeClearanceMm,true,interrupt)==null)driven.Add(h);}
        foreach(double d in FeasibleEndDistances(sections,profiles,offsets,last,offsets[offsets.Length-1]+last.AxisZ,settings,true,interrupt)){var h=AutoHole(offsets[offsets.Length-1]+last.AxisZ-d,CenterY(settings,last,d),sections,offsets,settings,"Primero motriz",interrupt);if(Conflict(sections[h.SectionIndex],profiles[h.SectionIndex],h,settings.EdgeClearanceMm,true,interrupt)==null)motor.Add(h);}
        foreach(var a in driven)foreach(var m in motor) {
            var catenaries=new List<double>{settings.CatenarySpanMm};
            if(settings.AutoCatenary){
                // Candidate second centres come from exact free-zone boundaries and the preferred span.
                var secondZones=FreeCentres(sections,profiles,offsets,a.GlobalZMm+minimum,m.GlobalZMm-minimum-ReturnRollerRules.CatenaryExtraMm,m.YMm,m.YMm,settings,interrupt);
                foreach(var r in secondZones){double preferred=m.GlobalZMm-settings.CatenarySpanMm;catenaries.Add(m.GlobalZMm-Math.Max(r[0],Math.Min(r[1],preferred)));catenaries.Add(m.GlobalZMm-r[0]);catenaries.Add(m.GlobalZMm-r[1]);}
                catenaries.Sort((x,y)=>Math.Abs(x-settings.CatenarySpanMm).CompareTo(Math.Abs(y-settings.CatenarySpanMm)));
            }
            foreach(double catenary in catenaries){
            if(catenary>ReturnRollerRules.NormalMaxMm+ReturnRollerRules.CatenaryExtraMm+1e-6)continue;
            maximum=Math.Min(settings.TargetPitchMm,catenary-ReturnRollerRules.CatenaryExtraMm);if(maximum<minimum)continue;
            double end=m.GlobalZMm-catenary;if(end-a.GlobalZMm<minimum)continue;
            var b=AutoHole(end,LowerY(end,m.YMm,profiles,offsets,settings),sections,offsets,settings,"Segundo motriz / catenaria",interrupt);if(Conflict(sections[b.SectionIndex],profiles[b.SectionIndex],b,settings.EdgeClearanceMm,true,interrupt)!=null)continue;
            var free=FreeLoweredRun(sections,profiles,offsets,a.GlobalZMm,end,a.YMm,b.YMm,settings,interrupt,a.Role,b.Role);
            var positions=PlaceInFreeIntervals(free,a.GlobalZMm,end,minimum,maximum);if(positions==null)continue;
            var plan=new ReturnRollerPlan{ReferencePitchMm=catenary-ReturnRollerRules.CatenaryExtraMm,ResolvedCatenaryMm=catenary,AutomaticSpacing=true,SlotsInterrupted=interrupt,FirstDrivenZMm=a.GlobalZMm,FirstMotorZMm=m.GlobalZMm,SecondMotorZMm=end,CenterY=a.YMm,FirstMotorY=m.YMm,RunningDrivenY=first.RunningY,DrivenDistanceMm=a.GlobalZMm-first.AxisZ,MotorDistanceMm=offsets[offsets.Length-1]+last.AxisZ-m.GlobalZMm};
            bool valid=true;
            for(int k=0;k<positions.Count;k++){double z=positions[k],y=a.YMm+(b.YMm-a.YMm)*(z-a.GlobalZMm)/(end-a.GlobalZMm);if(k>0&&k<positions.Count-1)y=LowerY(z,Math.Min(a.YMm,b.YMm),profiles,offsets,settings);var h=AutoHole(z,y,sections,offsets,settings,k==0?a.Role:k==positions.Count-1?b.Role:"Retorno",interrupt);if(Conflict(sections[h.SectionIndex],profiles[h.SectionIndex],h,settings.EdgeClearanceMm,true,interrupt)!=null){valid=false;break;}plan.Holes.Add(h);}
            if(!valid)continue;plan.Holes.Add(m);plan.MinimumNormalPitchMm=Double.MaxValue;
            for(int k=1;k<plan.Holes.Count-1;k++){double gap=plan.Holes[k].GlobalZMm-plan.Holes[k-1].GlobalZMm;plan.MinimumNormalPitchMm=Math.Min(plan.MinimumNormalPitchMm,gap);plan.MaximumNormalPitchMm=Math.Max(plan.MaximumNormalPitchMm,gap);}
            plan.UniformPitchMm=Math.Abs(plan.MaximumNormalPitchMm-plan.MinimumNormalPitchMm)<1e-6?plan.MaximumNormalPitchMm:0;
            for(int i=0;i<profiles.Length;i++)Apply(profiles[i],i,sections[i],plan);return plan;
            }
        }
        return null;
    }
}
}
