﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal sealed partial class CompleteBeltView
    {
        internal ReturnRollerSettings rollers=new ReturnRollerSettings();
        private DataGridView rollerTable;
        private bool rollerAccessPreview=false;
        private void BuildRollerEditor()
        {
            if(CurveRoute.HasCurves(sections)){Note("Retorno por rectos y curvas", "Los rectos conservan rodillos y alojamientos; el centro del último rodillo queda a 150 mm antes de cada curva. Las curvas llevan dos pletinas inferiores laterales ranuradas y una central, prolongadas tangencialmente hacia los rectos hasta 10 mm antes de la superficie del rodillo. La corona de cada rodillo de transición queda por defecto 10 mm arriba de la superficie de apoyo de esas pletinas, ajustable con la barra; la cubierta lateral se mecaniza con una entrada gradual para dejar pasar la banda. La catenaria queda dentro del grupo de rectos del motriz.");Action("Abrir manual de curvas",OpenCurveManual);}
            Note("Rodillos de retorno · banda completa", "El reparto atraviesa las juntas entre rectos y se interrumpe en las curvas. El alojamiento se repite en ambos laterales; el centro inferior es el centro del eje.");
            if(!CurveRoute.HasCurves(sections))Action("Explorar abrazo y retorno…",OpenRollerExplorer);
            Action("Ver imagen del manual guardada",delegate{ReturnRollerRules.ShowReference(this);});
            Note("Criterio del manual · > 2 m", "L ≤ 1000 mm. Primera catenaria = L + 200 mm. Con pasos variables, todos quedan ≤ L. Abrazo 180–210°.");
            Choice("Vista", "Revisa los barrenos del tramo o el reparto global de rodillos.",new[]{"Barrenos del tramo","Distribución completa"},rollerAccessPreview?"Barrenos del tramo":"Distribución completa",delegate(string v){rollerAccessPreview=v=="Barrenos del tramo";BeginInvoke((Action)delegate{ShowCategory(category);});});
            Toggle("Generar alojamientos para ejes de rodillos", "Requiere las placas de flecha activadas en ambos extremos. Se mantiene el espacio de catenaria del motriz.", rollers.Enabled,delegate(bool v){rollers.Enabled=v;});
            Toggle("Alojamiento de inserción con eje tableado", "Entrada R9, asiento R6.35, 10 mm entre caras y 15.35 mm entre centros. Eje Ø12.7 mm con extremos tableados.",rollers.KeyholeSeats,v=>{rollers.KeyholeSeats=v;if(v){rollers.ShaftDiameterMm=12.7;rollers.HoleAllowanceMm=0;}BeginInvoke((Action)delegate{ShowCategory(category);});});
            Toggle("Incluir rodillos y ejes como sólidos","Representación simplificada en visor y SolidWorks. Retención y cojinetes requieren su referencia real.",rollers.PhysicalRollers,v=>rollers.PhysicalRollers=v);
            Toggle("Interrumpir solo la primera ranura", "Solo la primera desde el extremo afectado por el rodillo de abrazo o transición. Las demás se conservan completas, incluso con esta opción activada.",rollers.AllowSlotInterruption,v=>rollers.AllowSlotInterruption=v);
            RollerSlider("Separación alojamiento–ranura", "Margen entre los alojamientos y las ranuras. Con curvas se buscan posiciones libres a la altura común del retorno; en bandas rectas define la altura bajo las ranuras. Los rodillos de abrazo conservan su tangencia.","SlotClearanceMm",0,50);
            if(CurveRoute.HasCurves(sections))RollerSlider("Nivel común de rodillos sobre nylamid de curva", "Las pletinas y sus soportes inferiores bajan juntos. El descenso se limita antes del labio inferior; se mantienen 10 mm entre el extremo de la pletina y el cuerpo del rodillo.","CurveRollerRiseMm",0,50);
            Note("Reparto automático", "Con curvas, todos los rodillos de retorno, incluido el segundo motriz, quedan al mismo nivel que los de entrada/salida de curva: 10 mm sobre el nylamid por defecto. Los primeros junto a los sprockets conservan el abrazo calculado; las transiciones conservan la diferencia de altura elegida respecto al nylamid.");
            N("Separación lateral del rodillo · mm","Espacio entre extremo del cuerpo y cara interna del perfil, en ambos lados.",rollers,"SideClearanceMm",0,100);
            N("Saliente exterior del eje · mm","Medido desde la cara exterior del perfil. Reserva para retención; no sustituye seleccionar su sistema real.",rollers,"ShaftProjectionMm",0,100);
            if(!rollers.KeyholeSeats){N("Diámetro de eje · mm", "Media pulgada = 12.7 mm.",rollers,"ShaftDiameterMm",3,50);
            N("Holgura de ajuste · mm", "Se suma al diámetro del eje; ajusta al proceso de perforación.",rollers,"HoleAllowanceMm",0,5);}else Note("Eje y asiento según referencia", "Eje Ø12.7 mm, tableado a 10 mm en ambos extremos. Entrada R9 mm, asiento R6.35 mm y centros a 15.35 mm. Cotas nominales de la imagen.");
            N("Diámetro exterior del rodillo · mm", "Tu croquis: 1.50 in = 38.1 mm. La imagen guardada no establece un diámetro; usa el requerido para tu banda.",rollers,"RollerDiameterMm",15,150);
            N("Flecha conducida a primer rodillo · mm", "Entre centros. El fabricante indica 200–500 mm; tu ejemplo usa 250 mm.",rollers,"FirstFromShaftMm",200,500);
            N("Flecha motriz a primer rodillo · mm", "Entre centros hacia el interior de la banda. Rango del fabricante: 200–300 mm.",rollers,"FirstMotorFromShaftMm",200,300);
            N("Paso máximo normal · mm", "Ejemplo: 800 mm. El modo automático admite pasos variables, limitados por este máximo y por L del manual (≤1000 mm).",rollers,"TargetPitchMm",100,1000);
            if(rollers.SlotConflictMode==2) Toggle("Calcular longitud de catenaria", "Busca una separación libre próxima al valor indicado, con L ≤1000 mm y catenaria = L + 200 mm. Todos los pasos normales quedan ≤L. Desactívalo para exigir la longitud exacta.",rollers.AutoCatenary,v=>rollers.AutoCatenary=v);
            Note("Curvatura y caída de banda", "La banda abraza los rodillos y forma una catenaria entre sus contactos. La caída se mide verticalmente desde la cuerda entre contactos hasta la banda en el punto medio. 10 y 50 mm son valores provisionales del modelo: no son una recomendación aprobada para E925. En las curvas se mantiene el apoyo continuo; la entrada al rodillo conserva su altura.");
            N("Caída entre rodillos normales · mm", "0 = retorno por tangentes. Ajusta según la medida real y el criterio del fabricante. No calcula tensión.",rollers,"NormalSagMm",0,300);
            N("Caída de catenaria junto al motriz · mm", "Aplica entre primer y segundo rodillo motriz. La separación entre centros es otra medida; no determina por sí sola la caída.",rollers,"CatenarySagMm",0,300);
            N("Primer a segundo rodillo motriz · mm", "1,200 mm en el ejemplo. Es una preferencia si activas calcular longitud de catenaria; de otro modo es un intervalo exacto.",rollers,"CatenarySpanMm",200,1200);
            N("Abrazo de sprocket · °", "La altura sigue automáticamente el sprocket y el espesor de banda. Usa Explorar abrazo y retorno para ajustar el ángulo entre 180° y 210°.",rollers,"WrapAngleDeg",180,210);
            N("Material junto a dobleces y fijaciones · mm", "Margen adicional alrededor del alojamiento. Los extremos conservan 100 mm y las ranuras conservan la separación ajustada.",rollers,"EdgeClearanceMm",0,25);
            Note("Posiciones de todos los rodillos", "Z global: distancia acumulada por el centro del recorrido. Z local: desde el inicio del tramo recto. Y: altura respecto al doblez superior. Los pasos se muestran dentro de cada grupo de rectos.");
            rollerTable=new DataGridView {Height=240,Dock=DockStyle.Top,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,RowHeadersVisible=false,
                AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.White,BorderStyle=BorderStyle.None};
            foreach(string header in new[]{"Tramo","Z global","Z local","Y","Función","Paso anterior"}) rollerTable.Columns.Add(header,header);
            rollerTable.Columns[4].FillWeight=180;Row(rollerTable);
            Note("Alcance de este apartado", "Genera alojamientos pasantes en ambos perfiles, independientes de las ranuras. La curva es esquemática. La altura real se muestra en la tabla y el visor 3D; rodillos y ejes sólidos se incluyen al activar su opción.");
        }
        private void RollerSlider(string title,string hint,string field,int minimum,int maximum){
            var member=typeof(ReturnRollerSettings).GetField(field);
            var value=new Label{AutoSize=true,Dock=DockStyle.Top,Text=title+": "+F((double)member.GetValue(rollers))+" mm"};Row(value);
            var slider=new TrackBar{Name=field+"Slider",Minimum=minimum,Maximum=maximum,Value=(int)Math.Round(Math.Max(minimum,Math.Min(maximum,(double)member.GetValue(rollers)))),TickFrequency=5,SmallChange=1,LargeChange=5,Height=45};
            var update=new Timer{Interval=100};update.Tick+=delegate{update.Stop();Changed(10);};
            slider.ValueChanged+=delegate{member.SetValue(rollers,(double)slider.Value);value.Text=title+": "+slider.Value+" mm";if(!update.Enabled)update.Start();};
            slider.Disposed+=delegate{update.Dispose();};Field(title,hint,slider);
        }
        private void RefreshRollerSummary(ReturnRollerPlan plan)
        {
            if(category!=10) return;
            if(!rollers.Enabled) {derived.Text="RODILLOS DESACTIVADOS\nConfigura las referencias y activa los barrenos para ver el reparto.";return;}
            if(plan==null) {derived.Text="RODILLOS / CONFIGURACIÓN PENDIENTE\nCorrige la referencia indicada en el estado de la banda.";return;}
            int count=plan.Holes.FindAll(delegate(ReturnRollerHole h){return h.SectionIndex==selected;}).Count;
            derived.Text="RETORNO / REPARTO GLOBAL\n"+plan.Holes.Count+" rodillos · "+count+" en este tramo"
                +"\nPaso normal: "+(plan.AutomaticSpacing?F(plan.MinimumNormalPitchMm)+"–"+F(plan.MaximumNormalPitchMm):F(plan.UniformPitchMm))+" mm · catenaria: "+F(plan.AutomaticSpacing?plan.ResolvedCatenaryMm:rollers.CatenarySpanMm)
                +"\nCuerpo Ø"+F(rollers.RollerDiameterMm)+" mm · eje Ø"+F(rollers.ShaftDiameterMm)+" mm"
                +"\nCentro conducido bajo nylamid: "+F(plan.RunningDrivenY-plan.CenterY)+" mm"
                +"\n"+(rollers.KeyholeSeats?"Alojamiento R9 / R6.35 · caras 10 mm":"Barreno Ø"+F(rollers.HoleDiameterMm)+" mm")+" · abrazo: "+(rollers.HeightMode==1 ? F(rollers.WrapAngleDeg)+"°" : "manual");
            derived.Text+="\nCaída del modelo: normal "+F(rollers.NormalSagMm)+" mm · motriz "+F(rollers.CatenarySagMm)+" mm (por confirmar)";
            if(rollers.ResolvedNormalYMm.HasValue)derived.Text+="\nAltura común de rodillos normales: "+F(rollers.ResolvedNormalYMm.Value)+" mm";
            derived.Text+="\nSeparación a ranuras: "+F(rollers.SlotClearanceMm)+" mm · elevación en curvas: "+F(rollers.CurveRollerRiseMm)+" mm";
            if(plan.SlotsInterrupted)derived.Text+="\nSolo primera ranura desde el extremo afectado; las demás y el logo se conservan.";
            if(plan.AutomaticSpacing)derived.Text+="\nManual: L = "+F(plan.ReferencePitchMm)+" mm · catenaria = L + 200 mm";
            if(plan.AutomaticSpacing)derived.Text+="\nFlecha a primer rodillo: conducido "+F(plan.DrivenDistanceMm)+" · motriz "+F(plan.MotorDistanceMm)+" mm";
            if(rollerTable!=null && !rollerTable.IsDisposed) {
                rollerTable.Rows.Clear();
                for(int k=0;k<plan.Holes.Count;k++){var h=plan.Holes[k];rollerTable.Rows.Add(h.SectionIndex+1,F(h.GlobalZMm),F(h.LocalZMm),F(h.YMm),h.Role,k==0||!ReturnRollerLayout.SameStraightRun(sections,plan.Holes[k-1].SectionIndex,h.SectionIndex)?"—":F(h.GlobalZMm-plan.Holes[k-1].GlobalZMm));}
            }
        }
    }

    internal sealed class ReturnRollerPreview : Control
    {
        public ReturnRollerPlan Plan;
        public ReturnRollerSettings Settings;
        public System.Collections.Generic.IList<BeltSectionSpec> Sections;
        public int Selected;
        public ReturnRollerPreview() {DoubleBuffered=true;ResizeRedraw=true;BackColor=Color.White;}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
            if(Width<120 || Height<120) return;
            using(var font=new Font("Segoe UI",9)) using(var bold=new Font("Segoe UI Semibold",10)) {
                if(Settings==null || !Settings.Enabled || Plan==null || Plan.Holes.Count==0) {
                    g.DrawString("Activa y configura los rodillos\npara ver su distribución.",font,Brushes.DimGray,12,25);return;
                }
                var frames=CurveRoute.Frames(Sections,Sections[0].Support??new SoporteSettings());double total=0,offset=0;foreach(var frame in frames)total+=frame.Length;
                float left=28,right=Width-28,top=65,center=Height*.50f;
                Func<double,float> x=delegate(double z){return left+(float)(z/total)*(right-left);};
                using(var rail=new Pen(DesignUi.Primary,3))g.DrawLine(rail,left,top,right,top);
                g.DrawString("BANDA COMPLETA / retorno",bold,Brushes.Black,12,8);
                using(var line=new Pen(Color.FromArgb(184,199,211),1){DashStyle=DashStyle.Dash})
                    for(int i=0;i<Sections.Count;i++) {
                        float a=x(offset),b=x(offset+frames[i].Length);
                        if(Sections[i].IsCurved)using(var guide=new Pen(Color.FromArgb(175,106,26),5))g.DrawLine(guide,a,center,b,center);
                        if(i==Selected) using(var fill=new SolidBrush(Color.FromArgb(28,0,150,110)))g.FillRectangle(fill,a,top,b-a,center-top+32);
                        g.DrawLine(line,a,top-10,a,center+45);g.DrawString((i+1).ToString("00")+(Sections[i].IsCurved?" · curva":""),font,Brushes.DimGray,(a+b)/2-8,top-28);offset+=frames[i].Length;
                    }
                double high=Double.MinValue,low=Double.MaxValue;
                foreach(var h in Plan.Holes){high=Math.Max(high,h.YMm);low=Math.Min(low,h.YMm);}
                Func<double,float> y=delegate(double value){return center+(float)((high-value)/Math.Max(1,high-low)*Math.Min(65,Height*.15));};
                for(int i=0;i<Plan.Holes.Count;i++) {
                    var h=Plan.Holes[i];float cy=y(h.YMm),cx=x(h.GlobalZMm),r=Math.Max(4,Math.Min(10,(float)(Settings.RollerDiameterMm/total)*(right-left)/2));
                    using(var fill=new SolidBrush(h.SectionIndex==Selected ? DesignUi.Accent : DesignUi.Primary))g.FillEllipse(fill,cx-r,cy-r,2*r,2*r);
                    g.DrawString((i+1).ToString(),font,Brushes.DimGray,cx-5,cy+14);
                    if(i>0&&ReturnRollerLayout.SameStraightRun(Sections,Plan.Holes[i-1].SectionIndex,h.SectionIndex)) {
                        float py=y(Plan.Holes[i-1].YMm),px=x(Plan.Holes[i-1].GlobalZMm),middle=(px+cx)/2;
                        using(var curve=new Pen(Color.FromArgb(43,93,173),1.5f))g.DrawBezier(curve,px,py-r,px+(cx-px)/3,Math.Max(py,cy)+22,cx-(cx-px)/3,Math.Max(py,cy)+22,cx,cy-r);
                        if(i==Plan.Holes.Count-1) {
                            using(var dim=new Pen(Color.FromArgb(175,106,26),1.5f))g.DrawLine(dim,px,center+55,cx,center+55);
                            g.DrawString("Catenaria "+(Plan.AutomaticSpacing?Plan.ResolvedCatenaryMm:Settings.CatenarySpanMm).ToString("0.##")+" mm",font,Brushes.SaddleBrown,new RectangleF(Math.Max(8,middle-65),center+62,150,45));
                        }
                    }
                }
                g.DrawString((Plan.AutomaticSpacing?"Paso normal: "+Plan.MinimumNormalPitchMm.ToString("0.##")+"–"+Plan.MaximumNormalPitchMm.ToString("0.##"):"Paso normal uniforme: "+Plan.UniformPitchMm.ToString("0.##"))+" mm\n"+(Settings.KeyholeSeats?"Alojamiento R9 / R6.35; caras 10 mm":"Ø alojamiento: "+Settings.HoleDiameterMm.ToString("0.##")+" mm")+"\nCurva y escala vertical esquemáticas.",font,Brushes.DimGray,new RectangleF(12,Height-85,Width-24,80));
            }
        }
    }
}
