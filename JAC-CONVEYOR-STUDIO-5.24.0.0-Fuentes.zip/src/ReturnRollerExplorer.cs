﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace PerfilBandas {
internal sealed partial class CompleteBeltView {
    internal ReturnRollerExplorer rollerExplorer;
    internal void OpenRollerExplorer(){
        if(CurveRoute.HasCurves(sections)){OpenDetails(10);return;}
        if(rollerExplorer==null||rollerExplorer.IsDisposed)rollerExplorer=new ReturnRollerExplorer(angle=>{rollers.WrapAngleDeg=angle;rollers.HeightMode=1;Changed();});
        RefreshRollerExplorer(currentPlan==null?null:currentPlan.Rollers);
        if(!rollerExplorer.Visible)rollerExplorer.Show(FindForm());rollerExplorer.Activate();
    }
    void RefreshRollerExplorer(ReturnRollerPlan plan){
        if(rollerExplorer==null||rollerExplorer.IsDisposed)return;
        if(CurveRoute.HasCurves(sections)){rollerExplorer.ShowIssue("La vista de catenaria recta no corresponde al trazado curvo. Usa el visor 3D para revisar el retorno deslizante.");return;}
        try{
            int last=sections.Count-1;var firstP=BeltLinePlan.ProfileFor(sections,0,profile);var lastP=BeltLinePlan.ProfileFor(sections,last,profile);
            var first=ShaftPlateGeometry.Nominal(sections[0],firstP,BeltLinePlan.SupportFor(sections[0],supportTemplate,firstP));
            var motor=ShaftPlateGeometry.Nominal(sections[last],lastP,BeltLinePlan.SupportFor(sections[last],supportTemplate,lastP));
            string issue=currentPlan!=null&&!currentPlan.Valid?currentPlan.Issues.Find(i=>i.Blocking).ToString():null;
            rollerExplorer.UpdateDesign(rollers,plan,first,motor,sections,currentPlan==null?null:currentPlan.Supports,issue,currentPlan==null?null:currentPlan.Profiles);
        }catch(Exception ex){rollerExplorer.ShowIssue(ex.Message);}
    }
}
internal sealed class ReturnRollerExplorer:Form {
    internal readonly TrackBar AngleSlider=new TrackBar{Minimum=1800,Maximum=2100,TickFrequency=50,SmallChange=1,LargeChange=10,Dock=DockStyle.Fill,Name="WrapAngleSlider"};
    internal readonly NumericUpDown AngleInput=new NumericUpDown{Minimum=180,Maximum=210,DecimalPlaces=1,Increment=.1m,Width=85,Name="WrapAngleInput"};
    internal readonly Label Results=new Label{Dock=DockStyle.Top,AutoSize=true,MaximumSize=new Size(320,0),Padding=new Padding(16),Font=new Font("Segoe UI",10),Name="RollerDimensionsSummary"};
    readonly ComboBox end=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=120};
    internal readonly ReturnOverviewDiagram drawing=new ReturnOverviewDiagram{Dock=DockStyle.Fill};
    readonly Timer debounce=new Timer{Interval=180};readonly Action<double> setAngle;
    bool syncing;
    public ReturnRollerExplorer(Action<double> change){
        setAngle=change;Text="Abrazo interactivo · rodillos y catenaria";Size=new Size(1100,760);MinimumSize=new Size(950,650);StartPosition=FormStartPosition.CenterParent;
        var top=new TableLayoutPanel{Dock=DockStyle.Top,Height=82,Padding=new Padding(12),ColumnCount=4};top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,140));top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,100));top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,130));
        top.Controls.Add(new Label{Text="Abrazo · 180–210°",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,0);top.Controls.Add(AngleSlider,1,0);top.Controls.Add(AngleInput,2,0);end.Items.AddRange(new object[]{"Banda completa","Motriz","Conducido"});end.SelectedIndex=0;top.Controls.Add(end,3,0);
        var summary=new Panel{Dock=DockStyle.Right,Width=340,AutoScroll=true,BackColor=Color.White};summary.Controls.Add(Results);Controls.Add(drawing);Controls.Add(summary);Controls.Add(top);
        AngleSlider.ValueChanged+=delegate{if(syncing)return;syncing=true;AngleInput.Value=AngleSlider.Value/10m;syncing=false;QueueAngle();};
        AngleInput.ValueChanged+=delegate{if(syncing)return;syncing=true;AngleSlider.Value=(int)Math.Round(AngleInput.Value*10);syncing=false;QueueAngle();};
        debounce.Tick+=delegate{FlushAngle();};end.SelectedIndexChanged+=delegate{RefreshDrawing();};drawing.SelectionChanged+=delegate{drawing.Invalidate();};FormClosing+=delegate{debounce.Stop();};
    }
    void QueueAngle(){debounce.Stop();debounce.Start();}
    internal void FlushAngle(){debounce.Stop();setAngle((double)AngleInput.Value);}
    protected override void Dispose(bool disposing){if(disposing)debounce.Dispose();base.Dispose(disposing);}
    internal void ShowIssue(string message){Results.ForeColor=Color.Firebrick;Results.Text=message;drawing.Issue=message;drawing.Invalidate();}
    internal void UpdateDesign(ReturnRollerSettings s,ReturnRollerPlan p,ShaftPlateLayout first,ShaftPlateLayout last,IList<BeltSectionSpec> sections,SoporteSettings[] supports,string issue,ProfileSettings[] profiles=null){
        if(profiles==null)profiles=new ProfileSettings[sections.Count];if(supports==null)supports=new SoporteSettings[sections.Count];
        for(int i=0;i<sections.Count;i++){if(profiles[i]==null)profiles[i]=BeltLinePlan.ProfileFor(sections,i,sections[i].Profile??new ProfileSettings());if(supports[i]==null)supports[i]=BeltLinePlan.SupportFor(sections[i],sections[i].Support??new SoporteSettings(),profiles[i]);}
        drawing.Model=ReturnOverviewGeometry.Build(sections,profiles,supports,s,p,first,last);
        syncing=true;AngleInput.Value=(decimal)Math.Max(180,Math.Min(210,s.WrapAngleDeg));AngleSlider.Value=(int)Math.Round(AngleInput.Value*10);syncing=false;
        var lines=new List<string>{"RODILLOS Y CATENARIA","","Abrazo: "+s.WrapAngleDeg.ToString("0.0")+"° · manual 180–210°","Conducido: "+first.Sprocket.Teeth+" dientes · Ø primitivo "+first.Sprocket.PitchDiameterMm.ToString("0.##")+" mm","Motriz: "+last.Sprocket.Teeth+" dientes · Ø primitivo "+last.Sprocket.PitchDiameterMm.ToString("0.##")+" mm","","Rodillo: Ø "+s.RollerDiameterMm.ToString("0.##")+" mm","Eje: Ø "+s.ShaftDiameterMm.ToString("0.##")+" mm",s.KeyholeSeats?"Alojamiento: R9 / R6.35 · caras 10 mm · centros 15.35 mm":"Barreno: Ø "+s.HoleDiameterMm.ToString("0.##")+" mm"};
        if(p!=null&&s.Enabled){
            lines.Add(s.PhysicalRollers?"Cantidad total: "+p.Holes.Count+" rodillos / "+p.Holes.Count+" ejes":"Cantidad total: 0 rodillos / 0 ejes");
            if(!s.PhysicalRollers)lines.Add("Posiciones de barreno: "+p.Holes.Count);
            double minBody=Double.MaxValue,maxBody=0,minShaft=Double.MaxValue,maxShaft=0;
            foreach(var h in p.Holes){var section=sections[h.SectionIndex];var support=supports!=null&&supports[h.SectionIndex]!=null?supports[h.SectionIndex]:section.Support??new SoporteSettings();double width=support.LengthMm,thickness=(section.Profile??new ProfileSettings()).ThicknessMm;minBody=Math.Min(minBody,width-2*s.SideClearanceMm);maxBody=Math.Max(maxBody,width-2*s.SideClearanceMm);minShaft=Math.Min(minShaft,width+2*(s.ShaftProjectionMm+thickness));maxShaft=Math.Max(maxShaft,width+2*(s.ShaftProjectionMm+thickness));}
            lines.Add("Largo de cuerpo: "+Range(minBody,maxBody)+" mm");lines.Add("Largo de eje: "+Range(minShaft,maxShaft)+" mm");
            lines.Add(s.PhysicalRollers?"Sólidos de rodillos y ejes: activados":"Sólidos desactivados · se colocan barrenos");lines.Add("");
            lines.Add("Márgenes: extremos 100 mm · ranuras "+s.SlotClearanceMm.ToString("0.#")+" mm");lines.Add(p.SlotsInterrupted?"Segunda opción: ranuras interrumpidas; logo conservado.":"Reparto con ranuras originales.");
            lines.Add("Paso normal: "+Range(p.MinimumNormalPitchMm,p.MaximumNormalPitchMm)+" mm");lines.Add("Catenaria entre centros: "+p.ResolvedCatenaryMm.ToString("0.##")+" mm");lines.Add("Manual L: "+p.ReferencePitchMm.ToString("0.##")+" mm · catenaria L + 200");
            lines.Add("Centro bajo nylamid, conducido: "+(first.RunningY-p.CenterY).ToString("0.##")+" mm");lines.Add("Centro bajo nylamid, motriz: "+(last.RunningY-p.FirstMotorY).ToString("0.##")+" mm");
        }else lines.Add(s.Enabled?"No hay reparto válido para esta configuración.":"Activa rodillos para calcular la cantidad.");
        lines.Add("");lines.Add("SOPORTES SUPERIORES: "+drawing.Model.Supports.Count);
        lines.Add(p==null||p.Holes.Count==0?"Retorno no comprobado: no hay reparto válido.":drawing.Model.CollisionCount==0?"Sin choque con paredes y lomo del soporte.":drawing.Model.CollisionCount+" soportes con interferencia (rojo).");
        double upperMinimum=Double.PositiveInfinity,returnMinimum=Double.PositiveInfinity;foreach(var station in drawing.Model.Supports){upperMinimum=Math.Min(upperMinimum,station.UpperGap);returnMinimum=Math.Min(returnMinimum,station.ReturnGap);}
        lines.Add("Banda superior → metal mín.: "+ReturnOverviewGeometry.DistanceText(upperMinimum));
        lines.Add("Retorno → metal mín.: "+ReturnOverviewGeometry.DistanceText(returnMinimum));
        lines.Add("Distancias mínimas 3D, sin incluir rodillos.");
        lines.Add("");lines.Add("POR SOPORTE · superior / retorno");int supportNumber=0;foreach(var station in drawing.Model.Supports)lines.Add((++supportNumber)+" · T"+(station.Section+1)+" · "+ReturnOverviewGeometry.DistanceText(station.UpperGap)+" / "+ReturnOverviewGeometry.DistanceText(station.ReturnGap));
        lines.Add("Clic en un soporte del lateral para ver sus ranuras y el paso de la banda.");
        lines.Add("");lines.Add("Altura por tangencia. Envolvente exterior: A del sprocket + espesor de banda.");lines.Add("Retorno sin flecha real de catenaria. Guías y placas de fijación no incluidas en el cálculo de choques.");if(issue!=null){lines.Add("");lines.Add(issue);}
        Results.ForeColor=issue==null&&drawing.Model.CollisionCount==0?Color.FromArgb(30,45,55):Color.Firebrick;Results.Text=String.Join("\n",lines.ToArray());RefreshDrawing();
    }
    static string Range(double a,double b){return Math.Abs(a-b)<1e-6?a.ToString("0.##"):a.ToString("0.##")+"–"+b.ToString("0.##");}
    void RefreshDrawing(){drawing.View=end.SelectedIndex;drawing.Issue=null;drawing.Invalidate();}
}
}
