﻿using System;
using System.Globalization;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal static class SolidWorksReturnRollerGenerator
    {
        public static void Cut(SldWorks sw,ModelDoc2 model,ProfileSettings p,bool right,string path)
        {
            if(p.ResolvedRollerHoles==null || p.ResolvedRollerHoles.Length==0) return;
            var datum=SolidWorksShaftPlateGenerator.Measure(model,p,right);
            double before=SolidWorksShaftPlateGenerator.Volume(model),expected=0;
            model.ClearSelection2(true);
            if(!((Entity)datum.OuterFace).Select(false)) throw new InvalidOperationException("Rodillos: no se pudo seleccionar la cara exterior del perfil.");
            var sketch=model.SketchManager;sketch.InsertSketch(true);
            var active=(Sketch)model.GetActiveSketch2();var math=(MathUtility)sw.GetMathUtility();
            if(active==null) throw new InvalidOperationException("Rodillos: no hay croquis activo.");
            sketch.AddToDB=true;
            try {
                foreach(var hole in p.ResolvedRollerHoles) {
                    Func<double,double,double[]> at=(z,y)=>{var point=(MathPoint)math.CreatePoint(new[]{datum.OuterX/1000,(hole.YMm+y)/1000,(hole.LocalZMm+z)/1000});return (double[])((MathPoint)point.MultiplyTransform(active.ModelToSketchTransform)).ArrayData;};
                    if(hole.Keyhole){double aFlat=ReturnRollerSeatGeometry.HalfFlat,up=ReturnRollerSeatGeometry.UpperJoin,low=ReturnRollerSeatGeometry.LowerJoin;var ur=at(aFlat,up);var ul=at(-aFlat,up);var top=at(0,ReturnRollerSeatGeometry.CenterDistance+ReturnRollerSeatGeometry.EntryRadius);var ll=at(-aFlat,low);var lr=at(aFlat,low);var bottom=at(0,-ReturnRollerSeatGeometry.SeatRadius);
                        sketch.Create3PointArc(ur[0],ur[1],0,ul[0],ul[1],0,top[0],top[1],0);sketch.CreateLine(ul[0],ul[1],0,ll[0],ll[1],0);sketch.Create3PointArc(ll[0],ll[1],0,lr[0],lr[1],0,bottom[0],bottom[1],0);sketch.CreateLine(lr[0],lr[1],0,ur[0],ur[1],0);
                        expected+=ReturnRollerSeatGeometry.Area*p.ThicknessMm/1e9;
                    }else{var a=at(0,0);sketch.CreateCircleByRadius(a[0],a[1],0,hole.DiameterMm/2000);expected+=Math.PI*Math.Pow(hole.DiameterMm/2000,2)*p.ThicknessMm/1000;}
                }
            } finally {sketch.AddToDB=false;}
            var cut=model.FeatureManager.FeatureCut4(true,false,false,
                (int)swEndConditions_e.swEndCondBlind,(int)swEndConditions_e.swEndCondBlind,
                p.ThicknessMm/500,.01,false,false,false,false,0,0,false,false,false,false,
                true,true,true,true,true,false,(int)swStartConditions_e.swStartSketchPlane,0,false,true);
            if(cut==null) throw new InvalidOperationException("Rodillos: no se crearon los barrenos pasantes.");
            cut.Name="Alojamientos_Ejes_Rodillos_Retorno";model.EditRebuild3();
            if(Math.Abs(before-SolidWorksShaftPlateGenerator.Volume(model)-expected)>Math.Max(expected*.002,1e-12))
                throw new InvalidOperationException("Rodillos: el volumen retirado no coincide con los alojamientos previstos. Volumen esperado="+(expected*1e9).ToString("0.###")+" mm3; retirado="+((before-SolidWorksShaftPlateGenerator.Volume(model))*1e9).ToString("0.###")+" mm3. Revisa diámetro, espesor y otros cortes.");
            var props=model.Extension.get_CustomPropertyManager("");
            props.Add3("Cantidad_Rodillos",30,p.ResolvedRollerHoles.Length.ToString(),2);
            props.Add3("Diametro_Barreno_Rodillo_mm",30,p.ResolvedRollerHoles[0].DiameterMm.ToString(CultureInfo.InvariantCulture),2);
            props.Add3("Tipo_Alojamiento_Rodillo",30,p.ResolvedRollerHoles[0].Keyhole?"Entrada R9; asiento R6.35; caras 10; centros 15.35 mm":"Circular",2);
            int error=0,warning=0;
            if(!model.SaveAs4(path,0,(int)swSaveAsOptions_e.swSaveAsOptions_Silent,ref error,ref warning) || error!=0)
                throw new InvalidOperationException("Rodillos: no se guardó el perfil perforado ("+error+").");
        }
    }
}
