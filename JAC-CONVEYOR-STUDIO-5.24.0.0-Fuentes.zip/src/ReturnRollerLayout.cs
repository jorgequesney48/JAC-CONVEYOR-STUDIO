using System;
using System.Collections.Generic;

namespace PerfilBandas
{
    internal sealed class ReturnRollerSettings
    {
        public bool Enabled=true;
        public bool PhysicalRollers=true;
        public bool KeyholeSeats=true;
        public int SlotConflictMode=2; // 0: split; 1: lower; 2: automatic spacing, preserve cuts.
        public double SlotClearanceMm=ReturnRollerRules.SlotClearanceMm;
        public bool AllowSlotInterruption=true; // Authorized only at the first slot adjacent to a mandatory end roller.
        public double CurveRollerRiseMm=10;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double? ResolvedNormalYMm;
        public bool AutoCatenary=true;
        public double NormalSagMm=10,CatenarySagMm=50; // Provisional geometric inputs, not manufacturer-approved sag.
        public double SideClearanceMm=10;
        public double ShaftProjectionMm=20;
        public bool OpenSeats;
        public double WindowHeightMm = 40;
        public double WindowLengthMm = 300;
        public double EntryClearanceMm = 2;
        public double MinimumBridgeMm = 10;
        public double ShaftFlatWidthMm = 9;
        public double ShaftFlatLengthMm = 10;
        public double SeatDropMm = 12.7;
        public double ShaftDiameterMm = 12.7;
        public double HoleAllowanceMm = 0;
        public double RollerDiameterMm = 38.1;
        public double FirstFromShaftMm = 250;
        public double FirstMotorFromShaftMm = 250;
        public double TargetPitchMm = 800;
        public double CatenarySpanMm = 1200;
        public double EdgeClearanceMm = 4;
        public int HeightMode = 1; // 0: specified center depth; 1: lower belt envelope + wrap tangent.
        public double CenterDepthBelowRunningMm = 0;
        public double LowerBeltDepthMm = 127;
        public double WrapAngleDeg = 186;
        public double HoleDiameterMm { get { return ShaftDiameterMm+HoleAllowanceMm; } }
        public ReturnRollerSettings Copy() { return (ReturnRollerSettings)MemberwiseClone(); }
    }
    internal sealed class ReturnRollerHole
    {
        public int SectionIndex;
        public double LocalZMm, GlobalZMm, YMm, DiameterMm;
        public string Role;
        public bool PreserveCuts;
        public double JointMarginMm=100;
        public double SlotClearanceMm=ReturnRollerRules.SlotClearanceMm;
        public bool Keyhole;
        public bool OpenSeat=false; // Circular holes only; historical export field.
        public ReturnRollerHole Copy() { return (ReturnRollerHole)MemberwiseClone(); }
    }
    internal sealed class ReturnRollerPlan
    {
        public readonly List<ReturnRollerHole> Holes = new List<ReturnRollerHole>();
        public readonly Dictionary<int,double> CurveReturnDrops=new Dictionary<int,double>();
        public bool AutomaticSpacing;
        public bool SlotsInterrupted;
        public double ResolvedCatenaryMm,ReferencePitchMm;
        public double MinimumNormalPitchMm,MaximumNormalPitchMm,DrivenDistanceMm,MotorDistanceMm;
        public double UniformPitchMm, FirstDrivenZMm, FirstMotorZMm, SecondMotorZMm, CenterY, FirstMotorY, RunningDrivenY;
    }
    internal static partial class ReturnRollerLayout
    {
        public static void ValidateSettings(ReturnRollerSettings s)
        {
            if(s==null) throw new InvalidOperationException("Rodillos: falta la configuración.");
            foreach(var field in typeof(ReturnRollerSettings).GetFields()) if(field.FieldType==typeof(double)) {
                double v=(double)field.GetValue(s);
                if(Double.IsNaN(v) || Double.IsInfinity(v) || v<0 || v>100000)
                    throw new InvalidOperationException("Rodillos: medida no válida en " + field.Name + ".");
            }
            if(s.NormalSagMm>300||s.CatenarySagMm>300)throw new InvalidOperationException("La caída del modelo debe estar entre 0 y 300 mm; el espacio libre entre rodillos también se comprueba.");
            if(s.KeyholeSeats&&(Math.Abs(s.ShaftDiameterMm-12.7)>.001||Math.Abs(s.HoleAllowanceMm)>.001))throw new InvalidOperationException("Alojamiento R9/R6.35: usa eje Ø12.7 mm y holgura de barreno 0; caras planas a 10 mm.");
            if(s.ShaftDiameterMm<=0 || s.RollerDiameterMm<=s.HoleDiameterMm || s.HoleAllowanceMm>5 || s.SideClearanceMm<0 || s.ShaftProjectionMm<0 || s.FirstFromShaftMm<=0 ||
                s.FirstMotorFromShaftMm<=0 || s.TargetPitchMm<=s.RollerDiameterMm || s.TargetPitchMm>ReturnRollerRules.NormalMaxMm || s.CatenarySpanMm<=s.RollerDiameterMm || s.EdgeClearanceMm<0 ||
                (s.HeightMode!=0 && s.HeightMode!=1) || (s.SlotConflictMode<0 || s.SlotConflictMode>2) || s.SlotClearanceMm<0 || s.SlotClearanceMm>100 || s.CurveRollerRiseMm>50) throw new InvalidOperationException("Rodillos: revisa diámetros, paso, catenaria y modo de altura.");
            if((s.SlotConflictMode!=2 || !s.AutoCatenary) && s.CatenarySpanMm>ReturnRollerRules.NormalMaxMm+ReturnRollerRules.CatenaryExtraMm)
                throw new InvalidOperationException("Rodillos: según la imagen, la primera catenaria es L + 200 mm y L ≤1000 mm; su longitud no puede superar 1200 mm.");
            if(s.FirstFromShaftMm<ReturnRollerRules.DrivenMinMm || s.FirstFromShaftMm>ReturnRollerRules.DrivenMaxMm || s.FirstMotorFromShaftMm<ReturnRollerRules.MotorMinMm || s.FirstMotorFromShaftMm>ReturnRollerRules.MotorMaxMm)
                throw new InvalidOperationException("Rodillos: primer centro a 200–500 mm del conducido y 200–300 mm del motriz, según el gráfico del fabricante.");
        }

        public static double BeltEnvelopeRadius(ShaftPlateLayout shaft) {
            // A locates the supporting underside of the flat belt above the shaft.
            // The external top face is A + belt thickness above that axis.
            double radius=shaft.Sprocket.AMm+shaft.BeltThicknessMm;
            if(shaft.BeltThicknessMm<=0 || radius<shaft.Sprocket.PitchDiameterMm/2)
                throw new InvalidOperationException("Rodillos: el espesor de banda no admite la envolvente del sprocket seleccionado.");
            return radius;
        }
        public static double CenterY(ReturnRollerSettings s,ShaftPlateLayout shaft)
        {return CenterY(s,shaft,s.FirstFromShaftMm);}
        public static double CenterY(ReturnRollerSettings s,ShaftPlateLayout shaft,double distance)
        {
            double beta=(s.WrapAngleDeg-180)*Math.PI/180;
            double radius=BeltEnvelopeRadius(shaft);
            if(s.WrapAngleDeg<ReturnRollerRules.WrapMinDeg || s.WrapAngleDeg>ReturnRollerRules.WrapMaxDeg)
                throw new InvalidOperationException("Rodillos: el abrazo debe estar entre 180° y 210° según el manual.");
            // Common tangent: lower contact on the sprocket, upper contact on the return roller.
            return shaft.AxisY+distance*Math.Tan(beta)-(radius+s.RollerDiameterMm/2)/Math.Cos(beta);
        }
        public static ReturnRollerPlan Build(IList<BeltSectionSpec> sections,ProfileSettings template,SoporteSettings support,ReturnRollerSettings settings)
        {
            var result=new ReturnRollerPlan();
            if(settings==null) return result;
            settings.OpenSeats=false;settings.SlotConflictMode=2;settings.ResolvedNormalYMm=null;
            if(!settings.Enabled) return result;
            settings.HeightMode=1; // Return height always follows sprocket geometry and wrap.
            ValidateSettings(settings);
            BeltLinePlan.Validate(sections,template,settings.OpenSeats);
            if(!ShaftPlateGeometry.Active(sections[0]) || !ShaftPlateGeometry.Active(sections[sections.Count-1]))
                throw new InvalidOperationException("Rodillos: activa las placas de flecha en ambos extremos para referenciar sus ejes.");
            var profiles=new ProfileSettings[sections.Count];var offsets=new double[sections.Count];
            double total=0;
            for(int i=0;i<sections.Count;i++) {profiles[i]=BeltLinePlan.ProfileFor(sections,i,template,settings.OpenSeats);offsets[i]=total;total+=profiles[i].LengthMm;}
            var first=ShaftPlateGeometry.Nominal(sections[0],profiles[0],BeltLinePlan.SupportFor(sections[0],support,profiles[0]));
            int lastIndex=sections.Count-1;
            var last=ShaftPlateGeometry.Nominal(sections[lastIndex],profiles[lastIndex],BeltLinePlan.SupportFor(sections[lastIndex],support,profiles[lastIndex]));
            settings.ResolvedNormalYMm=CommonNormalY(profiles,settings,Math.Min(CenterY(settings,first,settings.FirstFromShaftMm),CenterY(settings,last,settings.FirstMotorFromShaftMm)));
            if(CurveRoute.HasCurves(sections))return BuildMixed(sections,profiles,offsets,first,last,settings,support);
            if(settings.SlotConflictMode==2)return BuildAutomatic(sections,profiles,offsets,first,last,settings);
            result.FirstDrivenZMm=first.AxisZ+settings.FirstFromShaftMm;
            result.FirstMotorZMm=offsets[lastIndex]+last.AxisZ-settings.FirstMotorFromShaftMm;
            result.SecondMotorZMm=result.FirstMotorZMm-settings.CatenarySpanMm;
            result.ResolvedCatenaryMm=settings.CatenarySpanMm;result.ReferencePitchMm=settings.CatenarySpanMm-ReturnRollerRules.CatenaryExtraMm;result.DrivenDistanceMm=settings.FirstFromShaftMm;result.MotorDistanceMm=settings.FirstMotorFromShaftMm;
            result.CenterY=CenterY(settings,first);
            result.RunningDrivenY=first.RunningY;
            result.FirstMotorY=CenterY(settings,last,settings.FirstMotorFromShaftMm);
            double span=result.SecondMotorZMm-result.FirstDrivenZMm;
            double minimumPitch=settings.RollerDiameterMm+2*settings.EdgeClearanceMm;
            if(settings.CatenarySpanMm<settings.TargetPitchMm+200)
                throw new InvalidOperationException("Rodillos: la primera catenaria motriz debe superar el paso normal solicitado al menos 200 mm.");
            if(span<minimumPitch)
                throw new InvalidOperationException("Rodillos: la banda es demasiado corta para los primeros rodillos y la catenaria de " + settings.CatenarySpanMm.ToString("0.#") + " mm. Aumenta el largo total.");
            int minimum=(int)Math.Ceiling(span/settings.TargetPitchMm),maximum=Math.Min(1000,(int)Math.Floor(span/minimumPitch));
            string conflict="";
            for(int intervals=minimum;intervals<=maximum;intervals++) {
                double pitch=span/intervals;var candidates=new List<ReturnRollerHole>();bool valid=true;
                for(int i=0;i<=intervals+1;i++) {
                    double z=i==intervals+1 ? result.FirstMotorZMm : result.FirstDrivenZMm+i*pitch;
                    int sectionIndex=0;while(sectionIndex<lastIndex && z>=offsets[sectionIndex]+sections[sectionIndex].LengthMm) sectionIndex++;
                    var hole=new ReturnRollerHole {SectionIndex=sectionIndex,LocalZMm=z-offsets[sectionIndex],GlobalZMm=z,
                        Keyhole=settings.KeyholeSeats,YMm=i==intervals+1 ? result.FirstMotorY : result.CenterY+(result.FirstMotorY-result.CenterY)*(z-result.FirstDrivenZMm)/span,DiameterMm=settings.HoleDiameterMm,
                        JointMarginMm=100,Role=i==0 ? "Primero conducido" : i==intervals+1 ? "Primero motriz" : i==intervals ? "Segundo motriz / catenaria" : "Retorno"};
                    hole.SlotClearanceMm=settings.SlotClearanceMm;
                    if(settings.SlotConflictMode==1 && i>0 && i<intervals+1) LowerBelowCuts(profiles[sectionIndex],hole,settings);
                    conflict=Conflict(sections[sectionIndex],profiles[sectionIndex],hole,settings.EdgeClearanceMm);
                    if(conflict!=null) {valid=false;break;}
                    candidates.Add(hole);
                }
                if(valid) {
                    result.UniformPitchMm=pitch;result.MinimumNormalPitchMm=pitch;result.MaximumNormalPitchMm=pitch;result.Holes.Clear();result.Holes.AddRange(candidates);
                    try {
                        for(int i=0;i<sections.Count;i++) Apply(profiles[i],i,sections[i],result);
                        return result;
                    } catch(InvalidOperationException ex) { conflict=ex.Message; }
                }
            }
            throw new InvalidOperationException("Rodillos: no cabe una distribución uniforme sin invadir cortes o uniones. " + conflict + " Revisa referencias, logo o largo de tramos.");
        }
        // Preserve the first roller at each shaft; lower intermediate rollers only.
        internal static void LowerBelowCuts(ProfileSettings p,ReturnRollerHole h,ReturnRollerSettings settings)
        {
            var pattern=ProfileSlotLayout.Calculate(p);
            double radius=settings.RollerDiameterMm/2,gap=settings.SlotClearanceMm;
            foreach(var slot in pattern.Slots)
                if(h.LocalZMm+radius+gap>=slot.CenterMm-slot.LengthMm/2 && h.LocalZMm-radius-gap<=slot.CenterMm+slot.LengthMm/2)
                    h.YMm=Math.Min(h.YMm,slot.CenterYMm-slot.RadiusMm-radius-gap);
            if(pattern.LogoVisible && Math.Abs(h.LocalZMm-pattern.LogoCenterMm)<=pattern.LogoWidthMm/2+radius+gap)
                h.YMm=Math.Min(h.YMm,pattern.CenterYMm-pattern.LogoHeightMm/2-radius-gap);
        }
        private static double DistanceToRectangle(double x,double y,double left,double bottom,double right,double top)
        {double dx=Math.Max(left-x,Math.Max(0,x-right)),dy=Math.Max(bottom-y,Math.Max(0,y-top));return Math.Sqrt(dx*dx+dy*dy);}
        private static string Conflict(BeltSectionSpec section,ProfileSettings p,ReturnRollerHole h,double clearance,bool preserveCuts=false,bool ignoreSlots=false)
        {
            if(h.Keyhole){var entry=h.Copy();entry.Keyhole=false;entry.YMm+=ReturnRollerSeatGeometry.CenterDistance;entry.DiameterMm=18;var c=Conflict(section,p,entry,clearance,preserveCuts,ignoreSlots);if(c!=null)return c;var neck=h.Copy();neck.Keyhole=false;neck.YMm+=(ReturnRollerSeatGeometry.UpperJoin+ReturnRollerSeatGeometry.LowerJoin)/2;neck.DiameterMm=2*Math.Sqrt(25+Math.Pow((ReturnRollerSeatGeometry.UpperJoin-ReturnRollerSeatGeometry.LowerJoin)/2,2));c=Conflict(section,p,neck,clearance,preserveCuts,ignoreSlots);if(c!=null)return c;}
            double margin=h.DiameterMm/2+clearance;
            double tangentTop=ProfileBendGeometry.Tangent(p,true);
            double tangentBottom=(p.BendRadiusMm+p.ThicknessMm)*Math.Tan((180-p.BottomAngleDeg)*Math.PI/360);
            if(h.LocalZMm<h.DiameterMm/2+Math.Max(clearance,h.JointMarginMm) || h.LocalZMm>p.LengthMm-h.DiameterMm/2-Math.Max(clearance,h.JointMarginMm)) return "Un barreno está demasiado cerca del corte de un tramo.";
            if(h.YMm+margin>-tangentTop || h.YMm-margin<-p.WebHeightMm+tangentBottom) return "La altura del rodillo invade un doblez.";
            if(p.IncludeSupportHoles) foreach(double z in SupportHoleLayout.CentersMm(p)) {
                double half=p.SupportHoleSizeMm/2;
                if(DistanceToRectangle(h.LocalZMm,h.YMm,z-half,-p.SupportHoleYMm-half,z+half,-p.SupportHoleYMm+half)<margin || DistanceToRectangle(h.LocalZMm,h.YMm,z-half,-p.WebHeightMm+p.SupportHoleYMm-half,z+half,-p.WebHeightMm+p.SupportHoleYMm+half)<margin)
                    return "Un barreno invade el cuadrado de un soporte C.";
            }
            if(ShaftPlateGeometry.Active(section)) {
                double overlap=ShaftPlateGeometry.EffectiveOverlap(section,p);
                if((section.Type==BeltSectionType.Conducido && h.LocalZMm-margin<overlap) || (section.Type==BeltSectionType.Motriz && h.LocalZMm+margin>p.LengthMm-overlap))
                    return "Un barreno invade el solape de la placa de flecha.";
            }
            var pattern=ProfileSlotLayout.PatternFor(p);
            foreach(var slot in pattern.Slots)if(!(ignoreSlots&&RollerSlotInterruption.Allows(pattern,slot,h))) if(ProfileSlotLayout.DistanceToSlot(slot,h.LocalZMm,h.YMm)<h.DiameterMm/2+h.SlotClearanceMm) return ignoreSlots?"Un rodillo invade otra ranura: solo puede interrumpirse la primera desde el extremo afectado.":"Un barreno invade una ranura del patrón calculado.";
            if(pattern.LogoVisible && DistanceToRectangle(h.LocalZMm,h.YMm,pattern.LogoCenterMm-pattern.LogoWidthMm/2,pattern.CenterYMm-pattern.LogoHeightMm/2,pattern.LogoCenterMm+pattern.LogoWidthMm/2,pattern.CenterYMm+pattern.LogoHeightMm/2)<h.DiameterMm/2+Math.Max(clearance,ProfileSlotLayout.ClearanceMm))
                return "Un barreno invade el logo en su posición calculada.";
            return null;
        }
        public static void Apply(ProfileSettings profile,int index,BeltSectionSpec section,ReturnRollerPlan plan)
        {
            if(section.IsCurved){double drop;profile.ResolvedCurveReturnDropMm=plan.CurveReturnDrops.TryGetValue(index,out drop)?drop:0;return;}
            var original=ProfileSlotLayout.PatternFor(profile).Copy();
            profile.ResolvedRollerHoles=plan.Holes.FindAll(delegate(ReturnRollerHole h){return h.SectionIndex==index;}).ConvertAll(delegate(ReturnRollerHole h){return h.Copy();}).ToArray();
            // Re-resolve cuts with final roller centres; preview and CAD share these fragments.
            if(plan.SlotsInterrupted){ProfileSlotLayout.InterruptForRollers(profile,original);return;}
            if(profile.AdaptFunctionalCuts)ProfileSlotLayout.Resolve(profile,true,profile.ResolvedPattern==null?0:profile.ResolvedPattern.ProtectedLeftMm,profile.ResolvedPattern==null?0:profile.ResolvedPattern.ProtectedRightMm);
            else ProfileSlotLayout.PatternFor(profile);
        }
    }
}
