﻿using System;using System.Collections.Generic;
namespace PerfilBandas {internal static partial class ReturnRollerLayout {
 internal static double SeatTop(ReturnRollerSettings settings){return settings.KeyholeSeats?24.35:settings.HoleDiameterMm/2;}
 internal static double NormalY(ProfileSettings p,ReturnRollerSettings settings,double fallback){
  var slots=ProfileSlotLayout.PatternFor(p).Slots;if(slots.Length==0)return fallback;double y=Double.PositiveInfinity;foreach(var slot in slots)y=Math.Min(y,slot.CenterYMm-slot.RadiusMm-SeatTop(settings)-settings.SlotClearanceMm-.0001);return y;
 }
 internal static double CommonNormalY(ProfileSettings[] profiles,ReturnRollerSettings settings,double fallback){
  double level=Double.PositiveInfinity;foreach(var p in profiles)if(!p.CurvedWeldedProfile&&ProfileSlotLayout.PatternFor(p).Slots.Length>0)level=Math.Min(level,NormalY(p,settings,fallback));return Double.IsPositiveInfinity(level)?fallback:level;
 }
 static double LowerY(double z,double fallback,ProfileSettings[] profiles,double[] offsets,ReturnRollerSettings settings){return settings.ResolvedNormalYMm??CommonNormalY(profiles,settings,fallback);}
 static List<double[]> FreeLoweredRun(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,double start,double end,double y0,double y1,ReturnRollerSettings settings,bool interrupt,string startRole,string endRole){
  var free=new List<double[]>();double minimum=settings.RollerDiameterMm+2*settings.EdgeClearanceMm;
  for(int i=0;i<profiles.Length;i++)if(!sections[i].IsCurved){double lo=Math.Max(start+minimum,offsets[i]),hi=Math.Min(end-minimum,offsets[i]+profiles[i].LengthMm);if(hi<=lo)continue;double y=LowerY(lo,Math.Min(y0,y1),profiles,offsets,settings);free.AddRange(FreeCentres(sections,profiles,offsets,lo,hi,y,y,settings,false));}
  foreach(var q in new[]{new[]{start,y0},new[]{end,y1}}){var h=AutoHole(q[0],q[1],sections,offsets,settings,q[0]==start?startRole:endRole,interrupt);if(Conflict(sections[h.SectionIndex],profiles[h.SectionIndex],h,settings.EdgeClearanceMm,true,interrupt)==null)free.Add(new[]{q[0],q[0]});}
  return Merge(free);
 }
 static Dictionary<int,double> LowerCurves(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,ReturnRollerSettings settings,SoporteSettings support){
  var drops=new Dictionary<int,double>();var bases=new Dictionary<int,double>();
  double minimum=Double.NegativeInfinity,maximum=Double.PositiveInfinity;
  for(int i=0;i<sections.Count;i++)if(sections[i].IsCurved){var p=profiles[i];p.ResolvedCurveReturnDropMm=0;p.ResolvedCurveRollerRiseMm=settings.CurveRollerRiseMm;var s=BeltLinePlan.SupportFor(sections[i],support,p);double contact=CurveReturnTransitionLayout.ContactY(p,s);
   double bottom=CurveReturnLayout.SupportY(p,s,true)+Math.Min(0,s.ActualFlange1HeightMm-s.ActualFlange2HeightMm),limit=-p.WebHeightMm+p.ThicknessMm+1;
   double maximumDrop=Math.Max(0,bottom-limit);bases[i]=contact;minimum=Math.Max(minimum,contact-maximumDrop);maximum=Math.Min(maximum,contact);
  }
  if(bases.Count==0)return drops;
  if(minimum>maximum+.001)throw new InvalidOperationException("Los nylamid de retorno de las curvas no pueden compartir altura dentro del límite del labio inferior. Revisa las alturas de las almas y soportes.");
  double desired=settings.ResolvedNormalYMm.HasValue?settings.ResolvedNormalYMm.Value+settings.RollerDiameterMm/2-settings.CurveRollerRiseMm:maximum;
  double commonContact=Math.Max(minimum,Math.Min(maximum,desired));
  foreach(var pair in bases){double drop=Math.Max(0,pair.Value-commonContact);profiles[pair.Key].ResolvedCurveReturnDropMm=drop;drops[pair.Key]=drop;}
  // All return rollers follow the real curved guide level; only shaft rollers
  // keep their independent sprocket wrap tangency.
  settings.ResolvedNormalYMm=commonContact+settings.CurveRollerRiseMm-settings.RollerDiameterMm/2;
  return drops;
 }
}}
