﻿using System;using System.Collections.Generic;
namespace PerfilBandas {
internal static partial class ReturnRollerLayout {
 internal const double CurveApproachMm=150;
 sealed class MixedRunPlacement {internal double Start,End,Y0,Y1;internal bool First,Motor;internal List<double[]> Free;internal List<double> Positions;}

 internal static bool SameStraightRun(IList<BeltSectionSpec> sections,int first,int last){for(int i=Math.Min(first,last);i<=Math.Max(first,last);i++)if(sections[i].IsCurved)return false;return true;}
 static List<double> MixedEndDistances(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout shaft,double axis,ReturnRollerSettings settings,bool motor,bool interrupt){
  double low=motor?ReturnRollerRules.MotorMinMm:ReturnRollerRules.DrivenMinMm,high=motor?ReturnRollerRules.MotorMaxMm:ReturnRollerRules.DrivenMaxMm,preferred=motor?settings.FirstMotorFromShaftMm:settings.FirstFromShaftMm;
  double start=motor?axis-high:axis+low,end=motor?axis-low:axis+high;var values=new List<double>();
  foreach(var zone in FreeCentres(sections,profiles,offsets,start,end,CenterY(settings,shaft,motor?high:low),CenterY(settings,shaft,motor?low:high),settings,interrupt)){
   double a=motor?axis-zone[1]:zone[0]-axis,b=motor?axis-zone[0]:zone[1]-axis;values.Add(Math.Max(a,Math.Min(b,preferred)));values.Add(a);values.Add(b);values.Add((a+b)/2);
  }values.Sort((a,b)=>Math.Abs(a-preferred).CompareTo(Math.Abs(b-preferred)));return values;
 }
 static ReturnRollerPlan BuildMixed(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout first,ShaftPlateLayout last,ReturnRollerSettings settings,SoporteSettings support){
  var drops=LowerCurves(sections,profiles,settings,support);
  var runs=new List<int[]>();for(int i=0;i<sections.Count;i++){if(sections[i].IsCurved)continue;int start=i;while(i+1<sections.Count&&!sections[i+1].IsCurved)i++;runs.Add(new[]{start,i});}
  string issue="";
  foreach(bool interrupt in settings.AllowSlotInterruption?new[]{false,true}:new[]{false}){var plan=BuildMixedPass(sections,profiles,offsets,first,last,settings,runs,interrupt,support,out issue);if(plan!=null){foreach(var drop in drops)plan.CurveReturnDrops[drop.Key]=drop.Value;for(int i=0;i<sections.Count;i++)if(!sections[i].IsCurved)Apply(profiles[i],i,sections[i],plan);return plan;}}
  throw new InvalidOperationException("Rodillos en rectos: no cabe el reparto con el centro obligatorio a 150 mm antes de la curva y la catenaria dentro del recto motriz. "+issue+" Revisa largo de rectos, logo, abrazo y paso. Si el abrazo o la transición necesita un corte, activa Interrumpir solo la primera ranura.");
 }
 static ReturnRollerPlan BuildMixedPass(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,double[] offsets,ShaftPlateLayout first,ShaftPlateLayout last,ReturnRollerSettings settings,List<int[]> runs,bool interrupt,SoporteSettings support,out string issue){
  issue="";double minimum=settings.RollerDiameterMm+2*settings.EdgeClearanceMm;int motorIndex=sections.Count-1;double motorAxis=offsets[motorIndex]+last.AxisZ;
  var driven=MixedEndDistances(sections,profiles,offsets,first,first.AxisZ,settings,false,interrupt);
  var motors=MixedEndDistances(sections,profiles,offsets,last,motorAxis,settings,true,interrupt);
  foreach(double motorDistance in motors){var m=AutoHole(motorAxis-motorDistance,CenterY(settings,last,motorDistance),sections,offsets,settings,"Primero motriz",interrupt);
   if(sections[m.SectionIndex].IsCurved||Conflict(sections[m.SectionIndex],profiles[m.SectionIndex],m,settings.EdgeClearanceMm,true,interrupt)!=null)continue;
   double motorStart=offsets[runs[runs.Count-1][0]]+CurveApproachMm;
   var catenaries=new List<double>{settings.CatenarySpanMm};
   if(settings.AutoCatenary){double limit=m.GlobalZMm-minimum-ReturnRollerRules.CatenaryExtraMm;if(limit>=motorStart){var zones=FreeCentres(sections,profiles,offsets,motorStart,limit+1e-6,m.YMm,m.YMm,settings,interrupt);foreach(var zone in zones){double preferred=m.GlobalZMm-settings.CatenarySpanMm;catenaries.Add(m.GlobalZMm-Math.Max(zone[0],Math.Min(zone[1],preferred)));catenaries.Add(m.GlobalZMm-zone[0]);catenaries.Add(m.GlobalZMm-zone[1]);}catenaries.Sort((a,b)=>Math.Abs(a-settings.CatenarySpanMm).CompareTo(Math.Abs(b-settings.CatenarySpanMm)));}}
   foreach(double catenary in catenaries){double maximum=Math.Min(settings.TargetPitchMm,catenary-ReturnRollerRules.CatenaryExtraMm),second=m.GlobalZMm-catenary;
    if(maximum<minimum||catenary>ReturnRollerRules.NormalMaxMm+ReturnRollerRules.CatenaryExtraMm+1e-6||second<motorStart-1e-6)continue;
    foreach(double drivenDistance in driven){var a=AutoHole(first.AxisZ+drivenDistance,CenterY(settings,first,drivenDistance),sections,offsets,settings,"Primero conducido",interrupt);
     if(sections[a.SectionIndex].IsCurved||Conflict(sections[a.SectionIndex],profiles[a.SectionIndex],a,settings.EdgeClearanceMm,true,interrupt)!=null)continue;
     var plan=new ReturnRollerPlan{AutomaticSpacing=true,SlotsInterrupted=interrupt,ReferencePitchMm=catenary-ReturnRollerRules.CatenaryExtraMm,ResolvedCatenaryMm=catenary,FirstDrivenZMm=a.GlobalZMm,FirstMotorZMm=m.GlobalZMm,SecondMotorZMm=second,CenterY=a.YMm,FirstMotorY=m.YMm,RunningDrivenY=first.RunningY,DrivenDistanceMm=drivenDistance,MotorDistanceMm=motorDistance,MinimumNormalPitchMm=Double.MaxValue};
     bool valid=true;double commonPitch=Double.PositiveInfinity;var placements=new List<MixedRunPlacement>();
     foreach(var run in runs){bool isFirst=run[0]==0,isMotor=run[1]==motorIndex;double start=isFirst?a.GlobalZMm:offsets[run[0]]+CurveApproachMm,end=isMotor?second:offsets[run[1]]+profiles[run[1]].LengthMm-CurveApproachMm;
      double y0=isMotor?m.YMm:a.YMm+(m.YMm-a.YMm)*(start-a.GlobalZMm)/(m.GlobalZMm-a.GlobalZMm),y1=isMotor?m.YMm:a.YMm+(m.YMm-a.YMm)*(end-a.GlobalZMm)/(m.GlobalZMm-a.GlobalZMm);
      if(isMotor)y1=LowerY(end,m.YMm,profiles,offsets,settings);
      if(!isFirst&&sections[run[0]-1].IncludeSlideRails){int curve=run[0]-1;y0=CurveReturnTransitionLayout.RollerY(profiles[curve],BeltLinePlan.SupportFor(sections[curve],support,profiles[curve]),settings);}
      if(!isMotor&&sections[run[1]+1].IncludeSlideRails){int curve=run[1]+1;y1=CurveReturnTransitionLayout.RollerY(profiles[curve],BeltLinePlan.SupportFor(sections[curve],support,profiles[curve]),settings);}
      if(Math.Abs(end-start)<1e-6&&Math.Abs(y0-y1)>.00001){issue="Un mismo rodillo no puede resolver dos alturas de transición distintas.";valid=false;break;}
      if(end<start-1e-6){issue="El grupo de rectos que inicia en el tramo "+(run[0]+1)+" es demasiado corto.";valid=false;break;}
      var free=Math.Abs(end-start)<1e-6?new List<double[]>():FreeLoweredRun(sections,profiles,offsets,start,end,y0,y1,settings,interrupt,isFirst?"Primero conducido":"Salida de curva",isMotor?"Segundo motriz / catenaria":"Antes de curva · 150 mm");
      List<double> positions=Math.Abs(end-start)<1e-6?new List<double>{start}:PlaceInFreeIntervals(free,start,end,minimum,maximum);
      if(positions==null){issue="No hay espacio libre entre los rodillos límite del grupo de rectos que inicia en el tramo "+(run[0]+1)+".";valid=false;break;}
      placements.Add(new MixedRunPlacement{Start=start,End=end,Y0=y0,Y1=y1,First=isFirst,Motor=isMotor,Free=free,Positions=positions});
      if(positions.Count>1)commonPitch=Math.Min(commonPitch,(end-start)/(positions.Count-1));
     }
     if(!valid)continue;
     foreach(var placement in placements){
      double start=placement.Start,end=placement.End,y0=placement.Y0,y1=placement.Y1;bool isFirst=placement.First,isMotor=placement.Motor;
      var positions=placement.Positions.Count<2?placement.Positions:PlaceInFreeIntervals(placement.Free,start,end,minimum,maximum,commonPitch);
      for(int k=0;k<positions.Count;k++){double z=positions[k],y=positions.Count==1?y0:y0+(y1-y0)*(z-start)/(end-start);string role=k==0?(isFirst?"Primero conducido":"Salida de curva"):"Retorno";if(k==positions.Count-1)role=isMotor?"Segundo motriz / catenaria":"Antes de curva · 150 mm";
       if(k>0&&k<positions.Count-1)y=LowerY(z,Math.Min(y0,y1),profiles,offsets,settings);var h=AutoHole(z,y,sections,offsets,settings,role,interrupt);string conflict=Conflict(sections[h.SectionIndex],profiles[h.SectionIndex],h,settings.EdgeClearanceMm,true,interrupt);
       if(sections[h.SectionIndex].IsCurved||conflict!=null){issue="Tramo "+(h.SectionIndex+1)+": "+conflict;valid=false;break;}plan.Holes.Add(h);
       if(k>0){double gap=z-positions[k-1];plan.MinimumNormalPitchMm=Math.Min(plan.MinimumNormalPitchMm,gap);plan.MaximumNormalPitchMm=Math.Max(plan.MaximumNormalPitchMm,gap);}
      }
      if(!valid)break;
     }
     if(!valid)continue;plan.Holes.Add(m);if(plan.MinimumNormalPitchMm==Double.MaxValue)plan.MinimumNormalPitchMm=0;plan.UniformPitchMm=Math.Abs(plan.MaximumNormalPitchMm-plan.MinimumNormalPitchMm)<1e-6?plan.MaximumNormalPitchMm:0;return plan;
    }
   }
  }return null;
 }
}
}
