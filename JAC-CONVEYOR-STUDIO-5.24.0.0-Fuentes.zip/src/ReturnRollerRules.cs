﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace PerfilBandas {
internal static class ReturnRollerRules {
    public const double SlotClearanceMm=10; // Adjustable distance from the complete seat to slots.
    public const string ReferenceId="MANUAL_USUARIO_RETORNO_MAYOR_2M_20261005";
    public const double MinimumConveyorMm=2000,DrivenMinMm=200,DrivenMaxMm=500,MotorMinMm=200,MotorMaxMm=300,NormalMaxMm=1000,CatenaryExtraMm=200,WrapMinDeg=180,WrapMaxDeg=210;
    public const string ResourceName="PerfilBandas.ManualRodillos.png";
    public static void ShowReference(IWin32Window owner) {
        using(var stream=typeof(ReturnRollerRules).Assembly.GetManifestResourceStream(ResourceName)) {
            if(stream==null){MessageBox.Show(owner,"No se encontró la imagen de referencia incluida en esta compilación.","Manual de rodillos");return;}
            using(var source=Image.FromStream(stream))using(var image=new Bitmap(source))using(var form=new Form {Text="Referencia guardada · retorno para transportadores mayores de 2 m",Size=new Size(1000,550),StartPosition=FormStartPosition.CenterParent,MinimizeBox=false}) {
                var picture=new PictureBox{Dock=DockStyle.Fill,Image=image,SizeMode=PictureBoxSizeMode.Zoom,BackColor=Color.White};
                var note=new Label{Dock=DockStyle.Bottom,Height=100,Padding=new Padding(16),Text="Conducido: 200–500 mm · Motriz: 200–300 mm · L ≤ 1000 mm · Primera catenaria: L + 200 mm · Abrazo: 180–210°.\nEn reparto variable, todos los pasos normales quedan ≤ L. La imagen no especifica diámetro del rodillo, tensión ni flecha de la banda.",Font=new Font("Segoe UI",11)};
                form.Controls.Add(picture);form.Controls.Add(note);form.ShowDialog(owner);
            }
        }
    }
}
}
