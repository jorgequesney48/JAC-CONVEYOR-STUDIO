﻿using System;using System.Collections.Generic;using System.Drawing;
namespace PerfilBandas {
internal static class ReturnRollerSeatGeometry {
 public const double EntryRadius=9,SeatRadius=6.35,HalfFlat=5,CenterDistance=15.35;
 public static double UpperJoin {get{return CenterDistance-Math.Sqrt(EntryRadius*EntryRadius-HalfFlat*HalfFlat);}}
 public static double LowerJoin {get{return -Math.Sqrt(SeatRadius*SeatRadius-HalfFlat*HalfFlat);}}
 public static double Area {get{double u=CenterDistance-UpperJoin,v=-LowerJoin;return Math.PI*EntryRadius*EntryRadius-EntryRadius*EntryRadius*Math.Asin(HalfFlat/EntryRadius)+u*HalfFlat+2*HalfFlat*(UpperJoin-LowerJoin)+SeatRadius*SeatRadius*Math.Asin(HalfFlat/SeatRadius)-v*HalfFlat;}}
 public static PointF[] Contour(ReturnRollerHole h){if(!h.Keyhole)return Circle(h.DiameterMm/2);var points=new List<PointF>();double angle=Math.Acos(HalfFlat/EntryRadius);for(int i=0;i<=160;i++){double a=-angle+(Math.PI+2*angle)*i/160;points.Add(new PointF((float)(EntryRadius*Math.Cos(a)),(float)(CenterDistance+EntryRadius*Math.Sin(a))));}double lower=Math.Acos(HalfFlat/SeatRadius);for(int i=0;i<=80;i++){double a=Math.PI+lower+(Math.PI-2*lower)*i/80;points.Add(new PointF((float)(SeatRadius*Math.Cos(a)),(float)(SeatRadius*Math.Sin(a))));}return points.ToArray();}
 public static PointF[] Circle(double r){var p=new PointF[96];for(int i=0;i<p.Length;i++){double a=2*Math.PI*i/p.Length;p[i]=new PointF((float)(r*Math.Cos(a)),(float)(r*Math.Sin(a)));}return p;}
 public static PointF[] FlatShaft(){var points=new List<PointF>();double a=Math.Acos(HalfFlat/SeatRadius);for(int i=0;i<=80;i++){double t=a+(Math.PI-2*a)*i/80;points.Add(new PointF((float)(SeatRadius*Math.Cos(t)),(float)(SeatRadius*Math.Sin(t))));}for(int i=0;i<=80;i++){double t=Math.PI+a+(Math.PI-2*a)*i/80;points.Add(new PointF((float)(SeatRadius*Math.Cos(t)),(float)(SeatRadius*Math.Sin(t))));}return points.ToArray();}
 public static double FlatArea {get{return Math.PI*SeatRadius*SeatRadius-2*(SeatRadius*SeatRadius*Math.Acos(HalfFlat/SeatRadius)-HalfFlat*Math.Sqrt(SeatRadius*SeatRadius-HalfFlat*HalfFlat));}}
 public static double FlatLength(ReturnRollerSettings s,ProfileSettings p){return s.ShaftProjectionMm+p.ThicknessMm+Math.Min(1,s.SideClearanceMm);}
}
}
