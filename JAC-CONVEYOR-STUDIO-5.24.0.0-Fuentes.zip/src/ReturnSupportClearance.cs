﻿using System;
using System.Collections.Generic;
using System.Drawing;
namespace PerfilBandas {
internal sealed class SupportMaterialBox {
    public double X0,X1,Y0,Y1,Z0,Z1;
    public SupportMaterialBox(double x0,double x1,double y0,double y1,double z0,double z1){X0=x0;X1=x1;Y0=y0;Y1=y1;Z0=z0;Z1=z1;}
}
internal sealed class ReturnSupportStation {
    public bool HasGuides;public int Section,Index;public double Z,BaseY,TopY;public ProfileSettings Profile;public SoporteSettings Support;
    public readonly List<SupportMaterialBox> Material=new List<SupportMaterialBox>();
    public double RollerGap=Double.PositiveInfinity,ReturnGap=Double.PositiveInfinity,UpperGap=Double.PositiveInfinity;
    public bool Collision {get{return RollerGap<-.01||ReturnGap<-.01||UpperGap<-.01;}}
}
internal static class UpperSupportGeometry {
    public static List<double[]> Cuts(SoporteSettings s){
        var cuts=new List<double[]>();if(!s.IncludeNylamidSlots)return cuts;
        cuts.Add(new[]{0.0,s.SlotWidthMm,s.OuterSlotDepthMm});double step=(s.LengthMm-2*s.SlotWidthMm)/(s.CenterSlotCount+1);
        for(int j=1;j<=s.CenterSlotCount;j++){double center=s.SlotWidthMm+j*step;cuts.Add(new[]{center-s.SlotWidthMm/2,center+s.SlotWidthMm/2,s.CenterSlotDepthMm});}
        cuts.Add(new[]{s.LengthMm-s.SlotWidthMm,s.LengthMm,s.OuterSlotDepthMm});return cuts;
    }
    public static ReturnSupportStation Station(ProfileSettings p,SoporteSettings s,double z,int section,int index){
        double sy=-p.SupportHoleYMm-s.EndPlateHoleYMm,top=sy+s.ActualFlange1HeightMm,backBottom=top-s.ActualFlange2HeightMm,front=z+s.WebWidthMm/2,back=z-s.WebWidthMm/2;
        var result=new ReturnSupportStation{Section=section,Index=index,Z=z,BaseY=sy,TopY=top,Profile=p,Support=s};
        var cuts=Cuts(s);var edges=new List<double>{0,s.LengthMm};foreach(var c in cuts){edges.Add(c[0]);edges.Add(c[1]);}edges.Sort();
        for(int i=1;i<edges.Count;i++){double a=edges[i-1],b=edges[i];if(b-a<1e-8)continue;double depth=0;foreach(var c in cuts)if((a+b)/2>c[0]&&(a+b)/2<c[1])depth=c[2];double high=top-depth;
            if(high>sy)result.Material.Add(new SupportMaterialBox(a,b,sy,high,front-s.ThicknessMm,front));
            if(high>backBottom)result.Material.Add(new SupportMaterialBox(a,b,backBottom,high,back,back+s.ThicknessMm));
            if(depth==0)result.Material.Add(new SupportMaterialBox(a,b,top-s.ThicknessMm,top,back,front));
        }
        return result;
    }
    public static double CylinderGap(double x0,double x1,double z,double y,double radius,SupportMaterialBox box){
        double dx=Math.Max(box.X0-x1,Math.Max(0,x0-box.X1));
        double dz=Math.Max(box.Z0-z,Math.Max(0,z-box.Z1)),dy=Math.Max(box.Y0-y,Math.Max(0,y-box.Y1));double gap=Math.Sqrt(dz*dz+dy*dy)-radius;
        if(dx>1e-8)return Math.Sqrt(dx*dx+Math.Max(0,gap)*Math.Max(0,gap));return gap;
    }
}
internal sealed class ReturnBandStrip {
    // Plane coordinates are Z horizontally and Y vertically, extruded across the band width.
    public double X0,X1;public PointF[] Polygon;public bool IsUpper;
    public ReturnBandStrip(double x0,double x1,double z0,double y0,double z1,double y1,double thickness,bool upper=false){
        X0=x0;X1=x1;IsUpper=upper;double dz=z1-z0,dy=y1-y0,length=Math.Sqrt(dz*dz+dy*dy);double nz=length==0?0:-dy/length,ny=length==0?1:Math.Abs(dz)/length;
        Polygon=new[]{new PointF((float)z0,(float)y0),new PointF((float)z1,(float)y1),new PointF((float)(z1+nz*thickness),(float)(y1+ny*thickness)),new PointF((float)(z0+nz*thickness),(float)(y0+ny*thickness))};
    }
    public double[] HeightAt(double z){var ys=new List<double>();for(int i=0;i<Polygon.Length;i++){var a=Polygon[i];var b=Polygon[(i+1)%Polygon.Length];if(z>=Math.Min(a.X,b.X)-1e-6&&z<=Math.Max(a.X,b.X)+1e-6){if(Math.Abs(a.X-b.X)<1e-8){ys.Add(a.Y);ys.Add(b.Y);}else ys.Add(a.Y+(b.Y-a.Y)*(z-a.X)/(b.X-a.X));}}if(ys.Count==0)return null;ys.Sort();return new[]{ys[0],ys[ys.Count-1]};}
    static double PointSegment(double x,double y,PointF a,PointF b){double dx=b.X-a.X,dy=b.Y-a.Y,length=dx*dx+dy*dy,t=length==0?0:Math.Max(0,Math.Min(1,((x-a.X)*dx+(y-a.Y)*dy)/length));return Math.Sqrt(Math.Pow(x-a.X-t*dx,2)+Math.Pow(y-a.Y-t*dy,2));}
    public double Gap(SupportMaterialBox box){
        double dx=Math.Max(box.X0-X1,Math.Max(0,X0-box.X1));
        var rect=new[]{new PointF((float)box.Z0,(float)box.Y0),new PointF((float)box.Z1,(float)box.Y0),new PointF((float)box.Z1,(float)box.Y1),new PointF((float)box.Z0,(float)box.Y1)};
        // Separating axis test for the rectangular material and the finite band strip.
        bool separate=false;double overlap=Double.PositiveInfinity;
        foreach(var poly in new[]{Polygon,rect})for(int k=0;k<poly.Length;k++){var a=poly[k];var b=poly[(k+1)%poly.Length];double nx=-(b.Y-a.Y),ny=b.X-a.X,length=Math.Sqrt(nx*nx+ny*ny);if(length<1e-8)continue;nx/=length;ny/=length;double a0=Double.PositiveInfinity,a1=Double.NegativeInfinity,b0=a0,b1=a1;foreach(var q in Polygon){double v=q.X*nx+q.Y*ny;a0=Math.Min(a0,v);a1=Math.Max(a1,v);}foreach(var q in rect){double v=q.X*nx+q.Y*ny;b0=Math.Min(b0,v);b1=Math.Max(b1,v);}double d=Math.Min(a1,b1)-Math.Max(a0,b0);if(d<0)separate=true;overlap=Math.Min(overlap,d);}
        double planar=0;if(separate){planar=Double.PositiveInfinity;foreach(var q in Polygon)for(int k=0;k<rect.Length;k++)planar=Math.Min(planar,PointSegment(q.X,q.Y,rect[k],rect[(k+1)%rect.Length]));foreach(var q in rect)for(int k=0;k<Polygon.Length;k++)planar=Math.Min(planar,PointSegment(q.X,q.Y,Polygon[k],Polygon[(k+1)%Polygon.Length]));}
        else planar=-Math.Max(0,overlap);
        if(dx>1e-8)return Math.Sqrt(dx*dx+Math.Max(0,planar)*Math.Max(0,planar));return planar;
    }
}
internal sealed class SupportBandDimension {
    public double X,SupportY,BandY,Gap;public bool Upper;
}
internal sealed class ReturnOverviewGeometry {
    public readonly List<ReturnSupportStation> Supports=new List<ReturnSupportStation>();public readonly List<ReturnBandStrip> Bands=new List<ReturnBandStrip>();
    public readonly List<ReturnBandStrip> Curves=new List<ReturnBandStrip>();
    public IEnumerable<ReturnBandStrip> AllBands {get{foreach(var b in Bands)yield return b;foreach(var b in Curves)yield return b;}}
    void Arc(double x0,double x1,double z,double y,double inner,double outer,double start,double sweep){
        int steps=Math.Max(1,(int)Math.Ceiling(Math.Abs(sweep)/3));
        for(int i=0;i<steps;i++){double a=(start+sweep*i/steps)*Math.PI/180,b=(start+sweep*(i+1)/steps)*Math.PI/180;
            var strip=new ReturnBandStrip(x0,x1,0,0,1,0,1);strip.Polygon=new[]{new PointF((float)(z+inner*Math.Cos(a)),(float)(y+inner*Math.Sin(a))),new PointF((float)(z+inner*Math.Cos(b)),(float)(y+inner*Math.Sin(b))),new PointF((float)(z+outer*Math.Cos(b)),(float)(y+outer*Math.Sin(b))),new PointF((float)(z+outer*Math.Cos(a)),(float)(y+outer*Math.Sin(a)))};Curves.Add(strip);
        }
    }
    // Vertical clearance in the frontal projection; distinct from the minimum 3D distance.
    public SupportBandDimension VerticalDimension(ReturnSupportStation station,bool upper){
        SupportBandDimension best=null;
        foreach(var strip in AllBands){if(strip.IsUpper!=upper)continue;var height=strip.HeightAt(station.Z);if(height==null)continue;
            foreach(var box in station.Material){double left=Math.Max(box.X0,strip.X0),right=Math.Min(box.X1,strip.X1);if(right-left<1e-6)continue;
                double supportY,bandY,gap;
                if(height[0]>=box.Y1){supportY=box.Y1;bandY=height[0];gap=bandY-supportY;}
                else if(height[1]<=box.Y0){supportY=box.Y0;bandY=height[1];gap=supportY-bandY;}
                else {supportY=Math.Min(box.Y1,height[1]);bandY=Math.Max(box.Y0,height[0]);gap=-(supportY-bandY);}
                if(best==null||gap<best.Gap)best=new SupportBandDimension{X=(left+right)/2,SupportY=supportY,BandY=bandY,Gap=gap,Upper=upper};
            }
        }
        return best;
    }
    internal static string DistanceText(double gap){if(Double.IsInfinity(gap)||Double.IsNaN(gap))return "sin recorrido";return gap<-.01?"INTERFERENCIA":""+Math.Max(0,gap).ToString("0.##")+" mm";}
    public ReturnRollerPlan Plan;public ReturnRollerSettings Settings;public ShaftPlateLayout Driven,Motor;public double Length,MotorZ;
    public int CollisionCount {get{return Supports.FindAll(s=>s.Collision).Count;}}
    public double MinimumGap {get{double result=Double.PositiveInfinity;foreach(var s in Supports)result=Math.Min(result,Math.Min(s.RollerGap,Math.Min(s.ReturnGap,s.UpperGap)));return result;}}
    public static ReturnOverviewGeometry Build(IList<BeltSectionSpec> sections,ProfileSettings[] profiles,SoporteSettings[] supports,ReturnRollerSettings settings,ReturnRollerPlan plan,ShaftPlateLayout first,ShaftPlateLayout last){
        var result=new ReturnOverviewGeometry{Plan=plan,Settings=settings,Driven=first,Motor=last};double offset=0;
        for(int i=0;i<sections.Count;i++){var p=profiles[i];var s=supports[i];int n=0;foreach(double z in SupportHoleLayout.CentersMm(p)){var station=UpperSupportGeometry.Station(p,s,offset+z,i,n++);station.HasGuides=sections[i].IncludeSlideRails&&s.IncludeNylamidSlots;result.Supports.Add(station);}double running=ShaftPlateGeometry.RunningY(p,s,s.ActualFlange1HeightMm),x0=(s.LengthMm-p.BandWidthMm)/2;result.Bands.Add(new ReturnBandStrip(x0,x0+p.BandWidthMm,i==0?first.AxisZ:offset,running,i==sections.Count-1?offset+last.AxisZ:offset+p.LengthMm,running,p.BeltThicknessMm,true));if(i==sections.Count-1)result.MotorZ=offset+last.AxisZ;offset+=p.LengthMm;}
        result.Length=offset;
        if(plan!=null&&plan.Holes.Count>0){double radius=settings.RollerDiameterMm/2,width=supports[0].LengthMm,band=profiles[0].BandWidthMm,x0=(width-band)/2,thickness=profiles[0].BeltThicknessMm;
            for(int i=1;i<plan.Holes.Count;i++){var a=plan.Holes[i-1];var b=plan.Holes[i];double dz=b.GlobalZMm-a.GlobalZMm,dy=b.YMm-a.YMm,length=Math.Sqrt(dz*dz+dy*dy),nz=-dy/length,ny=dz/length;result.Bands.Add(new ReturnBandStrip(x0,x0+band,a.GlobalZMm+radius*nz,a.YMm+radius*ny,b.GlobalZMm+radius*nz,b.YMm+radius*ny,thickness));}
            double beta=(settings.WrapAngleDeg-180)*Math.PI/180,sin=Math.Sin(beta),cos=Math.Cos(beta),rf=ReturnRollerLayout.BeltEnvelopeRadius(first),rm=ReturnRollerLayout.BeltEnvelopeRadius(last);var f=plan.Holes[0];var m=plan.Holes[plan.Holes.Count-1];
            result.Bands.Add(new ReturnBandStrip(x0,x0+band,first.AxisZ+rf*sin,first.AxisY-rf*cos,f.GlobalZMm-radius*sin,f.YMm+radius*cos,thickness));
            result.Bands.Add(new ReturnBandStrip(x0,x0+band,m.GlobalZMm+radius*sin,m.YMm+radius*cos,result.MotorZ-rm*sin,last.AxisY-rm*cos,thickness));
            result.Arc(x0,x0+band,first.AxisZ,first.AxisY,rf-first.BeltThicknessMm,rf,90,settings.WrapAngleDeg);
            result.Arc(x0,x0+band,result.MotorZ,last.AxisY,rm-last.BeltThicknessMm,rm,90,-settings.WrapAngleDeg);
            for(int i=0;i<plan.Holes.Count;i++){
                var rod=plan.Holes[i];double incoming=90+settings.WrapAngleDeg-180,outgoing=90-(settings.WrapAngleDeg-180);
                if(i>0){var prev=plan.Holes[i-1];incoming=Math.Atan2(rod.GlobalZMm-prev.GlobalZMm,-(rod.YMm-prev.YMm))*180/Math.PI;}
                if(i+1<plan.Holes.Count){var next=plan.Holes[i+1];outgoing=Math.Atan2(next.GlobalZMm-rod.GlobalZMm,-(next.YMm-rod.YMm))*180/Math.PI;}
                result.Arc(x0,x0+band,rod.GlobalZMm,rod.YMm,radius,radius+thickness,incoming,outgoing-incoming);
            }
        }
        foreach(var station in result.Supports)foreach(var box in station.Material){
            if(plan!=null)foreach(var roller in plan.Holes){var support=supports[roller.SectionIndex];station.RollerGap=Math.Min(station.RollerGap,UpperSupportGeometry.CylinderGap(settings.SideClearanceMm,support.LengthMm-settings.SideClearanceMm,roller.GlobalZMm,roller.YMm,settings.RollerDiameterMm/2,box));}
            foreach(var strip in result.AllBands){double gap=strip.Gap(box);if(strip.IsUpper)station.UpperGap=Math.Min(station.UpperGap,gap);else station.ReturnGap=Math.Min(station.ReturnGap,gap);}
        }
        return result;
    }
}
}
