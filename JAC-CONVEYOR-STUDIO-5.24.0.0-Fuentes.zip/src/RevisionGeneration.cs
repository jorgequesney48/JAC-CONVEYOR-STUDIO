using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web.Script.Serialization;
namespace PerfilBandas {
internal static partial class SolidWorksEnsambleGenerator {
    sealed class RevisionReference{public string Revision,Ensamble;}
    internal static string LastRevisionAssembly(string root){string pointer=Path.Combine(root,"ULTIMA_REVISION.json");if(File.Exists(pointer)){var reference=new JavaScriptSerializer().Deserialize<RevisionReference>(File.ReadAllText(pointer));if(reference!=null&&File.Exists(reference.Ensamble))return reference.Ensamble;}string legacy=Path.Combine(root,"BANDA_COMPLETA.SLDASM");if(File.Exists(legacy))return legacy;throw new FileNotFoundException("Aún no hay una revisión completa en esta carpeta.");}
    public static string GenerateCompleteBelt(IList<BeltSectionSpec> sections,ProfileSettings profile,SoporteSettings support,string customFolder,Action<string> progress=null,ReturnRollerSettings rollers=null,bool shaded3D=true,BearingCatalog bearings=null,string filePrefix="",VerticalSupportSettings verticalSupports=null,CancellationToken cancellation=default(CancellationToken),bool exportFlatPatterns=true){
        if(filePrefix!=null&&filePrefix.IndexOfAny(Path.GetInvalidFileNameChars())>=0)throw new ArgumentException("Prefijo de archivos no válido.");var plan=BeltDesignPlan.Build(sections,profile,support,rollers,verticalSupports,bearings);plan.RequireValid();
        string root=Path.GetFullPath(String.IsNullOrWhiteSpace(customFolder)?ProjectPaths.GetDefaultPiecesFolder():customFolder);
        string revision="R"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+"_"+Guid.NewGuid().ToString("N").Substring(0,6);
        string folder=Path.Combine(root,revision);Directory.CreateDirectory(folder);string marker=Path.Combine(folder,"INCOMPLETO.txt");File.WriteAllText(marker,"Revisión en generación. No usar para fabricación.");
        Action<string> checkpoint=step=>{cancellation.ThrowIfCancellationRequested();if(progress!=null)progress(step);};
        try {
            checkpoint("Validación final · "+revision);
            string output;using(var reuse=new CadReuseSession()){output=GenerateCompleteBeltCore(sections,profile,support,folder,checkpoint,rollers,shaded3D,bearings,revision+"_"+(filePrefix??""),verticalSupports,exportFlatPatterns);reuse.Write(folder);}
            cancellation.ThrowIfCancellationRequested();
            CompleteRevision(root,folder,revision,output,sections,verticalSupports,rollers,plan);
            return output;
        }catch(Exception e){File.WriteAllText(marker,"Generación incompleta: "+e.Message);throw;}
    }
    internal static void CompleteRevision(string root,string folder,string revision,string output,IList<BeltSectionSpec> sections,VerticalSupportSettings verticalSupports,ReturnRollerSettings rollers,BeltDesignPlan plan){
            var parts=Directory.GetFiles(folder,"*.SLDPRT",SearchOption.AllDirectories).Where(path=>!Path.GetFileName(path).StartsWith("~$",StringComparison.Ordinal)).Select(path=>new{Archivo=path.Substring(folder.Length+1),Bytes=new FileInfo(path).Length,SHA256=FileHash(path)}).ToArray();
            var json=new JavaScriptSerializer();File.WriteAllText(Path.Combine(folder,"MANIFIESTO.json"),json.Serialize(new{Version=1,Revision=revision,Estado="Completa",CreadoUTC=DateTime.UtcNow,Aplicacion=typeof(BeltDesignPlan).Assembly.GetName().Version.ToString(),Ensamble=Path.GetFileName(output),Proyecto=new{Tramos=sections,Patas=verticalSupports,Rodillos=rollers},Avisos=plan.Issues,Piezas=parts}));
            WriteBillOfMaterials(folder,sections,plan,rollers,verticalSupports);
            File.Delete(Path.Combine(folder,"INCOMPLETO.txt"));Directory.CreateDirectory(root);string pointer=Path.Combine(root,"ULTIMA_REVISION.json"),temp=pointer+".tmp";File.WriteAllText(temp,json.Serialize(new{Revision=revision,Ensamble=output}));if(File.Exists(pointer))File.Replace(temp,pointer,null);else File.Move(temp,pointer);
    }
    static string FileHash(string path){using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite))using(var hash=System.Security.Cryptography.SHA256.Create())return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-","");}
    static string Csv(object value){return "\""+Convert.ToString(value,System.Globalization.CultureInfo.InvariantCulture).Replace("\"","\"\"")+"\"";}
    static void WriteBillOfMaterials(string folder,IList<BeltSectionSpec> sections,BeltDesignPlan plan,ReturnRollerSettings rollers,VerticalSupportSettings legs){
        var rows=new List<string>{"tramo,tipo,cantidad,referencia,dimension_mm"};
        Action<int,string,int,string,double> add=(i,type,n,reference,dimension)=>rows.Add(String.Join(",",new[]{Csv(i),Csv(type),Csv(n),Csv(reference),Csv(dimension)}));
        for(int i=0;i<sections.Count;i++){
            var p=plan.Profiles[i];var s=plan.Supports[i];
            if(sections[i].IsCurved){
                var frame=CurveRoute.Frames(sections,s)[i];double sign=sections[i].Curve.TurnRight?1:-1,r=frame.Curve.InnerRadiusMm+frame.Width/2,curveAngle=sections[i].Curve.AngleDeg*Math.PI/180;
                foreach(double u in new[]{0.0,s.LengthMm}){double length=(r-sign*(u-frame.Width/2))*curveAngle;add(i+1,"Alma curva",1,"Altura "+p.WebHeightMm+" mm; espesor "+p.ThicknessMm+" mm",length);add(i+1,"Ceja curva soldada superior",1,"90 grados; ancho neto "+(p.TopFlangeMm-p.ThicknessMm)+" mm",length);add(i+1,"Ceja curva soldada inferior",1,"90 grados; ancho neto "+(p.BottomFlangeMm-p.ThicknessMm)+" mm",length);}
                add(i+1,"Soporte superior",p.SupportCount,"Soporte C",s.LengthMm);add(i+1,"Soporte inferior",p.SupportCount,"Soporte C en el mismo sentido; una ranura central",s.LengthMm);
                if(sections[i].IncludeSlideRails)for(int level=0;level<2;level++)foreach(var rail in CurveReturnLayout.Rails(s,p.LengthMm,level==1)){double length=(r-sign*(rail.FromLeftMm+SlideRailGeometry.WidthMm/2-frame.Width/2))*curveAngle;add(i+1,level==0?"Pletina superior curva":"Pletina inferior curva",1,rail.Position.ToString(),length);}
                continue;
            }
            add(i+1,"Perfil",2,sections[i].Type.ToString(),p.LengthMm);add(i+1,"Travesano",p.SupportCount,"Soporte C",s.LengthMm);
            if(sections[i].IncludeSlideRails){var range=SlideRailGeometry.Range(s,i,sections.Count,0,ShaftPlateGeometry.RailLength(sections[i],p,s));add(i+1,"Guia nylamid",s.CenterSlotCount+2,"19.05x38.1",range[1]);}
            if(ShaftPlateGeometry.Active(sections[i])){add(i+1,"Placa flecha",2,"E925",ShaftPlateLayout.ThicknessMm);if(sections[i].ShaftPlates.Bearing!=null)add(i+1,"Chumacera",2,sections[i].ShaftPlates.BearingReference,0);}
            if(ConveyorShaftGeometry.Active(sections[i])){var shaft=ConveyorShaftGeometry.Calculate(sections[i],p,s,ShaftPlateGeometry.Nominal(sections[i],p,s));add(i+1,"Flecha",1,"Cuadrada con asientos",shaft.SquareLengthMm+shaft.Settings.FreeEndLengthMm+shaft.Settings.MotorEndLengthMm);if(shaft.Settings.Sprocket!=null)add(i+1,"Sprocket",SprocketGeometry.Centers(shaft).Length,shaft.Settings.Sprocket.Reference,0);}
            var settings=legs??new VerticalSupportSettings();int count=VerticalSupportLayout.LocalStations(p,i,sections.Count).Length*2;double mountY=VerticalSupportLayout.NominalMountMm(p)[1];
            if(settings.CrossbarEnabled)add(i+1,"Travesano PTR H",count/2,settings.TubeSideInches.ToString(System.Globalization.CultureInfo.InvariantCulture)+" pulgadas; eje a "+settings.CrossbarHeightMm.ToString(System.Globalization.CultureInfo.InvariantCulture)+" mm desde base",LegCrossbarLayout.Nominal(settings,p,s,0).LengthMm);
            add(i+1,"Pata PTR",count,settings.TubeSideInches.ToString("0.0",System.Globalization.CultureInfo.InvariantCulture)+" pulgadas (largo nominal)",settings.TubeLength(mountY));add(i+1,"Placa pata",count,"Fija 45 grados",VerticalSupportSettings.PlateThicknessMm);add(i+1,"Tapa PTR",count,"Con barreno nivelador",VerticalSupportSettings.CapThicknessMm);add(i+1,"Base circular",count,"Con barrenos originales",VerticalSupportSettings.FootDiameterMm);add(i+1,"Tornillo nivelador",count,"Cilindro simplificado; diametro "+settings.ScrewDiameterMm.ToString(System.Globalization.CultureInfo.InvariantCulture),settings.ScrewLengthMm);add(i+1,"Tuerca",count*3,settings.NutReference,settings.NutThicknessMm);
        }
        if(rollers!=null&&rollers.Enabled&&rollers.PhysicalRollers){add(0,"Rodillo retorno",plan.Rollers.Holes.Count,"Simplificado",rollers.RollerDiameterMm);add(0,"Eje retorno",plan.Rollers.Holes.Count,"Retencion pendiente",rollers.ShaftDiameterMm);}
        File.WriteAllLines(Path.Combine(folder,"LISTA_PIEZAS.csv"),rows,System.Text.Encoding.UTF8);
    }
}
}

