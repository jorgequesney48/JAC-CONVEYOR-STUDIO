﻿using System;
namespace PerfilBandas {
// First slot is counted from the affected end of the straight section.
internal static class RollerSlotInterruption {
 internal static int Side(ReturnRollerHole h){
  if(h.Role=="Primero conducido"||h.Role=="Salida de curva")return -1;
  if(h.Role=="Primero motriz"||h.Role=="Antes de curva · 150 mm")return 1;
  return 0;
 }
 internal static bool Allows(ProfilePattern pattern,ProfileSlotSpec slot,ReturnRollerHole h){
  if(h.PreserveCuts||pattern.Slots.Length==0)return false;int side=Side(h);if(side==0)return false;
  var first=pattern.Slots[0];foreach(var candidate in pattern.Slots)if(side<0?candidate.CenterMm<first.CenterMm:candidate.CenterMm>first.CenterMm)first=candidate;
  return Object.ReferenceEquals(first,slot);
 }
}
}
