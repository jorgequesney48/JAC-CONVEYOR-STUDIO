using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace PerfilBandas
{
    internal sealed class SectionHoleReference : Control
    {
        public ProfileSettings Settings;
        public bool ForLegs;
        public SectionHoleReference() { DoubleBuffered = true; ResizeRedraw = true; BackColor = Color.White; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Settings == null || Width < 150 || Height < 100) return;
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            var p = Settings;
            float left = 22, right = Width - 40, top = 26;
            float bodyHeight = Math.Max(32, Math.Min(100, Height - 110));
            using (var outline = new Pen(DesignUi.Primary, 2))
            using (var fill = new SolidBrush(DesignUi.Canvas))
            using (var hole = new SolidBrush(DesignUi.Accent))
            using (var text = new SolidBrush(DesignUi.Muted))
            using (var f = new Font("Segoe UI", 9f))
            {
                g.FillRectangle(fill, left, top, right - left, bodyHeight);
                g.DrawRectangle(outline, left, top, right - left, bodyHeight);
                if (!ForLegs)
                {
                    float holeY = top + (float)(p.SupportHoleYMm / Math.Max(1, p.WebHeightMm)) * bodyHeight;
                    double[] positions; try { positions = SupportHoleLayout.CentersMm(p); } catch { positions = new double[0]; }
                    foreach (double z in positions) { float x = left + (float)(z / p.LengthMm) * (right - left); g.FillRectangle(hole, x - 3, holeY - 3, 6, 6); }
                    using (var dimension = new Pen(DesignUi.Accent, 1))
                    {
                        g.DrawLine(dimension, right + 12, top, right + 12, holeY);
                        g.DrawLine(dimension, right + 8, top, right + 16, top);
                        g.DrawLine(dimension, right + 8, holeY, right + 16, holeY);
                    }
                    g.DrawString("A", f, hole, right + 19, top + (holeY - top) / 2 - 8);
                    string caption = "A  Superior → centro: " + p.SupportHoleYMm.ToString("0.##") + " mm\nBorde → primer cuadrado: " + p.SupportHoleEdgeMm.ToString("0.##") + " mm\nCuadrado: " + p.SupportHoleSizeMm.ToString("0.##") + " × " + p.SupportHoleSizeMm.ToString("0.##") + " mm";
                    g.DrawString(caption, f, text, new RectangleF(8, top + bodyHeight + 12, Width - 16, Height - top - bodyHeight - 12));
                }
                else
                {
                    float y = top + bodyHeight / 2;
                    int start = p.EndHoleTypeLeft == "ninguno" ? 0 : p.EndHoleTypeLeft == "final" ? 2 : 1, end = p.EndHoleTypeRight == "ninguno" ? 0 : p.EndHoleTypeRight == "final" ? 2 : 1;
                    for (int i = 0; i < start; i++) g.FillRectangle(hole, left + 12 + i * 22, y - 4, 8, 8);
                    for (int i = 0; i < end; i++) g.FillRectangle(hole, right - 20 - i * 22, y - 4, 8, 8);
                    if(VerticalSupportLayout.HasCenter(p)){float mid=(left+right)/2;g.FillRectangle(hole,mid-15,y-4,8,8);g.FillRectangle(hole,mid+7,y-4,8,8);}
                    g.DrawString("Inicio: " + start, f, text, left, 4);
                    g.DrawString("Final: " + end, f, text, right - 64, 4);
                    string caption = "Extremo → centro: " + p.EndHoleEdgeMm.ToString("0.##") + " mm\nPaso exterior: " + p.EndHoleSpacingMm.ToString("0.##") + " mm\n"+(VerticalSupportLayout.HasCenter(p)?"Centro: 2 cuadrados iguales (> 2000 mm).":"En la junta: 1 de este tramo + 1 del vecino.");
                    g.DrawString(caption, f, text, new RectangleF(8, top + bodyHeight + 12, Width - 16, Height - top - bodyHeight - 12));
                }
            }
        }
    }
}
