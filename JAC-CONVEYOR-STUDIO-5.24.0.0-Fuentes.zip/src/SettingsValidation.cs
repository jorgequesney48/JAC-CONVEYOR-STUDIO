using System;

namespace PerfilBandas
{
    internal static class SettingsValidation
    {
        public static void Numbers(object settings, string label)
        {
            if (settings == null) throw new InvalidOperationException(label + ": falta la configuración.");
            foreach (var field in settings.GetType().GetFields())
            {
                if (field.IsStatic || field.FieldType != typeof(double)) continue;
                double value = (double)field.GetValue(settings);
                if (Double.IsNaN(value) || Double.IsInfinity(value) || value < 0 || value > 100000)
                    throw new InvalidOperationException(label + ": medida no válida en " + field.Name + ".");
            }
        }
        public static void Support(SoporteSettings s)
        {
            Numbers(s,"Soporte");
            if(s.LengthMm<=0||s.ThicknessMm<=0||s.BendRadiusMm<=0||s.WebWidthMm<=2*s.ThicknessMm||s.Flange1HeightMm<=s.ThicknessMm||s.Flange2HeightMm<=s.ThicknessMm||s.KFactor<=0||s.KFactor>=1)
                throw new InvalidOperationException("Soporte: revisa dimensiones, espesor, radio y factor K entre 0 y 1.");
        }
    }
}
