﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal sealed partial class CompleteBeltView
    {
        private int platePage;
        private bool plateCrossSection;
        private Label plateFeedback;
        private Label shaftDimensions;
        private void PlateRedraw() { BeginInvoke((Action)delegate { ShowCategory(category); }); }
        private void BuildPlateEditor(BeltSectionSpec section)
        {
            plateFeedback = null;shaftDimensions=null;
            if (section.Type == BeltSectionType.Intermedio) {
                Note("Las placas se ajustan en los extremos", "Este tramo es intermedio. Abre un extremo para configurar sus placas, chumaceras y flecha.");
                var driven=ViewButton("Placas del conducido",delegate{SelectSection(0);OpenDetails(9);},280);driven.Name="GoToDrivenPlates";driven.Dock=DockStyle.Top;Row(driven);
                var motor=ViewButton("Placas del motriz",delegate{SelectSection(sections.Count-1);OpenDetails(9);},280);motor.Name="GoToMotorPlates";motor.Dock=DockStyle.Top;Row(motor);return;
            }
            if (section.ShaftPlates == null) section.ShaftPlates = new ShaftPlateSettings();
            var s = section.ShaftPlates;
            if(s.Shaft==null)s.Shaft=new ConveyorShaftSettings();
            Row(BearingButton());
            if(s.Bearing!=null)Note("Chumacera seleccionada",s.Bearing.Label+" · se insertarán dos modelos 3D sobre las placas de este extremo");
            if(s.Enabled && ShaftPlateGeometry.PendingBearingMount(s)!=null) {
                Note("Montaje pendiente",ShaftPlateGeometry.PendingBearingMount(s));
                Row(ViewButton("Completar montaje de chumacera",delegate {platePage=2;PlateRedraw();},280));
            }
            Toggle("Contorno elaborado con alivio inferior", "Transición cóncava y esquinas redondeadas; el radio efectivo se limita para proteger chumacera y fijaciones.",s.SculptedContour,delegate(bool v){s.SculptedContour=v;});
            N("Radio de esquinas · mm", "Se limita al espacio real de la placa.",s,"ContourRadiusMm",2,60);
            N("Radio solicitado de alivio inferior · mm", "El sistema reduce este radio cuando lo requiere la envolvente del montaje.",s,"ReliefRadiusMm",1,150);
            N("Material alrededor de chumacera · mm", "Margen geométrico adicional para el nuevo contorno.",s,"ContourMarginMm",2,40);
            Choice("Vista de referencia", "Lateral: altura y recorte. Transversal: contacto de placas y perfiles.", new[] {"Lateral", "Transversal"}, plateCrossSection ? "Transversal" : "Lateral",
                delegate(string v) { plateCrossSection=v=="Transversal"; });
            Toggle("Generar dos placas para esta flecha", "Configuración independiente del otro extremo de la banda.", s.Enabled,
                delegate(bool v) { s.Enabled = v; if(v && ShaftPlateGeometry.PendingBearingMount(s)!=null)platePage=2; PlateRedraw(); });
            Choice("Apartado", "Elige un grupo de ajustes; la vista del eje permanece visible.",
                new[] { "Banda y flecha", "Dimensiones de placa", "Montaje de chumacera", "Flecha 3D" },
                new[] { "Banda y flecha", "Dimensiones de placa", "Montaje de chumacera", "Flecha 3D" }[platePage],
                delegate(string v) { platePage = v == "Banda y flecha" ? 0 : v == "Dimensiones de placa" ? 1 : v == "Montaje de chumacera" ? 2 : 3; PlateRedraw(); });
            if (platePage == 0) {
                Choice("Sprocket E925 · dientes", "A y B máxima proceden de la tabla del fabricante.", new[] { "12", "16", "20" }, s.Teeth.ToString(),
                    delegate(string v) { s.Teeth = Int32.Parse(v); PlateRedraw(); });
                var tooth = E925Sprocket.For(s.Teeth);
                Note("A = " + F(tooth.AMm) + " mm · B máxima = " + F(tooth.BMaxMm) + " mm",
                    "Ø primitivo " + F(tooth.PitchDiameterMm) + " mm. A baja desde el plano de apoyo del nylamid al centro de la flecha.");
                string seat = s.ShaftSeatInches == 1.125 ? "1 1/8 in · 28.575 mm" : s.ShaftSeatInches == 1.5 ? "1 1/2 in · 38.100 mm" : "1 1/4 in · 31.750 mm";
                Choice("Diámetro de asiento en chumacera", "Sólo la parte cilíndrica de la flecha. Cambiarlo requiere revisar el inserto y su paso por la placa.",
                    new[] { "1 1/8 in · 28.575 mm", "1 1/4 in · 31.750 mm", "1 1/2 in · 38.100 mm" }, seat,
                    delegate(string v) { s.ShaftSeatInches = v.StartsWith("1 1/8") ? 1.125 : v.StartsWith("1 1/2") ? 1.5 : 1.25; s.BearingDimensionsVerified = false; });
                N("B elegida · mm", "Del eje al extremo del nylamid. Las tiras se prolongan hacia la flecha para conservar B y dejar los barrenos a 2 pulgadas del perfil.", s, "BMm", 1, 100);
            } else if (platePage == 1) {
                Note("Espesor: 3/16 in · 4.7625 mm", "Solape exterior: la placa apoya sobre la cara exterior del perfil. Alivios en el solape evitan los dobleces. Extremo libre con esquinas R20.");
                Choice("Posición de la placa", "La placa debe continuar el perfil sin superponer sólidos.",
                    new[] { "Solape exterior atornillado", "Prolongación al ras" }, s.Mounting == 1 ? "Prolongación al ras" : "Solape exterior atornillado",
                    delegate(string v) { s.Mounting = v == "Prolongación al ras" ? 1 : 2; PlateRedraw(); });
                Toggle("Calcular longitud para cubrir sprocket", "Aleja el eje hasta dejar 2 pulgadas libres desde los barrenos al perfil. Prolonga sólo el nylamid, conserva B y calcula la placa con su solape.", s.AutoPlateLength,
                    delegate(bool v) { s.AutoPlateLength = v; PlateRedraw(); });
                N("Margen radial solicitado · mm", "En modo automático se limita al espacio entre el sprocket y los bordes del perfil. El margen real aparece en las referencias calculadas.", s, "CoverMarginMm", 0, 80);
                if (!s.AutoPlateLength) {
                    N("Longitud total de placa · mm", "Incluye el solape con el perfil.", s, "PlateLengthMm", 0, 1000);
                    N("Extremo exterior a eje · mm", "Desde el borde libre de la placa al centro de la flecha, hacia la banda.", s, "AxisFromPlateEndMm", 0, 900);
                }
                if (s.Mounting == 2) {
                    N("Solape mínimo sobre perfil · mm", "Se amplía para alojar el paso de Ø31.75 mm completo con 4 mm de material al borde. Los tres cuadrados quedan a la mitad del solape real.", s, "OverlapMm", 10, 300);
                    N("Lado de los 3 cuadrados · mm", "Orificios para tornillos cabeza de coche. Se perforan también los perfiles con los mismos centros. 11 × 11 mm es la propuesta editable.", s, "LapBoltDiameterMm", 3, 30);
                    Note("Unión y acceso al tornillo del soporte", "Los tres cuadrados quedan centrados en el solape y debajo del paso de Ø1.25 in (31.75 mm). La distribución vertical se adapta al espesor de banda; el paso sólo corta la placa de chumacera.");
                }
                var attachment = new TextBox { Text = s.Attachment ?? "" };
                attachment.TextChanged += delegate { s.Attachment = attachment.Text; Changed(); };
                Field("Unión al perfil", "Descripción para el plano: soldadura u otra unión. Los cordones y uniones atornilladas no se modelan automáticamente.", attachment);
            } else if(platePage==2) {
                Note("Montaje F208", "Introduce las medidas del conjunto que utilizas. El diámetro de paso en la placa puede ser mayor que el asiento de la flecha.");
                Note("Separación mínima al perfil: 2 in · 50.8 mm", "Se mide desde el borde del barreno más cercano. Los barrenos de chumacera y la abertura central sólo perforan la placa.");
                var name = new TextBox { Text = s.BearingReference ?? "" };
                name.TextChanged += delegate { s.BearingReference = name.Text; s.BearingDimensionsVerified = false; Changed(); };
                Field("Marca / referencia completa", "Incluye el inserto y su diámetro de asiento.", name);
                N("Abertura central de placa · mm", "Diámetro libre necesario para el conjunto, con holgura de montaje.", s, "OpeningDiameterMm", 0, 180);
                N("Paso cuadrado de tornillos · mm", "Distancia entre centros, horizontal y vertical. Cuatro barrenos alrededor del eje.", s, "BoltPitchMm", 0, 250);
                N("Diámetro de barrenos de placa · mm", "Diámetro elegido para los tornillos; no es el diámetro nominal de éstos.", s, "BoltDiameterMm", 0, 40);
                N("Lado exterior de chumacera · mm", "Envolvente cuadrada para verificar espacio contra bordes y dobleces.", s, "BearingEnvelopeMm", 0, 350);
                Toggle("Medidas correspondientes a mi chumacera", "Confirma las medidas del montaje para el diámetro de asiento seleccionado.", s.BearingDimensionsVerified,
                    delegate(bool v) { s.BearingDimensionsVerified = v; });
                Note("Referencia de catálogo UCF208", "JTEKT publica cuerpo de 130 mm y paso de 102 mm. Son referencias: utiliza las medidas de tu pieza para completar los campos.");
            } else {
                shaftDimensions=new Label{AutoSize=true,Dock=DockStyle.Top,MaximumSize=new Size(285,0),ForeColor=DesignUi.Primary,Margin=new Padding(0,8,0,12)};Row(shaftDimensions);
                Note("Flecha centrada", "El largo cuadrado sigue el ancho de la banda. La separación es de 10 mm desde cada cara interior de placa hasta el hombro cuadrado; el diámetro cilíndrico sigue el asiento de la chumacera.");
                Toggle("Generar y colocar flecha", "Sección cuadrada centrada a la banda, con 10 mm a la cara interior de cada placa. Cambia automáticamente con el ancho.",s.Shaft.Enabled,delegate(bool v){s.Shaft.Enabled=v;});
                Choice("Lado del motor / cuñero", "Visto según los perfiles LH y RH de la banda.",new[]{"Derecho · RH","Izquierdo · LH"},s.Shaft.MotorOnRight?"Derecho · RH":"Izquierdo · LH",delegate(string v){s.Shaft.MotorOnRight=v.StartsWith("Derecho");});
                N("Lado de sección cuadrada · mm", "38.1 mm (1.5 in), como el generador de flechas. Sólo cambia el largo automáticamente.",s.Shaft,"SquareSideMm",25,80);
                N("Longitud cilíndrica lado motor · mm", "Desde el inicio del asiento junto al cuadrado hasta el extremo exterior; incluye el cuñero.",s.Shaft,"MotorEndLengthMm",20,500);
                N("Longitud cilíndrica lado libre · mm", "Extremo opuesto sin cuñero. Debe atravesar la placa y la chumacera.",s.Shaft,"FreeEndLengthMm",20,500);
                Toggle("Cuñero en extremo del motor", "Por defecto activo en la flecha motriz y desactivado en la conducida.",s.Shaft.Keyway,delegate(bool v){s.Shaft.Keyway=v;});
                N("Ancho de cuñero · mm", "Editable según la cuña y el motor que utilizas.",s.Shaft,"KeyWidthMm",1,25);
                N("Profundidad de cuñero · mm", "Desde la cara exterior del cilindro hacia el eje.",s.Shaft,"KeyDepthMm",.1,15);
                N("Longitud de cuñero · mm", "Cuñero abierto hasta la punta, sólo en el extremo del motor.",s.Shaft,"KeyLengthMm",1,400);
            }
            plateFeedback = new Label { AutoSize = true, Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 16), ForeColor = DesignUi.Muted };
            Row(plateFeedback);
        }
        private void RefreshPlateSummary(ProfileSettings p, SoporteSettings support)
        {
            var section = sections[selected];
            if (category != 9) return;
            try {
                var layout = ShaftPlateGeometry.Nominal(section, p, support);
                derived.Text = "REFERENCIAS CALCULADAS · mm\nA " + F(layout.Sprocket.AMm) + " · B máx. " + F(layout.Sprocket.BMaxMm)
                    + "\nNylamid bajo doblez: " + F(layout.TopY-layout.RunningY) + " · eje: " + F(layout.TopY - layout.AxisY)
                    + "\nPlaca: " + F(layout.PlateLengthMm) + " × " + F(layout.HeightMm)
                    + "\nNylamid: " + F(layout.RailLengthMm) + " · margen real: " + F(layout.EffectiveCoverMarginMm);
                if(ConveyorShaftGeometry.Active(section)){var shaft=ConveyorShaftGeometry.Calculate(section,p,support,layout);if(shaftDimensions!=null)shaftDimensions.Text="Largo cuadrado calculado: "+F(shaft.SquareLengthMm)+" mm\nCentrado a la banda · 10 mm a cada placa\nAsientos Ø"+F(shaft.DiameterMm)+" mm · motor "+(shaft.Settings.MotorOnRight?"RH":"LH");derived.Text+="\nCuadrado: "+F(shaft.SquareLengthMm)+" × "+F(shaft.Settings.SquareSideMm)+" · 10 mm a cada placa";}
                if(section.ShaftPlates != null && section.ShaftPlates.Enabled)
                    derived.Text += "\nProlongación nylamid: " + F(layout.RailLengthMm-section.LengthMm);
                if(section.ShaftPlates != null && section.ShaftPlates.SculptedContour)
                    derived.Text += "\nAlivio inferior efectivo: R"+F(PlateContour.Build(section.ShaftPlates,layout).ReliefRadiusMm);
                if(section.ShaftPlates != null && section.ShaftPlates.Mounting==2)
                    derived.Text += "\nSolape: " + F(layout.OverlapMm) + " · fila al centro · paso Ø31.75";
                if(section.ShaftPlates != null && section.ShaftPlates.BoltPitchMm > 0)
                    derived.Text += "\nBarreno a perfil: " + F(ShaftPlateGeometry.BearingHoleClearance(section,layout)) + " · mínimo 50.8";
                if (plateFeedback != null && !plateFeedback.IsDisposed) {
                    ShaftPlateGeometry.Validate(section, p, support, layout);
                    plateFeedback.ForeColor = DesignUi.Accent;
                    plateFeedback.Text = section.ShaftPlates.Enabled ? "Medidas válidas para generar. La altura final se verifica en el CAD." : "Placas desactivadas. Puedes preparar los ajustes antes de activarlas.";
                }
            } catch (Exception ex) {
                if (plateFeedback != null && !plateFeedback.IsDisposed) { plateFeedback.ForeColor = Color.Firebrick; plateFeedback.Text = ex.Message; }
            }
        }
    }
}
