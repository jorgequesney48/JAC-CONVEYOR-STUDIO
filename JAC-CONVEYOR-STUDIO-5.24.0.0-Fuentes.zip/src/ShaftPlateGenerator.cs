﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal sealed class ProfilePlateDatums
    {
        public double InnerX, OuterX, TopY, WebTopY, WebBottomY;
        public Face2 OuterFace;
    }

    internal static class SolidWorksShaftPlateGenerator
    {
        public static ProfilePlateDatums Measure(ModelDoc2 model, ProfileSettings p, bool right)
        {
            var result = new ProfilePlateDatums { TopY = Double.NegativeInfinity };
            var webs = new List<Face2>();
            foreach (object item in (object[])((PartDoc)model).GetBodies2((int)swBodyType_e.swSolidBody, true))
                foreach (object value in (object[])((Body2)item).GetFaces()) {
                    var face = (Face2)value; var surface = (Surface)face.GetSurface();
                    if (!surface.IsPlane()) continue;
                    var b = (double[])face.GetBox();
                    if (b[5]-b[2] < p.LengthMm/1000*.8) continue;
                    if (b[3]-b[0] < .000001 && b[4]-b[1] > p.WebHeightMm/1000*.7) webs.Add(face);
                    if (b[4]-b[1] < .000001 && b[3]-b[0] > p.ThicknessMm/1000*2) result.TopY = Math.Max(result.TopY, b[4]*1000);
                }
            if (webs.Count < 2 || Double.IsInfinity(result.TopY)) throw new InvalidOperationException("No se pudieron medir el alma y el doblez superior del perfil.");
            webs.Sort(delegate(Face2 a, Face2 b) { return ((double[])a.GetBox())[0].CompareTo(((double[])b.GetBox())[0]); });
            result.OuterFace = right ? webs[webs.Count-1] : webs[0];
            var outer = (double[])result.OuterFace.GetBox();
            var inner = (double[])(right ? webs[0] : webs[webs.Count-1]).GetBox();
            result.OuterX = outer[0]*1000; result.InnerX = inner[0]*1000;
            result.WebTopY = outer[4]*1000; result.WebBottomY = outer[1]*1000;
            return result;
        }
        public static double Volume(ModelDoc2 model)
        {
            double volume = 0;
            foreach (object body in (object[])((PartDoc)model).GetBodies2((int)swBodyType_e.swSolidBody, true))
                volume += ((double[])((Body2)body).GetMassProperties(1))[3];
            return volume;
        }
        public static void CutLapHoles(SldWorks sw, ModelDoc2 model, ProfileSettings p, BeltSectionSpec section,
            ShaftPlateLayout layout, ProfilePlateDatums datums, string outputPath)
        {
            ShaftPlateGeometry.ValidateBearingHoleClearance(section,layout);
            if (section.ShaftPlates.Mounting != 2) return;
            double before = Volume(model);
            model.ClearSelection2(true);
            if (!((Entity)datums.OuterFace).Select(false)) throw new InvalidOperationException("No se pudo seleccionar el alma para los tres barrenos de solape.");
            var sketch = model.SketchManager; sketch.InsertSketch(true);
            var active = (Sketch)model.GetActiveSketch2(); var math = (MathUtility)sw.GetMathUtility();
            double radius = section.ShaftPlates.LapBoltDiameterMm / 2000;
            sketch.AddToDB = true;
            foreach (double y in ShaftPlateGeometry.LapHoleYs(layout)) {
                var point = (MathPoint)math.CreatePoint(new[] {datums.OuterX/1000, y/1000, layout.LapHoleZ/1000});
                var a = (double[])((MathPoint)point.MultiplyTransform(active.ModelToSketchTransform)).ArrayData;
                Square(sketch,a[0],a[1],radius);
            }
            double removedArea=3*4*radius*radius;
            sketch.AddToDB = false;
            var cut = model.FeatureManager.FeatureCut4(true, false, false,
                (int)swEndConditions_e.swEndCondBlind, (int)swEndConditions_e.swEndCondBlind,
                p.ThicknessMm/500, .01, false,false,false,false, 0,0, false,false,false,false,
                true,true,true,true,true,false, (int)swStartConditions_e.swStartSketchPlane,0,false,true);
            if (cut == null) throw new InvalidOperationException("No se crearon los barrenos de unión de placa a perfil.");
            cut.Name = "Tres_Barrenos_Placa_Flecha"; model.EditRebuild3();
            double expected = removedArea*p.ThicknessMm/1000;
            if (Math.Abs((before-Volume(model))-expected) > Math.Max(expected*.002, 1e-12))
                throw new InvalidOperationException("Los barrenos de solape coinciden con un corte existente o salen del alma. Ajusta solape o ranuras antes de fabricar.");
            int err=0, warn=0;
            if (!model.SaveAs4(outputPath,0,(int)swSaveAsOptions_e.swSaveAsOptions_Silent,ref err,ref warn) || err != 0)
                throw new InvalidOperationException("No se guardaron los barrenos de solape del perfil: " + err);
        }

        // u is measured from the exterior end of the plate towards the belt. Both sides share this contour.
        public static string Create(SldWorks sw,BeltSectionSpec section,ShaftPlateLayout l,bool right,string folder,string stem){string path=Path.Combine(folder,stem+".SLDPRT");return CadReuseSession.Part("Placa_flecha",new{section.Type,section.ShaftPlates,l,right},path,()=>{CreateUnique(sw,section,l,right,folder,stem);sw.CloseDoc(Path.GetFileName(path));});}
        static string CreateUnique(SldWorks sw, BeltSectionSpec section, ShaftPlateLayout l, bool right,
            string folder, string stem)
        {
            var s = section.ShaftPlates;
            ShaftPlateGeometry.ValidateBearingHoleClearance(section,l);
            string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
            var model = (ModelDoc2)sw.NewDocument(template, 0,0,0);
            if (model == null) throw new InvalidOperationException("SOLIDWORKS no creó la placa de flecha.");
            Feature plane = null;
            foreach (string name in new[] {"Plano Alzado","Front Plane","Plano frontal","Plano Frontal","Alzado"}) {
                plane = (Feature)((PartDoc)model).FeatureByName(name);
                if (plane != null && plane.Select2(false,0)) break;
            }
            if (plane == null) throw new InvalidOperationException("No se encontró el plano Alzado de la placa.");
            var sketch = model.SketchManager; sketch.InsertSketch(true); sketch.AddToDB = true;
            // Map canonical u to local x so local +z extrusion always goes outside the conveyor.
            double orientation = (right ? -1 : 1) * (section.Type == BeltSectionType.Conducido ? 1 : -1);
            Func<double,double> x = delegate(double u) { return orientation*(u-l.PlateLengthMm/2)/1000; };
            Func<double,double> y = delegate(double absolute) { return (absolute-l.TopY)/1000; };
            Action<double,double,double,double> line = delegate(double a,double b,double c,double d) { sketch.CreateLine(x(a),y(b),0,x(c),y(d),0); };
            var contour=PlateContour.Build(s,l);
            foreach(var edge in contour.Edges) {
                if(edge.Radius==0) line(edge.X1,edge.Y1,edge.X2,edge.Y2);
                else sketch.CreateArc(x(edge.CX),y(edge.CY),0,x(edge.X1),y(edge.Y1),0,x(edge.X2),y(edge.Y2),0,(short)(Math.Sign(edge.Sweep)*orientation));
            }
            Action<double,double,double> circle = delegate(double u, double v, double diameter) { sketch.CreateCircleByRadius(x(u),y(v),0,diameter/2000); };
            circle(l.AxisFromEndMm,l.AxisY,s.OpeningDiameterMm);
            foreach (int a in new[] {-1,1}) foreach (int b in new[] {-1,1})
                circle(l.AxisFromEndMm+a*s.BoltPitchMm/2,l.AxisY+b*s.BoltPitchMm/2,s.BoltDiameterMm);
            if (s.Mounting == 2) foreach (double hy in ShaftPlateGeometry.LapHoleYs(l))
                Square(sketch,x(section.Type==BeltSectionType.Conducido ? l.LapHoleZ-l.PlateStartZ : l.PlateEndZ-l.LapHoleZ),y(hy),s.LapBoltDiameterMm/2000);
            if(l.IncludeSupportHeadClearance)
                circle(section.Type==BeltSectionType.Conducido ? l.SupportHeadZ-l.PlateStartZ : l.PlateEndZ-l.SupportHeadZ,l.SupportHeadY,ShaftPlateGeometry.SupportHeadClearanceDiameterMm);
            sketch.AddToDB = false;
            var feature = model.FeatureManager.FeatureExtrusion2(true,false,false,(int)swEndConditions_e.swEndCondBlind,0,
                ShaftPlateLayout.ThicknessMm/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,
                (int)swStartConditions_e.swStartSketchPlane,0,false);
            if (feature == null) throw new InvalidOperationException("No se pudo extruir la placa y sus barrenos.");
            feature.Name = "Placa_Flecha_3_16"; model.EditRebuild3();
            object[] bodies = (object[])((PartDoc)model).GetBodies2((int)swBodyType_e.swSolidBody,true);
            if (bodies == null || bodies.Length != 1) throw new InvalidOperationException("La placa debe formar un solo sólido.");
            double area = contour.AreaMm2
                - Math.PI/4*(s.OpeningDiameterMm*s.OpeningDiameterMm+4*s.BoltDiameterMm*s.BoltDiameterMm
                    )-(s.Mounting == 2 ? 3*s.LapBoltDiameterMm*s.LapBoltDiameterMm : 0)
                -(l.IncludeSupportHeadClearance ? Math.PI/4*ShaftPlateGeometry.SupportHeadClearanceDiameterMm*ShaftPlateGeometry.SupportHeadClearanceDiameterMm : 0);
            if (Math.Abs(Volume(model)*1e9-area*ShaftPlateLayout.ThicknessMm) > .1)
                throw new InvalidOperationException("El volumen de la placa no coincide con el contorno y sus perforaciones.");
            dynamic props = ((dynamic)model.Extension).CustomPropertyManager("");
            props.Add3("Tipo",30,"Placa de flecha E925",2);
            props.Add3("Espesor_mm",30,"4.7625",2);
            props.Add3("Chumacera",30,s.BearingReference,2);
            props.Add3("Asiento_in",30,s.ShaftSeatInches.ToString(CultureInfo.InvariantCulture),2);
            props.Add3("A_mm",30,l.Sprocket.AMm.ToString(CultureInfo.InvariantCulture),2);
            props.Add3("B_mm",30,s.BMm.ToString(CultureInfo.InvariantCulture),2);
            props.Add3("Paso_Cabeza_Soporte_mm",30,l.IncludeSupportHeadClearance ? ShaftPlateGeometry.SupportHeadClearanceDiameterMm.ToString(CultureInfo.InvariantCulture) : "No interfiere",2);
            props.Add3("Descenso_Barrenos_Solape_mm",30,"25.4",2);
            props.Add3("Solape_real_mm",30,l.OverlapMm.ToString(CultureInfo.InvariantCulture),2);
            string path=Path.Combine(folder,stem+".SLDPRT");
            if (model.SaveAs3(path,0,1)!=0 || !File.Exists(path)) throw new InvalidOperationException("No se guardó la placa de flecha.");
            return path;
        }
        private static void Square(SketchManager sketch,double x,double y,double half)
        {
            sketch.CreateLine(x-half,y-half,0,x+half,y-half,0);
            sketch.CreateLine(x+half,y-half,0,x+half,y+half,0);
            sketch.CreateLine(x+half,y+half,0,x-half,y+half,0);
            sketch.CreateLine(x-half,y+half,0,x-half,y-half,0);
        }
    }
}
