using System;
using System.Collections.Generic;

namespace PerfilBandas
{
    internal sealed class E925Sprocket
    {
        public readonly int Teeth;
        public readonly double PitchDiameterMm, AMm, BMaxMm;
        private E925Sprocket(int teeth, double diameter, double a, double b)
        { Teeth = teeth; PitchDiameterMm = diameter; AMm = a; BMaxMm = b; }
        public static E925Sprocket For(int teeth)
        {
            switch (teeth) {
                case 12: return new E925Sprocket(12, 96.59, 42, 47);
                case 16: return new E925Sprocket(16, 128.15, 58, 54);
                case 20: return new E925Sprocket(20, 159.81, 73, 59);
                default: throw new InvalidOperationException("E925: sólo hay datos de fabricante para 12, 16 o 20 dientes.");
            }
        }
    }

    internal sealed class ShaftPlateSettings
    {
        // Opt-in preserves previously saved projects. Unspecified dimensions are not fabrication defaults.
        public bool Enabled;
        public bool SculptedContour = true;
        public double ContourRadiusMm = 20;
        public double ReliefRadiusMm = 60;
        public double ContourMarginMm = 8;
        public int Teeth = 16;
        public double ShaftSeatInches = 1.25;
        public double BMm = 45;
        public double PlateLengthMm = 0;
        public double AxisFromPlateEndMm = 0;
        public bool AutoPlateLength = true;
        public double CoverMarginMm = 10;
        public double OverlapMm = 50.8;
        public double LapBoltDiameterMm = 11;
        public double OpeningDiameterMm = 0;
        public double BoltPitchMm = 0;
        public double BoltDiameterMm = 0;
        public double BearingEnvelopeMm = 0;
        public string BearingReference = "F208 / inserto por definir";
        public bool BearingDimensionsVerified;
        public BearingCatalogEntry Bearing;
        public ConveyorShaftSettings Shaft=new ConveyorShaftSettings();
        public int Mounting = 2; // 1 flush extension; 2 exterior lap, requested by user.
        public string Attachment = "Solape exterior atornillado, tres barrenos";
        public ShaftPlateSettings Copy() { var s=(ShaftPlateSettings)MemberwiseClone();s.Bearing=Bearing==null?null:Bearing.Copy();s.Shaft=Shaft==null?new ConveyorShaftSettings():Shaft.Copy();return s; }
    }

    internal sealed class ShaftPlateLayout
    {
        public const double ThicknessMm = 4.7625;
        public E925Sprocket Sprocket;
        public double BeltThicknessMm;
        public double RunningY, AxisY, AxisZ, TopY, HeightMm, PlateStartZ, PlateEndZ;
        public double PlateLengthMm, AxisFromEndMm, OverlapMm, WebTopY, WebBottomY;
        public double RailStartZ, RailEndZ;
        public double LapHoleZ, SupportHeadZ, SupportHeadY;
        public double LapHoleSizeMm, EffectiveCoverMarginMm;
        public bool IncludeSupportHeadClearance;
        public double RailLengthMm { get { return RailEndZ - RailStartZ; } }
        public double PlateCenterZ { get { return (PlateStartZ + PlateEndZ) / 2; } }
    }

    internal static class ShaftPlateGeometry
    {
        public const double MinimumBearingHoleClearanceMm = 50.8;
        public const double LapHoleDropMm = 25.4, SupportHeadClearanceDiameterMm = 31.75;
        private static double EndSupportDistance(BeltSectionSpec section,ProfileSettings p) {
            var centers=SupportHoleLayout.CentersMm(p);
            return section.Type==BeltSectionType.Motriz?p.LengthMm-centers[centers.Length-1]:centers[0];
        }
        public static bool NeedsHeadClearance(BeltSectionSpec section,ProfileSettings p)
        { var s=section.ShaftPlates ?? new ShaftPlateSettings(); return s.Mounting==2 && EndSupportDistance(section,p)-SupportHeadClearanceDiameterMm/2<s.OverlapMm; }
        public static double EffectiveOverlap(BeltSectionSpec section,ProfileSettings p)
        {
            var s=section.ShaftPlates ?? new ShaftPlateSettings();
            if(s.Mounting!=2) return 0;
            // Keep the full access circle inside the lap with 4 mm material at its inner edge.
            return NeedsHeadClearance(section,p) ? Math.Max(s.OverlapMm,EndSupportDistance(section,p)+SupportHeadClearanceDiameterMm/2+4) : s.OverlapMm;
        }
        public static double AxisDistanceFromProfile(BeltSectionSpec section, ShaftPlateLayout layout)
        { return section.Type == BeltSectionType.Conducido ? -layout.AxisZ : layout.AxisZ-section.LengthMm; }
        public static double RequiredAxisDistance(ShaftPlateSettings s)
        { return MinimumBearingHoleClearanceMm + Math.Max(s.OpeningDiameterMm/2, s.BoltPitchMm/2+s.BoltDiameterMm/2); }
        public static double BearingHoleClearance(BeltSectionSpec section, ShaftPlateLayout layout)
        { return AxisDistanceFromProfile(section,layout)-Math.Max(section.ShaftPlates.OpeningDiameterMm/2,section.ShaftPlates.BoltPitchMm/2+section.ShaftPlates.BoltDiameterMm/2); }
        public static void ValidateBearingHoleClearance(BeltSectionSpec section, ShaftPlateLayout layout)
        {
            if (BearingHoleClearance(section,layout) < MinimumBearingHoleClearanceMm-.001)
                throw new InvalidOperationException("Placas: deja 50.8 mm libres entre el borde del barreno de chumacera más cercano y el extremo del perfil. Este montaje requiere eje a "
                    + RequiredAxisDistance(section.ShaftPlates).ToString("0.###") + " mm del perfil. Activa el cálculo automático o aumenta la longitud de placa; el nylamid se prolonga conservando B.");
        }
        internal static string PendingBearingMount(ShaftPlateSettings s) {
            var missing=new System.Collections.Generic.List<string>();
            if(String.IsNullOrWhiteSpace(s.BearingReference) || s.BearingReference.IndexOf("por definir",StringComparison.OrdinalIgnoreCase)>=0)missing.Add("referencia completa");
            if(s.OpeningDiameterMm<=0)missing.Add("abertura central");
            if(s.BoltPitchMm<=0)missing.Add("paso de tornillos");
            if(s.BoltDiameterMm<=0)missing.Add("diámetro de barrenos");
            if(s.BearingEnvelopeMm<=0)missing.Add("lado exterior de chumacera");
            if(!s.BearingDimensionsVerified)missing.Add("confirmar medidas correspondientes a tu chumacera");
            return missing.Count==0?null:String.Join(", ",missing.ToArray());
        }
        public static bool Active(BeltSectionSpec section) { return section.ShaftPlates != null && section.ShaftPlates.Enabled; }
        public static double RunningY(ProfileSettings profile, SoporteSettings support, double topLocalMm)
        {
            return -profile.SupportHoleYMm - support.EndPlateHoleYMm + topLocalMm
                - support.CenterSlotDepthMm + SlideRailGeometry.HeightMm;
        }
        public static void FiniteSettings(ShaftPlateSettings settings)
        {
            foreach (var field in typeof(ShaftPlateSettings).GetFields())
                if (field.FieldType == typeof(double)) {
                    double value = (double)field.GetValue(settings);
                    if (Double.IsNaN(value) || Double.IsInfinity(value) || value < 0 || value > 100000)
                        throw new InvalidOperationException("Placas: medida no válida en " + field.Name + ".");
                }
        }

        // Nominal model used by preview. CAD passes the measured support top and profile datums.
        public static ShaftPlateLayout Calculate(BeltSectionSpec section, ProfileSettings profile, SoporteSettings support,
            double supportTopMm, double plateTopMm, double straightHeightMm)
        {
            var s = section.ShaftPlates ?? new ShaftPlateSettings();
            FiniteSettings(s);
            var result = new ShaftPlateLayout { BeltThicknessMm=profile.BeltThicknessMm,Sprocket = E925Sprocket.For(s.Teeth),
                RunningY = RunningY(profile, support, supportTopMm), TopY = plateTopMm, HeightMm = straightHeightMm,
                RailStartZ = 0, RailEndZ = section.LengthMm };
            result.AxisY = result.RunningY - result.Sprocket.AMm;
            double availableMargin = Math.Min(result.TopY-result.AxisY, result.HeightMm-result.TopY+result.AxisY)-result.Sprocket.PitchDiameterMm/2;
            result.EffectiveCoverMarginMm = s.AutoPlateLength ? Math.Min(s.CoverMarginMm,Math.Max(0,availableMargin)) : s.CoverMarginMm;
            // Until mounting is specified, preview only displays a plate around the axis.
            double overlap = EffectiveOverlap(section,profile);
            double endDistance = s.AutoPlateLength ? Math.Max(result.Sprocket.PitchDiameterMm / 2 + result.EffectiveCoverMarginMm, s.BearingEnvelopeMm/2+20) : s.AxisFromPlateEndMm;
            double axisDistance = Math.Max(s.BMm, RequiredAxisDistance(s));
            double length = s.AutoPlateLength ? endDistance + axisDistance + overlap : s.PlateLengthMm;
            result.PlateLengthMm = length; result.AxisFromEndMm = endDistance; result.OverlapMm = overlap;
            result.WebTopY = plateTopMm - pTopClear(profile);
            result.WebBottomY = result.WebTopY - straightHeightMm;
            if (section.Type == BeltSectionType.Conducido) {
                result.PlateStartZ = -length + overlap; result.PlateEndZ = overlap;
                result.AxisZ = result.PlateStartZ + endDistance;
            } else {
                result.PlateStartZ = section.LengthMm - overlap; result.PlateEndZ = section.LengthMm + length - overlap;
                result.AxisZ = result.PlateEndZ - endDistance;
            }
            if (Active(section)) {
                if (section.Type == BeltSectionType.Conducido) result.RailStartZ = Math.Min(0,result.AxisZ+s.BMm);
                else if (section.Type == BeltSectionType.Motriz) result.RailEndZ = Math.Max(section.LengthMm,result.AxisZ-s.BMm);
            }
            result.IncludeSupportHeadClearance=NeedsHeadClearance(section,profile);
            double supportDistance=EndSupportDistance(section,profile);
            double lapDistance=overlap/2;
            result.LapHoleSizeMm=s.LapBoltDiameterMm;
            result.LapHoleZ=section.Type==BeltSectionType.Conducido ? lapDistance : section.LengthMm-lapDistance;
            result.SupportHeadZ=section.Type==BeltSectionType.Conducido ? supportDistance : section.LengthMm-supportDistance;
            result.SupportHeadY=-profile.SupportHoleYMm;
            return result;
        }
        private static double pTopClear(ProfileSettings p) { return ProfileBendGeometry.Tangent(p,true); }
        public static double[] LapHoleYs(ShaftPlateLayout l)
        {
            double top = Math.Min(l.TopY, l.WebTopY) - .25;
            double bottom = Math.Max(l.TopY - l.HeightMm, l.WebBottomY) + .25;
            double lower = bottom + (top-bottom)*.25-LapHoleDropMm;
            double middle = bottom + (top-bottom)*.5-LapHoleDropMm;
            double upper = bottom + (top-bottom)*.75-LapHoleDropMm;
            double half=l.LapHoleSizeMm/2, spacing=l.LapHoleSizeMm+8;
            lower=Math.Max(lower,bottom+half+4);
            upper=Math.Min(upper,top-half-4);
            if(l.IncludeSupportHeadClearance)
                upper=Math.Min(upper,l.SupportHeadY-SupportHeadClearanceDiameterMm/2-half-4);
            if(upper-lower < 2*spacing)
                throw new InvalidOperationException("Placas: no caben tres cuadrados centrados debajo del paso de la cabeza. Aumenta la altura del perfil o revisa el espesor de la banda.");
            middle=Math.Max(lower+spacing,Math.Min(middle,upper-spacing));
            return new[] {lower,middle,upper};
        }
        public static ShaftPlateLayout Nominal(BeltSectionSpec section, ProfileSettings p, SoporteSettings s)
        {
            // Clear straight height between bend tangencies, for an outward bent open sheet profile.
            double tangentTop = ProfileBendGeometry.Tangent(p,true);
            double tangentBottom = (p.BendRadiusMm + p.ThicknessMm) * Math.Tan((180 - p.BottomAngleDeg) * Math.PI / 360);
            return Calculate(section, p, s, s.ActualFlange1HeightMm, 0, p.WebHeightMm - tangentTop - tangentBottom);
        }
        public static void Validate(BeltSectionSpec section, ProfileSettings p, SoporteSettings support, ShaftPlateLayout layout)
        {
            if (!Active(section)) return;
            var s = section.ShaftPlates;
            FiniteSettings(s);
            if(s.Bearing!=null){s.Bearing.Validate();if(!s.Bearing.Matches(s))throw new InvalidOperationException("Chumacera: las medidas cambiaron después de seleccionarla. Vuelve a seleccionarla o elige Usar medidas manuales en el menú Chumacera.");}
            if (section.Type == BeltSectionType.Intermedio) throw new InvalidOperationException("Placas: sólo se colocan en los tramos conducido y motriz.");
            if (!String.Equals(p.BeltModelName, "E925", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Placas: la tabla disponible corresponde únicamente a E925.");
            if (!section.IncludeSlideRails) throw new InvalidOperationException("Placas: activa las pletinas para establecer el nivel de rodadura.");
            SlideRailGeometry.Placements(support, section.LengthMm);
            if (Math.Abs(p.TopAngleDeg - 90) > .01) throw new InvalidOperationException("Placas: se requiere el doblez superior de 90°.");
            if (s.ShaftSeatInches != 1.125 && s.ShaftSeatInches != 1.25 && s.ShaftSeatInches != 1.5)
                throw new InvalidOperationException("Placas: elige un asiento de 1 1/8, 1 1/4 o 1 1/2 pulgadas.");
            if (s.BMm <= 0 || s.BMm > layout.Sprocket.BMaxMm)
                throw new InvalidOperationException("Placas: B debe ser mayor que cero y no superar " + layout.Sprocket.BMaxMm + " mm.");
            if (s.Mounting != 1 && s.Mounting != 2) throw new InvalidOperationException("Placas: define la unión de la placa con el extremo del perfil.");
            if (layout.PlateLengthMm <= 0 || layout.AxisFromEndMm <= 0 || layout.AxisFromEndMm >= layout.PlateLengthMm)
                throw new InvalidOperationException("Placas: define longitud y distancia del eje desde el extremo exterior.");
            if (s.Mounting == 2 && (s.OverlapMm <= s.LapBoltDiameterMm + 2 * ShaftPlateLayout.ThicknessMm || layout.OverlapMm >= section.LengthMm || s.LapBoltDiameterMm <= 0))
                throw new InvalidOperationException("Placas: revisa el solape y el diámetro de sus tres barrenos.");
            if(s.Mounting==2) {
                double lapTop=Math.Min(layout.TopY,layout.WebTopY)-.25,lapBottom=Math.Max(layout.TopY-layout.HeightMm,layout.WebBottomY)+.25;
                foreach(double y in LapHoleYs(layout))
                    if(y+s.LapBoltDiameterMm/2>=lapTop || y-s.LapBoltDiameterMm/2<=lapBottom)
                        throw new InvalidOperationException("Placas: los cuadrados bajados 25.4 mm salen del alma. Revisa la altura de la placa.");
                if(layout.IncludeSupportHeadClearance && (layout.SupportHeadY+SupportHeadClearanceDiameterMm/2>=lapTop || layout.SupportHeadY-SupportHeadClearanceDiameterMm/2<=lapBottom || EndSupportDistance(section,p)<SupportHeadClearanceDiameterMm/2+.25))
                    throw new InvalidOperationException("Placas: el paso circular de 31.75 mm para la cabeza del soporte sale del borde. Revisa la altura o margen del barreno de soporte.");
            }
            string pending=PendingBearingMount(s);
            if(pending!=null)throw new InvalidOperationException("Placas: en Detalles > Placas / ejes > Montaje de chumacera, completa: " + pending + ".");
            if (s.OpeningDiameterMm <= s.ShaftSeatInches * 25.4 || s.BoltPitchMm <= 0 || s.BoltDiameterMm <= 0 || s.BearingEnvelopeMm <= s.BoltPitchMm)
                throw new InvalidOperationException("Placas: revisa abertura de paso, paso de tornillos, diámetro de barrenos y tamaño de chumacera.");
            if(ConveyorShaftGeometry.Active(section))ConveyorShaftGeometry.Calculate(section,p,support,layout);
            PlateContour.Build(s,layout);
            ValidateBearingHoleClearance(section,layout);
            double halfPitch = s.BoltPitchMm / 2, radius = s.BoltDiameterMm / 2;
            double axisDepth = layout.TopY - layout.AxisY;
            double envelope = Math.Max(s.BearingEnvelopeMm / 2, Math.Max(s.OpeningDiameterMm / 2, halfPitch + radius + ShaftPlateLayout.ThicknessMm));
            if (axisDepth < envelope || layout.HeightMm - axisDepth < envelope || layout.AxisFromEndMm < envelope + 4 || layout.PlateLengthMm - layout.AxisFromEndMm < envelope + 4)
                throw new InvalidOperationException("Placas: la chumacera o sus barrenos exceden el borde de la placa. Revisa longitud, posición del eje o nivel del soporte; A se conserva.");
            double coverRadius = layout.Sprocket.PitchDiameterMm / 2 + layout.EffectiveCoverMarginMm;
            if (axisDepth+.001 < coverRadius || layout.HeightMm - axisDepth+.001 < coverRadius || layout.AxisFromEndMm+.001 < coverRadius)
                throw new InvalidOperationException("Placas: el margen de cobertura excede el contorno. Ajusta el margen o el nivel de soporte manteniendo A.");
            double actualB=section.Type==BeltSectionType.Conducido ? layout.RailStartZ-layout.AxisZ : layout.AxisZ-layout.RailEndZ;
            if (actualB<=0 || actualB>layout.Sprocket.BMaxMm || Math.Abs(actualB-s.BMm)>.01)
                throw new InvalidOperationException("Placas: posición longitudinal incompatible con B desde el extremo del nylamid. Adapta la longitud de placa o activa el cálculo automático.");
            if (s.OpeningDiameterMm / 2 + radius + ShaftPlateLayout.ThicknessMm >= Math.Sqrt(2) * halfPitch)
                throw new InvalidOperationException("Placas: la abertura central se aproxima demasiado a los barrenos de fijación.");
            if (layout.RailLengthMm <= 0) throw new InvalidOperationException("Placas: el recorte elimina toda la pletina.");
            double[] centers = SupportHoleLayout.CentersMm(p);
            if (layout.RailStartZ > centers[0] - support.WebWidthMm / 2 || layout.RailEndZ < centers[centers.Length - 1] + support.WebWidthMm / 2)
                throw new InvalidOperationException("Placas: el recorte de nylamid deja sin apoyo uno de los soportes C. Ajusta B o la posición del eje.");
        }
        public static double RailLength(BeltSectionSpec section, ProfileSettings p, SoporteSettings support)
        { return Active(section) ? Nominal(section,p,support).RailLengthMm : section.LengthMm; }
    }
}
