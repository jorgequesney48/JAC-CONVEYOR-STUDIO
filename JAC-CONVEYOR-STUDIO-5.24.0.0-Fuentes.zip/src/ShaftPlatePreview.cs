﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal sealed class ShaftPlatePreview : Control
    {
        public BeltSectionSpec Section;
        public ProfileSettings Profile;
        public SoporteSettings Support;
        public bool CrossSection;
        public ShaftPlatePreview() { DoubleBuffered = true; ResizeRedraw = true; BackColor = Color.White; AccessibleName = "Vista lateral de placa, eje y nylamid con cotas A y B"; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Section == null || Profile == null || Support == null || Width < 160 || Height < 100) return;
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            if (Section.Type == BeltSectionType.Intermedio) { Text(g, "Sin flecha en este tramo", 10, 10, Width - 20, 45, DesignUi.Muted); return; }
            try {
                var s = Section.ShaftPlates ?? new ShaftPlateSettings();
                var l = ShaftPlateGeometry.Nominal(Section, Profile, Support);
                if (CrossSection) { DrawCrossSection(g,l,s); return; }
                bool complete = l.PlateLengthMm > 0 && l.AxisFromEndMm > 0;
                if (!complete) {
                    Text(g, "Define la longitud de placa y la posición longitudinal del eje para ver el montaje.", 12, 8, Width - 24, 85, DesignUi.Muted);
                    DrawReference(g, l, 100, Math.Max(60, Height - 125)); return;
                }
                Text(g, Section.Type + " · vista lateral", 8, 0, Width - 16, 26, DesignUi.Ink);
                float scale = (float)Math.Min((Width - 65) / (l.PlateLengthMm + 100), (Height - 110) / Math.Max(l.HeightMm, l.TopY - l.AxisY + l.Sprocket.PitchDiameterMm / 2));
                if (scale <= 0) return;
                float x = 28, top = 55, w = (float)l.PlateLengthMm * scale, h = (float)l.HeightMm * scale;
                // Local view is reflected at the driven end: exterior always on the left, belt interior on right.
                float axisX = x + (float)l.AxisFromEndMm * scale;
                float axisY = top + (float)(l.TopY - l.AxisY) * scale;
                float railY = top + (float)(l.TopY - l.RunningY) * scale;
                float railX = axisX + (float)s.BMm * scale;
                using (var fill = new SolidBrush(Color.FromArgb(228, 236, 242)))
                using (var line = new Pen(DesignUi.Ink, 1.4f)) {
                    float join=x+w-(float)l.OverlapMm*scale;
                    using(var contour=PlateContour.Build(s,l).Drawing(x,top,scale,l.TopY)) {
                        g.FillPath(fill,contour);g.DrawPath(line,contour);
                    }
                    g.DrawLine(line, join, top, Width - 12, top);
                    g.DrawLine(line, join, top + h, Width - 12, top + h);
                    if(s.Mounting==2) {
                        using(var dash=new Pen(DesignUi.Muted,1){DashStyle=DashStyle.Dash})g.DrawLine(dash,join,top,join,top+h);
                        foreach(double hy in ShaftPlateGeometry.LapHoleYs(l)) {
                            double u=Section.Type==BeltSectionType.Conducido ? l.LapHoleZ-l.PlateStartZ : l.PlateEndZ-l.LapHoleZ;
                            float cr=(float)s.LapBoltDiameterMm*scale/2,cx=x+(float)u*scale,cy=top+(float)(l.TopY-hy)*scale;
                            g.FillRectangle(Brushes.White,cx-cr,cy-cr,2*cr,2*cr);g.DrawRectangle(line,cx-cr,cy-cr,2*cr,2*cr);
                        }
                        if(l.IncludeSupportHeadClearance) {
                            double u=Section.Type==BeltSectionType.Conducido ? l.SupportHeadZ-l.PlateStartZ : l.PlateEndZ-l.SupportHeadZ;
                            float r=(float)ShaftPlateGeometry.SupportHeadClearanceDiameterMm*scale/2,cx=x+(float)u*scale,cy=top+(float)(l.TopY-l.SupportHeadY)*scale;
                            g.FillEllipse(Brushes.White,cx-r,cy-r,2*r,2*r);g.DrawEllipse(line,cx-r,cy-r,2*r,2*r);
                        }
                    }
                    if (s.OpeningDiameterMm > 0) {
                        float r = (float)s.OpeningDiameterMm * scale / 2;
                        g.FillEllipse(Brushes.White, axisX-r, axisY-r, 2*r, 2*r); g.DrawEllipse(line, axisX-r, axisY-r, 2*r, 2*r);
                    }
                    if (s.BoltPitchMm > 0 && s.BoltDiameterMm > 0) foreach (int a in new[] {-1,1}) foreach (int b in new[] {-1,1}) {
                        float r = (float)s.BoltDiameterMm * scale / 2, d = (float)s.BoltPitchMm * scale / 2;
                        g.FillEllipse(Brushes.White, axisX+a*d-r, axisY+b*d-r, 2*r, 2*r);
                        g.DrawEllipse(line, axisX+a*d-r, axisY+b*d-r, 2*r, 2*r);
                    }
                }
                using (var sprocket = new Pen(Color.FromArgb(166, 111, 34), 1.5f) { DashStyle = DashStyle.Dash }) {
                    float r = (float)l.Sprocket.PitchDiameterMm * scale / 2;
                    g.DrawEllipse(sprocket, axisX-r, axisY-r, 2*r, 2*r);
                }
                using (var rail = new Pen(Color.FromArgb(35, 94, 164), 5)) g.DrawLine(rail, railX, railY+2.5f, Width-12, railY+2.5f);
                using(var belt=new SolidBrush(Color.FromArgb(70,196,150,65)))
                    g.FillRectangle(belt,railX,railY-(float)Profile.BeltThicknessMm*scale,Math.Max(0,Width-12-railX),(float)Profile.BeltThicknessMm*scale);
                using (var axis = new Pen(DesignUi.Accent, 1) { DashStyle = DashStyle.Dash }) {
                    g.DrawLine(axis, axisX, 30, axisX, top+h+10); g.DrawLine(axis, 12, axisY, Width-12, axisY);
                    g.DrawLine(axis, 17, railY, 17, axisY);
                    g.DrawLine(axis, axisX, 35, railX, 35);
                }
                Text(g, "B " + s.BMm.ToString("0.#"), (int)axisX, 12, 90, 20, DesignUi.Accent);
                Text(g, "A " + l.Sprocket.AMm, 20, (int)((railY+axisY)/2), 80, 22, DesignUi.Accent);
                Text(g, "Azul: nylamid · dorado: banda " + Profile.BeltThicknessMm.ToString("0.#") + " mm\nSeparación al doblez: " + (l.TopY-l.RunningY).ToString("0.#") + " mm · círculo: Ø primitivo\n" + (Section.Type == BeltSectionType.Motriz ? "Espejo local: interior de banda a la derecha" : "Interior de banda a la derecha"), 8, Height-65, Width-16, 65, DesignUi.Muted);
            } catch (Exception ex) { Text(g, ex.Message, 10, 10, Width-20, Height-20, Color.Firebrick); }
        }
        private void DrawReference(Graphics g, ShaftPlateLayout l, int top, int height)
        {
            int mid = Width / 2, y = top + Math.Min(height-25, 80);
            using (var blue = new Pen(Color.FromArgb(35,94,164), 5)) g.DrawLine(blue, mid+30, top, Width-20, top);
            using (var pen = new Pen(DesignUi.Accent, 1.5f)) { g.DrawLine(pen, mid, top, mid, y); g.DrawEllipse(pen, mid-12,y-12,24,24); }
            Text(g, "A = " + l.Sprocket.AMm + " mm", 10, top+20, mid-12, 40, DesignUi.Accent);
        }
        private void DrawCrossSection(Graphics g,ShaftPlateLayout l,ShaftPlateSettings s)
        {
            Text(g,"SECCIÓN TRANSVERSAL · esquema",8,0,Width-16,32,DesignUi.Ink);
            float scale=(float)Math.Min((Width-80)/Support.LengthMm,(Height-110)/Profile.WebHeightMm);
            float left=35,right=left+(float)Support.LengthMm*scale,top=55,bottom=top+(float)Profile.WebHeightMm*scale;
            float plate=Math.Max(4,(float)ShaftPlateLayout.ThicknessMm*scale),web=Math.Max(2,(float)Profile.ThicknessMm*scale);
            using(var profile=new Pen(DesignUi.Ink,web)) {
                g.DrawLine(profile,left,top,left,bottom);g.DrawLine(profile,right,top,right,bottom);
                g.DrawLine(profile,left-20,top,left,top);g.DrawLine(profile,right,top,right+20,top);
                g.DrawLine(profile,left-17,bottom+12,left,bottom);g.DrawLine(profile,right,bottom,right+17,bottom+12);
            }
            using(var fill=new SolidBrush(DesignUi.Accent)) {
                g.FillRectangle(fill,left-web/2-plate,top+5,plate,bottom-top-10);
                g.FillRectangle(fill,right+web/2,top+5,plate,bottom-top-10);
            }
            float rail=top+(float)(l.TopY-l.RunningY)*scale,axis=top+(float)(l.TopY-l.AxisY)*scale;
            using(var blue=new Pen(Color.FromArgb(35,94,164),4)) g.DrawLine(blue,left+7,rail,right-7,rail);
            using(var dash=new Pen(DesignUi.Accent,1){DashStyle=DashStyle.Dash})g.DrawLine(dash,15,axis,Width-15,axis);
            Text(g,"Eje · Ø asiento "+(s.ShaftSeatInches*25.4).ToString("0.###")+" mm",12,(int)axis+5,Width-24,45,DesignUi.Accent);
            Text(g,"Verde: placas exteriores de 3/16 in\nAzul: plano de apoyo del nylamid\nEspesores ampliados para su lectura",8,Height-70,Width-16,70,DesignUi.Muted);
        }
        private new void Text(Graphics g, string text, int x, int y, int w, int h, Color color)
        { TextRenderer.DrawText(g, text, Font, new Rectangle(x,y,Math.Max(1,w),Math.Max(1,h)), color, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix); }
    }
}
