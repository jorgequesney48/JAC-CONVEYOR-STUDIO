﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal static class SolidWorksSlideRailGenerator
    {
        public static string CreateCenter(double sectionLengthMm, string folder, string stem, SldWorks instance = null)
        {
            return Create(sectionLengthMm, folder, stem, SlideRailPosition.Center, instance);
        }

        static string CreateUnique(double sectionLengthMm,string folder,string stem,SlideRailPosition position,SldWorks instance=null,System.Collections.Generic.List<SlideRailRelief> reliefs=null){
            string path=Path.Combine(folder,stem+".SLDPRT");return CadReuseSession.Part("Pletina_recta",new{sectionLengthMm,position,Relieves=reliefs},path,()=>CreateUnique(sectionLengthMm,folder,stem,position,instance,reliefs));
        }
        public static string Create(double sectionLengthMm, string folder, string stem, SlideRailPosition position, SldWorks instance = null,
            System.Collections.Generic.List<SlideRailRelief> reliefs = null)
        {
            if (Double.IsNaN(sectionLengthMm)||Double.IsInfinity(sectionLengthMm)||sectionLengthMm <= 0 || String.IsNullOrWhiteSpace(folder) || String.IsNullOrWhiteSpace(stem))
                throw new ArgumentException("Largo, carpeta y nombre de pletina deben estar definidos.");
            SldWorks sw = instance;
            if (sw == null)
            {
                Type type = Type.GetTypeFromProgID("SldWorks.Application");
                if (type == null) throw new InvalidOperationException("SOLIDWORKS no está instalado.");
                try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
                catch { sw = (SldWorks)Activator.CreateInstance(type); }
            }
            string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
            if (String.IsNullOrWhiteSpace(template) || !File.Exists(template))
                throw new InvalidOperationException("Configura una plantilla predeterminada de pieza en SOLIDWORKS.");
            ModelDoc2 model = (ModelDoc2)sw.NewDocument(template, 0, 0, 0);
            if (model == null) throw new InvalidOperationException("SOLIDWORKS no creó la pletina de deslizamiento.");
            PartDoc part = (PartDoc)model;
            model.ClearSelection2(true);
            Feature plane = null;
            foreach (string name in new[] { "Plano Alzado", "Front Plane", "Plano frontal", "Plano Frontal", "Alzado" })
            {
                try { plane = (Feature)part.FeatureByName(name); if (plane != null && plane.Select2(false, 0)) break; }
                catch (COMException) { plane = null; }
            }
            if (plane == null) throw new InvalidOperationException("No se encontró el plano Alzado para la pletina.");
            SketchManager sketch = model.SketchManager;
            sketch.InsertSketch(true);
            sketch.AddToDB = true;
            PointF[] points = position == SlideRailPosition.Center ? SlideRailGeometry.CenterSectionMm() :
                SlideRailGeometry.SideSectionMm(position == SlideRailPosition.Right);
            for (int i = 0; i < points.Length; i++)
            {
                PointF a = points[i], b = points[(i + 1) % points.Length];
                sketch.CreateLine(a.X / 1000.0, a.Y / 1000.0, 0, b.X / 1000.0, b.Y / 1000.0, 0);
            }
            sketch.AddToDB = false;
            Feature feature = model.FeatureManager.FeatureExtrusion2(
                true, false, false,
                (int)swEndConditions_e.swEndCondBlind, 0,
                sectionLengthMm / 1000.0, 0,
                false, false, false, false,
                0, 0, false, false, false, false,
                true, true, true,
                (int)swStartConditions_e.swStartSketchPlane, 0, false);
            if (feature == null) throw new InvalidOperationException("SOLIDWORKS no extruyó la pletina de deslizamiento.");
            try { feature.Name = position == SlideRailPosition.Center ? "Pletina_Central" : "Pletina_Lateral"; } catch { }
            model.EditRebuild3();
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            if (bodies == null || bodies.Length != 1) throw new InvalidOperationException("La pletina no tiene un sólido único.");
            double[] box = (double[])((Body2)bodies[0]).GetBodyBox();
            if (box == null || Math.Abs((box[3] - box[0]) * 1000 - SlideRailGeometry.WidthMm) > .1 ||
                Math.Abs((box[4] - box[1]) * 1000 - SlideRailGeometry.HeightMm) > .1 ||
                Math.Abs((box[5] - box[2]) * 1000 - sectionLengthMm) > .1)
                throw new InvalidOperationException("La pletina no tiene las dimensiones solicitadas.");
            if(reliefs!=null && reliefs.Count>0) AddReliefs(model,reliefs);
            dynamic props = ((dynamic)model.Extension).CustomPropertyManager("");
            props.Add3("Tipo", 30, position == SlideRailPosition.Center ? "Pletina central de deslizamiento" : "Pletina lateral " + position, 2);
            if (position != SlideRailPosition.Center) {
                props.Add3("RebajeAncho_mm", 30, "12.7", 2);
                props.Add3("RebajeProfundidad_mm", 30, "6.35", 2);
            }
            props.Add3("Material", 30, "Nylamid / UHMWPE", 2);
            props.Add3("Ancho_mm", 30, SlideRailGeometry.WidthMm.ToString(CultureInfo.InvariantCulture), 2);
            props.Add3("Alto_mm", 30, SlideRailGeometry.HeightMm.ToString(CultureInfo.InvariantCulture), 2);
            props.Add3("Largo_mm", 30, sectionLengthMm.ToString(CultureInfo.InvariantCulture), 2);
            props.Add3("Alojamientos_Plaquitas",30,(reliefs==null ? 0 : reliefs.Count).ToString(),2);
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder, stem + ".SLDPRT");
            int error = model.SaveAs3(path, 0, 2);
            if (error != 0 || !File.Exists(path)) throw new InvalidOperationException("No se guardó la pletina central (error " + error + ").");
            return path;
        }
        private static void AddReliefs(ModelDoc2 model,System.Collections.Generic.List<SlideRailRelief> reliefs)
        {
            double before=SolidWorksShaftPlateGenerator.Volume(model), removed=0;
            int index=0;
            foreach(var r in reliefs) {
                model.ClearSelection2(true); Feature front=null;
                foreach(string name in new[]{"Plano Alzado","Front Plane","Plano frontal","Plano Frontal","Alzado"}) {
                    front=(Feature)((PartDoc)model).FeatureByName(name); if(front!=null && front.Select2(false,0)) break;
                }
                if(front==null) throw new InvalidOperationException("No se encontró Alzado para alojamientos del nylamid.");
                var plane=(RefPlane)model.FeatureManager.InsertRefPlane(8,(r.StartZ+r.EndZ)/2000,0,0,0,0);
                if(plane==null || !((Feature)plane).Select2(false,0)) throw new InvalidOperationException("No se creó el plano de alojamiento de plaquita.");
                var sketch=model.SketchManager;sketch.InsertSketch(true);sketch.AddToDB=true;
                double a=(r.FromX==0 ? -.1 : r.FromX)/1000,b=(r.ToX==SlideRailGeometry.WidthMm ? r.ToX+.1 : r.ToX)/1000;
                double bottom=-.1/1000,top=r.DepthMm/1000;
                sketch.CreateLine(a,bottom,0,b,bottom,0);sketch.CreateLine(b,bottom,0,b,top,0);
                sketch.CreateLine(b,top,0,a,top,0);sketch.CreateLine(a,top,0,a,bottom,0);sketch.AddToDB=false;
                double half=(r.EndZ-r.StartZ)/2000;
                var cut=model.FeatureManager.FeatureCut4(false,false,false,
                    (int)swEndConditions_e.swEndCondBlind,(int)swEndConditions_e.swEndCondBlind,half,half,
                    false,false,false,false,0,0,false,false,false,false,false,true,true,true,true,false,
                    (int)swStartConditions_e.swStartSketchPlane,0,false,true);
                if(cut==null) throw new InvalidOperationException("No se creó el alojamiento local en la tira de nylamid.");
                cut.Name="Alojamiento_Plaquita_"+(++index);model.EditRebuild3();
                removed+=(r.ToX-r.FromX)*r.DepthMm*(r.EndZ-r.StartZ)/1e9;
            }
            if(Math.Abs(before-SolidWorksShaftPlateGenerator.Volume(model)-removed)>Math.Max(removed*.002,1e-12))
                throw new InvalidOperationException("El volumen de los alojamientos de nylamid no corresponde a las plaquitas originales.");
        }
    }
}
