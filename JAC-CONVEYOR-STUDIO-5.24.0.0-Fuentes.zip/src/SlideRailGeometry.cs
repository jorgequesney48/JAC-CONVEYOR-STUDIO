﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace PerfilBandas
{
    internal enum SlideRailPosition { Left, Center, Right }

    internal sealed class SlideRailPlacement
    {
        public SlideRailPosition Position;
        public double FromLeftMm;
        public double LengthMm;
        public int Index;
    }
    internal sealed class SlideRailRelief
    {
        public double FromX, ToX, DepthMm, StartZ, EndZ;
    }

    internal static class SlideRailGeometry
    {
        public const double WidthMm = 19.05;  // 3/4 in
        public const double DefaultSlotAllowanceMm = 1;
        public const double HeightMm = 38.10; // 1 1/2 in

        public static PointF[] CenterSectionMm()
        {
            return new[] {
                new PointF(0, 0), new PointF((float)WidthMm, 0),
                new PointF((float)WidthMm, (float)HeightMm), new PointF(0, (float)HeightMm)
            };
        }
        public static List<SlideRailRelief> EndPlateReliefs(ProfileSettings p,SoporteSettings support,SlideRailPosition position,double measuredTopMm,double railStartMm=0)
        {
            var result=new List<SlideRailRelief>();
            if(position==SlideRailPosition.Center || !support.IncludeEndPlates) return result;
            double depth=support.Flange1HeightMm-SoporteSettings.EndPlateTopReliefMm-(measuredTopMm-support.OuterSlotDepthMm);
            if(depth<=.01) return result;
            depth+=.2;
            double width=support.EndPlateThicknessMm+.2;
            if(width>=WidthMm || depth>=31.75) throw new InvalidOperationException("El alojamiento de plaquita excede la sección de nylamid lateral.");
            foreach(double center in SupportHoleLayout.CentersMm(p)) {
                double a=Math.Max(0,center-support.WebWidthMm/2+support.ThicknessMm-.2);
                double b=Math.Min(p.LengthMm,center+support.WebWidthMm/2-support.ThicknessMm+.2);
                if(b>a) result.Add(new SlideRailRelief {FromX=position==SlideRailPosition.Left ? 0 : WidthMm-width,
                    ToX=position==SlideRailPosition.Left ? width : WidthMm, DepthMm=depth, StartZ=a-railStartMm, EndZ=b-railStartMm});
            }
            return result;
        }

        // Drawing supplied by the user: full 0.75 × 1.50 in section, with a
        // 0.50 in wide and 0.25 in deep recess at the inner upper corner.
        public static PointF[] SideSectionMm(bool right)
        {
            float w = (float)WidthMm, h = (float)HeightMm;
            float lip = 6.35f, recess = 6.35f;
            PointF[] contour = {
                new PointF(0, 0), new PointF(w, 0),
                new PointF(w, h - recess), new PointF(lip, h - recess),
                new PointF(lip, h), new PointF(0, h)
            };
            if (right) for (int i = 0; i < contour.Length; i++) contour[i].X = w - contour[i].X;
            return contour;
        }

        // Centers come from the same construction used by AddNylamidSlots.
        public static List<SlideRailPlacement> Placements(SoporteSettings support, double sectionLengthMm)
        {
            if (support == null) throw new ArgumentNullException("support");
            SettingsValidation.Numbers(support,"Soporte");
            if (Double.IsNaN(sectionLengthMm)||Double.IsInfinity(sectionLengthMm)||sectionLengthMm <= 0) throw new InvalidOperationException("La pletina necesita un largo de tramo positivo y finito.");
            if (!support.IncludeNylamidSlots) throw new InvalidOperationException("Activa las ranuras del soporte antes de añadir pletinas.");
            if(support.SlotAllowanceMm>5||Math.Abs(support.SlotWidthMm-(WidthMm+support.SlotAllowanceMm))>.01)
                throw new InvalidOperationException("Ranura nylamid: el ancho debe ser 19.05 mm + la holgura aprobada (0–5 mm).");
            double sideContact=support.CurveGuideBandThicknessMm>0?CurveUpperGuideGeometry.ContactHeightMm(support.CurveGuideBandThicknessMm):31.75;
            if (Math.Abs(support.OuterSlotDepthMm - (support.CenterSlotDepthMm + sideContact - HeightMm)) > .01)
                throw new InvalidOperationException("Las profundidades del soporte no nivelan la superficie de apoyo de las pletinas laterales y centrales.");
            if (support.LengthMm <= 2 * WidthMm || support.CenterSlotCount < 0 || support.CenterSlotCount > 8)
                throw new InvalidOperationException("El soporte es demasiado corto o tiene una cantidad de ranuras centrales inválida.");

            var result = new List<SlideRailPlacement>();
            result.Add(new SlideRailPlacement { Position = SlideRailPosition.Left, FromLeftMm = 0, LengthMm = sectionLengthMm, Index = 0 });
            double step = (support.LengthMm - 2 * support.SlotWidthMm) / (support.CenterSlotCount + 1);
            for (int i = 1; i <= support.CenterSlotCount; i++)
                result.Add(new SlideRailPlacement { Position = SlideRailPosition.Center,
                    FromLeftMm = support.SlotWidthMm-WidthMm/2 + i * step, LengthMm = sectionLengthMm, Index = i });
            result.Add(new SlideRailPlacement { Position = SlideRailPosition.Right,
                FromLeftMm = support.LengthMm - WidthMm, LengthMm = sectionLengthMm, Index = support.CenterSlotCount + 1 });
            return result;
        }
        public static double[] Range(SoporteSettings support,int index,int count,double start,double length){
            double gap=support.GuideJointGapMm+length*support.GuideExpansionPerK*support.GuideTemperatureRiseK;
            if(Double.IsNaN(gap)||Double.IsInfinity(gap)||gap<0||gap>length/3)throw new InvalidOperationException("Junta nylamid: separación térmica no válida. Revisa coeficiente del proveedor y temperatura.");
            double left=index>0?gap/2:0,right=index<count-1?gap/2:0;return new[]{start+left,length-left-right};
        }
    }
}
