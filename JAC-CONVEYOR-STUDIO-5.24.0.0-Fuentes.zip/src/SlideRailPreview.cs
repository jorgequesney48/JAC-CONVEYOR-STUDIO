﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PerfilBandas
{
    internal sealed class SlideRailPreview : Control
    {
        public SoporteSettings Support;
        public SlideRailPreview() { DoubleBuffered = true; ResizeRedraw = true; BackColor = Color.White; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Support == null || Width < 200 || Height < 120) return;
            Graphics g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            float scale = Math.Min(2.7f, (Height - 85) / (Support.CurveGuideBandThicknessMm>0?55f:44f)), yBase = Height - 40;
            float xLeft = 18, xMiddle = Width / 2f - 25, xRight = Width - 86;
            DrawRail(g, Support.CurveGuideBandThicknessMm>0?CurveUpperGuideGeometry.SectionMm(Support.CurveGuideBandThicknessMm,false):SlideRailGeometry.SideSectionMm(false), xLeft, yBase, scale, Color.FromArgb(0, 117, 94));
            DrawRail(g, SlideRailGeometry.CenterSectionMm(), xMiddle, yBase + (float)(Support.CenterSlotDepthMm - Support.OuterSlotDepthMm) * scale,
                scale, Color.FromArgb(39, 93, 142));
            DrawRail(g, Support.CurveGuideBandThicknessMm>0?CurveUpperGuideGeometry.SectionMm(Support.CurveGuideBandThicknessMm,true):SlideRailGeometry.SideSectionMm(true), xRight, yBase, scale, Color.FromArgb(0, 117, 94));
            float sideTop = yBase - (float)(Support.CurveGuideBandThicknessMm>0?CurveUpperGuideGeometry.ContactHeightMm(Support.CurveGuideBandThicknessMm):31.75) * scale;
            float middleTop = yBase + (float)(Support.CenterSlotDepthMm - Support.OuterSlotDepthMm) * scale - 38.1f * scale;
            using (var pen = new Pen(Color.FromArgb(175, 116, 34), 1.5f) { DashStyle = DashStyle.Dash })
            {
                g.DrawLine(pen, 8, middleTop, Width - 8, middleTop);
                if (Math.Abs(sideTop - middleTop) > 1) g.DrawLine(pen, 8, sideTop, Width - 8, sideTop);
            }
            TextRenderer.DrawText(g, "LATERAL LH", Font, new Rectangle((int)xLeft, 4, 90, 20), DesignUi.Ink);
            TextRenderer.DrawText(g, "CENTRAL", Font, new Rectangle((int)xMiddle, 4, 90, 20), DesignUi.Ink);
            TextRenderer.DrawText(g, "LATERAL RH", Font, new Rectangle((int)xRight, 4, 90, 20), DesignUi.Ink);
            string status = Math.Abs(sideTop - middleTop) < 1 ? "Caras de rodadura niveladas" : "Desnivel: " + (Math.Abs(sideTop - middleTop) / scale).ToString("0.##") + " mm";
            TextRenderer.DrawText(g, status, Font, new Rectangle(12, Height - 23, Width - 24, 20),
                Math.Abs(sideTop - middleTop) < 1 ? DesignUi.Accent : Color.Firebrick);
        }
        private static void DrawRail(Graphics g, PointF[] section, float x, float bottom, float scale, Color color)
        {
            PointF[] points = new PointF[section.Length];
            for (int i = 0; i < points.Length; i++) points[i] = new PointF(x + section[i].X * scale, bottom - section[i].Y * scale);
            using (var fill = new SolidBrush(Color.FromArgb(220, color)))
            using (var pen = new Pen(color, 1.5f)) { g.FillPolygon(fill, points); g.DrawPolygon(pen, points); }
        }
    }
}
