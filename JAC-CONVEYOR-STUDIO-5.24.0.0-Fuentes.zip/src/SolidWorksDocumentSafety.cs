using System;
using System.Collections.Generic;
using System.IO;
using SolidWorks.Interop.sldworks;

namespace PerfilBandas
{
    internal static class SolidWorksDocumentSafety
    {
        public static void Check(SldWorks sw, IEnumerable<string> targets)
        {
            var names=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
            foreach(string target in targets)names[Path.GetFileNameWithoutExtension(target)]=Path.GetFullPath(target);
            var documents=(object[])sw.GetDocuments();
            if(documents==null)return;
            foreach(ModelDoc2 doc in documents)
            {
                string path=doc.GetPathName(),name=Path.GetFileNameWithoutExtension(String.IsNullOrEmpty(path)?doc.GetTitle():path),expected;
                if(!names.TryGetValue(name,out expected))continue;
                if(String.IsNullOrEmpty(path)||!String.Equals(Path.GetFullPath(path),expected,StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("SOLIDWORKS tiene abierto otro archivo llamado "+name+" en una carpeta distinta. Cierra ese modelo antes de generar para evitar mezclar piezas.");
                if(doc.GetSaveFlag())throw new InvalidOperationException("Hay cambios sin guardar en "+name+". Guarda o cierra ese modelo antes de regenerarlo.");
            }
        }
    }
}
