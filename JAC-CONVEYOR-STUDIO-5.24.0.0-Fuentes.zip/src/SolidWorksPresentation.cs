using System;
using System.IO;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    internal static class SolidWorksPresentation
    {
        public static void Apply(ModelDoc2 model, bool shaded)
        {
            model.ClearSelection2(true);
            var scene = model.ConfigurationManager.ActiveConfiguration.GetScene();
            if (scene != null)
            {
                scene.FloorReflections = false; scene.FloorShadows = false;
                scene.BackgroundType = (int)swSceneBackgroundType_e.swBackgroundType_Graduated;
                scene.BackgroundTopGradientColor = 0xFFFFFF;
                scene.BackgroundBottomGradientColor = 0xEEEAE6;
                if (!scene.Modify()) throw new InvalidOperationException("No se pudo actualizar la escena del documento.");
            }
            var view = (ModelView)model.ActiveView;
            if (view != null)
            {
                view.DisplayMode = (int)(shaded ? swViewDisplayMode_e.swViewDisplayMode_ShadedWithEdges : swViewDisplayMode_e.swViewDisplayMode_HiddenLinesRemoved);
                view.RemovePerspective();
            }
            model.ShowNamedView2("*Isométrica", (int)swStandardViews_e.swIsometricView);
            model.ViewZoomtofit2(); model.GraphicsRedraw2();
        }
        public static void Open(string path, bool shaded)
        {
            if (!File.Exists(path)) throw new InvalidOperationException("Genera primero el ensamble o elige una carpeta que lo contenga.");
            var sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application");
            int error=0,warning=0;
            var model = (ModelDoc2)sw.OpenDoc6(path,(int)swDocumentTypes_e.swDocASSEMBLY,(int)swOpenDocOptions_e.swOpenDocOptions_Silent,"",ref error,ref warning);
            if (model==null) throw new InvalidOperationException("No se pudo abrir el ensamble ("+error+").");
            sw.ActivateDoc3(model.GetTitle(),false,0,ref error); Apply(model,shaded);
        }
    }
}
