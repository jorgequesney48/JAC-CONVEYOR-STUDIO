﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

namespace PerfilBandas
{
    // ═════════════════════════════════════════════════════════════════════════════
    // PARÁMETROS DE CONFIGURACIÓN DEL SOPORTE C
    // ═════════════════════════════════════════════════════════════════════════════
    internal sealed class SoporteSettings
    {
        public const double EndPlateTopReliefMm = 12.7;
        public double EndPlateDropMm { get { return IncludeEndPlates && IncludeNylamidSlots ? Math.Max(0,OuterSlotDepthMm-EndPlateTopReliefMm) : 0; } }
        public double ActualFlange1HeightMm { get { return Flange1HeightMm+EndPlateDropMm; } }
        public double ActualFlange2HeightMm { get { return Flange2HeightMm+EndPlateDropMm; } }
        public SoporteSettings Copy() { return (SoporteSettings)MemberwiseClone(); }
        // Dimensiones generales
        public double LengthMm = 545.0;             // Longitud total del canal C (mm)
        public double WebWidthMm = 50.80;           // Ancho del lomo superior (mm) [2.00 pulgadas]
        public double Flange1HeightMm = 38.10;      // Altura pestaña 1 / frontal (mm) [1.50 pulgadas]
        public double Flange2HeightMm = 50.80;      // Altura pestaña 2 / trasera (mm) [2.00 pulgadas]
        public string Gauge = "12";                 // Calibre de lámina estándar (12 para soporte según arquitectura)
        public double ThicknessMm = 2.66;           // Espesor asociado (mm)
        public double BendRadiusMm = 1.50;          // Radio interior de doblez (mm)
        public double KFactor = 0.45;               // Factor K de desarrollo

        // Vinculación con banda transportadora
        public string BeltModelName = "E925";
        public double BandWidthMm = 520.0;
        public bool AutoSyncWithBandWidth = true;

        // Ranuras superiores para guías de Nylamid (peine)
        public bool IncludeNylamidSlots = true;
        public double SlotWidthMm = SlideRailGeometry.WidthMm+SlideRailGeometry.DefaultSlotAllowanceMm;
        public double SlotAllowanceMm = SlideRailGeometry.DefaultSlotAllowanceMm;
        public double GuideJointGapMm;
        public double GuideExpansionPerK;
        public double GuideTemperatureRiseK;
        [System.Web.Script.Serialization.ScriptIgnore]
        public double CurveGuideBandThicknessMm; // Resolved upper curved guide section, not a project input.
        public double OuterSlotDepthMm = 19.05;     // 0.75 pulgadas: alinea el rebaje lateral con la cara central
        public double CenterSlotDepthMm = 25.40;    // 1.00 pulgada (1") para pistas centrales puras
        public int CenterSlotCount = 2;             // Dos pistas centrales por defecto.

        // Plaquitas de fijación soldadas en extremos (Fase 2)
        public bool IncludeEndPlates = true;        // Generar plaquitas en ambos extremos (Z=0 y Z=L)
        public double EndPlateHoleSizeMm = 11.0;   // Barreno cuadrado estándar 11×11 mm (tornillo coche 3/8")
        public double EndPlateHoleYMm = 12.0;      // Cota vertical centro del barreno (mm)
        public double EndPlateThicknessMm = 2.66;  // Espesor de lámina de la plaquita (mm)

        /// <summary>Calcula la longitud del soporte: AnchoBanda + 20.0 mm según especificación de taller</summary>
        public static double CalculateLengthFromBand(double bandWidthMm)
        {
            return Math.Round(bandWidthMm + 20.0, 2);
        }

        /// <summary>Sugiere la cantidad de pistas centrales de Nylamid según el ancho nominal de la banda.</summary>
        public static int SuggestCenterSlots(double bandWidthMm)
        {
            if (bandWidthMm <= 300) return 1;
            if (bandWidthMm <= 600) return 2;
            if (bandWidthMm <= 900) return 3;
            if (bandWidthMm <= 1200) return 4;
            return 5;
        }

        public static double GaugeThickness(string gauge)
        {
            switch (gauge)
            {
                case "10": return 3.42;
                case "12": return 2.66;
                case "14": return 1.90;
                case "16": return 1.51;
                case "18": return 1.21;
                default: return 2.66;
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // VISTA PREVIA 2D: SECCIÓN TRANSVERSAL DEL CANAL C (ALZADO)
    // ═════════════════════════════════════════════════════════════════════════════
    internal sealed class SoporteCrossSectionPreview : Control
    {
        public SoporteSettings Settings { get; set; }

        public SoporteCrossSectionPreview()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Color.FromArgb(248, 249, 250);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (Settings == null) return;

            int pad = 28;
            float availW = Width - (pad * 2);
            float availH = Height - (pad * 2) - 20;
            if (availW <= 10 || availH <= 10) return;

            // Dimensiones nominales de la sección
            double webW = Math.Max(10.0, Settings.WebWidthMm);
            double f1H  = Math.Max(5.0, Settings.ActualFlange1HeightMm);
            double f2H  = Math.Max(5.0, Settings.ActualFlange2HeightMm);
            double maxH = Math.Max(f1H, f2H);
            double thick = Math.Max(0.5, Settings.ThicknessMm);

            // Escala para ajustar en el viewport
            float scale = (float)Math.Min(availW / (webW + thick * 2 + 30.0), availH / (maxH + thick + 30.0));
            float originX = pad + (availW - (float)webW * scale) / 2f;
            float originY = pad + 15;

            // Dibujar la sección C con espesor
            // Pestaña 1 (izquierda, altura f1H), Lomo (superior, ancho webW), Pestaña 2 (derecha, altura f2H)
            float sWeb = (float)webW * scale;
            float sF1  = (float)f1H * scale;
            float sF2  = (float)f2H * scale;
            float sThick = Math.Max(2f, (float)thick * scale);

            // Trayectoria exterior e interior
            using (var path = new GraphicsPath())
            {
                // Contorno exterior
                path.AddLine(originX, originY + sF1, originX, originY);
                path.AddLine(originX, originY, originX + sWeb, originY);
                path.AddLine(originX + sWeb, originY, originX + sWeb, originY + sF2);
                path.AddLine(originX + sWeb - sThick, originY + sF2, originX + sWeb - sThick, originY + sThick);
                path.AddLine(originX + sWeb - sThick, originY + sThick, originX + sThick, originY + sThick);
                path.AddLine(originX + sThick, originY + sThick, originX + sThick, originY + sF1);
                path.CloseFigure();

                using (var brush = new SolidBrush(Color.FromArgb(220, 230, 242)))
                using (var pen = new Pen(Color.FromArgb(0, 102, 170), 2f))
                {
                    g.FillPath(brush, path);
                    g.DrawPath(pen, path);
                }
            }

            // Si incluye plaquitas de unión en extremos, dibujarla dentro de la sección
            if (Settings.IncludeEndPlates)
            {
                float pTopY = originY + (float)(SoporteSettings.EndPlateTopReliefMm+Settings.EndPlateDropMm) * scale;
                float pX1 = originX + sThick;
                float pX2 = originX + sWeb - sThick;
                float pYBotRight = originY + sF2;
                float pYBotLeft = originY + sF1;

                using (var platePath = new GraphicsPath())
                {
                    platePath.AddLine(pX1, pTopY, pX2, pTopY);
                    platePath.AddLine(pX2, pTopY, pX2, pYBotRight);
                    platePath.AddLine(pX2, pYBotRight, pX1, pYBotLeft);
                    platePath.AddLine(pX1, pYBotLeft, pX1, pTopY);
                    platePath.CloseFigure();

                    using (var plateBrush = new SolidBrush(Color.FromArgb(200, 225, 210)))
                    using (var platePen = new Pen(Color.FromArgb(30, 120, 70), 1.5f))
                    {
                        g.FillPath(plateBrush, platePath);
                        g.DrawPath(platePen, platePath);
                    }
                }

                // Barreno cuadrado 11×11 mm centrado horizontalmente
                float pHoleSz = (float)Settings.EndPlateHoleSizeMm * scale;
                float pHcx = (pX1 + pX2) / 2f;
                // En pantalla Y crece hacia abajo; origen Y=0 del modelo es el fondo de pestaña 1
                float pHcy = originY + sF1 - (float)Settings.EndPlateHoleYMm * scale;

                using (var holeBrush = new SolidBrush(Color.FromArgb(248, 249, 250)))
                using (var holePen = new Pen(Color.FromArgb(40, 50, 60), 1.5f))
                {
                    g.FillRectangle(holeBrush, pHcx - pHoleSz / 2f, pHcy - pHoleSz / 2f, pHoleSz, pHoleSz);
                    g.DrawRectangle(holePen, pHcx - pHoleSz / 2f, pHcy - pHoleSz / 2f, pHoleSz, pHoleSz);
                }
            }

            // Cotas y anotaciones
            using (var dimPen = new Pen(Color.FromArgb(120, 130, 140), 1f) { DashStyle = DashStyle.Dash })
            using (var textBrush = new SolidBrush(Color.FromArgb(40, 50, 60)))
            using (var font = new Font("Segoe UI", 8.5f))
            {
                // Cota lomo superior
                g.DrawLine(dimPen, originX, originY - 10, originX + sWeb, originY - 10);
                string webText = Settings.WebWidthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm (" + (Settings.WebWidthMm / 25.4).ToString("0.##", CultureInfo.InvariantCulture) + "\")";
                SizeF webSz = g.MeasureString(webText, font);
                g.DrawString(webText, font, textBrush, originX + (sWeb - webSz.Width) / 2f, originY - 24);

                // Cota pestaña 1 (izquierda)
                g.DrawLine(dimPen, originX - 10, originY, originX - 10, originY + sF1);
                string f1Text = "Ala 1: " + Settings.ActualFlange1HeightMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm";
                g.DrawString(f1Text, font, textBrush, originX - 15 - g.MeasureString(f1Text, font).Width, originY + (sF1 / 2f) - 7);

                // Cota pestaña 2 (derecha)
                g.DrawLine(dimPen, originX + sWeb + 10, originY, originX + sWeb + 10, originY + sF2);
                string f2Text = "Ala 2: " + Settings.ActualFlange2HeightMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm";
                g.DrawString(f2Text, font, textBrush, originX + sWeb + 15, originY + (sF2 / 2f) - 7);

                // Espesor y calibre
                string infoText = "Calibre: " + Settings.Gauge + "  ·  Espesor: " + Settings.ThicknessMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm" + (Settings.IncludeEndPlates ? "  ·  Placas soldadas: Cuadrado 11×11 mm" : "");
                g.DrawString(infoText, font, Brushes.DimGray, 12, Height - 22);
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // VISTA PREVIA 2D: VISTA LONGITUDINAL DEL SOPORTE Y PEINE DE NYLAMID
    // ═════════════════════════════════════════════════════════════════════════════
    internal sealed class SoporteLongitudinalPreview : Control
    {
        public SoporteSettings Settings { get; set; }

        public SoporteLongitudinalPreview()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            BackColor = Color.FromArgb(248, 249, 250);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (Settings == null) return;

            int padX = 35, padY = 25;
            float availW = Width - (padX * 2);
            float availH = Height - (padY * 2) - 22;
            if (availW <= 20 || availH <= 20) return;

            double totalL = Math.Max(50.0, Settings.LengthMm);
            double f1H    = Math.Max(20.0, Settings.ActualFlange1HeightMm);

            float scale = (float)Math.Min(availW / (totalL * 1.05), availH / (f1H * 2.2));
            float sLength = (float)totalL * scale;
            float sHeight = (float)f1H * scale;

            float originX = padX + (availW - sLength) / 2f;
            float originY = padY + Math.Min(120f, availH * 0.20f);

            // Dibujar el cuerpo principal del canal (vista lateral del ala frontal)
            using (var bodyBrush = new SolidBrush(Color.FromArgb(235, 240, 245)))
            using (var bodyPen = new Pen(Color.FromArgb(0, 102, 170), 1.5f))
            using (var slotBrush = new SolidBrush(Color.FromArgb(255, 255, 255)))
            using (var slotCutPen = new Pen(Color.FromArgb(210, 45, 45), 1.5f))
            using (var dimPen = new Pen(Color.FromArgb(140, 150, 160), 1f) { DashStyle = DashStyle.Dash })
            using (var font = new Font("Segoe UI", 8.0f))
            {
                // Rectángulo base del soporte
                g.FillRectangle(bodyBrush, originX, originY, sLength, sHeight);
                g.DrawRectangle(bodyPen, originX, originY, sLength, sHeight);

                // Si incluye ranuras de Nylamid, dibujarlas recortadas desde el borde superior
                if (Settings.IncludeNylamidSlots)
                {
                    float sSlotW = (float)Settings.SlotWidthMm * scale;
                    float sOuterD = (float)Settings.OuterSlotDepthMm * scale;
                    float sCenterD = (float)Settings.CenterSlotDepthMm * scale;

                    // 1. Ranura extrema izquierda (0 a SlotWidth, profundidad configurable; 19.05 mm estándar)
                    g.FillRectangle(slotBrush, originX, originY, sSlotW, sOuterD);
                    g.DrawRectangle(slotCutPen, originX, originY, sSlotW, sOuterD);
                    // Relleno para abrir el borde superior
                    g.DrawLine(new Pen(Color.White, 2f), originX, originY, originX + sSlotW, originY);

                    // 2. Ranura extrema derecha (Length - SlotWidth a Length, profundidad configurable; 19.05 mm estándar)
                    float rightSlotX = originX + sLength - sSlotW;
                    g.FillRectangle(slotBrush, rightSlotX, originY, sSlotW, sOuterD);
                    g.DrawRectangle(slotCutPen, rightSlotX, originY, sSlotW, sOuterD);
                    g.DrawLine(new Pen(Color.White, 2f), rightSlotX, originY, rightSlotX + sSlotW, originY);

                    // 3. Ranuras centrales (profundidad 25.4 mm)
                    int k = Settings.CenterSlotCount;
                    if (k > 0)
                    {
                        double availDist = Settings.LengthMm - (2.0 * Settings.SlotWidthMm);
                        double step = availDist / (k + 1);

                        for (int i = 1; i <= k; i++)
                        {
                            double centerZ = Settings.SlotWidthMm + (i * step);
                            float cX = originX + (float)(centerZ - Settings.SlotWidthMm / 2.0) * scale;

                            g.FillRectangle(slotBrush, cX, originY, sSlotW, sCenterD);
                            g.DrawRectangle(slotCutPen, cX, originY, sSlotW, sCenterD);
                            g.DrawLine(new Pen(Color.White, 2f), cX, originY, cX + sSlotW, originY);

                            // Línea de centro constructiva
                            g.DrawLine(dimPen, cX + sSlotW / 2f, originY - 6, cX + sSlotW / 2f, originY + sHeight + 6);
                        }
                    }

                }

                // Cota de longitud total
                g.DrawLine(dimPen, originX, originY + sHeight + 14, originX + sLength, originY + sHeight + 14);
                string lenText = "Longitud total: " + Settings.LengthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm";
                SizeF lenSz = g.MeasureString(lenText, font);
                g.DrawString(lenText, font, Brushes.Black, originX + (sLength - lenSz.Width) / 2f, originY + sHeight + 18);

                // Representación de las plaquitas de unión soldadas en ambos extremos
                if (Settings.IncludeEndPlates)
                {
                    float pThick = Math.Max(3f, (float)Settings.EndPlateThicknessMm * scale);
                    float pOuterD = (float)(SoporteSettings.EndPlateTopReliefMm+Settings.EndPlateDropMm) * scale;
                    using (var greenBrush = new SolidBrush(Color.FromArgb(180, 46, 139, 87)))
                    using (var greenPen = new Pen(Color.FromArgb(30, 110, 60), 1.5f))
                    {
                        // Plaquita izquierda en Z=0
                        g.FillRectangle(greenBrush, originX, originY + pOuterD, pThick, sHeight - pOuterD);
                        g.DrawRectangle(greenPen, originX, originY + pOuterD, pThick, sHeight - pOuterD);
                        // Plaquita derecha en Z=L
                        g.FillRectangle(greenBrush, originX + sLength - pThick, originY + pOuterD, pThick, sHeight - pOuterD);
                        g.DrawRectangle(greenPen, originX + sLength - pThick, originY + pOuterD, pThick, sHeight - pOuterD);
                    }
                }

                if (Height > 280)
                {
                    int infoY = Height - 108;
                    using (var rule = new Pen(Color.FromArgb(220, 227, 234)))
                        g.DrawLine(rule, 24, infoY - 14, Width - 24, infoY - 14);
                    string slots = Settings.IncludeNylamidSlots
                        ? "RANURAS  " + (Settings.CenterSlotCount + 2).ToString(CultureInfo.InvariantCulture) + " · ancho " + Settings.SlotWidthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm"
                        : "RANURAS  Desactivadas";
                    TextRenderer.DrawText(g, slots, Font, new Point(24, infoY), Color.FromArgb(160, 50, 50));
                    TextRenderer.DrawText(g, "EXTREMOS  profundidad " + Settings.OuterSlotDepthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm",
                        Font, new Point(24, infoY + 26), Color.FromArgb(41, 55, 72));
                    TextRenderer.DrawText(g, "CENTRALES  profundidad " + Settings.CenterSlotDepthMm.ToString("0.##", CultureInfo.InvariantCulture) + " mm",
                        Font, new Point(24, infoY + 52), Color.FromArgb(41, 55, 72));
                }
                g.DrawString("Rojo: ranuras Nylamid  ·  Verde: placas de unión", font, Brushes.DimGray, 24, Height - 21);
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // VENTANA DEL MÓDULO DE CREACIÓN DE SOPORTES C (SoporteForm)
    // ═════════════════════════════════════════════════════════════════════════════
    internal sealed class SoporteForm : Form
    {
        private readonly SoporteSettings values = new SoporteSettings();
        private readonly ProfileSettings linkedProfile;
        private readonly SoporteCrossSectionPreview crossPreview = new SoporteCrossSectionPreview();
        private readonly SoporteLongitudinalPreview longPreview  = new SoporteLongitudinalPreview();

        // Controles de entrada
        private readonly ComboBox beltModelBox = new ComboBox();
        private readonly ComboBox bandWidthBox = new ComboBox();
        private readonly Label bandInfoLabel   = new Label { AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(0, 0, 0, 8) };

        private readonly NumericUpDown length = Number(540, 50, 4000, 1);
        private readonly Button calcLengthBtn = new Button { Text = "Ajustar a luz (ancho + 19.05 mm)", AutoSize = true, Height = 26, Margin = new Padding(0, 2, 0, 8) };
        private readonly NumericUpDown webWidth = Number(50.80m, 10, 500, 0.01m);
        private readonly NumericUpDown flange1 = Number(38.10m, 10, 500, 0.01m);
        private readonly NumericUpDown flange2 = Number(50.80m, 10, 500, 0.01m);
        private readonly ComboBox gauge = new ComboBox();
        private readonly NumericUpDown thickness = Number(2.66m, 0.5m, 10, 0.01m);
        private readonly NumericUpDown radius = Number(1.50m, 0.1m, 25, 0.01m);

        // Ranuras de Nylamid
        private readonly CheckBox includeSlots = new CheckBox { Text = "Generar ranuras para guías de Nylamid (peine)", Checked = true, AutoSize = true };
        private readonly NumericUpDown slotWidth = Number(20.05m, 19.05m, 100, 0.01m);
        private readonly NumericUpDown outerDepth = Number(19.05m, 2, 100, 0.01m);
        private readonly NumericUpDown centerDepth = Number(25.40m, 2, 100, 0.01m);
        private readonly NumericUpDown centerCount = Number(1, 0, 20, 1);

        // Plaquitas de fijación a laterales (Fase 2)
        private readonly CheckBox includePlates = new CheckBox { Text = "Generar plaquitas de unión en ambos extremos (Z=0 y Z=L)", Checked = true, AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = Color.FromArgb(0, 102, 170) };
        private readonly NumericUpDown plateHoleSize = Number(11.00m, 6, 25, 0.5m);
        private readonly NumericUpDown plateHoleY = Number(12.00m, 0, 50, 0.5m);
        private readonly NumericUpDown plateThick = Number(2.66m, 0.5m, 10, 0.01m);
        private readonly Button exportPlateBtn = new Button { Text = "Exportar placa individual (.SLDPRT)", AutoSize = true, Height = 28, Margin = new Padding(0, 4, 0, 8) };

        private readonly TextBox targetFolderBox = new TextBox { Text = ProjectPaths.GetDefaultPiecesFolder(), Dock = DockStyle.Fill };
        private readonly Label status = new Label { AutoSize = true, ForeColor = Color.DimGray, MaximumSize = new Size(480, 0) };
        private BeltModel[] catalog;

        public SoporteForm(string initBeltModel = "E925", double initBandWidthMm = 520.0, ProfileSettings profileSettings = null)
        {
            linkedProfile = profileSettings;
            Text = "JAC · Soportes C";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(1120, 720);
            Size = new Size(1440, 860);
            BackColor = DesignUi.Canvas;
            Font = new Font("Segoe UI", 10f);

            values.BeltModelName = initBeltModel;
            double initialBw = initBandWidthMm >= 100 ? initBandWidthMm : 520.0;
            values.BandWidthMm = initialBw;
            values.LengthMm = SoporteSettings.CalculateLengthFromBand(initialBw);
            length.Value = (decimal)values.LengthMm;

            gauge.DropDownStyle = ComboBoxStyle.DropDownList;
            gauge.Items.AddRange(new object[] { "10", "12", "14", "16", "18" });
            gauge.SelectedItem = "12"; // Calibre 12 estándar para soportes
            gauge.SelectedIndexChanged += delegate
            {
                thickness.Value = (decimal)SoporteSettings.GaugeThickness(gauge.Text);
                Sync();
            };

            // Catálogo de bandas
            catalog = BeltCatalog.Load(AppDomain.CurrentDomain.BaseDirectory);
            beltModelBox.DropDownStyle = ComboBoxStyle.DropDownList;
            foreach (BeltModel m in catalog) beltModelBox.Items.Add(m);
            if (beltModelBox.Items.Count > 0)
            {
                int matchIdx = 0;
                for (int i = 0; i < beltModelBox.Items.Count; i++)
                {
                    if (beltModelBox.Items[i].ToString() == initBeltModel) { matchIdx = i; break; }
                }
                beltModelBox.SelectedIndex = matchIdx;
            }

            bandWidthBox.DropDownStyle = ComboBoxStyle.DropDownList;
            RebuildWidths(values.BandWidthMm);

            beltModelBox.SelectedIndexChanged += delegate { RebuildWidths(values.BandWidthMm); Sync(); };
            bandWidthBox.SelectedIndexChanged += delegate
            {
                double bw;
                if (double.TryParse(bandWidthBox.Text, out bw))
                {
                    values.BandWidthMm = bw;
                    decimal autoL = (decimal)SoporteSettings.CalculateLengthFromBand(bw);
                    if (autoL >= length.Minimum && autoL <= length.Maximum)
                        length.Value = autoL;
                    bandInfoLabel.Text = "Regla de taller: Ancho " + bw.ToString("0") + " mm + 20 mm = " + autoL.ToString("0.##") + " mm";
                    centerCount.Value = SoporteSettings.SuggestCenterSlots(bw);
                }
                Sync();
            };

            calcLengthBtn.Click += delegate
            {
                double bw;
                if (double.TryParse(bandWidthBox.Text, out bw))
                {
                    decimal calcL = (decimal)SoporteSettings.CalculateLengthFromBand(bw);
                    if (calcL >= length.Minimum && calcL <= length.Maximum)
                        length.Value = calcL;
                }
                Sync();
            };

            includeSlots.CheckedChanged += delegate
            {
                slotWidth.Enabled = includeSlots.Checked;
                outerDepth.Enabled = includeSlots.Checked;
                centerDepth.Enabled = includeSlots.Checked;
                centerCount.Enabled = includeSlots.Checked;
                Sync();
            };

            includePlates.CheckedChanged += delegate
            {
                plateHoleSize.Enabled = includePlates.Checked;
                plateHoleY.Enabled = includePlates.Checked;
                plateThick.Enabled = includePlates.Checked;
                Sync();
            };
            exportPlateBtn.Click += ExportStandalonePlate;

            var categories = new CategoryWorkspace();
            var leftPanel = categories.AddPage("Banda", "Vincula el soporte con el modelo y ancho de banda.");

            // Encabezado decorativo
            var headerTitle = new Label
            {
                Text = "Configurador Paramétrico de Soporte C",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 102, 170),
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 4)
            };
            var headerSub = new Label
            {
                Text = "Canal C inoxidable con peine ranurado para pistas de rodadura Nylamid",
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = Color.DimGray,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 14)
            };
            leftPanel.Controls.Add(headerTitle, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(headerTitle, 2); leftPanel.RowCount++;
            leftPanel.Controls.Add(headerSub, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(headerSub, 2); leftPanel.RowCount++;

            // Sección 1: Vinculación con banda
            Section(leftPanel, "1. Vinculación con Banda Transportadora");
            Row(leftPanel, "Modelo de banda", beltModelBox);
            Row(leftPanel, "Ancho de banda (mm)", bandWidthBox);
            leftPanel.Controls.Add(bandInfoLabel, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(bandInfoLabel, 2); leftPanel.RowCount++;

            leftPanel = categories.AddPage("Geometría", "Define las medidas del canal C de lámina inoxidable.");
            // Sección 2: Dimensiones del perfil C
            Section(leftPanel, "2. Geometría del Canal C (Lámina Inox)");
            Row(leftPanel, "Longitud total (mm)", length);
            leftPanel.Controls.Add(calcLengthBtn, 1, leftPanel.RowCount); leftPanel.RowCount++;
            Row(leftPanel, "Ancho de lomo superior (mm)", webWidth);
            Row(leftPanel, "Altura ala 1 - frontal (mm)", flange1);
            Row(leftPanel, "Altura ala 2 - trasera (mm)", flange2);
            Row(leftPanel, "Calibre de lámina inoxidable", gauge);
            Row(leftPanel, "Espesor asociado (mm)", thickness);
            Row(leftPanel, "Radio interior doblez (mm)", radius);

            leftPanel = categories.AddPage("Peine Nylamid", "Configura las ranuras de las pistas laterales y centrales.");
            // Sección 3: Ranuras de peine Nylamid (siempre pasante de lado a lado)
            Section(leftPanel, "3. Ranurado Superior (Peine pasante para Nylamid)");
            leftPanel.Controls.Add(includeSlots, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(includeSlots, 2); leftPanel.RowCount++;
            Row(leftPanel, "Ancho ranuras (mm)", slotWidth);
            Row(leftPanel, "Prof. extremos lateral (mm)", outerDepth);
            Row(leftPanel, "Prof. pistas centrales (mm)", centerDepth);
            Row(leftPanel, "Cantidad pistas centrales", centerCount);
            var cutNote = new Label { Text = "✓ Las ranuras se cortan atravesando de lado a lado ambas alas del canal C.", Font = new Font("Segoe UI", 8.25f, FontStyle.Italic), ForeColor = Color.FromArgb(0, 102, 170), AutoSize = true, Margin = new Padding(0, 2, 0, 8) };
            leftPanel.Controls.Add(cutNote, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(cutNote, 2); leftPanel.RowCount++;

            leftPanel = categories.AddPage("Plaquitas", "Barrenos y placas de unión en ambos extremos.");
            // Sección 4: Plaquitas de fijación soldadas en ambos extremos
            Section(leftPanel, "4. Plaquitas de Unión a Perfiles Laterales");
            leftPanel.Controls.Add(includePlates, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(includePlates, 2); leftPanel.RowCount++;
            Row(leftPanel, "Barreno cuadrado tornillo (mm)", plateHoleSize);
            Row(leftPanel, "Altura centro barreno Y (mm)", plateHoleY);
            Row(leftPanel, "Espesor de lámina plaquita (mm)", plateThick);
            var plateTip = new Label
            {
                Text = "✓ Barreno 11×11 mm para tornillo de coche 3/8\". Las placas se crean en ambos extremos (Z=0 y Z=L) como sólidos independientes (multibody) soldados al canal C.",
                Font = new Font("Segoe UI", 8.25f, FontStyle.Italic),
                ForeColor = Color.FromArgb(40, 110, 60),
                AutoSize = true,
                Margin = new Padding(0, 2, 0, 4)
            };
            leftPanel.Controls.Add(plateTip, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(plateTip, 2); leftPanel.RowCount++;
            leftPanel.Controls.Add(exportPlateBtn, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(exportPlateBtn, 2); leftPanel.RowCount++;

            leftPanel = categories.AddPage("Generación", "Guarda el soporte o arma la sección completa.");
            // Sección 5: Carpeta de destino para ensamble
            Section(leftPanel, "5. Carpeta de Destino para Ensamble");
            var folderPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoSize = true, Margin = new Padding(0, 0, 0, 6) };
            folderPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            folderPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            var openFolderBtn = new Button { Text = "Abrir carpeta", Dock = DockStyle.Fill, Height = 34 };
            openFolderBtn.Click += delegate { ProjectPaths.OpenFolder(targetFolderBox.Text); };
            var browseFolderBtn = new Button { Text = "Examinar...", Dock = DockStyle.Fill, Height = 34 };
            browseFolderBtn.Click += delegate
            {
                using (var fbd = new FolderBrowserDialog())
                {
                    fbd.SelectedPath = targetFolderBox.Text;
                    if (fbd.ShowDialog() == DialogResult.OK)
                        targetFolderBox.Text = fbd.SelectedPath;
                }
            };
            folderPanel.Controls.Add(targetFolderBox, 0, 0); folderPanel.SetColumnSpan(targetFolderBox, 2);
            folderPanel.Controls.Add(browseFolderBtn, 0, 1);
            folderPanel.Controls.Add(openFolderBtn, 1, 1);
            leftPanel.Controls.Add(folderPanel, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(folderPanel, 2); leftPanel.RowCount++;

            // Botón de generación
            var generateBtn = new Button
            {
                Text = "Generar soporte C",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Height = 42,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(0, 120, 70),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 8, 0, 8)
            };
            generateBtn.Click += GenerateSoporte;
            leftPanel.Controls.Add(generateBtn, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(generateBtn, 2); leftPanel.RowCount++;

            var assembleBtn = new Button
            {
                Text = "Armar ensamble completo",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Height = 44,
                Dock = DockStyle.Fill,
                BackColor = DesignUi.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 2, 0, 8)
            };
            assembleBtn.Click += AssembleAllConveyor;
            leftPanel.Controls.Add(assembleBtn, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(assembleBtn, 2); leftPanel.RowCount++;

            leftPanel.Controls.Add(status, 0, leftPanel.RowCount); leftPanel.SetColumnSpan(status, 2); leftPanel.RowCount++;


            // Una vista amplia a la vez permite leer cotas y detalles del peine.
            var rightPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18), BackColor = DesignUi.Canvas };
            var previewTitle = new Label {
                Text = "Vista previa del soporte C", Dock = DockStyle.Top, Height = 42,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI Semibold", 14f, FontStyle.Bold),
                ForeColor = DesignUi.Ink
            };
            var previewTabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10f), Padding = new Point(16, 7) };
            var crossBox = new TabPage("Sección transversal") { BackColor = Color.White };
            crossPreview.Dock = DockStyle.Fill;
            crossBox.Controls.Add(crossPreview);
            var longBox = new TabPage("Peine longitudinal") { BackColor = Color.White };
            longPreview.Dock = DockStyle.Fill;
            longBox.Controls.Add(longPreview);
            previewTabs.TabPages.AddRange(new TabPage[] { crossBox, longBox });
            categories.PageChanged += delegate(int page) { previewTabs.SelectedIndex = page == 2 ? 1 : 0; };
            rightPanel.Controls.Add(previewTabs);
            rightPanel.Controls.Add(previewTitle);
            Controls.Add(rightPanel);
            Controls.Add(categories);
            DesignUi.StyleInputs(categories);

            // Suscripción de eventos para actualización reactiva
            foreach (Control c in new Control[] { length, webWidth, flange1, flange2, thickness, radius, slotWidth, outerDepth, centerDepth, centerCount, plateHoleSize, plateHoleY, plateThick })
            {
                if (c is NumericUpDown) ((NumericUpDown)c).ValueChanged += delegate { Sync(); };
            }

            Sync();
        }

        private static NumericUpDown Number(decimal value, decimal min, decimal max, decimal increment)
        {
            return new NumericUpDown
            {
                DecimalPlaces = increment < 1 ? 2 : 0,
                Increment = increment,
                Minimum = min,
                Maximum = max,
                Value = value,
                Dock = DockStyle.Fill
            };
        }

        private static void Section(TableLayoutPanel panel, string text)
        {
            var title = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = DesignUi.Primary,
                AutoSize = true,
                Margin = new Padding(0, 12, 0, 4)
            };
            panel.Controls.Add(title, 0, panel.RowCount);
            panel.SetColumnSpan(title, 2);
            panel.RowCount++;
        }

        private static void Row(TableLayoutPanel panel, string label, Control input)
        {
            panel.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Font = new Font("Segoe UI", 9.5f), ForeColor = DesignUi.Ink, Margin = new Padding(0, 5, 6, 5) }, 0, panel.RowCount);
            panel.Controls.Add(input, 1, panel.RowCount);
            panel.RowCount++;
        }

        private void RebuildWidths(double currentVal)
        {
            BeltModel m = beltModelBox.SelectedItem as BeltModel;
            if (m == null) return;
            bandWidthBox.Items.Clear();
            foreach (string w in m.ValidWidths()) bandWidthBox.Items.Add(w);

            int closest = (int)Math.Round(currentVal);
            int idx = bandWidthBox.Items.IndexOf(closest.ToString());
            bandWidthBox.SelectedIndex = idx >= 0 ? idx : 0;
            bandInfoLabel.Text = "Regla de taller: Ancho " + bandWidthBox.Text + " mm + 20 mm = " + (double.Parse(bandWidthBox.Text) + 20.0).ToString("0.##") + " mm";
        }


        private void Sync()
        {
            values.BeltModelName = beltModelBox.Text;
            double bw;
            if (double.TryParse(bandWidthBox.Text, out bw)) values.BandWidthMm = bw;
            values.LengthMm = (double)length.Value;
            values.WebWidthMm = (double)webWidth.Value;
            values.Flange1HeightMm = (double)flange1.Value;
            values.Flange2HeightMm = (double)flange2.Value;
            values.Gauge = gauge.Text;
            values.ThicknessMm = (double)thickness.Value;
            values.BendRadiusMm = (double)radius.Value;

            values.IncludeNylamidSlots = includeSlots.Checked;
            values.SlotWidthMm = (double)slotWidth.Value;
            values.SlotAllowanceMm = values.SlotWidthMm-SlideRailGeometry.WidthMm;
            values.OuterSlotDepthMm = (double)outerDepth.Value;
            values.CenterSlotDepthMm = (double)centerDepth.Value;
            values.CenterSlotCount = (int)centerCount.Value;

            values.IncludeEndPlates = includePlates.Checked;
            values.EndPlateHoleSizeMm = (double)plateHoleSize.Value;
            values.EndPlateHoleYMm = (double)plateHoleY.Value;
            values.EndPlateThicknessMm = (double)plateThick.Value;

            crossPreview.Settings = values; crossPreview.Invalidate();
            longPreview.Settings = values;  longPreview.Invalidate();
            status.Text = "";
        }

        internal SoporteSettings CurrentSettings()
        {
            Sync();
            return values;
        }

        private void GenerateSoporte(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(0, 102, 170);
                status.Text = "Conectando con SOLIDWORKS y generando soporte...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();

                string outputFile = SolidWorksSoporteGenerator.Create(values, folder);
                status.ForeColor = Color.FromArgb(0, 120, 60);
                status.Text = "¡Soporte C creado con éxito!\r\nArchivo: " + outputFile;
                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                status.Text = "ERROR AL GENERAR SOPORTE C:\r\n" + ex.Message;
            }
        }

        private void ExportStandalonePlate(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(0, 102, 170);
                status.Text = "Generando pieza individual de plaquita de unión...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();

                string outputFile = SolidWorksSoporteGenerator.CreateStandalonePlate(values, folder);
                status.ForeColor = Color.FromArgb(0, 120, 60);
                status.Text = "¡Placa individual creada con éxito!\r\nArchivo: " + outputFile;
                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                status.Text = "ERROR AL EXPORTAR PLACA:\r\n" + ex.Message;
            }
        }

        private void AssembleAllConveyor(object sender, EventArgs e)
        {
            try
            {
                Sync();
                status.ForeColor = Color.FromArgb(130, 40, 160);
                status.Text = "Armando ensamblaje con 6 soportes C en SOLIDWORKS...";
                Application.DoEvents();

                string folder = targetFolderBox.Text;
                if (String.IsNullOrWhiteSpace(folder)) folder = ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);

                // Al entrar desde Perfiles, conservar todas las cotas editadas allí,
                // especialmente el paso y el borde de los seis barrenos.
                var pValues = AssemblyProfileSettings();

                string assyPath = SolidWorksEnsambleGenerator.GenerateAssembly(folder, pValues, values);

                status.ForeColor = Color.FromArgb(0, 120, 60);
                status.Text = "¡Ensamblaje completado con éxito!\r\nArchivo: " + assyPath +
                    "\r\n✓ Perfiles laterales LH y RH alineados" +
                    "\r\n✓ 6 soportes C montados" +
                    "\r\n✓ Barrenos 100% concéntricos y alineados en altura.";

                ProjectPaths.OpenFolder(folder);
            }
            catch (Exception ex)
            {
                status.ForeColor = Color.Firebrick;
                status.Text = "ERROR AL ARMAR ENSAMBLAJE:\r\n" + ex.Message;
            }
        }

        private ProfileSettings AssemblyProfileSettings()
        {
            var profile = linkedProfile ?? new ProfileSettings();
            profile.BeltModelName = values.BeltModelName;
            profile.BandWidthMm = values.BandWidthMm;
            return profile;
        }
    }


    // ═════════════════════════════════════════════════════════════════════════════
    // MOTOR GENERADOR DE SOPORTE C EN SOLIDWORKS API
    // ═════════════════════════════════════════════════════════════════════════════
    internal static class SolidWorksSoporteGenerator
    {
        public static string Create(SoporteSettings s, string customFolder = null, string fileStem = null, SldWorks instance = null)
        {
            SettingsValidation.Support(s);
            string stage = "conectar con SOLIDWORKS";
            try
            {
                Type type = Type.GetTypeFromProgID("SldWorks.Application");
                if (type == null) throw new InvalidOperationException("SOLIDWORKS no está instalado o no registró su interfaz COM.");
                SldWorks sw = instance;
                if (sw == null)
                {
                    try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
                    catch { sw = (SldWorks)Activator.CreateInstance(type); }
                }
                if (sw == null) throw new InvalidOperationException("No fue posible obtener la instancia de SOLIDWORKS.");
                sw.Visible = true;

                stage = "localizar la plantilla de pieza";
                string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
                if (String.IsNullOrWhiteSpace(template) || !File.Exists(template))
                    throw new InvalidOperationException("Configura la plantilla predeterminada de pieza en SOLIDWORKS.");

                stage = "crear nuevo documento de pieza";
                ModelDoc2 model = (ModelDoc2)sw.NewDocument(template, 0, 0, 0);
                if (model == null) throw new InvalidOperationException("SOLIDWORKS no pudo crear la pieza nueva.");

                stage = "seleccionar plano Alzado";
                SelectPrimaryReferencePlane(model);

                stage = "dibujar croquis de sección de canal C";
                SketchManager skMgr = model.SketchManager;
                skMgr.InsertSketch(true);
                skMgr.AddToDB = true;

                // Dimensiones en metros para SOLIDWORKS
                double f1 = s.ActualFlange1HeightMm / 1000.0;
                double web = s.WebWidthMm / 1000.0;
                double f2 = s.ActualFlange2HeightMm / 1000.0;
                double len = s.LengthMm / 1000.0;
                double thick = s.ThicknessMm / 1000.0;
                double rad = s.BendRadiusMm / 1000.0;

                // Línea 1: vertical arriba (Pestaña 1)
                skMgr.CreateLine(0, 0, 0, 0, f1, 0);
                // Línea 2: horizontal derecha (Lomo)
                skMgr.CreateLine(0, f1, 0, web, f1, 0);
                // Línea 3: vertical abajo (Pestaña 2)
                skMgr.CreateLine(web, f1, 0, web, f1 - f2, 0);
                skMgr.AddToDB = false;

                stage = "crear Brida base/Pestaña de canal C";
                FeatureManager featMgr = model.FeatureManager;
                CustomBendAllowance allowance = featMgr.CreateCustomBendAllowance();
                allowance.KFactor = s.KFactor;

                dynamic baseData = featMgr.CreateDefinition((int)swFeatureNameID_e.swFmBaseFlange);
                if (baseData == null) throw new InvalidOperationException("CreateDefinition(swFmBaseFlange) devolvió nulo.");

                baseData.Initialize(false, true, allowance, true, 1, true, 0.5, 0.0001, 0.0001);
                baseData.BendRadius = rad;
                baseData.D1EndConditionDistance = len;
                baseData.D1EndConditionType = (int)swEndConditions_e.swEndCondBlind;
                baseData.D1ReverseOffset = false;
                baseData.D2EndConditionDistance = 0.00254;
                baseData.D2EndConditionType = (int)swEndConditions_e.swEndCondBlind;
                baseData.D2ReverseOffset = false;
                baseData.OffsetDirections = 1;
                baseData.ReverseDirection = false;
                baseData.ReverseThickness = false;
                baseData.Thickness = thick;

                Feature baseFeature = featMgr.CreateFeature(baseData);
                if (baseFeature == null) throw new InvalidOperationException("No se pudo crear la Brida base/Pestaña del canal C.");

                model.ClearSelection2(true);
                model.EditRebuild3();

                // Ranuras superiores para Nylamid (peine)
                if (s.IncludeNylamidSlots)
                {
                    stage = "cortar ranuras para Nylamid (peine)";
                    AddNylamidSlots(model, sw, s);
                    model.EditRebuild3();
                }

                // Plaquitas de fijación soldadas en ambos extremos
                if (s.IncludeEndPlates)
                {
                    stage = "generar plaquitas de unión en ambos extremos (Z=0 y Z=L)";
                    AddEndPlates(model, sw, s);
                    model.EditRebuild3();
                }

                // Registrar propiedades personalizadas para trazabilidad y ensamble
                stage = "registrar propiedades personalizadas";
                dynamic cp = ((dynamic)model.Extension).CustomPropertyManager("");
                cp.Add3("PerfilTipo", 30, "Soporte C", 2);
                cp.Add3("Longitud_mm", 30, s.LengthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("AnchoLomo_mm", 30, s.WebWidthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("Pestana1_mm", 30, s.Flange1HeightMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("Pestana2_mm", 30, s.Flange2HeightMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("Calibre", 30, s.Gauge, 2);
                cp.Add3("Espesor_mm", 30, s.ThicknessMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("ModeloBanda", 30, s.BeltModelName, 2);
                cp.Add3("AnchoBanda_mm", 30, s.BandWidthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanurasNylamid", 30, s.IncludeNylamidSlots ? "Si" : "No", 2);
                cp.Add3("RanuraAncho_mm", 30, s.SlotWidthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanurasExtremasProf_mm", 30, s.OuterSlotDepthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanurasCentrales", 30, s.CenterSlotCount.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("RanuraCentralProf_mm", 30, s.CenterSlotDepthMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("PlaquitasUnion", 30, s.IncludeEndPlates ? "Ambos Extremos" : "No", 2);
                cp.Add3("DescensoPlaquita_mm",30,s.EndPlateDropMm.ToString(CultureInfo.InvariantCulture),2);
                cp.Add3("Pestana1_real_mm",30,s.ActualFlange1HeightMm.ToString(CultureInfo.InvariantCulture),2);
                cp.Add3("Pestana2_real_mm",30,s.ActualFlange2HeightMm.ToString(CultureInfo.InvariantCulture),2);
                cp.Add3("BarrenoPlaquita_mm", 30, s.EndPlateHoleSizeMm.ToString(CultureInfo.InvariantCulture), 2);
                cp.Add3("EspesorPlaquita_mm", 30, s.EndPlateThicknessMm.ToString(CultureInfo.InvariantCulture), 2);

                stage = "guardar archivo de pieza .SLDPRT";
                string folder = !String.IsNullOrWhiteSpace(customFolder) ? customFolder : ProjectPaths.GetDefaultPiecesFolder();
                Directory.CreateDirectory(folder);
                string outputPath = Path.Combine(folder, (fileStem ?? "SOPORTE_C") + ".SLDPRT");
                int saveError = model.SaveAs3(outputPath, 0, 2);
                if (saveError != 0 || !File.Exists(outputPath))
                    throw new InvalidOperationException("SOLIDWORKS no guardó el soporte C (código " + saveError + "): " + outputPath);
                return outputPath;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Fallo durante: " + stage + ". " + ex.Message, ex);
            }
        }

        private static void SelectPrimaryReferencePlane(ModelDoc2 model)
        {
            model.ClearSelection2(true);
            PartDoc part = (PartDoc)model;
            string[] planeNames = new string[] { "Plano Alzado", "Front Plane", "Plano frontal", "Plano Frontal", "Alzado" };
            foreach (string p in planeNames)
            {
                try
                {
                    Feature pl = (Feature)part.FeatureByName(p);
                    if (pl != null && pl.Select2(false, 0)) return;
                }
                catch (COMException) { }
            }
            // Fallback por tipo de feature (primer plano del árbol)
            try
            {
                Feature feat = (Feature)part.FirstFeature();
                while (feat != null)
                {
                    if (feat.GetTypeName2() == "RefPlane")
                    {
                        if (feat.Select2(false, 0)) return;
                    }
                    feat = (Feature)feat.GetNextFeature();
                }
            }
            catch (COMException) { }

            throw new InvalidOperationException("No se pudo seleccionar el plano Alzado.");
        }

        private static void SelectLateralReferencePlane(ModelDoc2 model)
        {
            model.ClearSelection2(true);
            PartDoc part = (PartDoc)model;
            string[] planeNames = new string[] { "Vista lateral", "Right Plane", "Plano lateral", "Plano Lateral", "Lateral" };
            foreach (string p in planeNames)
            {
                try
                {
                    Feature pl = (Feature)part.FeatureByName(p);
                    if (pl != null && pl.Select2(false, 0)) return;
                }
                catch (COMException) { }
            }
            // Fallback: el 3er RefPlane estándar de la plantilla de pieza
            try
            {
                Feature feat = (Feature)part.FirstFeature();
                int refPlaneIndex = 0;
                while (feat != null)
                {
                    if (feat.GetTypeName2() == "RefPlane")
                    {
                        refPlaneIndex++;
                        if (refPlaneIndex == 3)
                        {
                            if (feat.Select2(false, 0)) return;
                        }
                    }
                    feat = (Feature)feat.GetNextFeature();
                }
            }
            catch (COMException) { }

            throw new InvalidOperationException("No se pudo seleccionar el plano de Vista lateral (Right Plane).");
        }

        private static void AddNylamidSlots(ModelDoc2 model, SldWorks sw, SoporteSettings s)
        {
            // ═══════════════════════════════════════════════════════════════════════════
            // CORTAR RANURAS SUPERIORES PARA NYLAMID (PEINE)
            //
            // Estrategia estándar de taller (conforme a ARQUITECTURA_ENSAMBLE_Y_SOPORTES.md
            // y macro funcional CORTE RANURA.swp):
            // 1. Obtener el BoundingBox del sólido del canal C para conocer con exactitud
            //    los límites físicos reales (xMin, xMax, yTop, zMin, zMax).
            // 2. Abrir croquis sobre el plano de Vista lateral (plano YZ a X=0).
            // 3. Transformar puntos 3D a coordenadas del croquis mediante ModelToSketchTransform.
            // 4. Dibujar los rectángulos cerrados para cada ranura:
            //    - Ranura extrema izquierda: Z desde zMin hasta zMin + slotW, prof. outerD
            //    - Ranura extrema derecha: Z desde zMax - slotW hasta zMax, prof. outerD
            //    - Ranuras centrales: distribuidas uniformemente, prof. centerD
            //    Cada rectángulo se extiende 5 mm por encima del lomo (yTop + 0.005)
            //    para garantizar una apertura superior limpia y libre de aristas parásitas.
            // 5. Ejecutar FeatureCut4 pasante a través de todo (ThroughAll) de lado a lado
            //    atravesando ambas alas y el lomo del canal C con el croquis activo.
            // ═══════════════════════════════════════════════════════════════════════════

            PartDoc part = (PartDoc)model;
            object[] bodies = (object[])part.GetBodies2((int)swBodyType_e.swSolidBody, true);
            if (bodies == null || bodies.Length == 0)
                throw new InvalidOperationException("No se encontró el sólido del soporte.");

            Body2 body = (Body2)bodies[0];
            double[] bodyBox = (double[])body.GetBodyBox();
            if (bodyBox == null)
                throw new InvalidOperationException("No se pudo obtener el BoundingBox del soporte.");

            double xMin = bodyBox[0];
            double xMax = bodyBox[3];
            double yTop = bodyBox[4]; // Cota superior máxima del lomo
            double zMin = bodyBox[2]; // Inicio longitudinal de la pieza
            double zMax = bodyBox[5]; // Fin longitudinal de la pieza
            double totalLen = zMax - zMin;
            if (totalLen <= 0.001) totalLen = s.LengthMm / 1000.0;

            double slotW   = s.SlotWidthMm       / 1000.0;
            double outerD  = s.OuterSlotDepthMm  / 1000.0;
            double centerD = s.CenterSlotDepthMm / 1000.0;

            // Seleccionar plano de Vista lateral y abrir croquis
            SelectLateralReferencePlane(model);

            SketchManager skMgr = model.SketchManager;
            skMgr.InsertSketch(true);
            Sketch actSketch = (Sketch)skMgr.ActiveSketch;
            if (actSketch == null)
                throw new InvalidOperationException("SolidWorks no dejó un croquis activo en el plano lateral.");

            MathTransform xform = actSketch.ModelToSketchTransform;
            MathUtility mathUtil = (MathUtility)sw.GetMathUtility();

            Func<double, double, double, double[]> toSk = (x, y, z) =>
            {
                MathPoint pt = (MathPoint)mathUtil.CreatePoint(new double[] { x, y, z });
                MathPoint ptSk = (MathPoint)pt.MultiplyTransform(xform);
                return (double[])ptSk.ArrayData;
            };

            skMgr.AddToDB = true;

            Action<double, double, double> drawSlot = (z1, z2, d) =>
            {
                double topY = yTop + 0.005; // 5 mm por encima del lomo para asegurar corte abierto
                double botY = yTop - d;     // Base de la ranura donde reposará el Nylamid

                double[] p1 = toSk(0, topY, z1);
                double[] p2 = toSk(0, topY, z2);
                double[] p3 = toSk(0, botY, z2);
                double[] p4 = toSk(0, botY, z1);

                skMgr.CreateLine(p1[0], p1[1], 0, p2[0], p2[1], 0);
                skMgr.CreateLine(p2[0], p2[1], 0, p3[0], p3[1], 0);
                skMgr.CreateLine(p3[0], p3[1], 0, p4[0], p4[1], 0);
                skMgr.CreateLine(p4[0], p4[1], 0, p1[0], p1[1], 0);
            };

            // 1. Ranura extrema izquierda
            drawSlot(zMin, zMin + slotW, outerD);

            // 2. Ranura extrema derecha
            drawSlot(zMax - slotW, zMax, outerD);

            // 3. Ranuras centrales intermedias
            int k = s.CenterSlotCount;
            if (k > 0)
            {
                double availDist = totalLen - (2.0 * slotW);
                double step = availDist / (k + 1);
                for (int i = 1; i <= k; i++)
                {
                    double cz = zMin + slotW + i * step;
                    drawSlot(cz - slotW / 2.0, cz + slotW / 2.0, centerD);
                }
            }

            skMgr.AddToDB = false;

            // FeatureCut4 pasante a través de todo (ThroughAll)
            FeatureManager featMgr = model.FeatureManager;

            // Intentar corte ThroughAll bidireccional (atraviesa ambas pestañas y el lomo)
            Feature cut = featMgr.FeatureCut4(
                false,                                                      // 0: Sd = false (ambas direcciones)
                false,                                                      // 1: Flip = false
                false,                                                      // 2: Dir = false
                (int)swEndConditions_e.swEndCondThroughAll,                 // 3: T1 = ThroughAll
                (int)swEndConditions_e.swEndCondThroughAll,                 // 4: T2 = ThroughAll
                0.01, 0.01,                                                 // 5-6: D1, D2
                false, false, false, false,                                 // 7-10: Dchk1..Ddir2
                0.0, 0.0,                                                   // 11-12: Dang1, Dang2
                false, false, false, false,                                 // 13-16: OffsetReverse..TranslateSurface
                false,                                                      // 17: NormalCut
                true, true,                                                 // 18-19: UseFeatScope, UseAutoSelect
                true, true, false,                                          // 20-22: AssemblyScope, AutoSelect, Propagate
                (int)swStartConditions_e.swStartSketchPlane,                // 23: T0
                0.0,                                                        // 24: StartOffset
                false,                                                      // 25: FlipStartOffset
                true);                                                      // 26: OptimizeGeometry

            if (cut == null)
            {
                // Fallback 1: Dirección única ThroughAll
                cut = featMgr.FeatureCut4(
                    true, false, false,
                    (int)swEndConditions_e.swEndCondThroughAll,
                    (int)swEndConditions_e.swEndCondBlind,
                    0.01, 0.01,
                    false, false, false, false,
                    0.0, 0.0,
                    false, false, false, false,
                    false, true, true, true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false, true);
            }

            if (cut == null)
            {
                // Fallback 2: Dirección única invertida (Flip = true)
                cut = featMgr.FeatureCut4(
                    true, true, false,
                    (int)swEndConditions_e.swEndCondThroughAll,
                    (int)swEndConditions_e.swEndCondBlind,
                    0.01, 0.01,
                    false, false, false, false,
                    0.0, 0.0,
                    false, false, false, false,
                    false, true, true, true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false, true);
            }

            if (cut == null)
            {
                // Fallback 3: Blind con profundidad mayor al ancho del lomo (span en X * 2)
                double blindDepth = Math.Max(0.1, (xMax - xMin) * 2.0);
                cut = featMgr.FeatureCut4(
                    true, false, false,
                    (int)swEndConditions_e.swEndCondBlind,
                    (int)swEndConditions_e.swEndCondBlind,
                    blindDepth, blindDepth,
                    false, false, false, false,
                    0.0, 0.0,
                    false, false, false, false,
                    false, true, true, true, true, false,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false, true);
            }

            if (cut == null)
            {
                throw new InvalidOperationException("FeatureCut4 devolvió null al cortar las ranuras de Nylamid en el soporte C.");
            }

            try { cut.Name = "Ranuras_Nylamid"; } catch { }
            model.ClearSelection2(true);
        }

        private static void AddEndPlates(ModelDoc2 model, SldWorks sw, SoporteSettings s)
        {
            PartDoc part = (PartDoc)model;
            SketchManager skMgr = model.SketchManager;
            FeatureManager featMgr = model.FeatureManager;

            double f1 = s.Flange1HeightMm / 1000.0;
            double web = s.WebWidthMm / 1000.0;
            double f2 = s.Flange2HeightMm / 1000.0;
            double len = s.LengthMm / 1000.0;
            double thick = s.ThicknessMm / 1000.0;
            double outerD = s.OuterSlotDepthMm / 1000.0;
            double pThick = s.EndPlateThicknessMm / 1000.0;
            double holeSz = s.EndPlateHoleSizeMm / 1000.0;
            double holeY = s.EndPlateHoleYMm / 1000.0;

            // Geometría del perfil de la plaquita (interior del canal C)
            // Despejando la ranura exterior para no interferir con el Nylamid
            double px1 = thick;
            double px2 = web - thick;
            double pyTop = f1 - SoporteSettings.EndPlateTopReliefMm / 1000;
            double pyBotRight = f1 - f2;
            double pyBotLeft = 0.0;

            double hcx = (px1 + px2) / 2.0;
            double hcy = holeY;
            double hhalf = holeSz / 2.0;

            Action drawPlateSketch = () =>
            {
                skMgr.AddToDB = true;
                // Contorno exterior de la plaquita
                skMgr.CreateLine(px1, pyTop, 0, px2, pyTop, 0);
                skMgr.CreateLine(px2, pyTop, 0, px2, pyBotRight, 0);
                skMgr.CreateLine(px2, pyBotRight, 0, px1, pyBotLeft, 0);
                skMgr.CreateLine(px1, pyBotLeft, 0, px1, pyTop, 0);

                // Barreno cuadrado centrado (para tornillo de coche)
                skMgr.CreateLine(hcx - hhalf, hcy - hhalf, 0, hcx + hhalf, hcy - hhalf, 0);
                skMgr.CreateLine(hcx + hhalf, hcy - hhalf, 0, hcx + hhalf, hcy + hhalf, 0);
                skMgr.CreateLine(hcx + hhalf, hcy + hhalf, 0, hcx - hhalf, hcy + hhalf, 0);
                skMgr.CreateLine(hcx - hhalf, hcy + hhalf, 0, hcx - hhalf, hcy - hhalf, 0);
                skMgr.AddToDB = false;
            };

            // 1. Plaquita en extremo izquierdo (Z = 0)
            SelectPrimaryReferencePlane(model);
            skMgr.InsertSketch(true);
            drawPlateSketch();

            // Extrusión hacia adentro (+Z), Merge = false para que sea sólido independiente de soldadura
            Feature plate1 = featMgr.FeatureExtrusion2(
                true, false, false,
                (int)swEndConditions_e.swEndCondBlind, 0,
                pThick, 0.0,
                false, false, false, false,
                0, 0, false, false, false, false,
                false, true, true,
                (int)swStartConditions_e.swStartSketchPlane, 0.0, false);

            if (plate1 == null)
                throw new InvalidOperationException("SOLIDWORKS no creó la plaquita izquierda con barreno.");
            try { plate1.Name = "Placa_Union_Izq"; } catch { }
            model.ClearSelection2(true);
            model.EditRebuild3();

            // 2. Plaquita en extremo derecho (Z = len)
            // Crear plano de referencia a distancia 'len' paralelo al Alzado
            SelectPrimaryReferencePlane(model);
            RefPlane refPlane = (RefPlane)featMgr.InsertRefPlane(8, len, 0, 0, 0, 0);
            if (refPlane == null)
                throw new InvalidOperationException("SOLIDWORKS no creó el plano de la plaquita derecha.");
            if (refPlane != null)
            {
                Feature refPlaneFeat = (Feature)refPlane;
                try { refPlaneFeat.Name = "Plano_Extremo_Der"; } catch { }
                refPlaneFeat.Select2(false, 0);

                skMgr.InsertSketch(true);
                drawPlateSketch();

                // Extrusión hacia adentro (-Z), Flip = true
                Feature plate2 = featMgr.FeatureExtrusion2(
                    true, false, true,
                    (int)swEndConditions_e.swEndCondBlind, 0,
                    pThick, 0.0,
                    false, false, false, false,
                    0, 0, false, false, false, false,
                    false, true, true,
                    (int)swStartConditions_e.swStartSketchPlane, 0.0, false);

                if (plate2 == null)
                {
                    // Fallback si la normal del plano resultante está invertida
                    plate2 = featMgr.FeatureExtrusion2(
                        true, false, false,
                        (int)swEndConditions_e.swEndCondBlind, 0,
                        pThick, 0.0,
                        false, false, false, false,
                        0, 0, false, false, false, false,
                        false, true, true,
                        (int)swStartConditions_e.swStartSketchPlane, 0.0, false);
                }

                if (plate2 == null)
                    throw new InvalidOperationException("SOLIDWORKS no creó la plaquita derecha con barreno.");
                try { plate2.Name = "Placa_Union_Der"; } catch { }
                model.ClearSelection2(true);
                model.EditRebuild3();
            }
        }

        public static string CreateStandalonePlate(SoporteSettings s, string customFolder = null)
        {
            SettingsValidation.Numbers(s,"Plaquita de soporte");
            Type type = Type.GetTypeFromProgID("SldWorks.Application");
            if (type == null) throw new InvalidOperationException("SOLIDWORKS no está instalado o no registró su interfaz COM.");
            SldWorks sw = null;
            try { sw = (SldWorks)Marshal.GetActiveObject("SldWorks.Application"); }
            catch { sw = (SldWorks)Activator.CreateInstance(type); }
            if (sw == null) throw new InvalidOperationException("No fue posible obtener la instancia de SOLIDWORKS.");
            sw.Visible = true;

            string template = sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart);
            if (String.IsNullOrWhiteSpace(template) || !File.Exists(template))
                throw new InvalidOperationException("Configura la plantilla predeterminada de pieza en SOLIDWORKS.");

            ModelDoc2 model = (ModelDoc2)sw.NewDocument(template, 0, 0, 0);
            if (model == null) throw new InvalidOperationException("No se pudo crear la pieza para la plaquita.");

            SelectPrimaryReferencePlane(model);

            double f1 = s.Flange1HeightMm / 1000.0;
            double web = s.WebWidthMm / 1000.0;
            double f2 = s.Flange2HeightMm / 1000.0;
            double thick = s.ThicknessMm / 1000.0;
            double outerD = s.OuterSlotDepthMm / 1000.0;
            double pThick = s.EndPlateThicknessMm / 1000.0;
            double holeSz = s.EndPlateHoleSizeMm / 1000.0;
            double holeY = s.EndPlateHoleYMm / 1000.0;

            double px1 = thick;
            double px2 = web - thick;
            double pyTop = f1 - SoporteSettings.EndPlateTopReliefMm / 1000;
            double pyBotRight = f1 - f2;
            double pyBotLeft = 0.0;

            double hcx = (px1 + px2) / 2.0;
            double hcy = holeY;
            double hhalf = holeSz / 2.0;

            SketchManager skMgr = model.SketchManager;
            skMgr.InsertSketch(true);
            skMgr.AddToDB = true;

            skMgr.CreateLine(px1, pyTop, 0, px2, pyTop, 0);
            skMgr.CreateLine(px2, pyTop, 0, px2, pyBotRight, 0);
            skMgr.CreateLine(px2, pyBotRight, 0, px1, pyBotLeft, 0);
            skMgr.CreateLine(px1, pyBotLeft, 0, px1, pyTop, 0);

            skMgr.CreateLine(hcx - hhalf, hcy - hhalf, 0, hcx + hhalf, hcy - hhalf, 0);
            skMgr.CreateLine(hcx + hhalf, hcy - hhalf, 0, hcx + hhalf, hcy + hhalf, 0);
            skMgr.CreateLine(hcx + hhalf, hcy + hhalf, 0, hcx - hhalf, hcy + hhalf, 0);
            skMgr.CreateLine(hcx - hhalf, hcy + hhalf, 0, hcx - hhalf, hcy - hhalf, 0);
            skMgr.AddToDB = false;

            FeatureManager featMgr = model.FeatureManager;
            Feature plateFeat = featMgr.FeatureExtrusion2(
                true, false, false,
                (int)swEndConditions_e.swEndCondBlind, 0,
                pThick, 0.0,
                false, false, false, false,
                0, 0, false, false, false, false,
                true, true, true,
                (int)swStartConditions_e.swStartSketchPlane, 0.0, false);

            if (plateFeat != null)
            {
                try { plateFeat.Name = "Placa_Union"; } catch { }
            }

            model.ClearSelection2(true);
            model.EditRebuild3();

            dynamic cp = ((dynamic)model.Extension).CustomPropertyManager("");
            cp.Add3("Descripcion", 30, "Plaquita de unión para soporte C a laterales", 2);
            cp.Add3("Barreno_mm", 30, s.EndPlateHoleSizeMm.ToString(CultureInfo.InvariantCulture), 2);
            cp.Add3("Espesor_mm", 30, s.EndPlateThicknessMm.ToString(CultureInfo.InvariantCulture), 2);

            string folder = !String.IsNullOrWhiteSpace(customFolder) ? customFolder : ProjectPaths.GetDefaultPiecesFolder();
            Directory.CreateDirectory(folder);
            string outputPath = Path.Combine(folder, "PLACA_UNION_SOPORTE.SLDPRT");
            int plateSaveError=model.SaveAs3(outputPath, 0, 2);
            if(plateSaveError!=0||!File.Exists(outputPath))throw new InvalidOperationException("No se guardó la plaquita independiente (error "+plateSaveError+").");
            return outputPath;
        }
    }
}



