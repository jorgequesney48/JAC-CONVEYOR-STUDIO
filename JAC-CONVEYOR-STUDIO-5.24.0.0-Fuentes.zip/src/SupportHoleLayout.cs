﻿using System;

namespace PerfilBandas
{
    // Fuente única para los centros de barrenos y las posiciones de los soportes.
    internal static class SupportHoleLayout
    {
        public const int MaximumCount = 32;
        public static void SetElevation(ProfileSettings profile, SoporteSettings support)
        {
            if (profile.AutoSupportHeight) {
                if (profile.BeltThicknessMm <= 0 || Double.IsNaN(profile.BeltThicknessMm) || Double.IsInfinity(profile.BeltThicknessMm))
                    throw new InvalidOperationException("El espesor de la banda debe ser mayor que cero.");
                if (Math.Abs(profile.TopAngleDeg-90) > .01)
                    throw new InvalidOperationException("La nivelación automática de la banda requiere el doblez superior de 90°.");
                profile.SupportHoleYMm = support.ActualFlange1HeightMm-support.EndPlateHoleYMm
                    -support.CenterSlotDepthMm+SlideRailGeometry.HeightMm+profile.BeltThicknessMm+CurveUpperGuideGeometry.BandTopBelowProfileMm;
            } else profile.SupportHoleYMm += support.EndPlateDropMm;
            profile.ResolvedUpperSupportBottomYMm=-profile.SupportHoleYMm-support.EndPlateHoleYMm+Math.Min(0,support.ActualFlange1HeightMm-support.ActualFlange2HeightMm);
        }

        public static double[] CentersMm(ProfileSettings settings)
        {
            if (settings == null) throw new ArgumentNullException("settings");
            SettingsValidation.Numbers(settings,"Perfil");
            if(settings.ResolvedSupportCentersMm!=null){
                var resolved=settings.ResolvedSupportCentersMm;
                if(settings.SupportCount<2||settings.SupportCount>MaximumCount||resolved.Length!=settings.SupportCount)throw new InvalidOperationException("La cantidad de posiciones de soportes no coincide con el tramo.");
                for(int i=0;i<resolved.Length;i++)
                    if(Double.IsNaN(resolved[i])||Double.IsInfinity(resolved[i])||resolved[i]<=settings.SupportHoleSizeMm/2||resolved[i]>=settings.LengthMm-settings.SupportHoleSizeMm/2||(i>0&&resolved[i]-resolved[i-1]<70-1e-7))
                        throw new InvalidOperationException("Los soportes no caben entre los extremos del tramo con el margen indicado.");
                return (double[])resolved.Clone();
            }
            double edge = settings.SupportHoleEdgeMm + settings.SupportHoleSizeMm / 2.0;
            double pitch = settings.SupportHoleSpacingMm;
            double length = settings.LengthMm;
            double radius = settings.SupportHoleSizeMm / 2.0;
            int count = settings.SupportCount;
            if (count < 2 || count > MaximumCount)
                throw new InvalidOperationException("La cantidad de soportes por tramo debe estar entre 2 y 32.");
            int perSide = count / 2;
            const double minimumCenterGapMm = 70.0;
            double halfCenterGap = count%2==0 ? minimumCenterGapMm/2 : minimumCenterGapMm;
            if (length <= 0 || edge <= radius ||
                (perSide > 1 && pitch < minimumCenterGapMm) ||
                edge + (perSide - 1) * pitch + halfCenterGap > length / 2.0)
            {
                double maximum = perSide == 1 ? 0 :
                    (length / 2.0 - edge - halfCenterGap) / (perSide - 1);
                throw new InvalidOperationException(string.Format(
                    "La separación de barrenos ({0:0.##} mm) no cabe en un perfil de {1:0.##} mm. " +
                    "Con {3} soportes, el paso máximo es {2:0.##} mm.",
                    pitch, length, Math.Max(0, maximum), count));
            }
            double[] centers = new double[count];
            if(count%2!=0)centers[count/2]=length/2;
            for (int i = 0; i < perSide; i++)
            {
                centers[i] = edge + i * pitch;
                centers[count - 1 - i] = length - edge - i * pitch;
            }
            return centers;
        }
    }
}
