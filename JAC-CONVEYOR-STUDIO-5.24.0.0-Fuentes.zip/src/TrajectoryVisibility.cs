using System;
using System.Drawing;
using System.Windows.Forms;

namespace PerfilBandas {
    internal static class TrajectoryVisibility {
        internal static Button Create(Action toggle) {
            var button=new RoundedButton{Name="ToggleBeltTrajectory",Width=194,Height=34,Margin=new Padding(0,0,8,5),Font=DesignUi.NavigationBold,Cursor=Cursors.Hand};
            button.Click+=delegate{toggle();};return button;
        }
        internal static void Update(Button button,bool visible) {
            button.Text=visible?"Ocultar trayectoria":"Mostrar trayectoria";
            button.AccessibleName=button.Text;
            button.AccessibleDescription="Mostrar u ocultar la envolvente de la banda para inspeccionar las piezas del ensamble.";
            button.BackColor=visible?DesignUi.Primary:DesignUi.Selection;
            button.ForeColor=visible?Color.White:DesignUi.Primary;
        }
    }
    internal sealed partial class CompleteBeltView {
        Button CreateTrajectoryButton() {
            var button=TrajectoryVisibility.Create(ToggleBeltTrajectory);
            TrajectoryVisibility.Update(button,showBeltTrajectory);return button;
        }
        internal void ToggleBeltTrajectory() {showBeltTrajectory=!showBeltTrajectory;Changed(-1);}
        void SyncTrajectoryButtons() {
            foreach(Control control in Controls.Find("ToggleBeltTrajectory",true)) {
                var button=control as Button;if(button!=null)TrajectoryVisibility.Update(button,showBeltTrajectory);
            }
            if(preview3D!=null&&!preview3D.IsDisposed)preview3D.SetTrajectoryVisibility(showBeltTrajectory);
        }
    }
}
