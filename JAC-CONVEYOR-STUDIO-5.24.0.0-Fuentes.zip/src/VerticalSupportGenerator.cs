using System;
using System.IO;
using System.Globalization;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
namespace PerfilBandas {
    internal static partial class SolidWorksEnsambleGenerator {
        internal static string[] VerticalPaths(string folder,string stem){return new[]{Path.Combine(folder,stem+".SLDASM"),Path.Combine(folder,stem+"_PTR.SLDPRT"),Path.Combine(folder,stem+"_PLACA.SLDPRT"),Path.Combine(folder,stem+"_TAPA.SLDPRT"),Path.Combine(folder,stem+"_BASE.SLDPRT")};}
        static ModelDoc2 VerticalTemplate(SldWorks sw,string asset,string target){
            sw.CloseDoc(Path.GetFileName(target));File.Copy(VerticalSupportLayout.Asset(asset),target,true);int e=0,w=0;
            var m=sw.OpenDoc6(target,1,1,"",ref e,ref w);if(m==null)throw new InvalidOperationException("No se pudo abrir la plantilla de la pata (error "+e+").");return m;
        }
        static void SetLegDimension(ModelDoc2 m,string name,double value){
            var d=m.Parameter(name) as Dimension;if(d==null)throw new InvalidOperationException("Falta la cota "+name+" de la pata.");
            if(d.SetSystemValue3(value,(int)swSetValueInConfiguration_e.swSetValue_InAllConfigurations,null)!=0)throw new InvalidOperationException("No se pudo cambiar "+name+".");
        }
        static void SaveLegPart(ModelDoc2 m){int e=0,w=0;m.EditRebuild3();if(!m.Save3(1,ref e,ref w)||e!=0)throw new InvalidOperationException("No se pudo guardar la pieza de la pata (error "+e+").");}
        static ModelDoc2 NewLegSketch(SldWorks sw){
            var model=(ModelDoc2)sw.NewDocument(sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart),0,0,0);
            if(model==null)throw new InvalidOperationException("No se pudo crear una pieza de la pata.");
            Feature plane=null;foreach(string name in new[]{"Alzado","Front Plane","Plano Alzado","Plano Frontal"}){plane=((PartDoc)model).FeatureByName(name) as Feature;if(plane!=null&&plane.Select2(false,0))break;}
            if(plane==null)throw new InvalidOperationException("No se encontró el plano de la pieza.");model.SketchManager.InsertSketch(true);model.SketchManager.AddToDB=true;return model;
        }
        internal static string GenerateVerticalSupport(SldWorks sw,VerticalSupportSettings settings,double mountYMm,string folder,string stem,string curvePlate=null){return CadReuseSession.Part("Pata_ensamble",new{settings,mountYMm,curvePlate},Path.Combine(folder,stem+".SLDASM"),()=>GenerateVerticalSupportUnique(sw,settings,mountYMm,folder,stem,curvePlate));}
        static string GenerateVerticalSupportUnique(SldWorks sw,VerticalSupportSettings settings,double mountYMm,string folder,string stem,string curvePlate,int onlyPart=0){
            settings.Validate();var paths=VerticalPaths(folder,stem);Directory.CreateDirectory(folder);SolidWorksDocumentSafety.Check(sw,onlyPart==0?paths:new[]{paths[onlyPart]});
            foreach(string p in onlyPart==0?paths:new[]{paths[onlyPart]})sw.CloseDoc(Path.GetFileName(p));
            double side=settings.TubeSideMm,bottom=settings.TubeBottom(mountYMm),length=settings.TubeLength(mountYMm);
            if(length<100)throw new InvalidOperationException("La altura solicitada deja un PTR menor de 100 mm.");
            if(onlyPart==0||onlyPart==1)paths[1]=CadReuseSession.Part("PTR_pata",new{side,length},paths[1],()=>{
            var tube=VerticalTemplate(sw,"Pieza1.SLDPRT",paths[1]);
            SetLegDimension(tube,"D1@Croquis1",side/1000);SetLegDimension(tube,"D2@Croquis1",side/1000);SetLegDimension(tube,"D1@Saliente-Extruir1",length/1000);SaveLegPart(tube);
            var tb=(double[])((Body2)((object[])((PartDoc)tube).GetBodies2(0,true))[0]).GetBodyBox();
            if(Math.Abs((tb[3]-tb[0])*1000-side)>.05||Math.Abs((tb[4]-tb[1])*1000-side)>.05||Math.Abs(tb[5]*1000-length)>.05)throw new InvalidOperationException("El PTR no reconstruyó el tamaño solicitado.");
            bool bevel=false;foreach(Face2 face in (object[])((Body2)((object[])((PartDoc)tube).GetBodies2(0,true))[0]).GetFaces()){
                var surface=(Surface)face.GetSurface();if(!surface.IsPlane())continue;var q=(double[])surface.PlaneParams;
                if(Math.Abs(q[1])<.6||Math.Abs(q[2])<.6)continue;bevel=true;
                if(Math.Abs(bottom+q[5]*1000-settings.EffectiveTubeCenterX-q[4]*1000-settings.BevelIntercept)>.05)
                    throw new InvalidOperationException("El corte de 45° del PTR no coincide con el apoyo de la placa.");
            }
            if(!bevel)throw new InvalidOperationException("Falta el corte de 45° del PTR.");
            sw.CloseDoc(tube.GetTitle());
            });
            if(onlyPart==0||onlyPart==3)paths[3]=CadReuseSession.Part("Tapa_PTR",new{side,settings.CapHoleDiameterMm},paths[3],()=>{
            var cap=NewLegSketch(sw);var capSketch=cap.SketchManager;
            capSketch.CreateCornerRectangle(0,-side/1000,0,side/1000,0,0);capSketch.CreateCircleByRadius(side/2000,-side/2000,0,settings.CapHoleDiameterMm/2000);capSketch.AddToDB=false;
            var capFeature=cap.FeatureManager.FeatureExtrusion2(true,false,false,0,0,VerticalSupportSettings.CapThicknessMm/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
            if(capFeature==null)throw new InvalidOperationException("No se pudo crear la tapa de la pata.");capFeature.Name="Tapa_PTR_Con_Tornillo_Centrado";
            int capErrors=0,capWarnings=0;if(!cap.SaveAs4(paths[3],0,1,ref capErrors,ref capWarnings)||capErrors!=0)throw new InvalidOperationException("No se pudo guardar la tapa de la pata.");sw.CloseDoc(cap.GetTitle());
            });
            int errors=0,warnings=0;
            if(onlyPart==0||onlyPart==2){if(curvePlate!=null)paths[2]=curvePlate;else {
            paths[2]=CadReuseSession.Part("Placa_pata_recta",new{Contorno=settings.PlateContour(),Espesor=VerticalSupportSettings.PlateThicknessMm},paths[2],()=>{
            var plate=NewLegSketch(sw);
            var sketch=plate.SketchManager;var contour=settings.PlateContour();
            for(int i=0;i<contour.Length;i++){var a=contour[i];var b=contour[(i+1)%contour.Length];sketch.CreateLine(a.X/1000,a.Y/1000,0,b.X/1000,b.Y/1000,0);}
            foreach(double u in new[]{-.03175,.03175})sketch.CreateCornerRectangle(u-.0055,-.0055,0,u+.0055,.0055,0);
            sketch.AddToDB=false;
            var feature=plate.FeatureManager.FeatureExtrusion2(true,false,false,0,0,VerticalSupportSettings.PlateThicknessMm/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
            if(feature==null)throw new InvalidOperationException("No se pudo extruir la placa de la pata.");feature.Name="Placa_Fija_45_PTR_"+side.ToString("0.0",CultureInfo.InvariantCulture);
            if(!plate.SaveAs4(paths[2],0,1,ref errors,ref warnings)||errors!=0)throw new InvalidOperationException("No se pudo guardar la placa de la pata.");sw.CloseDoc(plate.GetTitle());
            });
            }
            }
            if(onlyPart==0||onlyPart==4)paths[4]=GenerateLevelingHardware(sw,settings,paths[4]);
            if(onlyPart!=0)return paths[onlyPart];
            var assy=(AssemblyDoc)sw.NewDocument(sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplateAssembly),0,0,0);if(assy==null)throw new InvalidOperationException("No se pudo crear el subensamblaje de la pata.");
            var model=(ModelDoc2)assy;var math=(MathUtility)sw.GetMathUtility();double r=Math.Sqrt(.5);
            string[] names={"PTR","placa superior","tapa inferior","base niveladora"};
            double[][] transforms={
                new[]{0.0,0,1,1,0,0,0,1,0,settings.EffectiveTubeCenterX/1000,bottom/1000,0,1,0,0,0},
                curvePlate!=null?Translation(0,0,0):new[]{0.0,0,1,-r,-r,0,r,-r,0,0,0,0,1,0,0,0},
                new[]{0.0,0,1,1,0,0,0,1,0,(settings.EffectiveTubeCenterX+side/2)/1000,(bottom-VerticalSupportSettings.CapThicknessMm)/1000,-side/2000,1,0,0,0},
                Translation(0,bottom/1000,0)};
            int[] order={1,2,3,4};for(int i=0;i<order.Length;i++){var c=InsertComponentHelper(sw,assy,paths[order[i]],0,0,0);FixPlacedComponent(model,assy,c,math,transforms[i],names[i]);}
            model.EditRebuild3();var props=model.Extension.get_CustomPropertyManager("");props.Add3("PTR_pulgadas",30,settings.TubeSideInches.ToString(CultureInfo.InvariantCulture),2);props.Add3("Altura_banda_mm",30,settings.BeltHeightMm.ToString(CultureInfo.InvariantCulture),2);props.Add3("Largo_PTR_mm",30,length.ToString(CultureInfo.InvariantCulture),2);props.Add3("Placa_superior",30,settings.PlateStyle.ToString(),2);props.Add3("Tornillo_pulgadas",30,settings.ScrewDiameterInches.ToString(CultureInfo.InvariantCulture),2);
            if(!model.SaveAs4(paths[0],0,1,ref errors,ref warnings)||errors!=0)throw new InvalidOperationException("No se pudo guardar el subensamblaje de la pata.");sw.CloseDoc(model.GetTitle());return paths[0];
        }
        internal static string GenerateLevelingHardware(SldWorks sw,VerticalSupportSettings settings,string target){return CadReuseSession.Part("Base_niveladora",new{settings.EffectiveTubeCenterX,settings.ScrewDiameterMm,settings.ScrewLengthMm,settings.NutOuterRadius,settings.NutThicknessMm,settings.CapHoleDiameterMm,settings.FootHoleDiameterMm},target,()=>GenerateLevelingHardwareUnique(sw,settings,target));}
        static void GenerateLevelingHardwareUnique(SldWorks sw,VerticalSupportSettings settings,string target){
            var bodies=new System.Collections.Generic.List<Body2>();
            var math=(MathUtility)sw.GetMathUtility();double diameter=settings.ScrewDiameterMm;
            double[] radii={diameter/2,VerticalSupportSettings.FootDiameterMm/2,settings.NutOuterRadius,settings.NutOuterRadius,settings.NutOuterRadius};
            int[] sides={0,0,6,6,6};double[] starts={-VerticalSupportSettings.FootBelowTubeMm,-VerticalSupportSettings.FootBelowTubeMm,VerticalSupportSettings.LowerNutYMm,-VerticalSupportSettings.CapThicknessMm-settings.NutThicknessMm,0};double[] heights={settings.ScrewLengthMm,4,settings.NutThicknessMm,settings.NutThicknessMm,settings.NutThicknessMm};
            string[] names={"Tornillo_cilindrico_sin_rosca","Arandela_base","Tuerca_inferior_sin_rosca","Tuerca_tapa_inferior_sin_rosca","Tuerca_tapa_superior_sin_rosca"};
            for(int i=0;i<radii.Length;i++){
                var part=NewLegSketch(sw);var sketch=part.SketchManager;double radius=radii[i]/1000;
                if(sides[i]==0)sketch.CreateCircleByRadius(0,0,0,radius);
                else for(int j=0;j<sides[i];j++){double a=2*Math.PI*j/sides[i],b=2*Math.PI*(j+1)/sides[i];sketch.CreateLine(radius*Math.Cos(a),radius*Math.Sin(a),0,radius*Math.Cos(b),radius*Math.Sin(b),0);}
                if(i>0)sketch.CreateCircleByRadius(0,0,0,(i==1?settings.FootHoleDiameterMm:settings.CapHoleDiameterMm)/2000);
                if(i==1)sketch.CreateCircleByRadius(VerticalSupportSettings.FootAuxHoleXMm/1000,-VerticalSupportSettings.FootAuxHoleZMm/1000,0,VerticalSupportSettings.FootAuxHoleDiameterMm/2000);
                sketch.AddToDB=false;
                var feature=part.FeatureManager.FeatureExtrusion2(true,false,false,0,0,heights[i]/1000,0,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
                if(feature==null)throw new InvalidOperationException("No se pudo crear "+names[i]+".");
                var copy=(Body2)((Body2)((object[])((PartDoc)part).GetBodies2(0,true))[0]).Copy();
                var transform=(MathTransform)math.CreateTransform(new[]{1.0,0,0,0,0,-1,0,1,0,settings.EffectiveTubeCenterX/1000,starts[i]/1000,0,1,0,0,0});
                if(!copy.ApplyTransform(transform))throw new InvalidOperationException("No se pudo colocar "+names[i]+".");bodies.Add(copy);sw.CloseDoc(part.GetTitle());
            }
            var model=(ModelDoc2)sw.NewDocument(sw.GetUserPreferenceStringValue((int)swUserPreferenceStringValue_e.swDefaultTemplatePart),0,0,0);
            if(model==null)throw new InvalidOperationException("No se pudo crear la base niveladora.");
            for(int i=0;i<bodies.Count;i++){var f=(Feature)((PartDoc)model).CreateFeatureFromBody3(bodies[i],false,0);if(f==null)throw new InvalidOperationException("No se pudo insertar "+names[i]+".");f.Name=names[i];}
            model.Extension.get_CustomPropertyManager("").Add3("Tornillo_pulgadas",30,settings.ScrewDiameterInches.ToString(CultureInfo.InvariantCulture),2);
            int errors=0,warnings=0;if(!model.SaveAs4(target,0,1,ref errors,ref warnings)||errors!=0)throw new InvalidOperationException("No se pudo guardar la base niveladora.");sw.CloseDoc(model.GetTitle());
        }
    }
}

