using System;
using System.Collections.Generic;
using System.IO;
using SolidWorks.Interop.sldworks;
namespace PerfilBandas {
    internal static class VerticalSupportLayout {
        internal static double BottomHoleFromWebMm(ProfileSettings p) {
            double center=p.BottomFlangeMm-VerticalSupportSettings.PlateFreeEdgeToHoleMm;
            if(p.EndHolesBottom && center<=p.EndHoleSizeMm/2)
                throw new InvalidOperationException("El doblez inferior es demasiado corto para mantener los barrenos de pata a 19.148 mm del borde libre.");
            return center;
        }
        internal static double[] NominalMountMm(ProfileSettings p) {
            double a=(90+p.BottomAngleDeg)*Math.PI/180,d=BottomHoleFromWebMm(p);
            return new[]{d*Math.Cos(a),-p.WebHeightMm+d*Math.Sin(a)};
        }
        // CAD datum on the selected face, measured from its real free edge.
        internal static double[] FaceHoleOrigin(double[] box,ProfileSettings p,bool top) {
            if(top)return new[]{(box[0]+box[3])/2,(box[1]+box[4])/2};
            BottomHoleFromWebMm(p);
            double a=(90+p.BottomAngleDeg)*Math.PI/180,c=Math.Cos(a),s=Math.Sin(a);
            double width=Math.Sqrt(Math.Pow(box[3]-box[0],2)+Math.Pow(box[4]-box[1],2));
            double d=VerticalSupportSettings.PlateFreeEdgeToHoleMm/1000;
            if(width<=d+p.EndHoleSizeMm/2000)
                throw new InvalidOperationException("Los barrenos de pata no caben en la cara plana del doblez inferior con la distancia fija al borde libre.");
            // Use the real face inclination, including the profile's web tilt.
            // RH mirrors the section about X=0; the free edge is farther from the web.
            c=(Math.Abs(box[0])>Math.Abs(box[3])?-1:1)*(box[3]-box[0])/width;
            s=(s<0?-1:1)*(box[4]-box[1])/width;
            return new[]{(c<0?box[0]:box[3])-d*c,(s<0?box[1]:box[4])-d*s};
        }
        internal static bool HasCenter(ProfileSettings p) { return p.EndHolesBottom && (p.CurvedWeldedProfile || p.LengthMm > 2000.0); }
        internal static double[] HoleCenters(ProfileSettings p, bool top) {
            var holes=new List<double>();
            if(top ? !p.EndHolesTop : !p.EndHolesBottom)return holes.ToArray();
            if(p.EndHoleTypeLeft!="ninguno"){holes.Add(p.EndHoleEdgeMm);if(p.EndHoleTypeLeft=="final")holes.Add(p.EndHoleEdgeMm+p.EndHoleSpacingMm);}
            if(!top && HasCenter(p)){holes.Add(p.LengthMm/2-p.EndHoleSpacingMm/2);holes.Add(p.LengthMm/2+p.EndHoleSpacingMm/2);}
            if(p.EndHoleTypeRight!="ninguno"){if(p.EndHoleTypeRight=="final")holes.Add(p.LengthMm-p.EndHoleEdgeMm-p.EndHoleSpacingMm);holes.Add(p.LengthMm-p.EndHoleEdgeMm);}
            return holes.ToArray();
        }
        internal static string Asset(string name) {
            string root=AppDomain.CurrentDomain.BaseDirectory;
            foreach(string dir in new[]{root,Path.GetFullPath(Path.Combine(root,".."))}){
                string path=Path.Combine(dir,"assets","vertical_support",name);if(File.Exists(path))return path;
            }
            throw new FileNotFoundException("Falta la geometría del soporte vertical: "+name);
        }
        internal static double[] Placement(bool right,double x,double y,double z) {
            double sign=right?-1:1;
            return new[]{sign,0,0,0,1,0,0,0,sign,x,y,z,1,0,0,0};
        }
        internal static double[] Stations(IList<BeltSectionSpec> sections,ProfileSettings template) {
            var result=new List<double>();double offset=0;
            for(int i=0;i<sections.Count;i++){
                if(sections[i].IsCurved){offset+=sections[i].Curve.CenterLengthMm((sections[i].Profile??template).BandWidthMm);continue;}
                var p=BeltLinePlan.ProfileFor(sections,i,template);
                foreach(double station in LocalStations(p,i,sections.Count))result.Add(offset+station);
                offset+=p.LengthMm;
            }
            return result.ToArray();
        }
        internal static double[] LocalStations(ProfileSettings p,int index,int count) {
            var result=new List<double>();
            if(p.EndHolesBottom&&p.EndHoleTypeLeft=="final")result.Add(p.EndHoleEdgeMm+p.EndHoleSpacingMm/2);
            if(HasCenter(p))result.Add(p.LengthMm/2);
            if(p.EndHolesBottom&&p.EndHoleTypeRight!="ninguno")result.Add(p.EndHoleTypeRight=="final"?p.LengthMm-p.EndHoleEdgeMm-p.EndHoleSpacingMm/2:p.LengthMm);
            return result.ToArray();
        }
        internal static void Validate(IList<BeltSectionSpec> sections,ProfileSettings template) {
            for(int i=0;i<sections.Count;i++){
                if(sections[i].IsCurved)continue;
                var p=BeltLinePlan.ProfileFor(sections,i,template);
                if(Math.Abs(p.BottomAngleDeg-135)>.01 || Math.Abs(p.EndHoleSizeMm-11)>.01 || Math.Abs(p.EndHoleSpacingMm-63.5)>.01 || Math.Abs(p.EndHoleEdgeMm-31.75)>.01)
                    throw new InvalidOperationException("La pata MK2 requiere doblez inferior de 45°, cuadrados de 11 mm, paso de 63.5 mm y centro extremo a 31.75 mm (tramo "+(i+1)+").");
            }
        }
        internal static double[] MountOrigin(ModelDoc2 model,ProfileSettings p) {
            var cutFace=SolidWorksProfileGenerator.FindFlangeFace(model,p,false);
            if(cutFace==null)throw new InvalidOperationException("No se encontró la cara de montaje de la pata.");
            var box=(double[])cutFace.GetBox();var selected=(double[])((Surface)cutFace.GetSurface()).PlaneParams;
            var origin=FaceHoleOrigin(box,p,false);double x=origin[0],y=origin[1];
            double lowest=Double.PositiveInfinity;double[] plane=null;
            foreach(Body2 body in (object[])((PartDoc)model).GetBodies2(0,true))foreach(Face2 face in (object[])body.GetFaces()){
                var s=(Surface)face.GetSurface();if(!s.IsPlane())continue;var q=(double[])s.PlaneParams;
                if(Math.Abs(q[0]*selected[0]+q[1]*selected[1]+q[2]*selected[2])<.9999)continue;
                var b=(double[])face.GetBox();if(b[5]-b[2]<p.LengthMm/1000*.85)continue;
                double cy=(b[1]+b[4])/2;if(cy<lowest){lowest=cy;plane=q;}
            }
            if(plane==null)throw new InvalidOperationException("No se encontró la cara inferior del doblez para la pata.");
            // Project the hole datum onto the lower face, so the plate seats beneath the sheet.
            double distance=(x-plane[3])*plane[0]+(y-plane[4])*plane[1];
            return new[]{x-distance*plane[0],y-distance*plane[1]};
        }
    }
}
