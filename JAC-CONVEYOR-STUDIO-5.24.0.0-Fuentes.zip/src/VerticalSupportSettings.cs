using System;
using System.Drawing;
namespace PerfilBandas {
    internal enum VerticalPlateStyle { Fixed45, Articulated, Curve }
    internal sealed class VerticalSupportSettings {
        public double TubeSideInches=1.5;
        public bool CrossbarEnabled=true;
        public double CrossbarHeightInches=10;
        public double CrossbarHeightMm {get{return CrossbarHeightInches*25.4;}}
        public double BeltHeightMm=1300;
        public double ScrewDiameterInches=0.5;
        public double PlateCornerRadiusMm=2;
        public double ScrewLengthMm=100,NutAcrossFlatsMm,NutThicknessMm=10;
        public string NutReference="";
        public double NutAcrossFlats {get{return NutAcrossFlatsMm>0?NutAcrossFlatsMm:ScrewDiameterMm*1.5;}}
        public double NutOuterRadius {get{return NutAcrossFlats/2/Math.Cos(Math.PI/6);}}
        public VerticalPlateStyle PlateStyle=VerticalPlateStyle.Fixed45;
        public VerticalSupportSettings Copy(){return (VerticalSupportSettings)MemberwiseClone();}
        public double TubeSideMm {get{return TubeSideInches*25.4;}}
        public double ScrewDiameterMm {get{return ScrewDiameterInches*25.4;}}
        public double CapHoleDiameterMm {get{return ScrewDiameterMm+.762;}}
        public double FootHoleDiameterMm {get{return Math.Max(19.05,CapHoleDiameterMm);}}
        // Dimensions and installed orientation measured from the original leveling plate.
        public const double FootDiameterMm=88.9,FootThicknessMm=4,FootAuxHoleDiameterMm=7.9375;
        public const double FootAuxHoleXMm=8.20577970337912,FootAuxHoleZMm=30.6712842812233;
        public const double PlateThicknessMm=3.175,CapThicknessMm=1.5875,CapHoleMm=13.462;
        // Hole axis to the straight outer shoulder of the fixed 45-degree plate.
        public const double PlateFreeEdgeToHoleMm=19.147992436803;
        public const double PlateWebEdgeToHoleMm=19.147992436803;
        // Extend the default flange to fit the unmodified bolt area of the plate.
        public const double DefaultBottomFlangeMm=PlateFreeEdgeToHoleMm+PlateWebEdgeToHoleMm;
        public const double TubeCenterX=-10.066541276906;
        public const double FootBelowTubeMm=51.5875;
        public const double LowerNutYMm=-FootBelowTubeMm+FootThicknessMm;
        public void Validate(){
            if(Double.IsNaN(CrossbarHeightInches)||Double.IsInfinity(CrossbarHeightInches)||CrossbarHeightInches<=0||CrossbarHeightInches>120)throw new InvalidOperationException("La altura del travesaño H debe ser mayor que cero y no superar 120 pulgadas.");
            if(Double.IsNaN(ScrewLengthMm)||Double.IsInfinity(ScrewLengthMm)||ScrewLengthMm<FootBelowTubeMm+NutThicknessMm+ScrewDiameterMm||ScrewLengthMm>300)throw new InvalidOperationException("El tornillo debe atravesar la tuerca superior y conservar al menos un diámetro de saliente; largo máximo 300 mm.");
            if(Double.IsNaN(NutThicknessMm)||Double.IsInfinity(NutThicknessMm)||NutThicknessMm<5||NutThicknessMm>30||Double.IsNaN(NutAcrossFlatsMm)||Double.IsInfinity(NutAcrossFlatsMm)||NutAcrossFlatsMm<0||NutAcrossFlats<=CapHoleDiameterMm)throw new InvalidOperationException("Revisa espesor y ancho entre caras de la tuerca.");
            if(Double.IsNaN(PlateCornerRadiusMm)||Double.IsInfinity(PlateCornerRadiusMm)||PlateCornerRadiusMm<0||PlateCornerRadiusMm>3)throw new InvalidOperationException("El radio exterior de placa debe estar entre 0 y 3 mm.");
            if(Double.IsNaN(ScrewDiameterInches)||Double.IsInfinity(ScrewDiameterInches)||ScrewDiameterInches<0.5||ScrewDiameterInches>1)throw new InvalidOperationException("El diámetro del tornillo debe estar entre ½ y 1 pulgada.");
            if(Double.IsNaN(BeltHeightMm)||Double.IsInfinity(BeltHeightMm)||BeltHeightMm<450||BeltHeightMm>3000)throw new InvalidOperationException("La altura de banda debe estar entre 450 y 3000 mm.");
            if(TubeSideInches!=1.5 && TubeSideInches!=2)throw new InvalidOperationException("Selecciona PTR de 1½ o 2 pulgadas.");
            if(2*NutOuterRadius>TubeSideMm-6)throw new InvalidOperationException("La tuerca superior no cabe dentro del PTR seleccionado. Para este diámetro de tornillo selecciona PTR de 2 pulgadas o verifica el ancho real de la tuerca.");
            if(PlateStyle==VerticalPlateStyle.Articulated)throw new InvalidOperationException("Las placas articuladas y de curva requieren su geometría; por ahora está disponible la placa fija de 45°.");
        }
        public double TubeBottom(double mountYMm){return -BeltHeightMm-CurveUpperGuideGeometry.BandTopBelowProfileMm-mountYMm+FootBelowTubeMm;}
        public double EffectiveTubeCenterX {get{return PlateStyle==VerticalPlateStyle.Curve?CurvePlateReference.TubeCenterX:TubeCenterX;}}
        public double BevelIntercept {get{return PlateStyle==VerticalPlateStyle.Curve?CurvePlateReference.BevelInterceptMm:-Math.Sqrt(2)*PlateThicknessMm;}}
        public double TubeTop {get{return EffectiveTubeCenterX+TubeSideMm/2+BevelIntercept;}}
        public double TubeLength(double mountYMm){return TubeTop-TubeBottom(mountYMm);}
        public PointF[] PlateContour(){
            // Original plate contour: preserve the bolt area and the PTR tongue.
            double half=TubeSideMm/2,wall=3,wide=(TubeSideMm+50.8)/2;
            double top=44.352007563197+(TubeSideMm-38.1)/Math.Sqrt(2),shoulder=top-wall*Math.Sqrt(2);
            var polygon=new[]{new PointF((float)(-half+wall),(float)top),new PointF((float)(half-wall),(float)top),new PointF((float)half,(float)shoulder),new PointF((float)wide,19.147992f),new PointF((float)wide,-13.147992f),new PointF((float)(wide-6),-19.147992f),new PointF((float)(-wide+6),-19.147992f),new PointF((float)-wide,-13.147992f),new PointF((float)-wide,19.147992f),new PointF((float)-half,(float)shoulder)};
            if(PlateCornerRadiusMm==0)return polygon;
            var result=new System.Collections.Generic.List<PointF>();
            for(int i=0;i<polygon.Length;i++){if(i<4||i>7){result.Add(polygon[i]);continue;}var a=polygon[(i+polygon.Length-1)%polygon.Length];var b=polygon[i];var c=polygon[(i+1)%polygon.Length];double ax=a.X-b.X,ay=a.Y-b.Y,cx=c.X-b.X,cy=c.Y-b.Y,al=Math.Sqrt(ax*ax+ay*ay),cl=Math.Sqrt(cx*cx+cy*cy);ax/=al;ay/=al;cx/=cl;cy/=cl;double angle=Math.Acos(Math.Max(-1,Math.Min(1,ax*cx+ay*cy))),distance=Math.Min(PlateCornerRadiusMm/Math.Tan(angle/2),Math.Min(al,cl)*.4),radius=distance*Math.Tan(angle/2),bis=Math.Sqrt((ax+cx)*(ax+cx)+(ay+cy)*(ay+cy)),centerX=b.X+(ax+cx)/bis*radius/Math.Sin(angle/2),centerY=b.Y+(ay+cy)/bis*radius/Math.Sin(angle/2);double start=Math.Atan2(b.Y+ay*distance-centerY,b.X+ax*distance-centerX),end=Math.Atan2(b.Y+cy*distance-centerY,b.X+cx*distance-centerX),sweep=end-start;while(sweep>Math.PI)sweep-=2*Math.PI;while(sweep<-Math.PI)sweep+=2*Math.PI;for(int j=0;j<=6;j++){double theta=start+sweep*j/6;result.Add(new PointF((float)(centerX+radius*Math.Cos(theta)),(float)(centerY+radius*Math.Sin(theta))));}}
            return result.ToArray();
        }
    }
}
