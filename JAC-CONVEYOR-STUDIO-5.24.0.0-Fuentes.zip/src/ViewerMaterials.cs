﻿using System;
using System.Drawing;

namespace PerfilBandas {
    internal enum BeltSurface3D { StainlessSteel, Nylamid, Bearing }
    internal static class ViewerMaterials {
        internal static readonly string[] NylamidNames={"Blanco","Negro","Azul","Verde","Amarillo","Rojo","Natural"};
        internal static readonly Color Stainless=Color.FromArgb(208,211,215);
        internal static Color Nylamid(string name){
            switch(name){
                case "Blanco":return Color.FromArgb(250,250,248);
                case "Negro":return Color.FromArgb(39,41,44);
                case "Azul":return Color.FromArgb(36,112,205);
                case "Verde":return Color.FromArgb(40,146,99);
                case "Amarillo":return Color.FromArgb(245,205,62);
                case "Rojo":return Color.FromArgb(215,61,59);
                case "Natural":return Color.FromArgb(232,223,190);
                default:throw new ArgumentException("Color de Nylamid no admitido.");
            }
        }
    }
}
