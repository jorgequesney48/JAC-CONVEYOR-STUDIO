using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
[assembly: AssemblyFileVersion("5.3.0.0")]
internal static class LaunchJAC
{
    [STAThread] static void Main()
    {
        try
        {
            string app=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"outputs","PerfilBandas.exe");
            if(!File.Exists(app))app=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"PerfilBandas.exe");
            if(String.Equals(app,Process.GetCurrentProcess().MainModule.FileName,StringComparison.OrdinalIgnoreCase))throw new FileNotFoundException("No se encontró la aplicación principal en outputs.");
            if(!File.Exists(app))throw new FileNotFoundException("No se encontró la aplicación actualizada en outputs.",app);
            Process.Start(new ProcessStartInfo(app){WorkingDirectory=Path.GetDirectoryName(app),UseShellExecute=true});
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"JAC · Inicio",MessageBoxButtons.OK,MessageBoxIcon.Error);}
    }
}
