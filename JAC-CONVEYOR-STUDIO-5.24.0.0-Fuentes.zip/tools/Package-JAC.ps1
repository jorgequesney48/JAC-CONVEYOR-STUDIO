$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$version=[Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $root 'outputs\PerfilBandas.exe')).FileVersion
$release=Join-Path $root ('release\JAC-Conveyor-Studio-'+$version+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $release -Force | Out-Null
foreach($name in @('PerfilBandas.exe','SolidWorks.Interop.sldworks.dll','SolidWorks.Interop.swconst.dll','band_catalog.json')){Copy-Item -LiteralPath (Join-Path $root ('outputs\'+$name)) -Destination $release}
Copy-Item -LiteralPath (Join-Path $root 'assets') -Destination $release -Recurse
$pieces=Join-Path $release 'piezas_ensamble';New-Item -ItemType Directory -Path $pieces | Out-Null
foreach($name in @('CATALOGO_CHUMACERAS','CATALOGO_SPROCKETS')){Copy-Item -LiteralPath (Join-Path $root ('piezas_ensamble\'+$name)) -Destination $pieces -Recurse}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Install-JAC.ps1') -Destination (Join-Path $release 'Instalar.ps1')
@'
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar.ps1"
pause
'@ | Set-Content -LiteralPath (Join-Path $release 'INSTALAR.cmd') -Encoding ASCII
@'
JAC Conveyor Studio - Visor GPU

Extrae todo el ZIP. Ejecuta INSTALAR.cmd para instalar por usuario, sin privilegios de administrador, y crear accesos directos. También puedes abrir PerfilBandas.exe directamente desde la carpeta extraída.

Windows 10/11 con .NET Framework 4.8 recomendado. El visor usa automáticamente el controlador OpenGL de la tarjeta gráfica elegida por Windows (NVIDIA, AMD o Intel). No incluye ni modifica controladores. Si la aceleración no está disponible, utiliza el renderizador CPU. En equipos con varias GPU, Windows > Configuración > Pantalla > Gráficos permite asignar alto rendimiento al ejecutable instalado.

Vista > Diagnóstico de rendimiento muestra la GPU activa, MSAA, sincronización y tiempo de cuadro. Vista > Alternar GPU / CPU permite probar ambos modos; un proyecto puede conservar la preferencia CPU guardada previamente.

El visor y configurador no necesitan iniciar SolidWorks. Generar piezas y ensambles CAD sí requiere una instalación compatible de SolidWorks. Las DLL de interoperabilidad incluidas no sustituyen SolidWorks.

Para actualizar, guarda y cierra JAC y vuelve a ejecutar el instalador. Conserva tus proyectos y catálogos existentes. Prueba otra ubicación con Instalar.ps1 -InstallDirectory "ruta" -NoShortcuts.
'@ | Set-Content -LiteralPath (Join-Path $release 'LEEME.txt') -Encoding UTF8
$zip=$release+'.zip'
Compress-Archive -LiteralPath $release -DestinationPath $zip
Write-Output $release
Write-Output $zip
