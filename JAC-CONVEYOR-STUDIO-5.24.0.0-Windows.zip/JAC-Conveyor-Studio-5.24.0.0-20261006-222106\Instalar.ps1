param([string]$InstallDirectory=(Join-Path $env:LOCALAPPDATA 'Programs\JAC Conveyor Studio'),[switch]$NoShortcuts)
$ErrorActionPreference='Stop'
$destination=[IO.Path]::GetFullPath($InstallDirectory)
if($destination -eq [IO.Path]::GetPathRoot($destination)){throw 'Selecciona una carpeta de aplicación, no la raíz del disco.'}
foreach($process in Get-Process PerfilBandas -ErrorAction SilentlyContinue){if($process.Path -eq (Join-Path $destination 'PerfilBandas.exe')){throw 'Guarda tu proyecto y cierra JAC antes de actualizar esta instalación.'}}
New-Item -ItemType Directory -Force -Path $destination | Out-Null
foreach($name in @('PerfilBandas.exe','SolidWorks.Interop.sldworks.dll','SolidWorks.Interop.swconst.dll','LEEME.txt')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $destination -Force}
if(!(Test-Path -LiteralPath (Join-Path $destination 'band_catalog.json'))){Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'band_catalog.json') -Destination $destination}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'assets') -Destination $destination -Recurse -Force
# Existing catalogues and personal projects belong to the user and survive upgrades.
$pieces=Join-Path $destination 'piezas_ensamble';New-Item -ItemType Directory -Force -Path $pieces | Out-Null
foreach($name in @('CATALOGO_CHUMACERAS','CATALOGO_SPROCKETS')){if(!(Test-Path -LiteralPath (Join-Path $pieces $name))){Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('piezas_ensamble\'+$name)) -Destination $pieces -Recurse}}
if(!$NoShortcuts){$shell=New-Object -ComObject WScript.Shell;foreach($folder in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$shortcut=$shell.CreateShortcut((Join-Path $folder 'JAC Conveyor Studio.lnk'));$shortcut.TargetPath=Join-Path $destination 'PerfilBandas.exe';$shortcut.WorkingDirectory=$destination;$shortcut.Save()}}
Write-Output ('Instalado en '+$destination)
Write-Output 'Abre JAC Conveyor Studio. La GPU se detecta automáticamente; Vista > Diagnóstico de rendimiento muestra el adaptador activo.'
