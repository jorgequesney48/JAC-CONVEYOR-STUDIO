# Referencia E925 Flush Grid para curvas

Fuente conservada: E925_FlushGrid_curvas.pdf, EUROBELT, V.1 04/2021. Números de página según el archivo de 12 páginas. Se verificaron visualmente las páginas 2, 3, 6, 7, 8 y 9. Las reglas legibles por la aplicación están en E925_curvas_criterios.json.

## Corrección posterior: tabla completa del usuario (2026-10-06)

Para el cálculo actual se usa E925_tabla_completa_usuario.png, con factores por intervalos confirmados por el usuario. La tabla de cuatro filas y la política de no calcular otros anchos que se describen abajo documentan la versión anterior del PDF; quedan sustituidas para el cálculo por ancho × factor del intervalo. Los factores completos son 1.27, 1.60, 1.68, 1.73, 1.82, 1.84, 1.88, 1.88 y 1.92 desde los límites 100, 200, 300, 400, 500, 600, 720, 800 y 1000 mm respectivamente. Corrección adicional: E925 sólo admite múltiplos de 20 mm; 525 mm no es un ancho disponible. Para 520 mm el mínimo es 946.4 mm. Ver auditoria/2026-10-06/RADIOS_Y_CNC_CURVAS.md para diferencias entre radios impresos y calculados y desarrollos CNC.

## Radios y trazado del PDF original (referencia histórica)

Página 3: tabla completa disponible en este PDF:

| Ancho nominal mm | Factor impreso | Radio mínimo impreso mm |
| --- | --- | --- |
| 100 | 1.27 | 127 |
| 200 | 1.60 | 320 |
| 300 | 1.66 | 500 |
| 400 | 1.72 | 690 |

Se conserva el radio impreso: 300 × 1.66 = 498, pero la tabla indica 500; 400 × 1.72 = 688, pero indica 690. No interpolar ni extrapolar factores para otros anchos sin otra referencia del fabricante. La referencia al borde interior se interpreta del croquis de página 9; el texto de la tabla no declara expresamente el origen radial. El ancho nominal con lengüeta corresponde a la superficie útil, excluyendo las lengüetas.

Página 9: rectos inicial y final de al menos 1.5 × ancho nominal; recto entre curvas opuestas de al menos 2 × ancho; curvas consecutivas en el mismo sentido no requieren ese mínimo intermedio. La longitud total utiliza la longitud exterior de las curvas. El PDF no fija un ángulo máximo de giro: un límite de interfaz no debe presentarse como regla del manual.

## Banda, apoyos y sujeción

Página 2: variantes CL40 con lengüeta y SL40 sin lengüeta; paso 25 mm, ancho en múltiplos de 20 mm, varilla de 6 mm, área abierta del 42 %. La resistencia admisible en tramo curvo requiere consulta, no se deduce de la resistencia del tramo recto.

Página 8: pletinas planas mínimas en carga: 1 para 100–260 mm; 3 para 280–660; 5 para 680–1060; 7 para 1080–1300. El peso del producto también interviene. Distancia entre apoyos máxima de 150 mm en carga y 300 mm en retorno. El párrafo se refiere a perfiles y pletinas: no asumir que establece el paso longitudinal de los travesaños. Revisar los espacios transversales realmente libres y el dibujo de instalación antes de declarar conformidad.

Página 6: perfiles comerciales L de 40 × 20 × 2000 mm y U de 20 × 14 × 2000 mm, de polietileno; pletinas planas de 6 × 32 × 500 mm, juntas de 3–5 mm en ambiente normal y tornillos plásticos M6 × 25. Estas geometrías difieren de las pletinas actuales del proyecto. La instrucción del usuario es reutilizar las actuales; no reemplazarlas silenciosamente por las comerciales del PDF.

Página 7: retención superior para SL40, con cota indicada menor que 30 mm; retención sobre la lengüeta para CL40, con cota indicada menor que 25 mm. Los elementos de sujeción no deben estar en contacto con la banda. Estas cotas son las dibujadas; no asumir que representan holgura vertical. Para manipulación sobre la curva se recomienda protección del radio interior y exterior.

## Decisiones confirmadas por el usuario

Curvas sin rodillos; alma con la misma altura que los rectos; cejas independientes soldadas a 90°, sin dobleces de chapa. Soportes y pletinas superiores; soportes inferiores en el mismo sentido que los superiores con dos pletinas laterales y una central. Patas y su nuevo anclaje quedan para la última fase; barrenos definidos: par central y uno por extremo de unión curva-curva; no reutilizar automáticamente la placa recta de 45° en las curvas.

## Datos que necesitan cautela

El PDF sólo confirma cuatro anchos en la tabla de radios. El ancho de 525 mm de proyectos anteriores no es múltiplo de 20 y no tiene fila de radio en este PDF.

La página 4 imprime Ø primitivo Z12 = 96.59 mm; la página 9 imprime 98.56 mm. Mantener la tabla de engranajes existente basada en página 4 y registrar la diferencia. La tabla máxima de engranajes de página 8 tiene una fila impresa 470–780; no reinterpretarla como 740–780 sin confirmación.

No se deducen de este catálogo espesores de acero, tamaño de cordones, patrón de uniones soldadas ni geometría del futuro anclaje de patas. Los parámetros del taller se conservan por separado.


